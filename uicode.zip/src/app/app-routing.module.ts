/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth-guard';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/my-tasks' },
  { path: 'my-tasks', loadChildren: () => import('./pages/my-tasks/my-tasks.module').then((m) => m.MyTasksModule) },
  {
    path: 'tasks',
    loadChildren: () => import('./pages/task-list/task-list.module').then((m) => m.TaskListModule),
  },
  {
    path: 'modeler',
    loadChildren: () => import('./pages/modeler/modeler.module').then((m) => m.ModelerModule),
  },
  { path: 'users', loadChildren: () => import('./pages/users/users.module').then((m) => m.UsersModule) },
  { path: 'groups', loadChildren: () => import('./pages/groups/groups.module').then((m) => m.GroupsModule) },
  {
    path: 'projects',
    loadChildren: () => import('./pages/projects/projects.module').then((m) => m.ProjectsModule),
  },
  { path: 'roles', loadChildren: () => import('./pages/roles/roles.module').then((m) => m.RolesModule) },
  {
    path: 'workflow-definitions',
    loadChildren: () => import('./pages/workflow-definitions/workflow-definitions.module').then((m) => m.WorkflowDefinitionsModule),
  },
  {
    path: 'obsoleted-projects/:id',
    loadChildren: () => import('./pages/projects/project-detail/project-detail.module').then((m) => m.ProjectDetailModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'organization-settings',
    loadChildren: () => import('./pages/organization-settings/organization-settings.module').then((m) => m.OrganizationSettingsModule),
  },
  { path: '**', redirectTo: '/my-tasks' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      scrollPositionRestoration: 'enabled',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
