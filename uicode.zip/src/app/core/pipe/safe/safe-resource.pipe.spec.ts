import { async, inject, TestBed } from '@angular/core/testing';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { SafeResourcePipe } from './safe-resource.pipe';

describe('SafeResourcePipe', () => {
  let pipe: SafeResourcePipe;

  beforeEach(async(() => {
    TestBed.configureTestingModule({ imports: [BrowserModule] });
  }));

  beforeEach(inject([DomSanitizer], (sanitizer: DomSanitizer) => {
    pipe = new SafeResourcePipe(sanitizer);
  }));

  it('should create an instance', () => {
    expect(pipe).toBeTruthy();
  });
});
