import { ItemizedTooltipType, WorkflowItemizedTooltipPipe } from './workflow-itemized-tooltip.pipe';

describe('WorkflowItemizedTooltipPipe', () => {
  let pipe: WorkflowItemizedTooltipPipe;

  beforeEach(() => {
    pipe = new WorkflowItemizedTooltipPipe();
  });

  it('should create', () => {
    expect(pipe).toBeTruthy();
  });

  describe('given zero-length array', () => {
    it(`should transform to "0" when ${ItemizedTooltipType.CountOnly}`, () => {
      expect(pipe.transform([], ItemizedTooltipType.CountOnly)).toBe('0');
    });

    it(`should transform to null when ${ItemizedTooltipType.FirstItemThenRemainingCount}`, () => {
      expect(pipe.transform([], ItemizedTooltipType.FirstItemThenRemainingCount)).toBeNull();
    });

    it('should throw error when invalid type', () => {
      expect(() => {
        pipe.transform([], ('nonexistent' as unknown) as ItemizedTooltipType);
      }).toThrowError('Unsupported type given.');
    });
  });

  describe('given string array', () => {
    it(`should transform one value when ${ItemizedTooltipType.CountOnly}`, () => {
      expect(pipe.transform(['Item A'], ItemizedTooltipType.CountOnly)).toBe('1');
    });

    it(`should transform one value when ${ItemizedTooltipType.FirstItemThenRemainingCount}`, () => {
      expect(pipe.transform(['Item A'], ItemizedTooltipType.FirstItemThenRemainingCount)).toBe('Item A');
    });

    it(`should transform multiple values when ${ItemizedTooltipType.CountOnly}`, () => {
      expect(pipe.transform(['Item A', 'Item B', 'Item C'], ItemizedTooltipType.CountOnly)).toBe('3');
    });

    it(`should transform multiple values when ${ItemizedTooltipType.FirstItemThenRemainingCount}`, () => {
      expect(pipe.transform(['Item A', 'Item B', 'Item C'], ItemizedTooltipType.FirstItemThenRemainingCount)).toBe('Item A, +2');
    });
  });

  describe('given object array', () => {
    const KEY = 'name';

    it(`should transform one value when ${ItemizedTooltipType.CountOnly}`, () => {
      expect(pipe.transform([{ name: 'Item A' }], ItemizedTooltipType.CountOnly, KEY)).toBe('1');
    });

    it(`should transform one value when ${ItemizedTooltipType.FirstItemThenRemainingCount}`, () => {
      expect(pipe.transform([{ name: 'Item A' }], ItemizedTooltipType.FirstItemThenRemainingCount, KEY)).toBe('Item A');
    });

    it(`should transform multiple values when ${ItemizedTooltipType.CountOnly}`, () => {
      expect(
        pipe.transform([{ name: 'Item A' }, { name: 'Item B' }, { name: 'Item C' }, { name: 'Item D' }], ItemizedTooltipType.CountOnly, KEY)
      ).toBe('4');
    });

    it(`should transform multiple values when ${ItemizedTooltipType.FirstItemThenRemainingCount}`, () => {
      expect(
        pipe.transform(
          [{ name: 'Item A' }, { name: 'Item B' }, { name: 'Item C' }, { name: 'Item D' }],
          ItemizedTooltipType.FirstItemThenRemainingCount,
          KEY
        )
      ).toBe('Item A, +3');
    });
  });
});
