import { Pipe, PipeTransform } from '@angular/core';

const UNSUPPORTED_TYPE = new Error('Unsupported type given.');
type ItemizedRecord = Record<string, unknown> | string;

export enum ItemizedTooltipType {
  FirstItemThenRemainingCount,
  CountOnly,
}

/**
 * Pipe to transform arrays of objects into an itemized string.
 */
@Pipe({ name: 'workflowItemizedTooltip' })
export class WorkflowItemizedTooltipPipe implements PipeTransform {
  private static getTransformForZeroLengthValue(type: ItemizedTooltipType): string {
    switch (type) {
      case ItemizedTooltipType.FirstItemThenRemainingCount:
        return null;
      case ItemizedTooltipType.CountOnly:
        return '0';
      default:
        throw UNSUPPORTED_TYPE;
    }
  }

  private static getTransformForNonzeroLengthValue(value: ItemizedRecord[], type: ItemizedTooltipType, key?: string): string {
    switch (type) {
      case ItemizedTooltipType.FirstItemThenRemainingCount: {
        const first = value[0];
        return typeof first === 'string'
          ? WorkflowItemizedTooltipPipe.itemizeValue(first, value)
          : WorkflowItemizedTooltipPipe.itemizeValue(first[key], value);
      }
      case ItemizedTooltipType.CountOnly:
        return value.length.toString();
      default:
        throw UNSUPPORTED_TYPE;
    }
  }

  private static itemizeValue(firstItem: unknown, value: ItemizedRecord[]): string {
    return firstItem.toString() + (value.length <= 1 ? '' : ', +' + (value.length - 1));
  }

  /**
   * Transforms the given value into an itemized string based on the given type.
   *
   * Examples:
   * <ul>
   *   <li>
   *     If type is {@link ItemizedTooltipType.FirstItemThenRemainingCount} and value is <code>['Item A', 'Item B', 'Item C']</code>
   *     (key not needed for string arrays), then output is <code>'Item A, +2'</code>.
   *   </li>
   *   <li>
   *     If type is {@link ItemizedTooltipType.FirstItemThenRemainingCount}, value is <code>[{ name: 'Item A' }]</code>,
   *     and key is <code>'name'</code> then output is <code>'Item A'</code>.
   *   </li>
   *   <li>
   *     If type is {@link ItemizedTooltipType.CountOnly} and value is <code>['Item A', 'Item B']</code>, then output is <code>'2'</code>.
   *   </li>
   * </ul>
   *
   * @param value The value to transform.
   * @param type The type to transform to.
   * @param key The key to read from, if the value is a {@link Record} array.
   *
   * @return The transformed string.
   */
  transform(value: ItemizedRecord[], type: ItemizedTooltipType, key?: string): string {
    if (!value) {
      return null;
    }

    return value.length === 0
      ? WorkflowItemizedTooltipPipe.getTransformForZeroLengthValue(type)
      : WorkflowItemizedTooltipPipe.getTransformForNonzeroLengthValue(value, type, key);
  }
}
