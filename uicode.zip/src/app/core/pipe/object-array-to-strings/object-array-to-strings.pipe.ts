import { Pipe, PipeTransform } from '@angular/core';
import _ from 'lodash';
/*
 * Transform an Array of objects into an Array of a key value
 * and convert the array of a key value into a string list separated by a specific separator
 * Usage:
 *   value | ObjectArrayToStrings:key:separator
 * Example:
 *   {{ [{name:"person1", active:true}, {name:"person2", active:true}] | ObjectArrayToStrings:"name","," }}
 *   formats to: person1, person2
 */

@Pipe({ name: 'objectArrayToStrings' })
export class ObjectArrayToStringsPipe implements PipeTransform {
  transform(input: Record<string, unknown>[], key: string, separator: string = ', '): string {
    return _.map(input, key).join(separator);
  }
}
