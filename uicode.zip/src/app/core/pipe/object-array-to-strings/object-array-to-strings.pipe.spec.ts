import { ObjectArrayToStringsPipe } from './object-array-to-strings.pipe';

describe('ObjectArrayToStringsPipe', () => {
  let pipe: ObjectArrayToStringsPipe;
  const VALUE = [
    { name: 'person1', active: true },
    { name: 'person2', active: true },
  ];
  const KEY = 'name';
  const SEPARATOR = '.';

  beforeEach(() => {
    pipe = new ObjectArrayToStringsPipe();
  });

  it('should create', () => {
    expect(pipe).toBeTruthy();
  });

  it('should transform array value to blank when array with 0 items is given as a value ', () => {
    expect(pipe.transform([], KEY, SEPARATOR)).toBe('');
  });

  it('should transform array value to a string given a specific key and an empty string as a separator ', () => {
    expect(pipe.transform(VALUE, KEY, '')).toBe('person1person2');
  });

  it('should transform array value to a string list given a specific key', () => {
    expect(pipe.transform(VALUE, KEY)).toBe('person1, person2');
  });

  it('should transform array value to a string list given a specific key and a characther as a separator', () => {
    expect(pipe.transform(VALUE, KEY, SEPARATOR)).toBe('person1.person2');
  });

  it('should transform array value to a string list given a specific key and a space as a separator', () => {
    expect(pipe.transform(VALUE, KEY, ' ')).toBe('person1 person2');
  });

  it('should default to the separator when the given key doesnt exist', () => {
    expect(pipe.transform(VALUE, 'age', SEPARATOR)).toBe(SEPARATOR);
  });

  it('should default to an empty string when the value is undefined', () => {
    expect(pipe.transform(undefined, KEY, SEPARATOR)).toBe('');
  });

  it('should default to the value when the key is undefined', () => {
    expect(pipe.transform(VALUE, undefined, SEPARATOR)).toBe('[object Object].[object Object]');
  });
});
