import { CamundaVariablePipe } from './camunda-variable.pipe';

describe('CamundaVariablePipe', () => {
  const TF_EXECUTION_TIME_HOURS_RAW = 'tf_executionTimeHours';
  const EXPECTED_EXECUTION_TIME_HOURS = ' execution time hours';

  let pipe: CamundaVariablePipe;

  beforeEach(() => {
    pipe = new CamundaVariablePipe();
  });

  it('should reformat the variable name for readability', () => {
    expect(pipe.transform(TF_EXECUTION_TIME_HOURS_RAW)).toBe(EXPECTED_EXECUTION_TIME_HOURS);
  });
});
