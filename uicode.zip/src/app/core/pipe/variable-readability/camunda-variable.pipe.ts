import { Pipe, PipeTransform } from '@angular/core';
import { CamundaServerVariable } from '../../../pages/shared/camunda-variable';

@Pipe({ name: 'camundaVariable' })
export class CamundaVariablePipe implements PipeTransform {
  transform(value: string): string {
    for (const camundaServerVariable of Object.values(CamundaServerVariable)) {
      if (value.indexOf(camundaServerVariable) > -1) {
        let displayValue = '';
        const array = camundaServerVariable.replace('tf_', '').split(/(?=[A-Z])/);
        for (const word of array) {
          displayValue += ` ${word.toLowerCase()}`;
        }
        value = value.replace(camundaServerVariable, displayValue);
      }
    }
    return value;
  }
}
