import { WorkflowDatePipe } from './workflow-date.pipe';

describe('WorkflowDatePipe', () => {
  const DATE_WITHOUT_Z = '2020-02-11T11:00:00';
  const EXPECTED_DATE_OUTPUT = '2/11/2020, 6:00:00 AM';
  const LOCALE = 'en-US';
  const TIME_ZONE = 'America/New_York';

  let pipe: WorkflowDatePipe;

  beforeEach(() => {
    pipe = new WorkflowDatePipe();
  });

  it('should transform the date string without a Z', () => {
    expect(pipe.transform(DATE_WITHOUT_Z).toLocaleString(LOCALE, { timeZone: TIME_ZONE })).toBe(EXPECTED_DATE_OUTPUT);
  });

  it('should transform the date string with a Z', () => {
    expect(pipe.transform(DATE_WITHOUT_Z + 'Z').toLocaleString(LOCALE, { timeZone: TIME_ZONE })).toBe(EXPECTED_DATE_OUTPUT);
  });

  it('should not transform the date when no date was given', () => {
    expect(pipe.transform(null)).toBeNull();
  });
});
