import { Pipe, PipeTransform } from '@angular/core';

/**
 * Pipes an ISO string that is missing the trailing &quot;Z&quot; to a {@link Date}.
 */
@Pipe({ name: 'workflowDate' })
export class WorkflowDatePipe implements PipeTransform {
  transform(value: string): Date {
    if (!value) {
      return null;
    }

    return new Date(value.endsWith('Z') ? value : value + 'Z');
  }
}
