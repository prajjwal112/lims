import { NgModule } from '@angular/core';
import { WorkflowDatePipe } from './date/workflow-date.pipe';
import { SafeResourcePipe } from './safe/safe-resource.pipe';
import { CamundaVariablePipe } from './variable-readability/camunda-variable.pipe';
import { WorkflowItemizedTooltipPipe } from './itemized-tooltip/workflow-itemized-tooltip.pipe';
import { ObjectArrayToStringsPipe } from './object-array-to-strings/object-array-to-strings.pipe';

@NgModule({
  declarations: [WorkflowDatePipe, SafeResourcePipe, CamundaVariablePipe, WorkflowItemizedTooltipPipe, ObjectArrayToStringsPipe],
  exports: [WorkflowDatePipe, SafeResourcePipe, CamundaVariablePipe, WorkflowItemizedTooltipPipe, ObjectArrayToStringsPipe],
})
export class WorkflowPipeModule {}
