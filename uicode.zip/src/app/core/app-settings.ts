export const DATE_DISPLAY_FORMAT = 'MMM d, y h:mm a';
export const DATE_INPUT_FORMAT = 'MM/dd/yyyy';
export const DATE_API_FORMAT = 'YYYY-MM-DD';
export const TIME_INPUT_FORMAT = 'hh:mm a';
export const TIME_API_FORMAT = 'HH:mm';

export type IsoDate = string;
export type Integer = number;
