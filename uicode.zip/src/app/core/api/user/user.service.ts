import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import type {
  UserFilter,
  UserFilterRequest,
  UserFilterResponse,
  UserFilterItemResponse,
  UserFilterItem,
} from '../../../pages/users/shared/user';

const URL = `${environment.endpoint}/users`;

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient) {}

  fetchUser(id: number): Observable<UserFilterItem> {
    return this.http.get<UserFilterItemResponse>(`${URL}/${encodeURIComponent(id)}`).pipe(
      catchError((error: HttpErrorResponse) => throwError(error)),
      map((response: UserFilterItemResponse) => ({
        ...response,
        fullName: `${response.firstName} ${response.lastName}`,
      }))
    );
  }

  filter(requestData: UserFilterRequest = {}): Observable<UserFilter> {
    return this.http.post<UserFilterResponse>(`${URL}/filter`, requestData).pipe(
      catchError((error: HttpErrorResponse) => throwError(error)),
      map((response: UserFilterResponse) => ({
        ...response,
        items: response.items.map((item: UserFilterItemResponse) => ({ ...item, fullName: `${item.firstName} ${item.lastName}` })),
      }))
    );
  }
}
