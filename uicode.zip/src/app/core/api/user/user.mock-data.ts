export const ITEMS = [
  {
    id: 1,
    firstName: 'User',
    lastName: 'One',

    email: 'user.one@company.com',
    active: true,
    admin: false,
    roles: [],
    projects: [],
    groups: [],
  },
];
