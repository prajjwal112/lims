import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { UserService } from './user.service';
import { ITEMS } from './user.mock-data';
import { environment } from 'src/environments/environment';
import type { UserFilter, UserFilterResponse, UserFilterItemResponse, UserFilterItem } from '../../../pages/users/shared/user';

describe('User Service', () => {
  let httpTestingController: HttpTestingController;
  let userService: UserService;
  const URL = `${environment.endpoint}/users`;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UserService],
    });

    httpTestingController = TestBed.inject(HttpTestingController);
    userService = TestBed.inject(UserService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should return expected user (called once)', () => {
    const mockUser: UserFilterItemResponse = ITEMS[0];
    userService.fetchUser(1).subscribe({
      next: (response: UserFilterItem) => {
        expect(response).toEqual(
          {
            ...mockUser,
            fullName: `${mockUser.firstName} ${mockUser.lastName}`,
          } as UserFilterItem,
          'should return expected user'
        );
      },
    });
    const req = httpTestingController.expectOne(`${URL}/${encodeURIComponent(mockUser.id)}`);

    expect(req.request.method).toEqual('GET');
    req.flush(mockUser);
  });

  it('should return expected users (called once)', () => {
    const mockUsers: UserFilterResponse = {
      count: 1,
      items: ITEMS,
    };
    userService.filter().subscribe({
      next: (response: UserFilter) => {
        expect(response).toEqual(
          {
            count: 1,
            items: [{ ...mockUsers.items[0], fullName: `${mockUsers.items[0].firstName} ${mockUsers.items[0].lastName}` }],
          },
          'should return expected users'
        );
      },
    });
    const req = httpTestingController.expectOne(`${URL}/filter`);

    expect(req.request.method).toEqual('POST');
    req.flush(mockUsers);
  });
});
