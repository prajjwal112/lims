import { TaskFilterItemResponse, TaskFilterRequest, TaskFilterResponse } from 'src/app/pages/task-list/shared/task-filter';
import { Status } from '../../../pages/shared/status';
import { ITEMS } from '../user/user.mock-data';

export const TASK: TaskFilterItemResponse = {
  projects: [{ id: 1, name: 'project 1' }],
  description: '',
  workflowName: '',
  priority: 1,
  dueDate: '',
  name: '',
  id: '1',
  startTime: '',
  endTime: '',
  status: Status.Pending,
  staleDate: '',
  referenceId: 1,
  assignees: ITEMS,
  groupAssignees: [],
  runName: '',
};

export const TASK_REQUEST: TaskFilterRequest = {
  taskDefinitionId: '1',
  top: 10,
  skip: 5,
};

export const TASK_RESPONSE: TaskFilterResponse = {
  items: [TASK],
  count: 1,
};
