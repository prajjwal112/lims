import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Action, ActionType, StoreService } from '../../../store.service';
import { AssigneeUtility } from '../../../pages/shared/utility/assignee-utility';
import { DefaultAssignmentTab } from '../../../pages/workflow-definitions/default-assignment/default-assignment';
import type {
  ActionItemRequest,
  TaskFilterResponse,
  TaskFilterRequest,
  TaskFilterItemResponse,
} from '../../../pages/task-list/shared/task-filter';
import type { TaskStartResponse } from '../../../pages/task-list/shared/task';
import type { TaskDetail } from '../../../pages/shared/task-detail';
import type { TaskActionVariable } from '../../../pages/modeler/task-configuration/task-action/task-template';
import type { DefaultAssignmentItems } from '../../../pages/workflow-definitions/default-assignment/default-assignment';

const URL = `${environment.endpoint}/tasks`;
const FILTER_URL = `${URL}/filter`;
const DETAIL_ENDPOINT = 'detail';
const START_ENDPOINT = 'start';
const COMPLETE_ENDPOINT = 'complete';

@Injectable({
  providedIn: 'root',
})
export class TaskService {
  #taskDetail: TaskDetail;

  constructor(private http: HttpClient, private store: StoreService) {
    this.store.select('taskDetailData').subscribe({
      next: (data: TaskDetail) => {
        if (data) {
          this.#taskDetail = data;
        }
      },
    });
  }

  public static buildAssigneeRequest(event: DefaultAssignmentItems, selectedItems: number[]): Omit<ActionItemRequest, 'taskInstanceIds'> {
    const request = {
      assignedUserIds: [],
      assignedGroupIds: [],
    };
    if (event.tab === DefaultAssignmentTab.Group) {
      request.assignedGroupIds = selectedItems;
    } else {
      request.assignedUserIds = selectedItems;
    }
    return request;
  }

  private static remapFilterResponse(response: TaskFilterResponse): TaskFilterResponse {
    return {
      ...response,
      items: response.items.map(TaskService.remapFilterItem),
    };
  }

  private static remapFilterItem(response: TaskFilterItemResponse): TaskFilterItemResponse {
    return {
      ...response,
      allAssigneeNames: AssigneeUtility.buildAssigneeNames({ groupAssignees: response.groupAssignees, assignees: response.assignees }),
    };
  }

  /**
   * Get filtered tasks.
   * @param {TaskFilterRequest} request
   * @returns {Observable<TaskFilterResponse>}
   */
  filter(request: TaskFilterRequest): Observable<TaskFilterResponse> {
    return this.http.post<TaskFilterResponse>(FILTER_URL, request).pipe(
      catchError((error: HttpErrorResponse) => throwError(error)),
      map(TaskService.remapFilterResponse)
    );
  }

  getTaskDetail(taskInstanceReferenceId: number): Observable<TaskDetail> {
    return this.http.get<TaskDetail>(`${URL}/${taskInstanceReferenceId}/${DETAIL_ENDPOINT}`).pipe(
      catchError((error: HttpErrorResponse) => throwError(error)),
      tap({
        next: (taskDetail: TaskDetail) => {
          this.store.dispatch(new Action(ActionType.Update, { taskDetailData: taskDetail }));
        },
      })
    );
  }

  updateTaskActionItems(actionItemRequest: ActionItemRequest): Observable<void> {
    return this.http.patch<void>(URL, actionItemRequest);
  }

  startTask(taskInstanceReferenceId: number): Observable<TaskStartResponse> {
    return this.http.post<TaskStartResponse>(`${URL}/${taskInstanceReferenceId}/${START_ENDPOINT}`, null);
  }

  getStartTaskEligibility(taskInstanceReferenceId: number): Observable<void> {
    return this.http.head<void>(`${URL}/${taskInstanceReferenceId}/${START_ENDPOINT}`);
  }

  completeTask(taskInstanceReferenceId: number, taskType: string, variables: TaskActionVariable[]): Observable<TaskActionVariable[]> {
    return this.http.post<TaskActionVariable[]>(`${URL}/${taskInstanceReferenceId}/${COMPLETE_ENDPOINT}`, {
      taskType: taskType,
      variables: variables,
    });
  }

  saveTaskVariables(taskInstanceReferenceId: number, variables: TaskActionVariable[]): Observable<TaskActionVariable[]> {
    return this.http.post<TaskActionVariable[]>(`${URL}/${taskInstanceReferenceId}/variables/task`, { variables });
  }
}
