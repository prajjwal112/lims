import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TaskService } from './task.service';
import { environment } from 'src/environments/environment';
import { TaskFilterResponse } from 'src/app/pages/task-list/shared/task-filter';
import { TASK_REQUEST, TASK_RESPONSE } from './task.mock-data';

const URL = `${environment.endpoint}/tasks`;
const FILTER_URL = `${URL}/filter`;

describe('Task Service', () => {
  let httpTestingController: HttpTestingController;
  let taskService: TaskService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TaskService],
    });

    httpTestingController = TestBed.inject(HttpTestingController);
    taskService = TestBed.inject(TaskService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should return expected tasks', () => {
    const mockData: TaskFilterResponse = TASK_RESPONSE;
    taskService.filter(TASK_REQUEST).subscribe({
      next: (response: TaskFilterResponse) => {
        expect(response).toEqual(
          {
            ...mockData,
            items: [
              {
                ...mockData.items[0],
                allAssigneeNames: `${mockData.items[0].assignees[0].firstName} ${mockData.items[0].assignees[0].lastName}`,
              },
            ],
          },
          'should return expected tasks'
        );
      },
    });
    const req = httpTestingController.expectOne(FILTER_URL);

    expect(req.request.body).toEqual(TASK_REQUEST);
    expect(req.request.method).toEqual('POST');
    req.flush(mockData);
  });
});
