import { Injectable } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { UserService } from '../../../core/api/user/user.service';
import { GroupService } from '../group/group.service';
import type { UserFilterItem, UserFilter, UserFilterItemResponse } from '../../../pages/users/shared/user';
import type { Group, GroupResponse } from '../../../pages/groups/shared/group';
import type { DefaultAssignmentResponse } from '../../../pages/workflow-definitions/default-assignment/default-assignment';
import type { IdNamePair } from '../../../pages/shared/id-name-pair';
import type { TaskFilterItemResponse } from '../../../pages/task-list/shared/task-filter';

export interface Assignee {
  id: string;
  name: string;
  category: 'Group' | 'User';
}

type UserAssigneeType = UserFilterItemResponse | UserFilterItem;

@Injectable({
  providedIn: 'root',
})
export class AssigneeService {
  constructor(private readonly userService: UserService, private readonly groupService: GroupService) {}

  private static sortByNameComparator(a: Assignee, b: Assignee): number {
    return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : b.name.toLowerCase() > a.name.toLowerCase() ? -1 : 0;
  }

  private static convertGroupToAssignee(group: Group): Assignee {
    return {
      id: `Group|${group.id}`,
      name: group.name,
      category: 'Group',
    };
  }

  private static convertUserToAssignee(userFilterItem: UserFilterItem): Assignee {
    return {
      id: `User|${userFilterItem.id}`,
      name: userFilterItem.fullName,
      category: 'User',
    };
  }

  populateAssigneeFilter(): Observable<Assignee[]> {
    // TODO: Replace with backend sorting when available

    return this.getAssigneeData().pipe(
      map(([userFilterData, groupFilterData]: [UserFilter, GroupResponse]) => {
        const groups = groupFilterData.items
          .map((group: Group) => AssigneeService.convertGroupToAssignee(group))
          .sort(AssigneeService.sortByNameComparator) as Assignee[];

        const users = userFilterData.items
          .map((userFilterItem: UserFilterItem) => AssigneeService.convertUserToAssignee(userFilterItem))
          .sort(AssigneeService.sortByNameComparator) as Assignee[];

        return [...groups, ...users];
      })
    );
  }

  populateAssigneeFilterForRunDetails(taskData: TaskFilterItemResponse[]): Observable<Assignee[]> {
    // TODO: Replace with backend sorting when available
    return this.getAssigneeData().pipe(
      map(([userFilterData, groupFilterData]: [UserFilter, GroupResponse]) => {
        const allAssignees: Assignee[] = [];
        taskData.forEach((task: TaskFilterItemResponse) => {
          const groupAssigneeFilteredData = this.filterGroupAssigneeData(groupFilterData.items, task.groupAssignees);
          const groups = groupAssigneeFilteredData
            .map((group: Group) => AssigneeService.convertGroupToAssignee(group))
            .sort(AssigneeService.sortByNameComparator) as Assignee[];
          const userAssigneeFilteredData = this.filterUserAssigneeData(userFilterData.items, task.assignees);
          const users = userAssigneeFilteredData
            .map((userFilterItem: UserFilterItem) => AssigneeService.convertUserToAssignee(userFilterItem))
            .sort(AssigneeService.sortByNameComparator) as Assignee[];
          allAssignees.push(...groups, ...users);
        });
        return allAssignees;
      })
    );
  }
  populateAssigneeFilterForDefaultAssignment(taskData: DefaultAssignmentResponse[]): Observable<Assignee[]> {
    // TODO: Replace with backend sorting when available

    return this.getAssigneeData().pipe(
      map(([userFilterData, groupFilterData]: [UserFilter, GroupResponse]) => {
        const allAssignees: Assignee[] = [];
        taskData.forEach((task: DefaultAssignmentResponse) => {
          const groupAssigneeFilteredData = this.filterGroupAssigneeData(groupFilterData.items, task.assignees?.groups);
          const groups = groupAssigneeFilteredData
            .map((group: Group) => AssigneeService.convertGroupToAssignee(group))
            .sort(AssigneeService.sortByNameComparator) as Assignee[];
          const userAssigneeFilteredData = this.filterUserAssigneeData(userFilterData.items, task.assignees?.users);
          const users = userAssigneeFilteredData
            .map((userFilterItem: UserFilterItem) => AssigneeService.convertUserToAssignee(userFilterItem))
            .sort(AssigneeService.sortByNameComparator) as Assignee[];
          allAssignees.push(...groups, ...users);
        });
        return allAssignees;
      })
    );
  }

  private getAssigneeData(): Observable<[UserFilter, GroupResponse]> {
    return forkJoin([this.userService.filter(), this.groupService.filter()]);
  }

  private filterUserAssigneeData(userData: UserAssigneeType[], assignees: UserAssigneeType[]): UserAssigneeType[] {
    return userData.filter((user: UserAssigneeType) => {
      return assignees.some((assignee: UserAssigneeType) => user.firstName === assignee.firstName && user.lastName === assignee.lastName);
    });
  }
  private filterGroupAssigneeData(groupData: Group[], assignees: IdNamePair[]): Group[] {
    return groupData.filter((group: Group) => {
      return assignees.some((assignee: IdNamePair) => group.name === assignee.name);
    });
  }
}
