import { Directive, Input, ViewContainerRef, TemplateRef } from '@angular/core';

@Directive({
  selector: '[appNgVar]',
})
export class NgVarDirective {
  context: any = {};

  constructor(private viewContainerRef: ViewContainerRef, private templateRef: TemplateRef<any>) {}

  @Input()
  set appNgVar(context: any) {
    this.context.$implicit = this.context.appNgVar = context;
    this.updateView();
  }

  updateView(): void {
    this.viewContainerRef.clear();
    this.viewContainerRef.createEmbeddedView(this.templateRef, this.context);
  }
}
