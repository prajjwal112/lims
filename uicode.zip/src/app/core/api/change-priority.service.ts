import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

import { TaskService } from './task/task.service';
import { WorkflowCamundaIdPair } from '../../pages/shared/id-name-pair';
import { WorkflowInstanceService } from '../../pages/workflow-definitions/shared/workflow-instance.service';

@Injectable({
  providedIn: 'root',
})
export class ChangePriorityService {
  constructor(private readonly taskService: TaskService, private readonly workflowInstanceService: WorkflowInstanceService) {}

  updateTaskPriorities(priority: number, taskIds: WorkflowCamundaIdPair[]): Observable<void> {
    return this.taskService
      .updateTaskActionItems({
        priority: priority,
        taskInstanceIds: taskIds,
        assignedUserIds: [],
      })
      .pipe(take(1));
  }

  updateRunPriority(priority: number, runId: string): Observable<void> {
    return this.workflowInstanceService.updateWorkflowInstanceDetail(runId, priority).pipe(take(1));
  }
}
