import { HttpErrorResponse } from '@angular/common/http';

export interface WorkflowError {
  message: string;
  details: string[];
}

export class WorkflowHttpErrorResponse extends HttpErrorResponse {
  readonly error: WorkflowError;

  constructor(init: { error?: WorkflowError }) {
    super(init);
    this.error = init.error;
  }
}
