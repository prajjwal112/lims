import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from '../../auth.service';

@Injectable()
export class HeadersInterceptor implements HttpInterceptor {
  constructor(private readonly authService: AuthService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if (this.authService.sessionData) {
      const { tfsPlatformUserID, tfsPlatformTenantAlias } = this.authService.sessionData;

      return next.handle(
        request.clone({
          headers: request.headers.set(
            'Tf-Platform-User-Information',
            JSON.stringify({ platformUserId: tfsPlatformUserID, tenantAlias: tfsPlatformTenantAlias })
          ),
          withCredentials: false,
        })
      );
    }

    return next.handle(request);
  }
}
