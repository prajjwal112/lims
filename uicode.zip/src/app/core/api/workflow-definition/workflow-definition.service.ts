import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, flatMap } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { WorkflowHttpParams } from '../workflow-http-params';
import type {
  WorkflowDefinitionDetail,
  WorkflowDefinitionsRequest,
  WorkflowPublishResponse,
  FilteredWorkflowDefinition,
  SaveWorkflowDefinitionRequest,
  WorkflowDefinitionTemplateFilterResponse,
  WorkflowDefinitionTemplateResponse,
  SaveWorkflowDefinitionTemplateRequest,
  WorkflowDefinitionCopyResponse,
  UpdateWorkflowDefinitionRequest,
} from '../../../pages/workflow-definitions/shared/workflow-definition';
import type { WorkflowStatistic, WorkflowStatisticRequest } from '../../../pages/task-list/workflow-statistic';

// TODO: extract template calls to a template service

const WORKFLOW_DEFINITION_TEMPLATES_URL = `${environment.endpoint}/workflow-definition-templates`;
const WORKFLOW_DEFINITIONS_URL = `${environment.endpoint}/workflow-definitions`;
const WORKFLOW_DEFINITION_FILTER_URL = `${WORKFLOW_DEFINITIONS_URL}/filter`;
const WORKFLOW_DEFINITION_FILTER_COUNT_URL = `${WORKFLOW_DEFINITION_FILTER_URL}/count`;
const VERIFY_TEMPLATE_URL = `${WORKFLOW_DEFINITION_TEMPLATES_URL}/validate`;

@Injectable({
  providedIn: 'root',
})
export class WorkflowDefinitionService {
  constructor(private http: HttpClient) {}

  private static pipeToCatchError<T>(observable: Observable<T>): Observable<T> {
    return observable.pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  filterWorkflowDefinitions(requestData?: WorkflowDefinitionsRequest): Observable<FilteredWorkflowDefinition[]> {
    return WorkflowDefinitionService.pipeToCatchError(
      this.http.post<FilteredWorkflowDefinition[]>(WORKFLOW_DEFINITION_FILTER_URL, requestData)
    );
  }

  getWorkflowDefinitionDetail(workflowDefinitionId: string): Observable<WorkflowDefinitionDetail> {
    return WorkflowDefinitionService.pipeToCatchError(
      this.http.get<WorkflowDefinitionDetail>(`${WORKFLOW_DEFINITIONS_URL}/${encodeURIComponent(workflowDefinitionId)}/detail`)
    );
  }

  getWorkflowDefinitionsCount(requestData?: WorkflowDefinitionsRequest): Observable<number> {
    return WorkflowDefinitionService.pipeToCatchError(this.http.post<number>(WORKFLOW_DEFINITION_FILTER_COUNT_URL, requestData));
  }

  getStatistics(request: WorkflowStatisticRequest): Observable<WorkflowStatistic[]> {
    const params = new WorkflowHttpParams().append('top', (request.top || '').toString());
    return this.http.get<WorkflowStatistic[]>(`${WORKFLOW_DEFINITIONS_URL}/statistics`, { params });
  }

  getWorkflowDefinitionTemplates(): Observable<WorkflowDefinitionTemplateFilterResponse[]> {
    return WorkflowDefinitionService.pipeToCatchError(
      this.http.get<WorkflowDefinitionTemplateFilterResponse[]>(WORKFLOW_DEFINITION_TEMPLATES_URL)
    );
  }

  getWorkflowDefinitionTemplate(definitionTemplateId: number): Observable<WorkflowDefinitionTemplateResponse> {
    return WorkflowDefinitionService.pipeToCatchError(
      this.http.get<WorkflowDefinitionTemplateResponse>(`${WORKFLOW_DEFINITION_TEMPLATES_URL}/${definitionTemplateId}`)
    );
  }

  getWorkflowDefinitionTemplateId(id: string, newName: string): Observable<WorkflowDefinitionCopyResponse> {
    return WorkflowDefinitionService.pipeToCatchError(
      this.http.post<WorkflowDefinitionCopyResponse>(`${WORKFLOW_DEFINITIONS_URL}/${encodeURIComponent(id)}/copy`, { name: newName })
    );
  }

  definitionExists(name: string): Observable<void> {
    return this.http.head<void>(WORKFLOW_DEFINITIONS_URL, { params: new WorkflowHttpParams().append('name', name) });
  }

  publish(definitionTemplateId: number): Observable<WorkflowPublishResponse> {
    return this.http.post<WorkflowPublishResponse>(
      `${WORKFLOW_DEFINITION_TEMPLATES_URL}/${encodeURIComponent(definitionTemplateId)}/publish`,
      null
    );
  }

  deleteWorkflowDefinitionTemplate(definitionTemplateIdOrDefinitionName: number | string): Observable<void> {
    let observable: Observable<void>;

    if (typeof definitionTemplateIdOrDefinitionName === 'number') {
      observable = this.http.delete<void>(
        `${WORKFLOW_DEFINITION_TEMPLATES_URL}/${encodeURIComponent(definitionTemplateIdOrDefinitionName)}`
      );
    } else {
      observable = this.http.delete<void>(WORKFLOW_DEFINITION_TEMPLATES_URL, {
        params: new WorkflowHttpParams().append('name', definitionTemplateIdOrDefinitionName),
      });
    }

    return WorkflowDefinitionService.pipeToCatchError(observable);
  }

  saveWorkflowDefinition(requestBody: SaveWorkflowDefinitionRequest): Observable<void> {
    return WorkflowDefinitionService.pipeToCatchError(this.http.post<void>(WORKFLOW_DEFINITIONS_URL, requestBody));
  }

  updateWorkflowDefinition(workflowDefinitionId: string, requestBody: UpdateWorkflowDefinitionRequest): Observable<void> {
    return WorkflowDefinitionService.pipeToCatchError(
      this.http.patch<void>(`${WORKFLOW_DEFINITIONS_URL}/${encodeURIComponent(workflowDefinitionId)}`, requestBody)
    );
  }

  saveWorkflowDefinitionTemplate(requestBody: SaveWorkflowDefinitionTemplateRequest): Observable<WorkflowDefinitionTemplateResponse> {
    return WorkflowDefinitionService.pipeToCatchError(
      this.http
        .post<void>(WORKFLOW_DEFINITION_TEMPLATES_URL, requestBody, { observe: 'response' })
        .pipe(
          flatMap((response: HttpResponse<void>) => {
            return this.http.get<WorkflowDefinitionTemplateResponse>(`${environment.endpoint}${response.headers.get('Location')}`);
          })
        )
    );
  }

  verifyTemplate(xml: string): Observable<void> {
    return WorkflowDefinitionService.pipeToCatchError(this.http.post<void>(VERIFY_TEMPLATE_URL, xml));
  }
}
