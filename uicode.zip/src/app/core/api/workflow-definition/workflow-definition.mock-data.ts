const ITEMS = [
  {
    id: '1',
    name: 'workflow test',
    description: 'desc',
    projects: [{ id: 1, name: 'project one' }],
    referenceId: 1,
    trackDueDate: true,
    lastUpdate: '2021-02-28T21:34:05.909312',
    active: true,
  },
  {
    id: '2',
    name: 'workflow test 1',
    description: 'desc 1',
    projects: [{ id: 1, name: 'project one' }],
    referenceId: 2,
    lastUpdate: '2021-02-28T21:34:05.909312',
    trackDueDate: false,
    active: true,
  },
];

const DETAIL = {
  id: '1.1',
  name: 'workflow test',
  archived: false,
  projects: [{ id: 1, name: 'project one' }],
  estimatedCompletionDate: '',
  xml: 'xml file',
};

const REQUEST_ITEM = {
  active: true,
  top: 0,
  nameLike: '',
  sortDescriptors: [],
  nameEquals: '',
  projectIds: [1, 2],
};

const TEMPLATE_FILTER = {
  id: 1,
  name: 'workflow test',
  description: 'desc',
  projectIds: [1, 2],
  lastUpdate: '2021-02-28T21:34:05.909312',
  dueDateTracked: true,
};

const SAVE_REQUEST = {
  name: 'workflow test',
  description: 'desc',
  projectIds: [1, 2],
  dueDateTracked: true,
};

export { ITEMS, DETAIL, REQUEST_ITEM, TEMPLATE_FILTER, SAVE_REQUEST };
