import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpHeaders } from '@angular/common/http';
import { WorkflowDefinitionService } from './workflow-definition.service';
import { environment } from 'src/environments/environment';
import type {
  WorkflowDefinitionTemplateResponse,
  SaveWorkflowDefinitionTemplateRequest,
} from '../../../pages/workflow-definitions/shared/workflow-definition';
import { SAVE_REQUEST, TEMPLATE_FILTER } from './workflow-definition.mock-data';

const WORKFLOW_DEFINITION_TEMPLATES_URL = `${environment.endpoint}/workflow-definition-templates`;

describe('Workflow Definition Service', () => {
  let httpTestingController: HttpTestingController;
  let workflowDefinitionService: WorkflowDefinitionService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [WorkflowDefinitionService],
    });

    httpTestingController = TestBed.inject(HttpTestingController);
    workflowDefinitionService = TestBed.inject(WorkflowDefinitionService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should deleteWorkflowDefinitionTemplate by Id', () => {
    const mockData = { status: 204, statusText: 'No Content' };
    workflowDefinitionService.deleteWorkflowDefinitionTemplate(1).subscribe();
    const req = httpTestingController.expectOne(`${WORKFLOW_DEFINITION_TEMPLATES_URL}/1`);

    expect(req.request.method).toEqual('DELETE');
    req.flush('', mockData);
  });

  it('should deleteWorkflowDefinitionTemplate by name', () => {
    const mockData = { status: 204, statusText: 'No Content' };
    workflowDefinitionService.deleteWorkflowDefinitionTemplate('Workflow test').subscribe();
    const req = httpTestingController.expectOne(`${WORKFLOW_DEFINITION_TEMPLATES_URL}?name=Workflow%20test`);

    expect(req.request.method).toEqual('DELETE');
    req.flush('', mockData);
  });

  it('should saveWorkflowDefinitionTemplate', fakeAsync(() => {
    const mockData: WorkflowDefinitionTemplateResponse = { ...TEMPLATE_FILTER, xml: 'xml file' };

    workflowDefinitionService
      .saveWorkflowDefinitionTemplate({ ...SAVE_REQUEST, xml: 'xml file' } as SaveWorkflowDefinitionTemplateRequest)
      .subscribe({
        next: (response: WorkflowDefinitionTemplateResponse) => {
          expect(response).toEqual({ ...TEMPLATE_FILTER, xml: 'xml file' }, 'should return Workflow Definition Template that was saved');
        },
      });

    const reqURL = httpTestingController.expectOne(WORKFLOW_DEFINITION_TEMPLATES_URL);
    let headers = new HttpHeaders();
    headers = headers.set('Location', '/template/workflow_test');

    expect(reqURL.request.method).toEqual('POST');
    expect(reqURL.request.body).toEqual({ ...SAVE_REQUEST, xml: 'xml file' } as SaveWorkflowDefinitionTemplateRequest);

    reqURL.flush('', {
      headers: headers,
    });

    tick();

    const req = httpTestingController.expectOne(`${environment.endpoint}/template/workflow_test`);

    expect(req.request.method).toEqual('GET');

    req.flush(mockData);
  }));
});
