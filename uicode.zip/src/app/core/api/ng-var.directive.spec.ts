import { Component } from '@angular/core';
import { NgVarDirective } from './ng-var.directive';
import { TestBed, ComponentFixture } from '@angular/core/testing';

@Component({
  template: '<p *appNgVar="getName() as testName" >Testing Directives</p><span>{{testName}}</span>',
})
class TestComponent {
  /* eslint-disable-next-line @typescript-eslint/no-empty-function */
  constructor() {}

  getName(): string {
    return 'testName comes here';
  }
}

describe('NgVarDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, NgVarDirective],
    });

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;

    it('should create an component', () => {
      expect(component).toBeDefined();
    });
  });
});
