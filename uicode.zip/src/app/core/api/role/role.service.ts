import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SortDirection } from '../../../pages/shared/sort-direction';
import { environment } from '../../../../environments/environment';
import { WorkflowHttpParams } from '../../../core/api/workflow-http-params';
import {
  Role,
  Rule,
  RoleListRequest,
  UpdateRoleRequest,
  UpdateRoleResponse,
  RoleListResponse,
  CreateRoleRequest,
} from '../../../pages/roles/shared/role';

const URL = `${environment.endpoint}/roles`;
const RULES_URL = `${environment.endpoint}/rules`;

@Injectable({
  providedIn: 'root',
})
export class RoleService {
  constructor(private http: HttpClient) {}

  getData(requestData?: RoleListRequest): Observable<RoleListResponse> {
    let params = new WorkflowHttpParams();
    if (requestData) {
      params = params
        .append('top', (requestData.top || '').toString())
        .append('skip', (requestData.skip || '').toString())
        .append('roleName', requestData.name || '')
        .append('sort', requestData.sort || SortDirection.Ascending)
        .append('archived', (requestData.archived || false).toString());
    }
    return this.http
      .get<RoleListResponse>(URL, { params })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  getRole(roleId: number): Observable<Role> {
    return this.http.get<Role>(`${URL}/${roleId}`).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  getRules(): Observable<Rule[]> {
    return this.http.get<Rule[]>(RULES_URL).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  create(requestData: CreateRoleRequest): Observable<UpdateRoleResponse> {
    return this.http.post<UpdateRoleResponse>(URL, requestData).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  update(requestData: UpdateRoleRequest): Observable<UpdateRoleResponse> {
    return this.http.put<UpdateRoleResponse>(URL, requestData).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }
}
