import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SortDirection } from '../../../pages/shared/sort-direction';
import { environment } from '../../../../environments/environment';
import type { IdNameDescriptionService } from '../../../pages/shared/id-name-description-service';
import type {
  UpdateProjectRequest,
  UpdateProjectResponse,
  ProjectResponse,
  ProjectFilterRequest,
  ProjectItemRequest,
  ProjectDetailResponse,
} from '../../../pages/projects/shared/project';
import type { WorkflowStatistic } from '../../../pages/task-list/workflow-statistic';

const URL = `${environment.endpoint}/projects`;

@Injectable({
  providedIn: 'root',
})
export class ProjectService implements IdNameDescriptionService {
  constructor(private http: HttpClient) {}

  private static buildFilterBody(requestData?: ProjectFilterRequest): ProjectFilterRequest {
    let body: ProjectFilterRequest = {};

    if (requestData) {
      body = Object.assign({}, requestData);
      body.sort = requestData.sort || SortDirection.Ascending;
      body.archived = requestData.archived || false;
    }

    return body;
  }

  filter(requestData?: ProjectFilterRequest): Observable<ProjectResponse> {
    return this.http
      .post<ProjectResponse>(`${URL}/filter`, ProjectService.buildFilterBody(requestData))
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  getProjectDetail(projectReferenceId: number): Observable<ProjectDetailResponse> {
    return this.http
      .get<ProjectDetailResponse>(`${URL}/${projectReferenceId}`)
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  getWorkflowStatistics(projectReferenceId: number): Observable<WorkflowStatistic[]> {
    return this.http
      .get<WorkflowStatistic[]>(`${URL}/${projectReferenceId}/workflow-statistics`)
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  create(requestData: UpdateProjectRequest): Observable<UpdateProjectResponse> {
    return this.http.post<UpdateProjectResponse>(URL, requestData).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  update(requestData: UpdateProjectRequest): Observable<UpdateProjectResponse> {
    return this.http.put<UpdateProjectResponse>(URL, requestData).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  addUsersToProject(requestData: ProjectItemRequest): Observable<void> {
    return this.http
      .post<void>(`${URL}/${requestData.projectReferenceId}/users`, requestData.updateIds)
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  addGroupsToProject(requestData: ProjectItemRequest): Observable<void> {
    const url = `${URL}/${requestData.projectReferenceId}/groups`;
    return this.http.post<void>(url, requestData.updateIds).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }
}
