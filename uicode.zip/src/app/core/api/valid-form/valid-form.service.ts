import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ValidFormService {
  readonly #valid = new BehaviorSubject<boolean>(false);

  getValid(): Observable<boolean> {
    return this.#valid.asObservable();
  }

  setValid(newValid: boolean): void {
    this.#valid.next(newValid);
  }
}
