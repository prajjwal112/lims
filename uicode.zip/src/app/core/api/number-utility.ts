export class NumberUtility {
  /* eslint-disable-next-line @typescript-eslint/no-empty-function */
  private constructor() {}

  /**
   * Converts the given value to a number, if the given value was numeric.
   *
   * @param value The value to convert.
   *
   * @return {number | null} The number, if it could be converted. Otherwise, <code>null</code>.
   */
  static toNumber(value?: unknown): number | null {
    return (typeof value === 'string' && value.trim() === '') || value === null || value === true || value === false || isNaN(+value)
      ? null
      : +value;
  }
}
