import { HttpParameterCodec, HttpParams } from '@angular/common/http';

class Encoder implements HttpParameterCodec {
  encodeKey(key: string): string {
    return encodeURIComponent(key);
  }

  encodeValue(value: string): string {
    return encodeURIComponent(value);
  }

  decodeKey(key: string): string {
    return decodeURIComponent(key);
  }

  decodeValue(value: string): string {
    return decodeURIComponent(value);
  }
}

export class WorkflowHttpParams extends HttpParams {
  constructor() {
    super({ encoder: new Encoder() });
  }
}
