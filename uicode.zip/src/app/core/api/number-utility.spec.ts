import { NumberUtility } from './number-utility';

describe('NumberUtility', () => {
  describe('to number', () => {
    it('should be the converted number when the given value is numeric', () => {
      expect(NumberUtility.toNumber(0)).toBe(0);
    });

    it('should be the converted number when the value is a numeric string', () => {
      expect(NumberUtility.toNumber('1')).toBe(1);
    });

    it('should be null when given value is blank string', () => {
      expect(NumberUtility.toNumber('     ')).toBeNull();
    });

    it('should be null when given value is null', () => {
      expect(NumberUtility.toNumber(null)).toBeNull();
    });

    it('should be null when given value is true', () => {
      expect(NumberUtility.toNumber(true)).toBeNull();
    });

    it('should be null when given value is false', () => {
      expect(NumberUtility.toNumber(false)).toBeNull();
    });

    it(`should be null when given value evaluates to ${NaN}`, () => {
      [undefined, 'abcd', [1, 2], { foo: 'bar' }].forEach((value) => {
        expect(NumberUtility.toNumber(value)).toBeNull();
      });
    });
  });
});
