import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import type { IdNameDescriptionService } from '../../../pages/shared/id-name-description-service';
import type {
  GroupResponse,
  GroupRequest,
  UpdateGroupRequest,
  UpdateGroupResponse,
  GroupItemRequest,
} from '../../../pages/groups/shared/group';

const URL = `${environment.endpoint}/groups`;

@Injectable({
  providedIn: 'root',
})
export class GroupService implements IdNameDescriptionService {
  private data: GroupResponse;

  constructor(private http: HttpClient) {}

  filter(requestData: GroupRequest = {}): Observable<GroupResponse> {
    return this.http.post<GroupResponse>(`${URL}/filter`, requestData).pipe(
      catchError((error: HttpErrorResponse) => throwError(error)),
      tap({
        next: (data: GroupResponse) => {
          this.data = data;
        },
      })
    );
  }

  create(requestData: UpdateGroupRequest): Observable<UpdateGroupResponse> {
    return this.http.post<UpdateGroupResponse>(URL, requestData).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  update(requestData: UpdateGroupRequest): Observable<UpdateGroupResponse> {
    return this.http.put<UpdateGroupResponse>(URL, requestData).pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  addUsers(requestData: GroupItemRequest): Observable<void> {
    return this.http
      .post<void>(`${URL}/${requestData.groupReferenceId}/users`, requestData.updateIds)
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  addProjects(requestData: GroupItemRequest): Observable<void> {
    return this.http
      .post<void>(`${URL}/${requestData.groupReferenceId}/projects`, requestData.updateIds)
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }
}
