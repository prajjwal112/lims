import { TestBed, fakeAsync } from '@angular/core/testing';

import { ErrorService } from './error.service';

describe('ErrorService', () => {
  let service: ErrorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ErrorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return error before setting', fakeAsync(() => {
    service.getError().subscribe({
      next: (error) => {
        expect(error).toBeFalse();
      },
    });
  }));

  it('should set error', fakeAsync(() => {
    service.addError(true);
    service.getError().subscribe({
      next: (error) => {
        expect(error).toBeTrue();
      },
    });
  }));
});
