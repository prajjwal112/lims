import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import type { SessionData } from '@dsp/lib-platform-header-data';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  readonly #redirectUrl$: Readonly<BehaviorSubject<string>> = new BehaviorSubject('');
  readonly #adminUser$: Readonly<BehaviorSubject<boolean>> = new BehaviorSubject(false);

  #sessionData: SessionData;

  /*
   * TODO: This is temporary. Currently, the header service returns a base64 encoding of CDC user ID + dex ID.
   *       To get around that, decode the value, split on the first non-alphanumeric character, and take the first
   *       item; that should be the CDC user ID. Platform Header service team will work on returning the ID in a
   *       readily-usable format.
   */
  private static decodeUserId(sessionData?: SessionData): SessionData {
    if (!sessionData?.tfsPlatformUserID) {
      return sessionData;
    }

    return {
      ...sessionData,
      tfsPlatformUserID: atob(sessionData.tfsPlatformUserID)
        .trim()
        .split(/[^\w]+/)[0],
    };
  }

  get sessionData(): SessionData {
    return this.#sessionData;
  }

  set sessionData(session: SessionData) {
    this.#sessionData = AuthService.decodeUserId(session);
  }

  get loggedIn(): boolean {
    return !!this.#sessionData;
  }

  get adminUser(): boolean {
    return this.#adminUser$.getValue();
  }

  set adminUser(admin: boolean) {
    this.#adminUser$.next(admin);
  }

  subscribeToAdminUser(): Observable<boolean> {
    return this.#adminUser$.asObservable();
  }

  set redirectUrl(url: string) {
    this.#redirectUrl$.next(url);
  }

  subscribeToRedirectUrl(): Observable<string> {
    return this.#redirectUrl$.asObservable();
  }
}
