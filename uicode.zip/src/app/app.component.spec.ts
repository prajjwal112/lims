import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { Subject } from 'rxjs';
import { DspPlatformComponentsModule, FooterModule, HeaderModule, SidebarNavModule } from '@dsp/platform-components';
import { LibPlatformHttpClientModule } from '@dsp/lib-platform-http-client';
import { LibPlatformHeaderDataService, LibPlatformHeaderDataServiceMock, PlatformHeaderData } from '@dsp/lib-platform-header-data';
import { ModalsModule } from 'gds-atom-components';
import { AppComponent } from './app.component';
import { LoaderModule } from './pages/shared/loader/loader.module';
import { HEADER_DATA } from './test/headerData';

const headerData = new Subject<PlatformHeaderData>();
describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async(() => {
    headerData.next(HEADER_DATA);

    TestBed.configureTestingModule({
      declarations: [AppComponent],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        DspPlatformComponentsModule,
        HeaderModule,
        SidebarNavModule,
        FooterModule,
        ModalsModule,
        LibPlatformHttpClientModule.forRootImports(),
        LoaderModule,
      ],
      providers: [
        {
          provide: LibPlatformHeaderDataService,
          useClass: LibPlatformHeaderDataServiceMock,
          useValue: { headerDataObservable: headerData },
        },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('should have configured links', () => {
    const routes = [
      { name: 'Home', path: '/my-tasks', icon: 'gds-icon-home-mono', default: true },
      { name: 'Workflow Mgmt.', path: '/workflow-definitions', icon: 'workflow-icon-workflow-mono' },
      { name: 'Tasks', path: '/tasks', icon: 'gds-icon-clipboard-mono' },
      { name: 'Projects', path: '/projects', icon: 'gds-icon-techdocumentation-mono' },
      {
        name: 'User Mgmt.',
        path: '',
        default: false,
        icon: 'workflow-icon-users-mono',
        links: [
          {
            path: '/users',
            name: 'Users',
            default: false,
            external: false,
          },
          {
            path: '/groups',
            name: 'Groups',
            default: false,
            external: false,
          },
          {
            path: '/roles',
            name: 'Roles',
            default: false,
            external: false,
          },
        ],
      },
      {
        name: 'Organization Settings',
        path: '/organization-settings',
        icon: 'gds-icon-settings-mono',
        settings: true,
      },
    ];

    expect(component.routes).toEqual(routes);
  });

  it('should have modal', () => {
    expect(fixture.debugElement.query(By.css('kmd-modal'))).toBeTruthy();
  });

  describe('Session timeout should show when', () => {
    it('error service registers an error', () => {
      expect(fixture.debugElement.query(By.css('kmd-modal div'))).toBeFalsy();
      component['errorService'].addError(true);
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('kmd-modal div'))).toBeTruthy();
    });

    it('session is empty', () => {
      expect(fixture.debugElement.query(By.css('kmd-modal div'))).toBeFalsy();
      headerData.next(null);
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('kmd-modal div'))).toBeTruthy();
    });
  });
});
