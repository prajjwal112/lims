import { TestBed } from '@angular/core/testing';

import { AuthService } from './auth.service';
import { SESSION_DATA } from './test/sessionData';

describe('AuthService', () => {
  let service: AuthService;
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have login as false when session is not set', () => {
    expect(service.sessionData).toBeUndefined();
    expect(service.loggedIn).toBeFalse();
  });

  it('should set login when session is set', () => {
    service.sessionData = SESSION_DATA;

    expect(service.loggedIn).toBeTrue();
  });
});
