import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ErrorService {
  readonly #error = new BehaviorSubject(false);

  addError(errors: boolean): void {
    this.#error.next(errors);
  }

  getError(): Observable<boolean> {
    return this.#error.asObservable();
  }
}
