import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DspPlatformComponentsModule, FooterModule, HeaderModule, SidebarNavModule } from '@dsp/platform-components';
import { LibPlatformHttpClientModule } from '@dsp/lib-platform-http-client';
import { LibPlatformHeaderDataService } from '@dsp/lib-platform-header-data';
import { ModalsModule } from 'gds-atom-components';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth-guard';
import { LoaderModule } from './pages/shared/loader/loader.module';
import { environment } from 'src/environments/environment';
import { HeadersInterceptor } from './core/api/headers.interceptor';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    DspPlatformComponentsModule,
    HeaderModule,
    SidebarNavModule,
    FooterModule,
    AppRoutingModule,
    LoaderModule,
    SidebarNavModule,
    ModalsModule,
    LibPlatformHttpClientModule.forRootImports(),
  ],
  providers: [
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HeadersInterceptor,
      multi: true,
    },
    {
      provide: LibPlatformHeaderDataService,
      useClass: environment.headerDataServiceType,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
