import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import type { OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SortDescriptor } from '@progress/kendo-data-query';
import { KmdModalService } from 'gds-atom-components';

import { RoleService } from '../../core/api/role/role.service';
import { StoreService, Action, ActionType } from '../../store.service';
import { ROLE_NAME_COLUMN, ROLE_DESCRIPTION_COLUMN, ROLE_OPTIONS_COLUMN } from './shared/role-grid-columns';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../shared/common-data-type';
import { SortDirection } from '../shared/sort-direction';
import { GridComponent, Pagination } from '../shared/grid/grid.component';
import { SearchTextService } from '../shared/search-text.service';
import { ModalId } from '../shared/modal-id';
import type { Role, RoleListRequest, RoleListResponse } from './shared/role';
import type { Column } from '../shared/grid/column';
import type { ActionClickEvent } from '../shared/grid/popover/action/action-popover';

const TAB_ID = {
  active: 'roles-Active',
  obsoleted: 'roles-Obsoleted',
} as const;

type TabId = typeof TAB_ID[keyof typeof TAB_ID];

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.scss', '../shared/page-header.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class RolesComponent implements OnInit, OnDestroy {
  readonly tabId = TAB_ID;

  readonly #unsubscribe: Readonly<Subject<void>> = new Subject<void>();

  sort: SortDescriptor[] = [];
  data: Role[] = [];
  searchData: Role[] = [];
  columns: Column[] = [ROLE_NAME_COLUMN, ROLE_DESCRIPTION_COLUMN, ROLE_OPTIONS_COLUMN];
  roleReferenceId: number;
  roleCount = 0;
  successMessage = false;
  suggest = false;

  @ViewChild(GridComponent) private grid: GridComponent;

  #sortDirection: SortDescriptor['dir'];
  #searchName = '';
  #skip = DEFAULT_SKIP;
  #top = DEFAULT_TOP;
  #obsoleted = false;

  constructor(
    public readonly roleService: RoleService,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly store: StoreService,
    private readonly kmdModalService: KmdModalService,
    private readonly searchTextService: SearchTextService
  ) {
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Roles' }));
    ROLE_OPTIONS_COLUMN.popover.action.onClick = this.onActionClick.bind(this);
  }

  ngOnInit(): void {
    this.successMessage = false;
    this.route.queryParams.subscribe({
      next: (queryParam) => {
        this.successMessage = queryParam.success === 'true';
      },
    });
    this.sort = [{ field: 'name', dir: SortDirection.Ascending }];
    this.getAllData();
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  public sortChanged(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.#sortDirection = sort[0]?.dir;
    this.getAllData();
  }

  public selectChange(filterName: string): void {
    this.#searchName = filterName;
    this.#skip = DEFAULT_SKIP;
    this.resetPagination();
    this.getAllData();
  }

  public onTabSelect(event: { nextId: TabId }): void {
    this.searchTextService.setText(this.#searchName);
    this.#searchName = '';
    this.data = [];
    this.#obsoleted = event.nextId === TAB_ID.obsoleted;
    ROLE_DESCRIPTION_COLUMN.width = this.#obsoleted ? 450 : 320;
    this.columns = this.#obsoleted
      ? [ROLE_NAME_COLUMN, ROLE_DESCRIPTION_COLUMN]
      : [ROLE_NAME_COLUMN, ROLE_DESCRIPTION_COLUMN, ROLE_OPTIONS_COLUMN];
    this.#skip = DEFAULT_SKIP;
    this.resetPagination();
    this.getAllData();
  }

  public onActionClick(event: ActionClickEvent): void {
    const selectedData = this.data.find((data) => data.referenceId === event.dataItem.id);
    this.roleReferenceId = +selectedData.referenceId;
    if (event.name === 'editRole') {
      this.router.navigate(['/roles/details/edit/', this.roleReferenceId]);
    }
    if (event.name === 'obsoleteRole') {
      this.kmdModalService.open(ModalId.MakeRoleObsolete);
    }
  }

  public onPageChangeHandler(event: Pagination): void {
    this.#skip = event.first;
    this.#top = event.resultsPerPage;
    this.getAllData();
  }

  public obsoleteConfirm(): void {
    this.getAllData();
  }

  private resetPagination(): void {
    this.#skip = DEFAULT_SKIP;
    this.#top = DEFAULT_TOP;
    if (this.grid) {
      this.grid.resetPagination();
    }
  }

  private getRoleRequestData(): RoleListRequest {
    return {
      top: this.#top,
      skip: this.#skip,
      name: (this.#searchName || '').trim(),
      sort: this.#sortDirection || '',
      archived: this.#obsoleted,
    };
  }

  private getAllData(): void {
    const requestData = this.getRoleRequestData();
    this.roleService
      .getData(requestData)
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: RoleListResponse) => {
          this.roleCount = data.count;
          this.data = data.items.map((obj) => ({
            ...obj,
            referenceId: obj.id,
          }));
          this.searchData = this.data.slice();
        },
        error: () => {
          this.data = [];
          this.searchData = [];
          this.roleCount = 0;
        },
      });
  }
}
