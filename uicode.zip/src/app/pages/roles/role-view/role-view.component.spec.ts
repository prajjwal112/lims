import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { By } from '@angular/platform-browser';
import {
  ButtonModule,
  AlertsModule,
  InputFieldsModule,
  PopoverModule,
  CheckboxModule,
  ModalsModule,
  TabsModule,
} from 'gds-atom-components';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { MakeObsoleteModule } from '../../shared/make-obsolete/make-obsolete.module';
import { RoleViewComponent } from './role-view.component';
import { RoleService } from '../../../core/api/role/role.service';
import { of } from 'rxjs';
import { Role } from '../shared/role';
import { UserListModule } from '../../users/shared/user-list/user-list.module';

describe('RoleViewComponent', () => {
  let component: RoleViewComponent;
  let fixture: ComponentFixture<RoleViewComponent>;
  let roleService: RoleService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RoleViewComponent],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        TabsModule,
        ManageItemsModule,
        ButtonModule,
        AlertsModule,
        InputFieldsModule,
        PopoverModule,
        CheckboxModule,
        ModalsModule,
        MakeObsoleteModule,
        UserListModule,
      ],
      providers: [
        RoleService,
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              queryParamMap: new Map([['success', 'true']]),
              paramMap: new Map([['id', '1']]),
            },
          },
        },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleViewComponent);
    component = fixture.componentInstance;
    roleService = TestBed.inject(RoleService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should disable assign users and editRole button when role is obsoleted', () => {
    component.roleData = {
      id: 1,
      name: 'roleName1',
      description: 'role description',
      archived: true,
      rules: [],
    };
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#assignUsers')).nativeElement.disabled).toBe(true);
    expect(fixture.debugElement.query(By.css('#editRole')).nativeElement.disabled).toBe(true);
  });

  it('should enable assign users and editRole button when role is not obsoleted', () => {
    component.roleData = {
      id: 1,
      name: 'roleName1',
      description: 'role description',
      archived: false,
      rules: [],
    };
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#assignUsers')).nativeElement.disabled).toBe(false);
    expect(fixture.debugElement.query(By.css('#editRole')).nativeElement.disabled).toBe(false);
  });

  it('should display `Permissions Users tabs`', () => {
    expect(fixture.debugElement.query(By.css('kmd-tabs')).nativeElement.textContent.trim()).toBe('Permissions Users');
  });

  it('should use Published tab columns by default', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[0].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.permissionTab).toBeTruthy();
  });

  it('should use Users tab columns', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[1].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.permissionTab).toBeFalsy();
  });

  it('should switch to Published tab columns', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[1].triggerEventHandler('click', null);
    fixture.detectChanges();
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[0].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.permissionTab).toBeTruthy();
  });

  it('should fetch the roledata', () => {
    spyOn(roleService, 'getRole').and.returnValue(of(mockRoleData()));
    component.ngOnInit();

    expect(component.roleReferenceId).not.toBeNull();
    expect(roleService.getRole).toHaveBeenCalledWith(component.roleReferenceId);
  });

  it('should open the modal for deleting role', () => {
    spyOn(component['kmdModalService'], 'open');
    component.openModal('abc');

    expect(component['kmdModalService'].open).toHaveBeenCalledWith('abc');
  });

  it('should confirm the obsoleted role', () => {
    spyOn(roleService, 'update').and.callThrough();
    component.obsoleteConfirm();

    expect(roleService.update).toHaveBeenCalledWith({ ...component.roleData, archived: true });
    expect(component.successMessage).toBeTruthy();
  });
});
function mockRoleData(): Role {
  return {
    id: 4,
    name: 'Java 11 testing',
    privileged: false,
    description: 'test',
    archived: false,
    rules: ['WORKFLOW_PUT'],
    ruleDetails: [
      {
        name: 'Workflow runs',
        types: [{ name: 'WORKFLOW_PUT', title: 'Edit', description: 'Modify the Workflow instance priority settings and terminate a run' }],
      },
    ],
  };
}
