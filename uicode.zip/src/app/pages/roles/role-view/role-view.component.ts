import { Component, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';

import { StoreService, Action, ActionType } from '../../../store.service';
import { GroupService } from '../../../core/api/group/group.service';
import { ProjectService } from '../../../core/api/project/project.service';
import { RoleService } from '../../../core/api/role/role.service';
import { UserService } from '../../../core/api/user/user.service';
import { UnassociatedService } from '../../shared/unassociated/unassociated.service';
import { UserManagementService } from '../../shared/user-management/user-management.service';
import {
  NAME_COLUMN,
  ADMIN_COLUMN,
  ACTIVE_COLUMN,
  ROLES_WITHOUT_FILTER_COLUMN,
  PROJECTS_COLUMN,
  GROUPS_COLUMN,
  OPTIONS_COLUMN,
} from '../../users/shared/user-grid-columns';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../../shared/common-data-type';
import { TabKeys, TabValues } from '../../shared/tab-name';
import { UserListComponent } from '../../users/shared/user-list/user-list.component';
import { bindActionClick } from '../../shared/grid/popover/action/action-popover';
import { ModalId } from '../../shared/modal-id';
import type { OnInit, OnDestroy, AfterViewChecked } from '@angular/core';
import type { Column } from '../../shared/grid/column';
import type { Role } from '../shared/role';
import type { Project, ProjectResponse } from '../../projects/shared/project';
import type { Group, GroupResponse } from '../../groups/shared/group';
import type { ManageItemsRequest, ConfirmedStatus } from '../../shared/common-data-type';
import type { UserFilterItem } from '../../users/shared/user';

@Component({
  selector: 'app-role-view',
  templateUrl: './role-view.component.html',
  styleUrls: ['./role-view.component.scss', '../../shared/page-header.scss'],
})
export class RoleViewComponent implements OnInit, OnDestroy, AfterViewChecked {
  public readonly userActions = {
    [ModalId.AddProjects]: 'Add to project',
    [ModalId.AddGroups]: 'Add to group',
    [ModalId.AddRoles]: 'Add role assignment',
  } as const;
  public readonly tabKey = TabKeys;
  public readonly tabValue = TabValues;
  public readonly modalId = ModalId;

  @ViewChild(UserListComponent) userListElement: UserListComponent;

  public roleData: Role;
  public roleReferenceId: number = null;
  public successMessage = false;
  public obsoleteErrorMessage = '';
  public posX = 0;
  public posY = 0;
  public permissionTab = true;
  public userColumns: Column[] = [
    NAME_COLUMN,
    ADMIN_COLUMN,
    ACTIVE_COLUMN,
    ROLES_WITHOUT_FILTER_COLUMN,
    PROJECTS_COLUMN,
    GROUPS_COLUMN,
    OPTIONS_COLUMN,
  ];
  public usersCount: number;
  public roleUsers: UserFilterItem[] = [];
  public listUsers: UserFilterItem[] = [];
  public groupData: Group[] = [];
  public projectData: Project[] = [];
  public confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };

  #unsubscribe = new Subject<void>();

  constructor(
    private readonly route: ActivatedRoute,
    private readonly store: StoreService,
    private readonly kmdModalService: KmdModalService,
    private readonly roleService: RoleService,
    private readonly userService: UserService,
    private readonly groupService: GroupService,
    private readonly projectService: ProjectService,
    private readonly userManagementService: UserManagementService,
    private readonly unassociatedService: UnassociatedService
  ) {
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Roles' }));
  }

  ngOnInit(): void {
    this.successMessage = this.route.snapshot.queryParamMap.get('success') === 'true';
    this.roleReferenceId = +this.route.snapshot.paramMap.get('id');
    if (this.roleReferenceId) {
      this.roleService.getRole(this.roleReferenceId).subscribe({
        next: (data) => {
          this.roleData = data;
        },
      });
    }
    this.getProjectsData();
    this.getGroupsData();
  }

  ngAfterViewChecked(): void {
    OPTIONS_COLUMN.popover.action.onClick = bindActionClick(OPTIONS_COLUMN, this.userListElement);
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  public openModal(modalId: string): void {
    this.kmdModalService.open(modalId);
  }

  public showHeadPopover(event: Event): void {
    event.preventDefault();
    const currentTarget = event.currentTarget as HTMLElement;
    this.posX = currentTarget.offsetLeft + currentTarget.clientWidth / 2;
    this.posY = currentTarget.offsetTop + currentTarget.clientHeight / 2;
  }

  public obsoleteRole(): void {
    this.obsoleteErrorMessage = '';
    this.openModal(ModalId.MakeRoleObsolete);
  }

  public obsoleteConfirm(): void {
    this.obsoleteErrorMessage = '';
    this.roleService
      .update({
        ...this.roleData,
        archived: true,
      })
      .subscribe({
        next: () => {
          this.successMessage = true;
          this.roleData.archived = true;
          this.kmdModalService.close(ModalId.MakeRoleObsolete);
        },
        error: () => {
          this.obsoleteErrorMessage = 'Unable to obsolete role. Please try again later.';
        },
      });
  }

  public onTabSelect(event: { activeId: TabKeys; nextId: TabKeys }): void {
    this.permissionTab = TabKeys.Permissions === event.nextId;
    if (event.nextId === TabKeys.Users) {
      this.getUsers();
    }
  }

  public openAssignUserModal(): void {
    this.successMessage = false;
    this.resetConfirmStatus();
    this.unassociatedService
      .getUnassociatedUsers(this.roleReferenceId)
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: UserFilterItem[]) => {
          this.listUsers = data.slice();
          this.openModal('assignUsers');
        },
      });
  }

  public onAddUserConfirm(confirmedData: ManageItemsRequest): void {
    this.resetConfirmStatus();
    this.userManagementService
      .addRoles({
        userIds: confirmedData.updateIds,
        updateIds: [this.roleReferenceId],
      })
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: () => {
          this.kmdModalService.close(ModalId.AssignUsers);
          this.getUsers();
          this.successMessage = true;
        },
        error: () => {
          this.confirmedStatus = {
            status: false,
            message: 'Unable to assign user(s) to role.',
          };
        },
      });
  }

  public getUsers(): void {
    this.userService
      .filter({
        top: DEFAULT_TOP,
        skip: DEFAULT_SKIP,
        roleId: this.roleReferenceId,
      })
      .subscribe({
        next: (data) => {
          this.usersCount = data.count;
          this.roleUsers = data.items.slice();
        },
        error: () => {
          this.roleUsers = [];
        },
      });
  }

  private resetConfirmStatus(): void {
    this.confirmedStatus = {
      status: true,
      message: '',
    };
  }

  private getGroupsData(): void {
    this.groupService
      .filter()
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (groupData: GroupResponse) => {
          this.groupData = groupData.items.slice();
          this.userColumns[5].filter.values = this.groupData.map((obj) => obj.name);
        },
      });
  }

  private getProjectsData(): void {
    this.projectService
      .filter()
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (projectData: ProjectResponse) => {
          this.projectData = projectData.items.slice();
          this.userColumns[5].filter.values = this.projectData.map((obj) => obj.name);
        },
      });
  }
}
