import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import {
  ButtonModule,
  AlertsModule,
  InputFieldsModule,
  PopoverModule,
  CheckboxModule,
  ModalsModule,
  TabsModule,
} from 'gds-atom-components';
import { RoleViewComponent } from './role-view.component';
import { UserListModule } from '../../users/shared/user-list/user-list.module';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { MakeObsoleteModule } from '../../shared/make-obsolete/make-obsolete.module';

@NgModule({
  declarations: [RoleViewComponent],
  imports: [
    CommonModule,
    ButtonModule,
    AlertsModule,
    CheckboxModule,
    InputFieldsModule,
    TabsModule,
    PopoverModule,
    ModalsModule,
    UserListModule,
    ManageItemsModule,
    MakeObsoleteModule,
    RouterModule.forChild([{ path: '', component: RoleViewComponent, pathMatch: 'full' }]),
  ],
})
export class RoleViewModule {}
