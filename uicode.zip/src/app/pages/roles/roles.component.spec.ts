import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { GridModule } from '../shared/grid/grid.module';
import { RolesComponent } from './roles.component';
import { ButtonModule, AlertsModule, TabsModule } from 'gds-atom-components';
import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { MakeObsoleteModule } from '../shared/make-obsolete/make-obsolete.module';

describe('RolesComponent', () => {
  let component: RolesComponent;
  let fixture: ComponentFixture<RolesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RolesComponent],
      imports: [
        GridModule,
        HttpClientTestingModule,
        RouterTestingModule,
        AlertsModule,
        ButtonModule,
        DropDownAutoCompleteModule,
        TabsModule,
        MakeObsoleteModule,
        AlertsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RolesComponent);
    component = fixture.componentInstance;
    component.data = [
      {
        id: 24,
        name: 'Role',
        description: 'Role description',
        rules: [],
      },
    ];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display create role button, have two tabs and with one grid item', () => {
    expect(fixture.debugElement.query(By.css('.create-role-head-btn')).nativeElement).toBeTruthy();
    expect(fixture.debugElement.queryAll(By.css('.nav-item')).length).toBe(2);
    expect(fixture.debugElement.queryAll(By.css('.k-grid-header tr')).length).toBe(1);
  });

  it('should display all tabs', () => {
    expect(fixture.debugElement.query(By.css('kmd-tabs')).nativeElement.textContent.trim()).toBe('Active Obsolete');
  });

  it('should load Active data by default', () => {
    expect(fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[0].nativeElement.getAttribute('id')).toEqual('roles-Active');
  });

  it('should load Obsoleted data', () => {
    expect(fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[1].nativeElement.getAttribute('id')).toEqual('roles-Obsoleted');
  });
});
