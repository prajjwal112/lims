import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ButtonModule, AlertsModule, InputFieldsModule, CheckboxModule } from 'gds-atom-components';

import { RoleDetailComponent } from './role-detail.component';

@NgModule({
  declarations: [RoleDetailComponent],
  imports: [CommonModule, ButtonModule, AlertsModule, CheckboxModule, InputFieldsModule, ReactiveFormsModule, FormsModule],
})
export class RoleDetailModule {}
