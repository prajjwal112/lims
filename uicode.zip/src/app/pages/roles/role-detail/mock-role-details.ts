import { Rule } from '../shared/role';

export const mockRuleDetails: Rule[] = [
  {
    name: 'Workflow definitions',
    types: [
      {
        name: 'WORKFLOW_CREATE_EDIT',
        title: 'Create and Edit',
        description: 'Create and edit Workflow Definitions using Task templates in the modeler',
      },
      {
        name: 'WORKFLOW_EDIT_DEFAULT_ASSIGNMENT',
        title: 'Edit Default Assignments',
        description: 'Change the default Users assigned to Tasks within a Workflow Definition',
      },
      {
        name: 'WORKFLOW_EDIT_VIEW',
        title: 'View',
        description: 'View Workflow Definition status page',
      },
    ],
  },
  {
    name: 'Workflow runs',
    types: [
      {
        name: 'WORKFLOW_POST',
        title: 'Create',
        description: 'Start a new Workflow instance',
      },
      {
        name: 'WORKFLOW_PUT',
        title: 'Edit',
        description: 'Modify the Workflow instance priority settings and terminate a run',
      },
      {
        name: 'WORKFLOW_GET',
        title: 'View',
        description: 'View Workflow instance summary pages',
      },
    ],
  },
  {
    name: 'Task instances',
    types: [
      {
        name: 'TASK_INSTANCE_ASSIGN_OTHERS',
        title: 'Assign Others',
        description: 'Assign other Users to Tasks',
      },
      {
        name: 'TASK_INSTANCE_CLAIM_TASKS',
        title: 'Claim Tasks',
        description: 'Assign unassigned or Group tasks to yourself',
      },
      {
        name: 'TASK_INSTANCE_EDIT_PRIORITY',
        title: 'Edit Priority',
        description: 'Change the priority of a Task instance',
      },
      {
        name: 'TASK_INSTANCE_EDIT_DUE_DATE',
        title: 'Edit Due Date',
        description: 'Change the due date of a Task instance',
      },
      {
        name: 'TASK_INSTANCE_BLOCK_UNBLOCK',
        title: 'Block/Unblock for Others',
        description: 'Block or unblock a Task assigned to another User',
      },
    ],
  },
  {
    name: 'Users',
    types: [
      {
        name: 'USERS_GET',
        title: 'View',
        description: 'View User lists and User details (Groups, Projects and Roles assigned)',
      },
    ],
  },
  {
    name: 'Groups',
    types: [
      {
        name: 'GROUPS_POST',
        title: 'Create',
        description: 'Create a Group',
      },
      {
        name: 'GROUPS_PUT',
        title: 'Edit',
        description: 'Change Group name and the assigned Users',
      },
      {
        name: 'GROUPS_GET',
        title: 'View',
        description: 'View Group information',
      },
    ],
  },
  {
    name: 'Projects',
    types: [
      {
        name: 'PROJECTS_POST',
        title: 'Create',
        description: 'Create a Project',
      },
      {
        name: 'PROJECTS_PUT',
        title: 'Edit',
        description: 'Edit the Name, Users, and Groups assigned to Projects',
      },
      {
        name: 'PROJECTS_GET',
        title: 'View',
        description: 'View Project information',
      },
    ],
  },
  {
    name: 'Roles',
    types: [
      {
        name: 'ROLES_CREATE_EDIT',
        title: 'Create and Edit',
        description: 'Create and edit a Role and the Users assigned',
      },
      {
        name: 'ROLES_PUT',
        title: 'Assign Roles',
        description: 'Assign Roles to Users',
      },
      {
        name: 'ROLES_GET',
        title: 'View',
        description: 'View Role information',
      },
    ],
  },
  {
    name: 'Organization Settings',
    types: [
      {
        name: 'ORGANIZATION_SETTINGS_PUT',
        title: 'View and Edit',
        description: 'View and edit Organization operation settings',
      },
    ],
  },
];
