import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { By } from '@angular/platform-browser';
import { of } from 'rxjs';
import { ReactiveFormsModule, FormsModule, FormControl, FormArray, FormGroup } from '@angular/forms';
import { ButtonModule, AlertsModule, InputFieldsModule, CheckboxModule } from 'gds-atom-components';

import { RoleDetailComponent } from './role-detail.component';
import { RoleService } from '../../../core/api/role/role.service';
import { mockRuleDetails } from './mock-role-details';

describe('RoleDetailComponent', () => {
  let component: RoleDetailComponent;
  let fixture: ComponentFixture<RoleDetailComponent>;
  let rolesService: RoleService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RoleDetailComponent],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        ReactiveFormsModule,
        FormsModule,
        ButtonModule,
        AlertsModule,
        InputFieldsModule,
        CheckboxModule,
      ],
      providers: [
        RoleService,
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ id: '0' }),
          },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(RoleDetailComponent);
    component = fixture.componentInstance;
    rolesService = component.roleService;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display name and description with no values', () => {
    expect(component.roleForm.get('name').value).toBeFalsy();
    expect(component.roleForm.get('description').value).toBeFalsy();
  });

  it('should have confirm button disabled when no fields are filled out', () => {
    component.roleForm.get('name').setValue('');
    component.roleForm.get('description').setValue('');
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#confirmButton')).nativeElement.disabled).toBe(true);
  });

  it('should have cancel button enabled on load', () => {
    expect(fixture.debugElement.query(By.css('#cancelButton')).nativeElement.disabled).toBe(false);
  });

  it('should display the rules details', () => {
    spyOn(rolesService, 'getRules').and.returnValue(of(mockRuleDetails));
    component.roleForm = new FormGroup({
      name: new FormControl(''),
      description: new FormControl(''),
      ruleControls: new FormArray([]),
    });
    component.getRules();
    fixture.detectChanges();

    expect(component.rules).toEqual(mockRuleDetails);
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[0].nativeElement.textContent.trim()).toBe('Workflow Definition');
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[1].nativeElement.textContent.trim()).toBe('Workflow Run');
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[2].nativeElement.textContent.trim()).toBe('Task Instance');
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[3].nativeElement.textContent.trim()).toBe('Users');
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[4].nativeElement.textContent.trim()).toBe('Groups');
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[5].nativeElement.textContent.trim()).toBe('Projects');
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[6].nativeElement.textContent.trim()).toBe('Roles');
    expect(fixture.debugElement.queryAll(By.css('.rule-container h6'))[7].nativeElement.textContent.trim()).toBe('Organization Settings');
  });
});
