import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';

import { StoreService, Action, ActionType } from '../../../store.service';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, ValidatorFn } from '@angular/forms';
import { Role, Rule } from '../shared/role';
import { RoleService } from '../../../core/api/role/role.service';
import { WorkflowHttpErrorResponse } from '../../../core/api/workflow-error';
import { CustomValidators } from '../../shared/custom-validators';

@Component({
  selector: 'app-role-detail',
  templateUrl: './role-detail.component.html',
  styleUrls: ['./role-detail.component.scss', '../../shared/page-header.scss'],
})
export class RoleDetailComponent implements OnDestroy {
  public rules: Rule[] = [];
  public roleReferenceId: number = null;
  public rulesData: string[] = [];
  public roleForm: FormGroup;
  public errorMessage = '';
  public fromViewPage = false;
  private unsubscribe = new Subject<void>();

  constructor(
    public roleService: RoleService,
    public formBuilder: FormBuilder,
    public route: ActivatedRoute,
    public router: Router,
    public store: StoreService
  ) {
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Roles' }));
    this.roleForm = this.formBuilder.group({
      name: new FormControl('', [Validators.required, CustomValidators.notBlank]),
      description: new FormControl('', [Validators.required, CustomValidators.notBlank]),
      ruleControls: this.formBuilder.array([], RoleDetailComponent.atLeastOneSelectedCheckboxes()),
    });
  }

  private static atLeastOneSelectedCheckboxes(): ValidatorFn {
    const validator: ValidatorFn = (formArray: FormArray) => {
      const selectedCount = formArray.controls.filter((control) => control.value?.length > 0);
      return selectedCount.length >= 1 ? null : { selected: true };
    };
    return validator;
  }

  get ruleControls(): FormArray {
    return this.roleForm.get('ruleControls') as FormArray;
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  public onSubmit(formValues): void {
    if (this.roleForm.invalid) {
      return;
    }
    this.roleService[this.roleReferenceId ? 'update' : 'create'](this.getRoleRequestData(formValues)).subscribe({
      next: () => {
        this.router.navigate([this.fromViewPage ? `/roles/${this.roleReferenceId}` : '/roles'], { queryParams: { success: true } });
      },
      error: (error: WorkflowHttpErrorResponse) => {
        this.errorMessage =
          error.status === 400
            ? error.error?.message || ''
            : `Unable to ${this.roleReferenceId ? 'update' : 'create'} role. Please try again later.`;
      },
    });
  }

  public navigateToRoles(): void {
    this.router.navigate([this.fromViewPage ? `/roles/${this.roleReferenceId}` : '/roles']);
  }

  public getRules(): void {
    let index = 0;
    this.roleService.getRules().subscribe({
      next: (data) => {
        this.rules = this.removeElementFromArray(data.slice());
        this.rules.forEach((rule) => {
          rule.name = rule.name.replace(/_/g, ' ');
          if (rule.name === 'Workflow definitions' || rule.name === 'Workflow runs' || rule.name === 'Task instances') {
            rule.name = rule.name.substring(0, rule.name.length - 1);
          }
          rule.types.forEach((type) => {
            type.index = index++;
            const ruleValue = this.rulesData.indexOf(type.name) !== -1 ? type.name : '';
            this.ruleControls.push(this.formBuilder.control(ruleValue ? [ruleValue] : false));
          });
        });
      },
    });
  }

  private removeElementFromArray(rules: Rule[]): Rule[] {
    return rules.filter((rule) => rule.name !== 'Reports');
  }

  private getRoleRequestData(formValues): Role {
    return {
      id: this.roleReferenceId,
      name: (formValues.name || '').trim(),
      description: (formValues.description || '').trim(),
      rules: [].concat(...formValues.ruleControls).filter((rule) => rule),
    };
  }
}
