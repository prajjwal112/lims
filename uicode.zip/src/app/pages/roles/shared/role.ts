export interface Role {
  referenceId?: number;
  id: number;
  name: string;
  description: string;
  archived?: boolean;
  rules: string[];
  ruleDetails?: Rule[];
  privileged?: boolean;
}

export interface RoleListRequest {
  id?: number;
  top?: number;
  skip?: number;
  name?: string;
  sort?: string;
  archived?: boolean;
}

export interface RoleListResponse {
  count: number;
  items: Role[];
}

export interface UpdateRoleRequest {
  id?: number;
  name?: string;
  description?: string;
  archived?: boolean;
  privileged?: boolean;
  rules?: string[];
}

export interface CreateRoleRequest extends UpdateRoleRequest {
  name: string;
  description: string;
}

export interface UpdateRoleResponse {
  id: number;
  name: string;
  description: string;
  archived?: boolean;
  privileged: boolean;
}

export interface Rule {
  name: string;
  types: RuleType[];
}

export interface RuleType {
  index?: number;
  name: string;
  title: string;
  description: string;
}
