import { ColumnType } from '../../shared/grid/column-type';
import { defaultActionPopoverColumn } from '../../shared/grid/popover/action/action-popover';
import type { Column } from '../../shared/grid/column';

export const ROLE_NAME_COLUMN: Readonly<Column> = {
  type: ColumnType.Link,
  field: 'name',
  title: 'Role Name',
  width: 120,
  sortable: true,
  filterable: false,
  linkPath: '/roles',
} as const;

export const ROLE_DESCRIPTION_COLUMN: Column = {
  type: ColumnType.String,
  field: 'description',
  title: 'Description',
  width: 320,
  sortable: false,
  filterable: false,
} as const;

export const ROLE_OPTIONS_COLUMN: Readonly<Column> = {
  ...defaultActionPopoverColumn([
    { name: 'editRole', display: 'Edit role' },
    { name: 'obsoleteRole', display: 'Obsolete role' },
  ]),
} as const;
