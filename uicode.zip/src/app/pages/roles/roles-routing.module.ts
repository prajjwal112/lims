import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RolesComponent } from './roles.component';
import { AuthGuard } from '../../auth-guard';

const routes: Routes = [
  {
    path: '',
    component: RolesComponent,
    pathMatch: 'full',
    canActivate: [AuthGuard],
  },
  {
    path: ':id',
    loadChildren: () => import('./role-view/role-view.module').then(m => m.RoleViewModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'details/new',
    loadChildren: () => import('./new-role/new-role.module').then(m => m.NewRoleModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'details/edit/:id',
    loadChildren: () => import('./edit-role/edit-role.module').then(m => m.EditRoleModule),
    canActivate: [AuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RolesRoutingModule {}
