import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ButtonModule, AlertsModule, InputFieldsModule, CheckboxModule } from 'gds-atom-components';
import { NewRoleComponent } from './new-role.component';
import { RoleDetailModule } from '../role-detail/role-detail.module';

@NgModule({
  declarations: [NewRoleComponent],
  imports: [
    CommonModule,
    ButtonModule,
    AlertsModule,
    CheckboxModule,
    InputFieldsModule,
    ReactiveFormsModule,
    FormsModule,
    RoleDetailModule,
    RouterModule.forChild([{ path: '', component: NewRoleComponent, pathMatch: 'full' }]),
  ],
})
export class NewRoleModule {}
