import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GridModule } from '../shared/grid/grid.module';
import { RolesRoutingModule } from './roles-routing.module';
import { RolesComponent } from './roles.component';
import { ButtonModule, AlertsModule, TabsModule } from 'gds-atom-components';
import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { MakeObsoleteModule } from '../shared/make-obsolete/make-obsolete.module';

@NgModule({
  declarations: [RolesComponent],
  imports: [
    ButtonModule,
    CommonModule,
    RolesRoutingModule,
    GridModule,
    DropDownAutoCompleteModule,
    TabsModule,
    AlertsModule,
    MakeObsoleteModule,
  ],
  providers: [],
})
export class RolesModule {}
