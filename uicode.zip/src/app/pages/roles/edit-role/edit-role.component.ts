import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

import { StoreService } from '../../../store.service';
import { RoleService } from '../../../core/api/role/role.service';
import { RoleDetailComponent } from '../role-detail/role-detail.component';

@Component({
  selector: 'app-edit-role',
  templateUrl: '../role-detail/role-detail.component.html',
  styleUrls: ['../role-detail/role-detail.component.scss', '../../shared/page-header.scss'],
})
export class EditRoleComponent extends RoleDetailComponent implements OnInit {
  constructor(
    public roleService: RoleService,
    public formBuilder: FormBuilder,
    public route: ActivatedRoute,
    public router: Router,
    public store: StoreService
  ) {
    super(roleService, formBuilder, route, router, store);
  }

  ngOnInit(): void {
    this.route.params.subscribe({
      next: (param) => {
        this.roleReferenceId = +param.id;
      },
    });
    this.route.queryParams.subscribe({
      next: (queryParam) => {
        this.fromViewPage = queryParam.from === 'view';
      },
    });

    this.roleService
      .getRole(this.roleReferenceId)
      .subscribe({
        next: (data) => {
          this.roleForm.controls.name.setValue(data.name);
          this.roleForm.controls.description.setValue(data.description);
          this.rulesData = data.rules;
        },
      })
      .add(() => {
        this.getRules();
      });
  }
}
