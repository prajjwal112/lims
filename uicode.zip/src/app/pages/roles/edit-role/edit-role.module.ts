import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ButtonModule, AlertsModule, InputFieldsModule, CheckboxModule } from 'gds-atom-components';
import { EditRoleComponent } from './edit-role.component';

@NgModule({
  declarations: [EditRoleComponent],
  imports: [
    CommonModule,
    ButtonModule,
    AlertsModule,
    CheckboxModule,
    InputFieldsModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild([{ path: '', component: EditRoleComponent, pathMatch: 'full' }]),
  ],
})
export class EditRoleModule {}
