import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskInputsComponent } from './task-inputs.component';
import { BasicTaskFormInput, DateTaskFormInput, SelectTaskFormInput, TaskFormInputType } from '../../../shared/task-detail';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownsModule, ToggleModule } from 'gds-atom-components';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { MultiSelectInputComponent } from '../multi-select-input/multi-select-input.component';
import { SingleSelectInputComponent } from '../single-select-input/single-select-input.component';
import { BasicInputComponent } from '../basic-input/basic-input.component';
import { DateInputComponent } from '../date-input/date-input.component';

const MULTI_SELECT: SelectTaskFormInput = {
  type: TaskFormInputType.Text,
  name: 'multi-select-field',
  displayName: 'Multi Select Field',
  sequence: 1,
  multiple: true,
  items: ['Item One', 'Item Two'],
  mandatory: true,
  defaultValue: '',
};
const TEXT: BasicTaskFormInput = {
  type: TaskFormInputType.Text,
  name: 'text-field',
  displayName: 'Text Field',
  sequence: 3,
  mandatory: true,
  defaultValue: '',
};
const NUMERIC: BasicTaskFormInput = {
  type: TaskFormInputType.Numeric,
  name: 'numeric-field',
  displayName: 'Numeric Field',
  sequence: 4,
  mandatory: true,
  defaultValue: '',
};
const TEXTAREA: BasicTaskFormInput = {
  type: TaskFormInputType.Textarea,
  name: 'textarea-field',
  displayName: 'Textarea Field',
  sequence: 5,
  mandatory: true,
  defaultValue: '',
};
const BOOLEAN: BasicTaskFormInput = {
  type: TaskFormInputType.Boolean,
  name: 'boolean-field',
  displayName: 'Boolean Field',
  sequence: 6,
  mandatory: true,
  defaultValue: '',
};
const DATE: DateTaskFormInput = {
  type: TaskFormInputType.Date,
  name: 'date-field',
  displayName: 'Date Field',
  sequence: 7,
  mandatory: true,
  defaultValue: '',
  defaultToCurrentDate: false,
};
const SINGLE_SELECT: SelectTaskFormInput = {
  type: TaskFormInputType.Numeric,
  name: 'single-select-field',
  displayName: 'Single Select Field',
  sequence: 10,
  multiple: false,
  items: ['10', '20'],
  mandatory: true,
  defaultValue: '',
};

describe('TaskInputsComponent', () => {
  let component: TaskInputsComponent;
  let fixture: ComponentFixture<TaskInputsComponent>;
  const getInputsContainerText = (): string => fixture.debugElement.query(By.css('#inputsForm')).nativeElement.textContent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskInputsComponent, MultiSelectInputComponent, SingleSelectInputComponent, BasicInputComponent, DateInputComponent],
      imports: [FormsModule, ReactiveFormsModule, ToggleModule, DatePickerModule, DropdownsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskInputsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no inputs by default', () => {
    expect(getInputsContainerText()).toBe('');
  });

  it('should properly sequence all of the inputs', () => {
    component.taskInput = JSON.stringify({
      basics: [NUMERIC, BOOLEAN, TEXT, TEXTAREA],
      dates: [DATE],
      selects: [SINGLE_SELECT, MULTI_SELECT],
    });
    component.ngOnInit();
    fixture.detectChanges();

    expect(getInputsContainerText()).toMatch(
      new RegExp(
        // eslint-disable-next-line max-len
        `${MULTI_SELECT.displayName}.*${TEXT.displayName}.*${NUMERIC.displayName}.*${TEXTAREA.displayName}.*${BOOLEAN.displayName}.*${DATE.displayName}.*${SINGLE_SELECT.displayName}`
      )
    );
  });
});
