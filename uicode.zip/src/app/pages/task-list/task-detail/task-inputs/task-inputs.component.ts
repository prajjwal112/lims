import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChange, SimpleChanges } from '@angular/core';
import type { BasicTaskFormInput, DateTaskFormInput, TaskFormInput, WorkflowTaskInput } from '../../../shared/task-detail';
import { TaskFormInputType, TaskInputType } from '../../../shared/task-detail';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { isEmpty, isEqual, sortBy, xorWith } from 'lodash';
import type { TaskActionVariable } from '../../../modeler/task-configuration/task-action/task-template';
import { ValidFormService } from '../../../../core/api/valid-form/valid-form.service';

@Component({
  selector: 'app-task-inputs',
  templateUrl: './task-inputs.component.html',
  styleUrls: ['./task-inputs.component.scss'],
})
export class TaskInputsComponent implements OnInit, OnChanges {
  @Input() taskInput: string;
  @Input() taskCompleted = false;
  @Input() variables: Record<string, unknown>;
  @Output() inputChange = new EventEmitter<TaskActionVariable>();
  @Output() validateInput = new EventEmitter<boolean>();

  readonly taskInputType = TaskInputType;
  readonly taskInputFormType = TaskFormInputType;
  readonly inputsForm = new FormGroup({});

  inputs: WorkflowTaskInput[] = [];
  currentDate = new Date();

  constructor(private readonly validFormService: ValidFormService) {}

  private static shouldRepopulateInputs(taskInputChange: SimpleChange): boolean {
    return (
      taskInputChange?.currentValue &&
      (!taskInputChange?.previousValue ||
        !isEmpty(xorWith(taskInputChange?.previousValue.basics, taskInputChange?.currentValue.basics, isEqual)) ||
        !isEmpty(xorWith(taskInputChange?.previousValue.dates, taskInputChange?.currentValue.dates, isEqual)) ||
        !isEmpty(xorWith(taskInputChange?.previousValue.selects, taskInputChange?.currentValue.selects, isEqual)))
    );
  }

  private static buildInputs(taskInput: string): WorkflowTaskInput[] {
    const parsedTaskInput: TaskFormInput = JSON.parse(taskInput);
    let inputs: WorkflowTaskInput[] = [];

    if (parsedTaskInput.basics) {
      inputs = inputs.concat(parsedTaskInput.basics.map((input) => ({ ...input, taskInputType: TaskInputType.Basic })));
    }

    if (parsedTaskInput.dates) {
      inputs = inputs.concat(parsedTaskInput.dates.map((input) => ({ ...input, taskInputType: TaskInputType.Date })));
    }

    if (parsedTaskInput.selects) {
      inputs = inputs.concat(parsedTaskInput.selects.map((input) => ({ ...input, taskInputType: TaskInputType.Select })));
    }
    return inputs;
  }

  ngOnInit(): void {
    if (this.taskInput) {
      this.populateInputs(this.taskInput);
    }
    this.validFormService.setValid(this.inputsForm.valid);
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.repopulateInputs(changes);
    this.currentDate = new Date();
    this.validateInput.emit(this.inputsForm.valid);
  }

  private repopulateInputs(changes: SimpleChanges): void {
    if (Object.keys(changes).length !== 0 && !Object.keys(changes).includes('taskInput')) {
      return;
    }
    const taskInputChange = changes.taskInput;

    if (!taskInputChange || !taskInputChange.currentValue) {
      this.clearInputs();
      return;
    }

    if (TaskInputsComponent.shouldRepopulateInputs(taskInputChange)) {
      this.populateInputs(taskInputChange.currentValue);
    }
  }

  private populateInputs(taskInput: string): void {
    this.clearInputs();
    this.inputs = sortBy(TaskInputsComponent.buildInputs(taskInput), ['sequence']);

    for (const input of this.inputs) {
      const control = new FormControl(null, Validators.required);

      if ((input as DateTaskFormInput).defaultToCurrentDate) {
        control.setValue(this.currentDate);
        this.inputChange.emit({ name: input.name, type: 'DATE', value: this.currentDate.toLocaleDateString('en-US') });
        this.validFormService.setValid(this.inputsForm.valid);
      }
      if (input.type && (input as BasicTaskFormInput).type === TaskFormInputType.Boolean) {
        if (!control.value) {
          control.setValue(false);
          this.inputChange.emit({ name: input.name, type: 'BOOLEAN', value: 'false' });
          this.validFormService.setValid(this.inputsForm.valid);
        }
      }
      this.inputsForm.addControl(input.name, control);
    }
  }

  private clearInputs(): void {
    this.inputs = [];
    for (const input of this.inputs) {
      this.inputsForm.removeControl(input.name);
    }
  }
}
