import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { SimpleChange } from '@angular/core';
import { AlertsModule } from 'gds-atom-components';
import { TaskHeaderComponent } from './task-header.component';
import { PriorityPillModule } from '../../../shared/grid/priority-pill/priority-pill.module';
import { StatusPillModule } from '../../../shared/grid/status-pill/status-pill.module';
import { WorkflowPipeModule } from '../../../../core/pipe/workflow-pipe.module';
import { CamundaServerVariable } from '../../../shared/camunda-variable';
import { Status } from '../../../shared/status';
import { DateLabelModule } from '../../../shared/date-label/date-label.module';
import { DueDateLabelModule } from '../../../shared/due-date-label/due-date-label.module';
import { DetailsHeaderModule } from 'src/app/pages/shared/details-header/details-header.module';
import { FieldTooltipModule } from 'src/app/pages/shared/grid/field-tooltip/field-tooltip.module';
import { ModalId } from '../../../shared/modal-id';

describe('TaskHeaderComponent', () => {
  let component: TaskHeaderComponent;
  let fixture: ComponentFixture<TaskHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskHeaderComponent],
      imports: [
        NoopAnimationsModule,
        PriorityPillModule,
        StatusPillModule,
        DateLabelModule,
        DueDateLabelModule,
        HttpClientTestingModule,
        WorkflowPipeModule,
        RouterTestingModule,
        AlertsModule,
        DetailsHeaderModule,
        FieldTooltipModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskHeaderComponent);
    component = fixture.componentInstance;
    component.taskDetail = {
      taskInstanceReferenceId: 1,
      status: Status.InProgress,
      dueDate: new Date(2019, 5, 30).toISOString().slice(0, -1),
      priority: 76,
      id: '123THSY6',
      name: 'Axiom GenoTyping',
      processDefinitionName: 'Test Workflow',
      assignees: [
        {
          id: 1,
          firstName: 'Test',
          lastName: 'Assignee',
          email: 'test.assignee@company.com',
          admin: false,
          active: true,
          projects: [],
          roles: [],
          groups: [],
        },
      ],
      groupAssignees: [],
      projects: [{ id: 1, name: 'Test Project' }],
      taskVariables: {
        [CamundaServerVariable.Endpoint]: '',
      },
      backingEntity: {
        type: 'type',
        identifiers: ['91W123', '96W345', '96W789'],
        connectionInformation: {},
      },
    };
    component.shouldExpand = true;
    component.showSecondaryButton = true;
    component.secondaryButtonText = 'Open application';
    component.taskStarted = true;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display all details when expanded', () => {
    expect(fixture.debugElement.query(By.css('app-due-date-label')).nativeElement.textContent.trim()).toBe('Jun 30, 2019 12:00 AM');
  });

  it('should display limited details when not expanded', () => {
    component.shouldExpand = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-due-date-label'))).toBeNull();
  });

  it('should not display due date when there is no due date', () => {
    delete component.taskDetail.dueDate;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.all()).nativeElement.textContent).toContain('Due: Not applicable');
  });

  it('should not offset create button when there is secondary button text', () => {
    expect(fixture.debugElement.query(By.css('.offset-2'))).toBeNull();
  });

  it('Tooltip data for single project should have one string value in array', () => {
    component.ngOnChanges({
      taskDetail: new SimpleChange(null, component.taskDetail, true),
    });
    fixture.detectChanges();

    expect(component.tooltipProjects).toEqual(['Test Project']);
  });

  it('Tooltip data for multiple projects should have multiple string values in array', () => {
    component.taskDetail.projects.push({ id: 2, name: 'another project' });
    component.ngOnChanges({
      taskDetail: new SimpleChange(null, component.taskDetail, true),
    });
    fixture.detectChanges();

    expect(component.tooltipProjects).toEqual(['Test Project', 'another project']);
  });

  it('should open change priority modal when change priority option is clicked', () => {
    const id = ModalId.ChangePriority;
    spyOn(component, 'openModal').and.callThrough();
    fixture.debugElement.queryAll(By.css('kmd-popover ul.no-style-action-list li'))[0].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.openModal).toHaveBeenCalledWith(id);
  });

  it('should open change assignment modal when change assignment option is clicked', () => {
    const id = ModalId.ChangeAssignment;
    spyOn(component, 'openModal').and.callThrough();
    fixture.debugElement.queryAll(By.css('kmd-popover ul.no-style-action-list li'))[1].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.openModal).toHaveBeenCalledWith(id);
  });

  it('should show complete task success alert', () => {
    component.taskCompletedAlert = 'mock-message';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('kmd-alerts[kmd-success]'))[0].nativeElement.getAttribute('ng-reflect-show')).toBe('true');
  });

  it('should show complete task error alert', () => {
    component.completeTaskErrorMessage = 'mock-error';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('kmd-alerts[kmd-error]'))[0].nativeElement.getAttribute('ng-reflect-show')).toBe('true');
  });

  it('should show save task success alert', () => {
    component.taskSavedAlert = 'Your changes were saved.';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('kmd-alerts[kmd-success]'))[1].nativeElement.getAttribute('ng-reflect-show')).toBe('true');
  });

  it('should show save task error alert', () => {
    component.saveTaskErrorMessage = 'mock-error';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('kmd-alerts[kmd-error]'))[1].nativeElement.getAttribute('ng-reflect-show')).toBe('true');
  });
});
