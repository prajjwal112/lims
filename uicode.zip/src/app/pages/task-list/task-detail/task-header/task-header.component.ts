import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ItemizedTooltipType, WorkflowItemizedTooltipPipe } from 'src/app/core/pipe/itemized-tooltip/workflow-itemized-tooltip.pipe';
import { ModalId } from '../../../shared/modal-id';
import { isStatusInactive } from '../../../shared/task-detail';
import type { OnChanges, SimpleChanges } from '@angular/core';
import type { TaskDetail } from '../../../shared/task-detail';

@Component({
  selector: 'app-task-header',
  templateUrl: './task-header.component.html',
  styleUrls: ['./task-header.component.scss'],
  providers: [WorkflowItemizedTooltipPipe],
})
export class TaskHeaderComponent implements OnChanges {
  readonly modalId = ModalId;

  @Input() taskDetail: TaskDetail;
  @Input() shouldExpand: boolean;
  @Input() showSecondaryButton: boolean;
  @Input() secondaryButtonText: string;
  @Input() taskStarted: boolean;
  @Input() userCanAccessTask: boolean;
  @Input() taskActionMessageForTooltip: string;
  @Input() completeTaskErrorMessage: string;
  @Input() saveTaskErrorMessage: string;
  @Input() taskCompletedAlert: string;
  @Input() taskSavedAlert: string;
  @Input() taskCompleted: boolean;
  @Input() validInput: boolean;
  @Input() assignee: string;
  @Output() secondaryButtonClick = new EventEmitter<void>();
  @Output() startTaskButtonClick = new EventEmitter<void>();
  @Output() completeTaskButtonClick = new EventEmitter<void>();
  @Output() saveButtonClick = new EventEmitter<void>();
  @Output() popoverOptionClick = new EventEmitter<string>();
  public posX: number = null;
  public posY: number = null;

  projects = '';
  tooltipProjects: string[] = [];
  disableChangeDueDateOption = true;

  constructor(private readonly router: Router, private readonly workflowItemizedPipe: WorkflowItemizedTooltipPipe) {}

  ngOnChanges(simpleChanges: SimpleChanges): void {
    this.onTaskDetailChange(simpleChanges);
  }

  /**
   * Navigates to the tasks page
   */
  public goToMyTasks(): void {
    this.router.navigate(['/my-tasks']);
  }

  public showHeadPopover(event: Event): void {
    event.preventDefault();
    const currentTarget = event.currentTarget as HTMLElement;
    this.posX = currentTarget.offsetLeft + currentTarget.clientWidth / 2;
    this.posY = currentTarget.offsetTop + currentTarget.clientHeight / 2;
  }

  public openModal(id: string): void {
    this.popoverOptionClick.emit(id);
  }

  private onTaskDetailChange(changes: SimpleChanges): void {
    if (!changes.taskDetail) {
      return;
    }

    const taskDetail: TaskDetail = changes.taskDetail.currentValue;
    this.tooltipProjects = taskDetail?.projects?.length > 0 ? taskDetail.projects.map((project) => project.name).sort() : [];
    this.projects = this.workflowItemizedPipe.transform(this.tooltipProjects, ItemizedTooltipType.FirstItemThenRemainingCount);
    this.disableChangeDueDateOption = !taskDetail?.dueDate || isStatusInactive(taskDetail);
  }
}
