import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';

import { TaskInformationService } from './task-information.service';
import { ValidFormService } from '../../../core/api/valid-form/valid-form.service';
import { BaseInputDirective } from './base-input.directive';
import { BasicTaskFormInput, SelectTaskFormInput, TaskFormInputType } from '../../shared/task-detail';

@Component({
  selector: 'app-concrete-component-with-modal',
  template: '<div></div>',
})
class ConcreteBaseInputComponent extends BaseInputDirective<BasicTaskFormInput> {
  constructor(protected readonly taskInformationService: TaskInformationService, protected readonly validFormService: ValidFormService) {
    super(taskInformationService, validFormService);
  }
}

describe('BaseInputDirective', () => {
  let component: BaseInputDirective<BasicTaskFormInput>;
  let fixture: ComponentFixture<BaseInputDirective<BasicTaskFormInput>>;

  const TEXT: BasicTaskFormInput = {
    type: TaskFormInputType.Text,
    name: 'text-field',
    displayName: 'Text Field',
    sequence: 3,
    mandatory: true,
    defaultValue: '',
  };
  const NUMERIC: BasicTaskFormInput = {
    type: TaskFormInputType.Numeric,
    name: 'numeric-field',
    displayName: 'Numeric Field',
    sequence: 4,
    mandatory: true,
    defaultValue: '',
  };
  const BOOLEAN: BasicTaskFormInput = {
    type: TaskFormInputType.Boolean,
    name: 'boolean-field',
    displayName: 'Boolean Field',
    sequence: 6,
    mandatory: true,
    defaultValue: '',
  };

  const SINGLE_SELECT_NUMERIC: SelectTaskFormInput = {
    type: TaskFormInputType.Numeric,
    name: 'single-select-field',
    displayName: 'Single Select Field',
    sequence: 10,
    multiple: false,
    items: ['10', '20'],
    mandatory: true,
    defaultValue: '',
  };

  const createControl = (name: string): void => {
    component.inputsForm.addControl(name, new FormControl(null));
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConcreteBaseInputComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConcreteBaseInputComponent);
    component = fixture.componentInstance;
    component.inputsForm = new FormGroup({});
    fixture.detectChanges();
  });

  it('should create an instance', () => {
    expect(component).toBeTruthy();
  });

  const TEST: [BasicTaskFormInput, string | boolean | number][] = [
    [TEXT, 'mock-value'],
    [BOOLEAN, true],
    [NUMERIC, '10'],
    [SINGLE_SELECT_NUMERIC, '1'],
  ];
  for (const [input, value] of TEST) {
    it(`should prepopulate ${input.type} if variable is present`, () => {
      component.input = input;
      component.readOnly = false;
      createControl(input.name);
      component.variables = { [input.name]: value };
      component.ngOnInit();
      fixture.detectChanges();

      expect(component.inputsForm.controls[input.name].value).toEqual(value);
    });
  }
});
