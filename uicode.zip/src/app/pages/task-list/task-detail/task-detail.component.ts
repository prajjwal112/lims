import { Component } from '@angular/core';
import type { OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Subject } from 'rxjs';
import { delay, startWith, switchMap, take, takeUntil } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';

import { TaskService } from '../../../core/api/task/task.service';
import { ValidFormService } from '../../../core/api/valid-form/valid-form.service';
import { UserService } from '../../../core/api/user/user.service';
import { GroupService } from '../../../core/api/group/group.service';
import { Status } from '../../shared/status';
import { CamundaServerVariable } from '../../shared/camunda-variable';
import { TaskActionVariable } from '../../modeler/task-configuration/task-action/task-template';
import { AssigneeUtility } from '../../shared/utility/assignee-utility';
import { DefaultAssignmentTab } from '../../workflow-definitions/default-assignment/default-assignment';
import { ItemsForActionDirective } from '../../shared/items-for-action.directive';
import { ChangeDueDateComponent } from '../../shared/change-due-date/change-due-date.component';
import { ModalId } from '../../shared/modal-id';
import type { DefaultAssignmentItems } from '../../workflow-definitions/default-assignment/default-assignment';
import type { TaskStartResponse } from '../shared/task';
import type { FormattedBackingEntity, TaskDetail } from '../../shared/task-detail';
import type { TabConfig } from '../../shared/tabconfig';
import type { ActionItemRequest } from '../shared/task-filter';
import type { IsoDate } from '../../../core/app-settings';
import { ChangePriorityService } from '../../../core/api/change-priority.service';

enum ErrorCode {
  Unauthorized = 401,
  NotFound = 404,
}

const ERROR_CODE_TO_COMPLETE_MESSAGE = Object.freeze({
  [ErrorCode.Unauthorized]: 'Only the task assignee(s) or authorized users may complete a task.',
  [ErrorCode.NotFound]: 'Data that is required to complete a task is not found. There might be undefined input or output variables.',
});
const DEFAULT_COMPLETE_ERROR_MESSAGE = 'An error occurred while completing the task. Please contact support.';

@Component({
  selector: 'app-task-detail',
  templateUrl: './task-detail.component.html',
  styleUrls: ['./task-detail.component.scss', '../../shared/page-header.scss'],
})
export class TaskDetailComponent extends ItemsForActionDirective implements OnInit {
  private static readonly defaultBackingEntitiesLabel = 'Entity Reference(s)';
  readonly #unsubscribe: Readonly<Subject<void>> = new Subject();
  readonly status = Status;
  readonly serverCamundaVariable = CamundaServerVariable;
  readonly tabConfig: Readonly<TabConfig> = {
    users: {
      name: 'Users',
      id: DefaultAssignmentTab.User,
      propertyId: 'id',
      columns: [{ name: 'fullName', title: 'Name', sortable: true }],
      filterKey: 'fullName',
    },
    groups: {
      name: 'Groups',
      id: DefaultAssignmentTab.Group,
      propertyId: 'id',
      columns: [{ name: 'name', title: 'Name', sortable: true }],
      filterKey: 'name',
    },
  };

  public taskDetail: TaskDetail;
  public taskOutputVariables: Record<string, string>;
  public backingEntitiesLabel = '';
  public backingEntities: FormattedBackingEntity[] = [];
  public variables: Record<string, unknown>;
  public taskVariables: Record<string, unknown>;
  public expandTaskHeader = true;
  public showSecondaryButton = false;
  public secondaryButtonText = '';
  public completeTaskErrorMessage = '';
  public saveTaskErrorMessage = '';
  public taskActionMessageForTooltip = '';
  public userCanAccessTask = false;
  public taskStarted = false;
  public taskCompletedAlert = '';
  public taskSavedAlert = '';
  public taskCompleted = false;
  public taskHasEndpoint = false;
  public shouldOpenEndpoint = false;
  public inputVariables = new Map<string, TaskActionVariable>();
  public enableComplete: boolean;
  public assignee = '';
  public priorityErrorMessage = '';

  #selectedItems: number[] = [];

  constructor(
    protected readonly kmdModalService: KmdModalService,
    protected readonly userService: UserService,
    protected readonly groupService: GroupService,
    protected readonly taskService: TaskService,
    private readonly route: ActivatedRoute,
    private readonly validFormService: ValidFormService,
    private readonly changePriorityService: ChangePriorityService
  ) {
    super(kmdModalService, userService, groupService, taskService);
  }

  static getStartTaskErrorMessage(errorStatus: number): string {
    return errorStatus === ErrorCode.Unauthorized
      ? 'Only the task assignee(s) or authorized users may start a task.'
      : 'An error occurred while starting the task. Please contact support.';
  }

  private static extractBackingEntitiesLabel(detail: TaskDetail): string {
    return detail.backingEntity?.label ? detail.backingEntity.label : TaskDetailComponent.defaultBackingEntitiesLabel;
  }

  private static buildBackingEntities(taskDetail: TaskDetail): FormattedBackingEntity[] {
    if (!taskDetail.backingEntity || !taskDetail.backingEntity.identifiers) {
      return [];
    }

    const backingEntities = [];

    for (const [i, identifier] of taskDetail.backingEntity.identifiers.entries()) {
      backingEntities[i] = TaskDetailComponent.buildBackingEntity(identifier, taskDetail.backingEntity.connectionInformation.endpoint);
    }

    return backingEntities;
  }

  private static buildBackingEntity(identifier: string, backingEntityEndpoint?: string): FormattedBackingEntity {
    return backingEntityEndpoint
      ? { identifier, endpoint: backingEntityEndpoint.replace('{{tf_backingEntityIdentifiersPlaceholder}}', identifier) }
      : { identifier };
  }

  private static buildVariables(data: TaskDetail): Record<string, unknown> {
    return Object.assign({}, data.processInstanceVariables, data.taskVariables);
  }

  private static getCompleteTaskErrorMessage(errorStatus: number): string {
    return ERROR_CODE_TO_COMPLETE_MESSAGE[errorStatus] ?? DEFAULT_COMPLETE_ERROR_MESSAGE;
  }

  ngOnInit(): void {
    this.route.paramMap.pipe(switchMap((params: ParamMap) => this.taskService.getTaskDetail(+params.get('id')))).subscribe({
      next: (data: TaskDetail) => {
        this.taskDetail = data;
        this.assignee = AssigneeUtility.buildAssigneeNames(this.taskDetail);
        this.taskStarted = this.taskDetail.status === Status.InProgress;
        this.taskCompleted = this.taskDetail.status === Status.Completed;
        this.backingEntitiesLabel = TaskDetailComponent.extractBackingEntitiesLabel(data);
        this.backingEntities = TaskDetailComponent.buildBackingEntities(data);
        this.variables = TaskDetailComponent.buildVariables(data);
        this.taskVariables = data.taskVariables;
        this.taskHasEndpoint = data.taskVariables && !!data.taskVariables[CamundaServerVariable.Endpoint];
      },
    });

    this.route.paramMap.pipe(switchMap((params: ParamMap) => this.taskService.getStartTaskEligibility(+params.get('id')))).subscribe({
      next: () => {
        this.userCanAccessTask = true;
      },
      error: (error: HttpErrorResponse) => {
        this.userCanAccessTask = false;
        this.taskActionMessageForTooltip = TaskDetailComponent.getStartTaskErrorMessage(error.status);
      },
    });

    this.validFormService
      .getValid()
      .pipe(startWith(true), delay(0), takeUntil(this.#unsubscribe))
      .subscribe((valid) => (this.enableComplete = valid));
  }

  onSecondaryButtonClick(): void {
    if (this.taskHasEndpoint) {
      this.closeEndpoint();
    }
  }

  onPopoverOptionClick(event: string): void {
    if (event === ModalId.ChangeAssignment) {
      super.openChangeAssignment(this.taskDetail.projects);
    } else {
      this.selectedTaskReferenceIds = [{ workflowId: this.taskDetail.taskInstanceReferenceId, camundaId: this.taskDetail.id }];
      this.kmdModalService.open(event);
    }
  }

  onSelectedItemsChange(event: number[]): void {
    this.#selectedItems = event;
  }

  onConfirmAssignee(event: DefaultAssignmentItems): void {
    this.updateTaskActionItems(
      TaskService.buildAssigneeRequest(event, this.#selectedItems),
      ModalId.ChangeAssignment,
      'Unable to change assignment.'
    );
  }

  onChangeDueDateConfirm(newDueDate: IsoDate): void {
    this.updateTaskActionItems({ dueDate: newDueDate }, ModalId.ChangeDueDate, ChangeDueDateComponent.errorMessage);
  }

  onConfirmPriority(priority: number): void {
    this.changePriorityService
      .updateTaskPriorities(priority, this.selectedTaskReferenceIds)
      .pipe(take(1))
      .subscribe({
        next: () => {
          this.kmdModalService.close(ModalId.ChangePriority);
          this.ngOnInit();
        },
        error: () => {
          this.priorityErrorMessage = 'Unable to change task priority.';
        },
      });
  }

  startTask(): void {
    this.taskService
      .startTask(this.taskDetail.taskInstanceReferenceId)
      .pipe(take(1))
      .subscribe({
        next: (response: TaskStartResponse) => {
          this.refreshTaskDetailAfterStart(response);
        },
      });
    this.taskStarted = true;
    this.route.paramMap.pipe(switchMap((params: ParamMap) => this.taskService.getStartTaskEligibility(+params.get('id')))).subscribe({
      next: () => {
        this.userCanAccessTask = true;
      },
      error: (error: HttpErrorResponse) => {
        this.userCanAccessTask = false;
        this.taskActionMessageForTooltip = TaskDetailComponent.getCompleteTaskErrorMessage(error.status);
      },
    });
  }

  completeTask(): void {
    const inputVariablesToSubmit = Array.from(this.inputVariables.values());
    this.taskService
      .completeTask(this.taskDetail.taskInstanceReferenceId, this.variables['type'] as string, inputVariablesToSubmit)
      .pipe(take(1))
      .subscribe({
        next: () => {
          this.taskCompleted = true;
          this.taskDetail.status = Status.Completed;
          this.taskCompleteMessageTimeout();
        },
        error: (error: HttpErrorResponse) => {
          this.taskCompleted = false;
          this.taskCompleteErrorMessageTimeout(error.status);
        },
      });
  }

  saveVariables(): void {
    const inputVariablesToSubmit = Array.from(this.inputVariables.values());
    this.taskService
      .saveTaskVariables(this.taskDetail.taskInstanceReferenceId, inputVariablesToSubmit)
      .pipe(take(1))
      .subscribe({
        next: () => {
          this.taskSavedMessageTimeout();
        },
        error: () => {
          this.taskSavedErrorMessageTimeout();
        },
      });
  }

  refreshTaskDetailAfterStart(response: TaskStartResponse): void {
    this.taskDetail.status = response.status;
    this.taskDetail.assignees = response.users;
    this.taskDetail.groupAssignees = [];
    this.assignee = AssigneeUtility.buildAssigneeNames(this.taskDetail);
  }

  openEndpoint(): void {
    this.expandTaskHeader = false;
    this.shouldOpenEndpoint = true;
    this.secondaryButtonText = 'Close application';
    this.showSecondaryButton = true;
  }

  closeEndpoint(): void {
    this.expandTaskHeader = true;
    this.shouldOpenEndpoint = false;
    this.hideSecondaryButton();
  }

  onInputChange(event: TaskActionVariable): void {
    this.inputVariables.set(event.name, event);
  }

  protected updateTaskActionItems(request: Omit<ActionItemRequest, 'taskInstanceIds'>, modalId: string, errorMessage: string): void {
    super.updateTaskActionItems(
      request,
      modalId,
      errorMessage,
      () => {
        this.ngOnInit();
      },
      [{ workflowId: this.taskDetail.taskInstanceReferenceId, camundaId: this.taskDetail.id }]
    );
  }

  private hideSecondaryButton(): void {
    this.secondaryButtonText = '';
    this.showSecondaryButton = false;
  }

  private taskSavedMessageTimeout(): void {
    this.taskSavedAlert = 'Your changes were saved.';
    setTimeout(() => {
      this.taskSavedAlert = '';
    }, 5000);
  }

  private taskSavedErrorMessageTimeout(): void {
    this.saveTaskErrorMessage = 'The operation could not be completed. Contact support.';
    setTimeout(() => {
      this.saveTaskErrorMessage = '';
    }, 5000);
  }

  private taskCompleteMessageTimeout(): void {
    this.taskCompletedAlert = 'The task was completed.';
    setTimeout(() => {
      this.taskCompletedAlert = '';
    }, 5000);
  }

  private taskCompleteErrorMessageTimeout(errorStatus: number): void {
    this.completeTaskErrorMessage = TaskDetailComponent.getCompleteTaskErrorMessage(errorStatus);
    setTimeout(() => {
      this.completeTaskErrorMessage = '';
    }, 5000);
  }
}
