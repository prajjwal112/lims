import { TestBed } from '@angular/core/testing';

import { TaskInformationService } from './task-information.service';

describe('TaskInformationService', () => {
  let service: TaskInformationService;
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TaskInformationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be able to get new variables', () => {
    const input = { variableValue: 'bars' };
    service.addVariables(input);
    service.getVariables().subscribe({
      next: (val) => {
        expect(val).toEqual({ variableValue: 'bars' });
      },
    });
  });
});
