import { Component, OnInit } from '@angular/core';
import type { SelectTaskFormInput } from 'src/app/pages/shared/task-detail';
import { DISPLAY_TYPE_TO_LOGIC_TYPE, TaskFormInputType } from 'src/app/pages/shared/task-detail';
import { BaseInputDirective } from '../base-input.directive';
import { TaskInformationService } from '../task-information.service';
import { ValidFormService } from '../../../../core/api/valid-form/valid-form.service';

@Component({
  selector: 'app-single-select-input',
  templateUrl: './single-select-input.component.html',
  styleUrls: ['./single-select-input.component.scss'],
})
export class SingleSelectInputComponent extends BaseInputDirective<SelectTaskFormInput> implements OnInit {
  constructor(protected readonly taskInformationService: TaskInformationService, protected readonly validFormService: ValidFormService) {
    super(taskInformationService, validFormService);
  }

  ngOnInit(): void {
    // Komodo bug only accepts string as value for dropdown
    this.onInit({ callback: (value): unknown => (this.input.type === TaskFormInputType.Numeric ? `${value}` : value) });
  }

  onSelectChange(
    inputName: string,
    inputType: TaskFormInputType.Text | TaskFormInputType.Numeric,
    changes: { selectedOption?: string }
  ): void {
    const type =
      inputType === TaskFormInputType.Numeric
        ? DISPLAY_TYPE_TO_LOGIC_TYPE[TaskFormInputType.Numeric]
        : DISPLAY_TYPE_TO_LOGIC_TYPE[TaskFormInputType.Text];
    this.inputChange.emit({ name: inputName, type: type, value: changes.selectedOption });
    this.validFormService.setValid(this.inputsForm.valid);
  }
}
