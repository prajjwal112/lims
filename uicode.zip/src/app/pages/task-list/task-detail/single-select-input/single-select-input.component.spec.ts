import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { DropdownsModule } from 'gds-atom-components';

import { SingleSelectInputComponent } from './single-select-input.component';
import { TaskFormInputType } from 'src/app/pages/shared/task-detail';
import type { SelectTaskFormInput } from '../../../shared/task-detail';

describe('SingleSelectInputComponent', () => {
  let component: SingleSelectInputComponent;
  let fixture: ComponentFixture<SingleSelectInputComponent>;
  const SINGLE_SELECT_NUMERIC: SelectTaskFormInput = {
    type: TaskFormInputType.Numeric,
    name: 'single-select-field',
    displayName: 'Single Select Field',
    sequence: 10,
    multiple: false,
    items: ['10', '20'],
    mandatory: true,
    defaultValue: '',
  };

  const SINGLE_SELECT_TEXT: SelectTaskFormInput = {
    type: TaskFormInputType.Text,
    name: 'single-select-field',
    displayName: 'Single Select Field',
    sequence: 10,
    multiple: false,
    items: ['Item One', 'Item Two'],
    mandatory: true,
    defaultValue: '',
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SingleSelectInputComponent],
      imports: [FormsModule, ReactiveFormsModule, DropdownsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleSelectInputComponent);
    component = fixture.componentInstance;
    component.input = SINGLE_SELECT_NUMERIC;
    component.inputsForm = new FormGroup({});
    component.inputsForm.addControl(SINGLE_SELECT_NUMERIC.name, new FormControl(null));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a single-select field when configured with one', () => {
    component.readOnly = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-dropdown'))).toBeTruthy();
  });

  it('should render single-select field value after task is completed', () => {
    component.readOnly = true;
    component.inputsForm.controls[SINGLE_SELECT_NUMERIC.name].setValue(10);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toEqual('10');
  });

  it('should emit on single select for text', () => {
    spyOn(component.inputChange, 'emit');
    component.inputsForm.addControl('mock-input', new FormControl(null, Validators.required));

    fixture.detectChanges();
    component.onSelectChange('mock-input', TaskFormInputType.Text, { selectedOption: 'a' });

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: 'mock-input', type: 'STRING', value: 'a' });
  });

  it('should emit on single select for number', () => {
    spyOn(component.inputChange, 'emit');
    component.inputsForm.addControl('mock-input', new FormControl(null, Validators.required));

    fixture.detectChanges();
    component.onSelectChange('mock-input', TaskFormInputType.Numeric, { selectedOption: 'a' });

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: 'mock-input', type: 'INTEGER', value: 'a' });
  });

  const TEST: [SelectTaskFormInput, string][] = [
    [SINGLE_SELECT_NUMERIC, '1'],
    [SINGLE_SELECT_TEXT, 'a'],
  ];
  for (const [input, value] of TEST) {
    it(`should prepopulate ${input.type} if variable is present`, () => {
      component.input = input;
      component.readOnly = false;
      createControl(input.name);
      component.variables = { [input.name]: value };
      component.ngOnInit();
      fixture.detectChanges();

      expect(component.inputsForm.controls[input.name].value).toEqual(value);
    });
  }

  const createControl = (name: string): void => {
    component.inputsForm.addControl(name, new FormControl(null));
  };
});
