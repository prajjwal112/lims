import { Component, OnInit } from '@angular/core';
import { DISPLAY_TYPE_TO_LOGIC_TYPE, SelectTaskFormInput, TaskFormInputType } from 'src/app/pages/shared/task-detail';
import { BaseInputDirective } from '../base-input.directive';
import { TaskInformationService } from '../task-information.service';
import { ValidFormService } from '../../../../core/api/valid-form/valid-form.service';

@Component({
  selector: 'app-multi-select-input',
  templateUrl: './multi-select-input.component.html',
  styleUrls: ['./multi-select-input.component.scss'],
})
export class MultiSelectInputComponent extends BaseInputDirective<SelectTaskFormInput> implements OnInit {
  constructor(protected readonly taskInformationService: TaskInformationService, protected readonly validFormService: ValidFormService) {
    super(taskInformationService, validFormService);
  }

  ngOnInit(): void {
    this.onInit({}, DISPLAY_TYPE_TO_LOGIC_TYPE[TaskFormInputType.Text]);
  }

  onSelectChange(inputName: string, changes: { selectedOptions?: string[] }): void {
    this.inputChange.emit({
      name: inputName,
      type: DISPLAY_TYPE_TO_LOGIC_TYPE[TaskFormInputType.Text],
      value: changes.selectedOptions.join(','),
    });
    this.validFormService.setValid(this.inputsForm.valid);
  }
}
