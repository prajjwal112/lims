import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { DropdownsModule } from 'gds-atom-components';

import { MultiSelectInputComponent } from './multi-select-input.component';
import { TaskFormInputType, SelectTaskFormInput } from 'src/app/pages/shared/task-detail';

describe('MultiSelectInputComponent', () => {
  let component: MultiSelectInputComponent;
  let fixture: ComponentFixture<MultiSelectInputComponent>;
  const MULTI_SELECT_TEXT: SelectTaskFormInput = {
    type: TaskFormInputType.Text,
    name: 'multi-select-field',
    displayName: 'Multi Select Field',
    sequence: 1,
    multiple: true,
    items: ['Item One', 'Item Two'],
    mandatory: true,
    defaultValue: '',
  };

  const MULTI_SELECT_NUMERIC: SelectTaskFormInput = {
    type: TaskFormInputType.Numeric,
    name: 'multi-select-field',
    displayName: 'Multi Select Field',
    sequence: 1,
    multiple: true,
    items: ['1', '2'],
    mandatory: true,
    defaultValue: '',
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MultiSelectInputComponent],
      imports: [FormsModule, ReactiveFormsModule, DropdownsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiSelectInputComponent);
    component = fixture.componentInstance;
    component.input = MULTI_SELECT_TEXT;
    component.inputsForm = new FormGroup({});
    component.inputsForm.addControl(MULTI_SELECT_TEXT.name, new FormControl(null));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a multi-select field when configured with one', () => {
    component.readOnly = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-multi-select-dropdown'))).toBeTruthy();
  });

  it('should render multi-select field value after task is completed', () => {
    component.readOnly = true;
    component.inputsForm.controls[MULTI_SELECT_TEXT.name].setValue(['Item One', 'Item Two']);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain('Item One', 'Item Two');
  });

  it('should emit on multi select for text', () => {
    spyOn(component.inputChange, 'emit');
    component.inputsForm.addControl('mock-input', new FormControl(null, Validators.required));

    fixture.detectChanges();
    component.onSelectChange('mock-input', { selectedOptions: ['a', 'b'] });

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: 'mock-input', type: 'STRING', value: 'a,b' });
  });

  it('should emit on multi select for number as it does for string because odata does not support multi select for number', () => {
    spyOn(component.inputChange, 'emit');
    component.inputsForm.addControl('mock-input', new FormControl(null, Validators.required));

    fixture.detectChanges();
    component.onSelectChange('mock-input', { selectedOptions: ['a', 'b'] });

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: 'mock-input', type: 'STRING', value: 'a,b' });
  });

  const TEST: [SelectTaskFormInput, string][] = [
    [MULTI_SELECT_TEXT, 'a,b,c'],
    [MULTI_SELECT_NUMERIC, '1,2,3'],
  ];
  for (const [input, value] of TEST) {
    it(`should prepopulate ${input.type} if variable is present`, () => {
      component.input = input;
      component.readOnly = false;
      createControl(input.name);
      component.variables = { [input.name]: value };
      component.ngOnInit();
      fixture.detectChanges();

      expect(component.inputsForm.controls[input.name].value).toEqual(value);
    });
  }

  const createControl = (name: string): void => {
    component.inputsForm.addControl(name, new FormControl(null));
  };
});
