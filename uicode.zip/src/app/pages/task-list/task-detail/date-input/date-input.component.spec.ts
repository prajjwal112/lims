import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DropdownsModule, ToggleModule } from 'gds-atom-components';
import { TaskFormInputType, WorkflowTaskInput, TaskInputType, DateTaskFormInput } from 'src/app/pages/shared/task-detail';

import { DateInputComponent } from './date-input.component';

describe('DateInputComponent', () => {
  let component: DateInputComponent;
  let fixture: ComponentFixture<DateInputComponent>;
  const DATE: WorkflowTaskInput = {
    type: TaskFormInputType.Date,
    name: 'date-field',
    displayName: 'Date Field',
    sequence: 7,
    taskInputType: TaskInputType.Date,
    mandatory: true,
    defaultValue: '',
    defaultToCurrentDate: false,
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DateInputComponent],
      imports: [FormsModule, ReactiveFormsModule, ToggleModule, DatePickerModule, DropdownsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateInputComponent);
    component = fixture.componentInstance;
    component.input = DATE;
    component.inputsForm = new FormGroup({});
    component.inputsForm.addControl(DATE.name, new FormControl());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a datepicker field when configured with one', () => {
    component.readOnly = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kendo-datepicker'))).toBeTruthy();
  });

  it('should render datepicker field value after task is completed', () => {
    component.readOnly = true;
    component.inputsForm.controls[DATE.name].setValue(new Date('10/01/2020'));
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain('October 1, 2020');
  });

  it('should emit on date selected', () => {
    spyOn(component.inputChange, 'emit');
    component.inputsForm.addControl('mock-input', new FormControl(null, Validators.required));

    fixture.detectChanges();
    component.onDateChange('mock-input', new Date(2020, 10, 10));

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: 'mock-input', type: 'DATE', value: '11/10/2020' });
  });

  it('should prepopulate date if variable is present', () => {
    const dateText = '10/10/2018';
    const INPUT_DATE = setInputDate(DATE, dateText);

    expect(INPUT_DATE).toEqual(new Date(dateText));
  });

  const setInputDate = (input: DateTaskFormInput, value: string): Date => {
    const mockValue = value;
    component.input = input;
    component.readOnly = false;
    createControl(input.name);
    component.variables = { [input.name]: mockValue };

    component.ngOnInit();
    fixture.detectChanges();

    return component.inputsForm.controls[input.name].value;
  };

  const createControl = (name: string): void => {
    component.inputsForm.addControl(name, new FormControl(null));
  };
});
