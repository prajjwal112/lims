import { Component, OnInit } from '@angular/core';
import type { DateTaskFormInput } from 'src/app/pages/shared/task-detail';
import { BaseInputDirective } from '../base-input.directive';
import { TaskInformationService } from '../task-information.service';
import { ValidFormService } from '../../../../core/api/valid-form/valid-form.service';
import { DATE_INPUT_FORMAT } from '../../../../core/app-settings';
@Component({
  selector: 'app-date-input',
  templateUrl: './date-input.component.html',
  styleUrls: ['./date-input.component.scss'],
})
export class DateInputComponent extends BaseInputDirective<DateTaskFormInput> implements OnInit {
  readonly dateInputFormat = DATE_INPUT_FORMAT;

  constructor(protected readonly taskInformationService: TaskInformationService, protected readonly validFormService: ValidFormService) {
    super(taskInformationService, validFormService);
  }

  ngOnInit(): void {
    this.onInit({ callback: (value): unknown => new Date(value as string) });
  }

  onDateChange(inputName: string, changes: Date): void {
    this.inputChange.emit({ name: inputName, type: 'DATE', value: changes.toLocaleDateString('en-US') });
    this.validFormService.setValid(this.inputsForm.valid);
  }
}
