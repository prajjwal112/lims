import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { LoadingIndicatorsModule, TabsModule, AlertsModule, PopoverModule } from 'gds-atom-components';
import { TaskDetailComponent } from './task-detail.component';
import { TaskHeaderComponent } from './task-header/task-header.component';
import { PriorityPillModule } from '../../shared/grid/priority-pill/priority-pill.module';
import { StatusPillModule } from '../../shared/grid/status-pill/status-pill.module';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { Status } from '../../shared/status';
import { TaskInformationComponent } from './task-information/task-information.component';
import { DeepLinkingTaskInformationComponent } from './deep-linking-task-information/deep-linking-task-information.component';
import { DateLabelModule } from '../../shared/date-label/date-label.module';
import { DueDateLabelModule } from '../../shared/due-date-label/due-date-label.module';
import { DeepLinkingTaskDetailComponent } from './deep-linking-task-detail/deep-linking-task-detail.component';
import { ManualTaskDetailComponent } from './manual-task-detail/manual-task-detail.component';
import { TaskInputsComponent } from './task-inputs/task-inputs.component';
import { DetailsHeaderModule } from '../../shared/details-header/details-header.module';
import { MultiSelectInputComponent } from './multi-select-input/multi-select-input.component';
import { SingleSelectInputComponent } from './single-select-input/single-select-input.component';
import { BasicInputComponent } from './basic-input/basic-input.component';
import { ChangePriorityModule } from '../../shared/change-priority/change-priority.module';
import { ChangeAssignmentModule } from '../../shared/change-assignment/change-assignment.module';
import { WorkflowCoreApiModule } from '../../../core/api/workflow-core-api.module';
import { ChangeDueDateModule } from '../../shared/change-due-date/change-due-date.module';
import { FieldTooltipModule } from '../../shared/grid/field-tooltip/field-tooltip.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

describe('TaskDetailComponent', () => {
  let component: TaskDetailComponent;
  let fixture: ComponentFixture<TaskDetailComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TaskHeaderComponent,
        TaskDetailComponent,
        ManualTaskDetailComponent,
        DeepLinkingTaskDetailComponent,
        TaskInformationComponent,
        DeepLinkingTaskInformationComponent,
        TaskInputsComponent,
        MultiSelectInputComponent,
        SingleSelectInputComponent,
        BasicInputComponent,
      ],
      imports: [
        DetailsHeaderModule,
        PriorityPillModule,
        StatusPillModule,
        DateLabelModule,
        DueDateLabelModule,
        HttpClientTestingModule,
        RouterTestingModule,
        WorkflowPipeModule,
        LoadingIndicatorsModule,
        TabsModule,
        AlertsModule,
        FormsModule,
        ReactiveFormsModule,
        ChangePriorityModule,
        ChangeAssignmentModule,
        ChangeDueDateModule,
        WorkflowCoreApiModule,
        FieldTooltipModule,
        PopoverModule,
        NoopAnimationsModule,
      ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            paramMap: of(convertToParamMap({ id: 'test' })),
          },
        },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskDetailComponent);
    component = fixture.componentInstance;
    component.taskDetail = {
      taskInstanceReferenceId: 1,
      status: Status.InProgress,
      dueDate: new Date(2019, 5, 30).toISOString().slice(0, -1),
      priority: 76,
      id: '123THSY6',
      name: 'Axiom GenoTyping',
      processDefinitionName: 'Test Workflow',
      assignees: [
        {
          id: 1,
          firstName: 'Test',
          lastName: 'Assignee',
          email: 'test.assignee@company.com',
          admin: false,
          active: true,
          projects: [],
          roles: [],
          groups: [],
        },
      ],
      groupAssignees: [],
      projects: [{ id: 1, name: 'Test Project' }],
      processInstanceVariables: {
        foo: 'bar',
      },
      backingEntity: {
        type: 'type',
        identifiers: ['91W123', '96W345', '96W789'],
        label: 'Test Entity Reference(s)',
        connectionInformation: {
          endpoint: 'fake-endpoint/{{tf_backingEntityIdentifiersPlaceholder}}',
        },
      },
    };
    component.enableComplete = true;

    // eslint-disable-next-line dot-notation
    spyOn(component['taskService'], 'getTaskDetail').and.returnValue(of(component.taskDetail));
    component.showSecondaryButton = false;
    component.taskStarted = true;
    fixture.detectChanges();
  });

  it('should contain the correct manual backing entities', () => {
    component.taskDetail.backingEntity.connectionInformation = {};
    component.ngOnInit();

    expect(component.backingEntities).toEqual([{ identifier: '91W123' }, { identifier: '96W345' }, { identifier: '96W789' }]);
  });

  it('should contain the correct deep-linking backing entities', () => {
    component.ngOnInit();

    expect(component.backingEntities).toEqual([
      { identifier: '91W123', endpoint: 'fake-endpoint/91W123' },
      { identifier: '96W345', endpoint: 'fake-endpoint/96W345' },
      { identifier: '96W789', endpoint: 'fake-endpoint/96W789' },
    ]);
  });

  it('should have a custom backing entities label when configured', () => {
    component.ngOnInit();

    expect(component.backingEntitiesLabel).toBe('Test Entity Reference(s)');
  });

  it('should have the default backing entities label', () => {
    delete component.taskDetail.backingEntity.label;
    component.ngOnInit();

    expect(component.backingEntitiesLabel).toBe('Entity Reference(s)');
  });

  it('should display start task button if a task has not been started', () => {
    component.expandTaskHeader = false;
    component.taskStarted = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#firstButton')).nativeElement.textContent.trim()).toBe('Start task');
  });

  it('should enable start task button if user is allowed to start a task', () => {
    component.expandTaskHeader = false;
    component.taskStarted = false;
    component.userCanAccessTask = true;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#startTaskButton')).nativeElement.disabled).toBe(false);
  });

  it('should disable start task button if user is not allowed to start a task', () => {
    component.expandTaskHeader = false;
    component.taskStarted = false;
    component.userCanAccessTask = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#startTaskButton')).nativeElement.disabled).toBe(true);
  });

  it('should display complete button when task is started and is not completed', () => {
    component.taskCompleted = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#firstButton')).nativeElement.textContent.trim()).toBe('Complete task');
  });

  it('should display go to my tasks button and success message when task is completed', () => {
    component.taskCompleted = true;
    component.taskCompletedAlert = 'The task was completed.';
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#firstButton')).nativeElement.textContent.trim()).toBe('Go to My tasks');
    expect(fixture.debugElement.queryAll(By.css('kmd-alerts[kmd-success]'))[0].nativeElement.getAttribute('ng-reflect-show')).toBe('true');
  });
});
