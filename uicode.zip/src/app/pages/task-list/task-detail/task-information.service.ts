import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TaskInformationService {
  #taskVariables = new BehaviorSubject<any>(null);

  getVariables(): Observable<any> {
    return this.#taskVariables.asObservable();
  }

  addVariables(input): void {
    this.#taskVariables.next(input);
  }
}
