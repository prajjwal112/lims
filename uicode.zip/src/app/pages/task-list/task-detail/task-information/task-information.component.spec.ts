import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskInformationComponent } from './task-information.component';
import { By } from '@angular/platform-browser';
import { FormattedBackingEntity } from '../../../shared/task-detail';
import { CamundaServerVariable } from '../../../shared/camunda-variable';

describe('TaskInformationComponent', () => {
  const BACKING_ENTITIES: Readonly<Readonly<FormattedBackingEntity>[]> = Object.freeze([
    Object.freeze({ identifier: '91W123', endpoint: 'http://localhost/91W123' }),
    Object.freeze({ identifier: '96W345', endpoint: 'http://localhost/96W345' }),
    Object.freeze({ identifier: '96W789', endpoint: 'http://localhost/96W789' }),
  ]);
  const VARIABLES = Object.freeze({ [CamundaServerVariable.Endpoint]: 'http://localhost', foo: 'bar' });

  let component: TaskInformationComponent;
  let fixture: ComponentFixture<TaskInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskInformationComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain "no backing entities" message', () => {
    expect(fixture.debugElement.query(By.css('#backing-entities-panel')).nativeElement.textContent.trim()).toBe(
      'Task Information:No backing entities.'
    );
  });

  it('should contain manual backing entities', () => {
    component.backingEntities = BACKING_ENTITIES.map((entity) => ({ identifier: entity.identifier }));
    fixture.detectChanges();

    const firstElement = fixture.debugElement.query(By.css('#manualBackingEntity-0')).nativeElement;
    const secondElement = fixture.debugElement.query(By.css('#manualBackingEntity-1')).nativeElement;
    const thirdElement = fixture.debugElement.query(By.css('#manualBackingEntity-2')).nativeElement;

    expect(firstElement.textContent).toBe(BACKING_ENTITIES[0].identifier);
    expect(secondElement.textContent).toBe(BACKING_ENTITIES[1].identifier);
    expect(thirdElement.textContent).toBe(BACKING_ENTITIES[2].identifier);

    expect(firstElement.href).toBeUndefined();
    expect(secondElement.href).toBeUndefined();
    expect(thirdElement.href).toBeUndefined();
  });

  it('should contain deep-linking backing entities', () => {
    component.backingEntities = BACKING_ENTITIES.slice();
    fixture.detectChanges();

    const firstElement = fixture.debugElement.query(By.css('#deepLinkingBackingEntity-0')).nativeElement;
    const secondElement = fixture.debugElement.query(By.css('#deepLinkingBackingEntity-1')).nativeElement;
    const thirdElement = fixture.debugElement.query(By.css('#deepLinkingBackingEntity-2')).nativeElement;

    expect(firstElement.textContent).toBe(BACKING_ENTITIES[0].identifier);
    expect(secondElement.textContent).toBe(BACKING_ENTITIES[1].identifier);
    expect(thirdElement.textContent).toBe(BACKING_ENTITIES[2].identifier);

    expect(firstElement.href).toBe(BACKING_ENTITIES[0].endpoint);
    expect(secondElement.href).toBe(BACKING_ENTITIES[1].endpoint);
    expect(thirdElement.href).toBe(BACKING_ENTITIES[2].endpoint);
  });

  it('should contain "no variables" message', () => {
    expect(fixture.debugElement.query(By.css('#variables-panel')).nativeElement.textContent.trim()).toBe('VariablesNo variables.');
  });

  it('should contain variables', () => {
    component.variables = VARIABLES;
    component.ngOnChanges();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#variables-panel')).nativeElement.textContent.trim()).toBe('Variablesfoo:bar');
  });
});
