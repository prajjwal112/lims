import { Component, Input, OnChanges, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FormattedBackingEntity } from '../../../shared/task-detail';
import { TaskInformationService } from '../task-information.service';

@Component({
  selector: 'app-task-information',
  templateUrl: './task-information.component.html',
  styleUrls: ['./task-information.component.scss'],
})
export class TaskInformationComponent implements OnChanges, OnDestroy {
  @Input() backingEntitiesLabel?: string;
  @Input() backingEntities?: FormattedBackingEntity[];
  @Input() variables?: Record<string, unknown>;
  @Input() taskInput: string;
  @Input() taskCompleted = false;
  variablesLength: number;
  inputVariables = {};
  nonThermoFisherVariablesLength: number;
  nonThermoFisherVariables: Record<string, unknown> = {};
  private unsubscribe = new Subject();

  constructor(private readonly taskInformationService: TaskInformationService) {}

  private static populateNonThermoFisherVariables(variables: Record<string, unknown>): Record<string, unknown> {
    if (variables) {
      return Object.keys(variables)
        .filter((val) => !val.startsWith('tf_'))
        .reduce((group, val) => {
          return {
            ...group,
            [val]: variables[val],
          };
        }, {});
    }
  }
  ngOnChanges(): void {
    this.setVariablesLength();
    this.nonThermoFisherVariables = this.variables && TaskInformationComponent.populateNonThermoFisherVariables(this.variables);
    this.nonThermoFisherVariablesLength = this.nonThermoFisherVariables && Object.keys(this.nonThermoFisherVariables).length;
    if (this.taskCompleted) {
      this.taskInformationService
        .getVariables()
        .pipe(takeUntil(this.unsubscribe))
        .subscribe({
          next: (val: any) => {
            this.inputVariables = { ...this.inputVariables, ...val };
          },
        });
    } else {
      this.unsubscribe.next();
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  private setVariablesLength(): void {
    this.variablesLength = this.variables ? Object.keys(this.variables).length : 0;
  }
}
