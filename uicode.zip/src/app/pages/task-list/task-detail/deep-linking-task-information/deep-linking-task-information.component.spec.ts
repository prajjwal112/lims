import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeepLinkingTaskInformationComponent } from './deep-linking-task-information.component';
import { TabsModule } from 'gds-atom-components';
import { By } from '@angular/platform-browser';
import { TaskInputsComponent } from '../task-inputs/task-inputs.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('DeepLinkingTaskInformationComponent', () => {
  let component: DeepLinkingTaskInformationComponent;
  let fixture: ComponentFixture<DeepLinkingTaskInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DeepLinkingTaskInformationComponent, TaskInputsComponent],
      imports: [FormsModule, ReactiveFormsModule, TabsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeepLinkingTaskInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have right arrow when open', () => {
    expect(fixture.debugElement.query(By.css('.wf-icon-hidepanel-right-mono'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('.wf-icon-showpanel-right-mono'))).toBeFalsy();
  });

  it('should have left arrow when not open', () => {
    component.open = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.wf-icon-hidepanel-right-mono'))).toBeFalsy();
    expect(fixture.debugElement.query(By.css('.wf-icon-showpanel-right-mono'))).toBeTruthy();
  });

  it('should not collapse tabs when open', () => {
    expect(fixture.debugElement.query(By.css('kmd-tabs[class~=collapse]'))).toBeFalsy();
  });

  it('should collapse tabs when not open', () => {
    component.open = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-tabs[class~=collapse]'))).toBeTruthy();
  });

  it('should toggle when the toggle icon is clicked', () => {
    spyOn(component.toggle, 'emit');
    fixture.debugElement.query(By.css('.toggle-icon')).nativeElement.click();
    fixture.detectChanges();

    expect(component.open).toBe(false);
    expect(component.toggle.emit).toHaveBeenCalledWith(false);
  });
});
