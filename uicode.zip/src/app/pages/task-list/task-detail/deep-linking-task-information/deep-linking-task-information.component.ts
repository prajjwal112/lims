import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormattedBackingEntity } from '../../../shared/task-detail';

@Component({
  selector: 'app-deep-linking-task-information',
  templateUrl: './deep-linking-task-information.component.html',
  styleUrls: ['./deep-linking-task-information.component.scss'],
})
export class DeepLinkingTaskInformationComponent {
  @Input() taskInput: string;
  @Input() backingEntitiesLabel?: string;
  @Input() backingEntities?: FormattedBackingEntity[];
  @Input() variables?: Record<string, unknown>;
  @Output() readonly toggle = new EventEmitter<boolean>();
  open = true;

  onToggleClick(): void {
    this.open = !this.open;
    this.toggle.emit(this.open);
  }
}
