import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DropdownsModule, ToggleModule } from 'gds-atom-components';

import { TaskFormInputType, TaskInputType } from 'src/app/pages/shared/task-detail';
import { BasicInputComponent } from './basic-input.component';
import type { BasicTaskFormInput } from '../../../shared/task-detail';

describe('BasicInputComponent', () => {
  let component: BasicInputComponent;
  let fixture: ComponentFixture<BasicInputComponent>;
  const TEXT: BasicTaskFormInput = {
    type: TaskFormInputType.Text,
    name: 'text-field',
    displayName: 'Text Field',
    sequence: 3,
    mandatory: true,
    defaultValue: '',
  };
  const NUMERIC: BasicTaskFormInput = {
    type: TaskFormInputType.Numeric,
    name: 'numeric-field',
    displayName: 'Numeric Field',
    sequence: 4,
    mandatory: true,
    defaultValue: '',
  };
  const TEXTAREA: BasicTaskFormInput = {
    type: TaskFormInputType.Textarea,
    name: 'textarea-field',
    displayName: 'Textarea Field',
    sequence: 5,
    mandatory: true,
    defaultValue: '',
  };
  const BOOLEAN: BasicTaskFormInput = {
    type: TaskFormInputType.Boolean,
    name: 'boolean-field',
    displayName: 'Boolean Field',
    sequence: 6,
    mandatory: true,
    defaultValue: '',
  };
  const createControl = (name: string, ...formState: any): void => {
    component.inputsForm.addControl(name, new FormControl(formState));
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BasicInputComponent],
      imports: [FormsModule, ReactiveFormsModule, ToggleModule, DatePickerModule, DropdownsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BasicInputComponent);
    component = fixture.componentInstance;
    component.inputsForm = new FormGroup({});
    component.input = TEXT;
    createControl(TEXT.name);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a text input when configured with one', () => {
    component.input = TEXT;
    component.readOnly = false;
    createControl(TEXT.name);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input')).nativeElement.name).toEqual(TEXT.name);
  });

  it('should have a number input when configured with one', () => {
    component.input = NUMERIC;
    component.readOnly = false;
    createControl(NUMERIC.name);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input')).nativeElement.name).toEqual(NUMERIC.name);
  });

  it('should have a textarea when configured with one', () => {
    component.input = TEXTAREA;
    component.readOnly = false;
    createControl(TEXTAREA.name);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('textarea')).nativeElement.name).toEqual(TEXTAREA.name);
  });

  it('should have a boolean field when configured with one', () => {
    component.input = BOOLEAN;
    component.readOnly = false;
    createControl(BOOLEAN.name);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-toggle'))).toBeTruthy();
  });

  it('should render text input value after task is completed', () => {
    component.input = TEXT;
    component.readOnly = true;
    createControl(TEXT.name);
    component.inputsForm.controls[TEXT.name].setValue('Text Field');
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain('Text Field');
  });

  it('should render number input value after task is completed', () => {
    component.input = NUMERIC;
    component.readOnly = true;
    createControl(NUMERIC.name);
    component.inputsForm.controls[NUMERIC.name].setValue(23);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain(23);
  });

  it('should render textarea value after task is completed', () => {
    component.input = TEXTAREA;
    component.readOnly = true;
    createControl(TEXTAREA.name);
    component.inputsForm.controls[TEXTAREA.name].setValue('This is a Text Area.');
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain('This is a Text Area.');
  });

  it('should render boolean field value of `yes` when in read only view', () => {
    component.input = BOOLEAN;
    component.readOnly = true;
    component.booleanFieldValue = true;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain('Yes');
  });

  it('should render boolean field value of `no` when in read only view', () => {
    component.input = BOOLEAN;
    component.readOnly = true;
    component.booleanFieldValue = false;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain('No');
  });

  it('should emit on text filled out', fakeAsync(() => {
    spyOn(component.inputChange, 'emit');
    component.inputsForm.get(TEXT.name).setValue('mock-value');
    tick(300);

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: TEXT.name, type: 'STRING', value: 'mock-value' });
  }));

  it('should emit on number filled out', fakeAsync(() => {
    spyOn(component.inputChange, 'emit');
    component.input = NUMERIC;
    createControl(NUMERIC.name, null, Validators.required);
    component.ngOnInit();
    component.inputsForm.get(NUMERIC.name).setValue('mock-value');
    tick(300);

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: NUMERIC.name, type: 'INTEGER', value: 'mock-value' });
  }));

  it('should emit on boolean toggled to true', () => {
    spyOn(component.inputChange, 'emit');
    const mockInput = {
      taskInputType: TaskInputType.Basic,
      type: TaskFormInputType.Boolean,
      name: 'mock-input',
      displayName: 'mock-input',
      sequence: 1,
      mandatory: true,
      defaultValue: 'mock-input',
    };
    component.inputsForm.addControl(mockInput.name, new FormControl('true', Validators.required));
    component.onToggleChange(mockInput);

    expect(component.inputChange.emit).toHaveBeenCalledWith({ name: mockInput.name, type: 'BOOLEAN', value: 'true' });
  });

  const TEST: [BasicTaskFormInput, string | boolean | number][] = [
    [TEXT, 'mock-value'],
    [BOOLEAN, true],
    [NUMERIC, '10'],
    [TEXTAREA, 'mock-value'],
  ];
  for (const [input, value] of TEST) {
    it(`should prepopulate ${input.type} if variable is present`, () => {
      component.input = input;
      component.readOnly = false;
      createControl(input.name);
      component.variables = { [input.name]: value };
      component.ngOnInit();
      fixture.detectChanges();

      expect(component.inputsForm.controls[input.name].value).toEqual(value);
    });
  }
});
