import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { isEqual } from 'lodash';

import { BaseInputDirective } from '../base-input.directive';
import { BasicTaskFormInput, DISPLAY_TYPE_TO_LOGIC_TYPE, TaskFormInputType, WorkflowTaskInput } from 'src/app/pages/shared/task-detail';
import { TaskInformationService } from '../task-information.service';
import { ValidFormService } from '../../../../core/api/valid-form/valid-form.service';

@Component({
  selector: 'app-basic-input',
  templateUrl: './basic-input.component.html',
  styleUrls: ['./basic-input.component.scss'],
})
export class BasicInputComponent extends BaseInputDirective<BasicTaskFormInput> implements OnInit, OnDestroy {
  public booleanFieldValue: boolean;
  readonly taskInputFormType = TaskFormInputType;
  readonly #unsubscribe: Readonly<Subject<void>> = new Subject();

  constructor(protected readonly taskInformationService: TaskInformationService, protected readonly validFormService: ValidFormService) {
    super(taskInformationService, validFormService);
  }

  ngOnInit(): void {
    this.onInit({ callback: (value): unknown => (this.input.type === TaskFormInputType.Numeric ? `${value}` : value) });
    this.onFormChanges().subscribe({
      next: (data: any) => {
        if (this.input.type === TaskFormInputType.Boolean) {
          // The type is boolean in edit mode, string in read-only mode
          if (typeof data === 'string') {
            this.booleanFieldValue = data === 'true' ? true : false;
          } else if (typeof data === 'boolean') {
            this.booleanFieldValue = data;
          }
        }
        this.onInputChange(data);
      },
    });
    this.updateBooleanValue();
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  onToggleChange(input: WorkflowTaskInput): void {
    if (input && input.type) {
      const value = this.inputsForm.get(input.name).value;
      this.inputChange.emit({ name: input.name, type: DISPLAY_TYPE_TO_LOGIC_TYPE[input.type], value: value ? `${value}` : 'false' });
      this.validFormService.setValid(this.inputsForm.valid);
    }
  }

  private onInputChange(value: any): void {
    const input: BasicTaskFormInput = this.input;
    if (input && input.type) {
      if (input.type === TaskFormInputType.Numeric) {
        this.inputChange.emit({ name: input.name, type: DISPLAY_TYPE_TO_LOGIC_TYPE[input.type], value: `${value}` });
      } else {
        this.inputChange.emit({ name: input.name, type: DISPLAY_TYPE_TO_LOGIC_TYPE[input.type], value });
      }
      this.validFormService.setValid(this.inputsForm.valid);
    }
  }

  private updateBooleanValue(): void {
    if (this.input.type === TaskFormInputType.Boolean) {
      this.inputsForm.get(this.input.name).updateValueAndValidity();
    }
  }

  private onFormChanges(): Observable<any> {
    if (this.input.type !== TaskFormInputType.Boolean) {
      return this.inputsForm.get(this.input.name).valueChanges.pipe(
        debounceTime(300),
        distinctUntilChanged((first, second) => isEqual(first, second)),
        takeUntil(this.#unsubscribe)
      );
    }
    return this.inputsForm.get(this.input.name).valueChanges.pipe(takeUntil(this.#unsubscribe));
  }
}
