import { Directive, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { BasicTaskFormInput, DISPLAY_TYPE_TO_LOGIC_TYPE } from '../../shared/task-detail';
import { TaskInformationService } from './task-information.service';
import type { TaskActionVariable } from '../../modeler/task-configuration/task-action/task-template';
import { ValidFormService } from '../../../core/api/valid-form/valid-form.service';

@Directive()
export abstract class BaseInputDirective<T extends BasicTaskFormInput> implements OnInit, OnChanges {
  @Input() readOnly = false;
  @Input() input: T;
  @Input() inputsForm: FormGroup;
  @Input() variables: Record<string, unknown>;
  @Output() inputChange = new EventEmitter<TaskActionVariable>();
  @Output() validInput = new EventEmitter<boolean>();

  protected constructor(
    protected readonly taskInformationService: TaskInformationService,
    protected readonly validFormService: ValidFormService
  ) {}

  ngOnInit(): void {
    this.onInit();
  }

  protected onInit<T extends { new (...args: unknown[]): InstanceType<T> }>(
    transformValue?: {
      callback?(...args: unknown[]): void;
    },
    overwriteType?: string
  ): void {
    if (this.input && this.variables) {
      let value = this.variables[this.input.name];
      if (value) {
        if (transformValue?.callback) {
          value = transformValue.callback(value);
        }
        this.inputsForm.get(this.input.name)?.setValue(value);
        this.inputChange.emit({
          name: this.input.name,
          type: overwriteType ?? DISPLAY_TYPE_TO_LOGIC_TYPE[this.input.type],
          value: value as string,
        });
      }
      this.validFormService.setValid(this.inputsForm.valid);
    }
  }

  ngOnChanges(): void {
    if (this.readOnly) {
      const input = {};
      input[this.input.name] = this.inputsForm.controls[this.input.name].value;
      this.taskInformationService.addVariables(input);
    }
  }
}
