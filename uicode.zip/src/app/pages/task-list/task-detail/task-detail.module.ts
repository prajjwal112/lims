import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {
  ButtonModule,
  LoadingIndicatorsModule,
  TabsModule,
  AlertsModule,
  InputFieldsModule,
  ToggleModule,
  DropdownsModule,
  PopoverModule,
} from 'gds-atom-components';

import { TaskDetailComponent } from './task-detail.component';
import { TaskHeaderComponent } from './task-header/task-header.component';
import { TaskInformationComponent } from './task-information/task-information.component';
import { StatusPillModule } from '../../shared/grid/status-pill/status-pill.module';
import { PriorityPillModule } from '../../shared/grid/priority-pill/priority-pill.module';
import { DetailsHeaderModule } from '../../shared/details-header/details-header.module';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { IframeModule } from '../../shared/iframe/iframe.module';
import { DeepLinkingTaskInformationComponent } from './deep-linking-task-information/deep-linking-task-information.component';
import { DueDateLabelModule } from '../../shared/due-date-label/due-date-label.module';
import { DateLabelModule } from '../../shared/date-label/date-label.module';
import { DeepLinkingTaskDetailComponent } from './deep-linking-task-detail/deep-linking-task-detail.component';
import { ManualTaskDetailComponent } from './manual-task-detail/manual-task-detail.component';
import { LabelModule } from '@progress/kendo-angular-label';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { TaskInputsComponent } from './task-inputs/task-inputs.component';
import { DateInputComponent } from './date-input/date-input.component';
import { MultiSelectInputComponent } from './multi-select-input/multi-select-input.component';
import { SingleSelectInputComponent } from './single-select-input/single-select-input.component';
import { BasicInputComponent } from './basic-input/basic-input.component';
import { FieldTooltipModule } from '../../shared/grid/field-tooltip/field-tooltip.module';
import { ChangePriorityModule } from '../../shared/change-priority/change-priority.module';
import { ChangeAssignmentModule } from '../../shared/change-assignment/change-assignment.module';
import { ChangeDueDateModule } from '../../shared/change-due-date/change-due-date.module';
import { WorkflowCoreApiModule } from '../../../core/api/workflow-core-api.module';

@NgModule({
  declarations: [
    TaskHeaderComponent,
    TaskDetailComponent,
    ManualTaskDetailComponent,
    DeepLinkingTaskDetailComponent,
    TaskInformationComponent,
    DeepLinkingTaskInformationComponent,
    TaskInputsComponent,
    DateInputComponent,
    MultiSelectInputComponent,
    SingleSelectInputComponent,
    BasicInputComponent,
  ],
  imports: [
    CommonModule,
    ButtonModule,
    LoadingIndicatorsModule,
    StatusPillModule,
    PriorityPillModule,
    WorkflowPipeModule,
    IframeModule,
    DetailsHeaderModule,
    RouterModule.forChild([{ path: '', component: TaskDetailComponent, pathMatch: 'full' }]),
    TabsModule,
    AlertsModule,
    DueDateLabelModule,
    DateLabelModule,
    InputFieldsModule,
    LabelModule,
    ReactiveFormsModule,
    ToggleModule,
    FormsModule,
    DatePickerModule,
    DropdownsModule,
    FieldTooltipModule,
    PopoverModule,
    ChangePriorityModule,
    ChangeAssignmentModule,
    ChangeDueDateModule,
    WorkflowCoreApiModule,
  ],
})
export class TaskDetailModule {}
