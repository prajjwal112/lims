import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualTaskDetailComponent } from './manual-task-detail.component';
import { TaskInputsComponent } from '../task-inputs/task-inputs.component';
import { TaskInformationComponent } from '../task-information/task-information.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('ManualTaskDetailComponent', () => {
  let component: ManualTaskDetailComponent;
  let fixture: ComponentFixture<ManualTaskDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ManualTaskDetailComponent, TaskInputsComponent, TaskInformationComponent],
      imports: [FormsModule, ReactiveFormsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualTaskDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
