import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormattedBackingEntity } from '../../../shared/task-detail';
import { TaskActionVariable } from '../../../modeler/task-configuration/task-action/task-template';

@Component({
  selector: 'app-manual-task-detail',
  templateUrl: './manual-task-detail.component.html',
  styleUrls: ['../shared/task-information.scss', '../shared/task-detail.scss', './manual-task-detail.component.scss'],
})
export class ManualTaskDetailComponent {
  @Input() taskInput: string;
  @Input() taskOutputVariables: Record<string, string>;
  @Input() backingEntitiesLabel?: string;
  @Input() backingEntities?: FormattedBackingEntity[];
  @Input() variables?: Record<string, unknown>;
  @Input() taskCompleted = false;
  @Output() inputChange = new EventEmitter<TaskActionVariable>();
}
