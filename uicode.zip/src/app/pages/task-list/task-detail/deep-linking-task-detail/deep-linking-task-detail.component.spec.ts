import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoadingIndicatorsModule, TabsModule } from 'gds-atom-components';
import { DeepLinkingTaskDetailComponent } from './deep-linking-task-detail.component';
import { Status } from '../../../shared/status';
import { CamundaServerVariable } from '../../../shared/camunda-variable';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TaskInformationComponent } from '../task-information/task-information.component';
import { DeepLinkingTaskInformationComponent } from '../deep-linking-task-information/deep-linking-task-information.component';
import { IframeModule } from '../../../shared/iframe/iframe.module';
import { TaskInputsComponent } from '../task-inputs/task-inputs.component';
import { SimpleChange } from '@angular/core';
import type { TaskDetail } from '../../../shared/task-detail';

describe('DeepLinkingTaskDetailComponent', () => {
  const TASK_DETAIL: Readonly<TaskDetail> = {
    taskInstanceReferenceId: 1,
    status: Status.InProgress,
    priority: 76,
    id: '123THSY6',
    name: 'Axiom GenoTyping',
    processDefinitionName: 'Test Workflow',
    assignees: [
      {
        id: 1,
        firstName: 'Test',
        lastName: 'Assignee',
        email: 'test.assignee@company.com',
        admin: false,
        active: true,
        projects: [],
        roles: [],
        groups: [],
      },
    ].slice(),
    groupAssignees: [].slice(),
    projects: [{ id: 1, name: 'Test Project' }].slice(),
    taskVariables: {
      [CamundaServerVariable.Endpoint]: 'http://localhost',
    },
  } as const;
  let component: DeepLinkingTaskDetailComponent;
  let fixture: ComponentFixture<DeepLinkingTaskDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DeepLinkingTaskDetailComponent, TaskInformationComponent, DeepLinkingTaskInformationComponent, TaskInputsComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule, TabsModule, IframeModule, LoadingIndicatorsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeepLinkingTaskDetailComponent);
    component = fixture.componentInstance;
    component.taskDetail = TASK_DETAIL;

    component.ngOnChanges({ taskDetail: new SimpleChange(null, TASK_DETAIL, true) });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the extracted endpoint information', () => {
    expect(component.endpoint).toEqual({ url: 'http://localhost', description: undefined, label: 'Open application' });
  });

  it('should display button to open an endpoint with default text when endpoint is not already open', () => {
    expect(fixture.debugElement.query(By.css('#openApplicationButton')).nativeElement.textContent.trim()).toBe('Open application');
  });

  it('should display button to open an endpoint with custom text when configured with custom text', () => {
    const customButtonText = 'Open with custom text';
    component.endpoint.label = customButtonText;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#openApplicationButton')).nativeElement.textContent.trim()).toBe(customButtonText);
  });

  it('should not display description with button for opening and endpoint when not configured with a description', () => {
    expect(fixture.debugElement.query(By.css('.label.pb-3'))).toBeFalsy();
  });

  it('should display description with button for opening and endpoint when configured with a description', () => {
    const buttonDescription = 'A description for the button';
    component.endpoint.description = buttonDescription;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.label.pb-3')).nativeElement.textContent.trim()).toBe(buttonDescription);
  });

  it('should enable open application button if user is allowed to start a task', () => {
    component.userCanAccessTask = true;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#openApplicationButton')).nativeElement.disabled).toBe(false);
  });

  it('should disable open application button if user is not allowed to start a task', () => {
    expect(fixture.debugElement.query(By.css('#openApplicationButton')).nativeElement.disabled).toBe(true);
  });

  it('should display message when endpoint is loading', () => {
    component['loadEndpoint']();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.loading-overlay')).nativeElement.textContent.trim()).toBe(
      'The application is loading You are in full view mode. Close the application to go back to the default view.'
    );
  });

  it('should display iframe when endpoint is opened', () => {
    component.endpointOpen = true;
    fixture.detectChanges();
    const iframe = fixture.debugElement.query(By.css('app-iframe')).nativeElement;

    expect(iframe).toBeDefined();
    expect(iframe).not.toBeNull();
  });

  it('should show general task information when endpoint is not open', () => {
    expect(fixture.debugElement.query(By.css('app-task-information'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('app-deep-linking-task-information'))).toBeFalsy();
  });

  it('should show deep-linking task information when endpoint is open', () => {
    component.endpointOpen = true;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-task-information'))).toBeFalsy();
    expect(fixture.debugElement.query(By.css('app-deep-linking-task-information'))).toBeTruthy();
  });

  it('should have task information open by default', () => {
    expect(component.taskInformationOpen).toBe(true);
  });

  it('should toggle deep-linking task information when toggled', () => {
    component.endpointOpen = true;
    fixture.detectChanges();
    fixture.debugElement.query(By.css('app-deep-linking-task-information')).triggerEventHandler('toggle', false);
    fixture.detectChanges();

    expect(component.taskInformationOpen).toBe(false);
  });
});
