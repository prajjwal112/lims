import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Status } from '../../../shared/status';
import { CamundaServerVariable } from '../../../shared/camunda-variable';
import { take } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { TaskDetailComponent } from '../task-detail.component';
import { TaskService } from '../../../../core/api/task/task.service';
import { differenceWith, isEqual } from 'lodash';
import type { OnChanges, SimpleChanges } from '@angular/core';
import type { TaskStartResponse } from '../../shared/task';
import type { FormattedBackingEntity, TaskDetail } from '../../../shared/task-detail';

interface Endpoint {
  url: string;
  description?: string;
  label?: string;
}
@Component({
  selector: 'app-deep-linking-task-detail',
  templateUrl: './deep-linking-task-detail.component.html',
  styleUrls: ['../shared/task-information.scss', '../shared/task-detail.scss', './deep-linking-task-detail.component.scss'],
})
export class DeepLinkingTaskDetailComponent implements OnChanges {
  @Output() readonly endpointOpened = new EventEmitter<void>();
  @Output() readonly endpointClosed = new EventEmitter<void>();
  @Output() readonly taskStarted = new EventEmitter<TaskStartResponse>();
  readonly status = Status;
  readonly serverCamundaVariable = CamundaServerVariable;

  @Input() taskDetail: TaskDetail;
  @Input() backingEntitiesLabel?: string;
  @Input() backingEntities?: FormattedBackingEntity[];
  @Input() variables?: Record<string, unknown>;
  @Input() shouldOpenEndpoint: boolean;
  @Input() userCanAccessTask = false;
  @Input() openApplicationButtonTooltipText = '';
  endpointOpen = false;
  endpointLoading = false;
  startTaskErrorMessage = '';
  taskInformationOpen = true;
  endpoint: Endpoint;
  disableOpenApplication = true;

  constructor(private readonly taskService: TaskService) {}

  private static isEndpointOpen(changes: SimpleChanges): boolean {
    return changes.shouldOpenEndpoint?.currentValue;
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.endpointOpen = DeepLinkingTaskDetailComponent.isEndpointOpen(changes);
    this.disableOpenApplication = this.shouldDisableOpenApplication(changes);
    this.endpoint = this.buildEndpoint();

    this.toggleEndpoint(this.endpointOpen);
  }

  openEndpoint(): void {
    this.closeEndpoint();

    if (this.taskDetail?.status === Status.Todo) {
      this.startTask();
    } else {
      this.loadEndpoint();
    }

    this.endpointOpened.emit();
  }

  onEndpointLoad(): void {
    this.endpointLoading = false;
  }

  onDeepLinkingTaskInformationToggle(event: boolean): void {
    this.taskInformationOpen = event;
  }

  private startTask(): void {
    this.taskService
      .startTask(this.taskDetail?.taskInstanceReferenceId)
      .pipe(take(1))
      .subscribe({
        next: (response: TaskStartResponse) => {
          this.clearErrorMessages();
          this.loadEndpoint();
          this.taskStarted.emit(response);
        },
        error: (error: HttpErrorResponse) => {
          this.startTaskErrorMessage = TaskDetailComponent.getStartTaskErrorMessage(error.status);
        },
      });
  }

  private buildEndpoint(): Endpoint {
    return {
      url: this.taskDetail?.taskVariables[CamundaServerVariable.Endpoint],
      description: this.taskDetail?.taskVariables[CamundaServerVariable.EndpointDescription],
      label: this.taskDetail?.taskVariables[CamundaServerVariable.EndpointLabel] ?? 'Open application',
    };
  }

  private shouldDisableOpenApplication(changes: SimpleChanges): boolean {
    const taskDetailChange = changes.taskDetail;
    return taskDetailChange
      ? differenceWith(taskDetailChange.currentValue, taskDetailChange.previousValue, isEqual).length > 0 &&
          [Status.Pending, Status.Completed].includes(taskDetailChange.currentValue?.status)
      : this.disableOpenApplication;
  }

  private toggleEndpoint(endpointOpen: boolean): void {
    if (endpointOpen) {
      this.openEndpoint();
    } else {
      this.closeEndpoint();
    }
  }

  private closeEndpoint(): void {
    this.clearErrorMessages();
    this.endpointOpen = false;
    this.endpointLoading = false;
    this.taskInformationOpen = true;
    this.endpointClosed.emit();
  }

  private loadEndpoint(): void {
    this.endpointOpen = true;
    this.endpointLoading = true;
  }

  private clearErrorMessages(): void {
    this.startTaskErrorMessage = '';
  }
}
