import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { TaskListComponent } from './task-list.component';
import { TaskListRoutingModule } from './task-list-routing.module';
import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { GridModule } from '../shared/grid/grid.module';
import { TabsModule } from 'gds-atom-components';
import { ChangePriorityModule } from '../shared/change-priority/change-priority.module';
import { ChangeAssignmentModule } from '../shared/change-assignment/change-assignment.module';
import { ChangeDueDateModule } from '../shared/change-due-date/change-due-date.module';

@NgModule({
  declarations: [TaskListComponent],
  imports: [
    CommonModule,
    LayoutModule,
    GridModule,
    TabsModule,
    DropDownAutoCompleteModule,
    TaskListRoutingModule,
    ChangePriorityModule,
    ChangeAssignmentModule,
    ChangeDueDateModule,
  ],
})
export class TaskListModule {}
