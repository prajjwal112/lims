import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { By } from '@angular/platform-browser';
import { TabsModule } from 'gds-atom-components';
import { GridModule } from '../shared/grid/grid.module';
import { of, throwError } from 'rxjs';
import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { TabKeys } from '../shared/tab-name';
import { Status } from '../shared/status';
import { ChangeAssignmentModule } from '../shared/change-assignment/change-assignment.module';
import { ChangePriorityModule } from '../shared/change-priority/change-priority.module';
import { ManageItemsModule } from '../shared/manage-items/manage-items.module';
import { TASK_ITEMS } from '../workflow-definitions/detail/test/taskFilterResponse';
import { DefaultAssignmentTab } from '../workflow-definitions/default-assignment/default-assignment';
import { environment } from 'src/environments/environment';
import { ModalId } from '../shared/modal-id';
import { ChangeDueDateModule } from '../shared/change-due-date/change-due-date.module';
import { TaskService } from '../../core/api/task/task.service';
import { TaskListComponent } from './task-list.component';

const ACTIONS: Readonly<Partial<Record<ModalId, string>>> = {
  [ModalId.ChangeAssignment]: 'Change Assignment',
  [ModalId.ChangePriority]: 'Change Priority',
} as const;

describe('TaskListComponent', () => {
  let component: TaskListComponent;
  let fixture: ComponentFixture<TaskListComponent>;
  let httpTestingController: HttpTestingController;
  let taskService: TaskService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskListComponent],
      imports: [
        LayoutModule,
        GridModule,
        TabsModule,
        DropDownAutoCompleteModule,
        HttpClientTestingModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        ChangeAssignmentModule,
        ChangePriorityModule,
        ChangeDueDateModule,
        NoopAnimationsModule,
        ManageItemsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskListComponent);
    httpTestingController = TestBed.inject(HttpTestingController);
    taskService = TestBed.inject(TaskService);
    component = fixture.componentInstance;
    component.tasks = TASK_ITEMS;
    component['updateSelectedTasks'](TASK_ITEMS);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display `Active, Upcoming, History tabs`', () => {
    expect(fixture.debugElement.query(By.css('kmd-tabs')).nativeElement.textContent.trim()).toMatch(/Active.*Upcoming.*History/);
  });

  it('should use Active tab columns', () => {
    const tab = fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[0].nativeElement.getAttribute('id');

    expect(tab).toEqual(TabKeys.Active);
  });

  it('should use Upcoming tab columns', () => {
    const tab = fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[1].nativeElement.getAttribute('id');

    expect(tab).toEqual(TabKeys.Upcoming);
  });

  it('should use History tab columns', () => {
    const tab = fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[2].nativeElement.getAttribute('id');

    expect(tab).toEqual(TabKeys.History);
  });

  it('should display table', () => {
    expect(fixture.debugElement.query(By.css('app-grid'))).toBeTruthy();
  });

  it('should open change priority modal when change priority option is clicked', () => {
    const data = {
      dataItem: {
        id: 'c291c777-0f86-11eb-9adc-76154a7797f1',
        referenceId: 223,
        name: 'A',
        description: 'test',
        status: Status.Todo,
        priority: 100,
        workflowName: 'Shen-WF716-02',
        runName: 'test',
        processDefinitionId: 'key40:1:bf9daf55-0712-11eb-bf6f-c2207bcabeb5',
        startTime: '2020-10-16T08:08:23.098897',
        endTime: null,
        dueDate: '2020-10-19T03:08:23.104737',
        staleDate: '2020-10-16T09:08:23.104737',
        projects: [
          {
            id: 10,
            name: 'Demo Project B',
          },
        ],
        assignees: [],
        groupAssignees: [],
        allAssigneeNames: '',
      },
      name: ModalId.ChangePriority,
    };

    component['updateSelectedTasks']([data.dataItem]);
    spyOn(component['kmdModalService'], 'open');
    component.onActionClick(data);

    expect(component['kmdModalService'].open).toHaveBeenCalledWith(data.name);
    expect(fixture.debugElement.query(By.css('app-change-priority'))).toBeTruthy();
  });

  it('should close the change assignee modal when assign success', () => {
    spyOn(TestBed.inject(TaskService), 'updateTaskActionItems').and.returnValue(of(null));
    spyOn(component['kmdModalService'], 'close').and.callThrough();
    component.onConfirmAssignee({ tab: DefaultAssignmentTab.User, userIds: [], updateIds: [25] });

    expect(component['kmdModalService'].close).toHaveBeenCalledWith(ModalId.ChangeAssignment);
  });

  it('should show error message when assign fails', () => {
    spyOn(TestBed.inject(TaskService), 'updateTaskActionItems').and.returnValue(throwError('Error'));
    component.onConfirmAssignee({ tab: DefaultAssignmentTab.User, userIds: [], updateIds: [98] });

    expect(component.confirmedStatus).toEqual({
      status: false,
      message: 'Unable to change assignment.',
    });
  });

  it('should add the assignment for user', () => {
    const task = {
      taskInstanceIds: [{ workflowId: 223, camundaId: 'a-b-c' }],
      assignedUserIds: [8],
      assignedGroupIds: [],
    };
    taskService.updateTaskActionItems(task).subscribe();
    const req = httpTestingController.expectOne({ method: 'PATCH', url: `${environment.endpoint}/tasks` });

    expect(req.request.body).toEqual(task);
  });

  it('should add the assignment for group', () => {
    const task = {
      taskInstanceIds: [{ workflowId: 223, camundaId: 'a-b-c' }],
      assignedUserIds: [],
      assignedGroupIds: [8],
    };
    taskService.updateTaskActionItems(task).subscribe();
    const req = httpTestingController.expectOne({ method: 'PATCH', url: `${environment.endpoint}/tasks` });

    expect(req.request.body).toEqual(task);
  });

  it('should deselect the selectAll checkbox when assign success', () => {
    spyOn(TestBed.inject(TaskService), 'updateTaskActionItems').and.returnValue(of(null));
    spyOn(component['gridService'], 'setClearCheckboxes').and.callThrough();
    component.onConfirmAssignee({ tab: DefaultAssignmentTab.User, userIds: [], updateIds: [25] });

    expect(component['gridService'].setClearCheckboxes).toHaveBeenCalledWith(true);
  });

  it('should not show the actions on banner when active tab is History tab', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[2].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.taskListActions).not.toEqual(ACTIONS);
  });

  it('should show the actions on banner when active tab is Active tab', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[0].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.taskListActions).toEqual(ACTIONS);
  });

  it('should show the actions on banner when active tab is Upcoming tab', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[1].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.taskListActions).toEqual(ACTIONS);
  });
});
