import { Component, ViewChild, ElementRef } from '@angular/core';
import { take } from 'rxjs/operators';
import { orderBy, SortDescriptor } from '@progress/kendo-data-query';
import { KmdModalService, KmdTabsComponent } from 'gds-atom-components';

import { TaskService } from '../../core/api/task/task.service';
import { AssigneeService } from '../../core/api/assignee/assignee.service';
import { ProjectService } from '../../core/api/project/project.service';
import { StoreService, Action, ActionType } from 'src/app/store.service';
import { WorkflowDefinitionService } from '../../core/api/workflow-definition/workflow-definition.service';
import { SearchTextService } from '../shared/search-text.service';
import { UserService } from '../../core/api/user/user.service';
import { GroupService } from '../../core/api/group/group.service';
import {
  DUE_DATE_COLUMN,
  END_TIME_COLUMN,
  NAME_COLUMN,
  WORKFLOW_NAME_COLUMN,
  PROJECT_COLUMN,
  STATUS_COLUMN,
  PRIORITY_COLUMN,
  ASSIGNEE_COLUMN,
  COMPLETED_BY_COLUMN,
  OPTIONS_COLUMN,
} from './shared/task-grid-columns';
import { WorkflowDatePipe } from 'src/app/core/pipe/date/workflow-date.pipe';
import { GridComponent } from '../shared/grid/grid.component';
import { customOrderBy } from './shared/custom-orderby';
import { DateUtility } from '../shared/utility/date-utility';
import { Status } from '../shared/status';
import { SortDirection } from '../shared/sort-direction';
import { TabKeys, TabValues } from '../shared/tab-name';
import { DefaultAssignmentTab } from '../workflow-definitions/default-assignment/default-assignment';
import { ItemsForActionDirective } from '../shared/items-for-action.directive';
import { GridService } from '../shared/grid/grid.service';
import { ChangeDueDateComponent } from '../shared/change-due-date/change-due-date.component';
import { ModalId } from '../shared/modal-id';
import type { OnInit } from '@angular/core';
import type { Column } from '../shared/grid/column';
import type { IdNamePair } from '../shared/id-name-pair';
import type { TabConfig } from '../shared/tabconfig';
import type { TaskFilterResponse, TaskFilterItemResponse, TaskFilterRequest, ActionItemRequest } from './shared/task-filter';
import type { IsoDate } from '../../core/app-settings';
import type { DefaultAssignmentItems } from '../workflow-definitions/default-assignment/default-assignment';
import { ChangePriorityService } from '../../core/api/change-priority.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss', '../shared/page-header.scss'],
  providers: [WorkflowDatePipe],
})
export class TaskListComponent extends ItemsForActionDirective implements OnInit {
  @ViewChild('grid') private grid: GridComponent;
  @ViewChild('tasklist', { read: ElementRef }) private taskListElementRef: ElementRef;
  @ViewChild('tabsComponent') private tabsComponent: KmdTabsComponent;

  pageData: TaskFilterItemResponse[] = [];
  sort: SortDescriptor[] = [];
  columns: Column[] = [];
  lastSearched = '';
  tabData: TaskFilterItemResponse[] = [];
  priorityErrorMessage = '';
  readonly tabKey = TabKeys;
  readonly tabValue = TabValues;
  taskListActions: Partial<Record<ModalId, string>>;
  readonly tabConfig: Readonly<TabConfig> = {
    users: {
      name: 'Users',
      id: DefaultAssignmentTab.User,
      propertyId: 'id',
      columns: [{ name: 'fullName', title: 'Name', sortable: true }],
      filterKey: 'fullName',
    },
    groups: {
      name: 'Groups',
      id: DefaultAssignmentTab.Group,
      propertyId: 'id',
      columns: [{ name: 'name', title: 'Name', sortable: true }],
      filterKey: 'name',
    },
  };

  #selectedItems: number[] = [];
  #projectIds: IdNamePair[] = [];
  #activeTab: TabKeys = TabKeys.Active;
  #activeTabStatus: Status[];
  #filter: TaskFilterRequest = {};

  constructor(
    protected readonly kmdModalService: KmdModalService,
    protected readonly userService: UserService,
    protected readonly groupService: GroupService,
    protected readonly taskService: TaskService,
    private readonly assigneeService: AssigneeService,
    private readonly projectService: ProjectService,
    private readonly store: StoreService,
    private readonly workflowDatePipe: WorkflowDatePipe,
    private readonly workflowDefinitionService: WorkflowDefinitionService,
    private readonly searchTextService: SearchTextService,
    private readonly gridService: GridService,
    private readonly changePriorityService: ChangePriorityService
  ) {
    super(kmdModalService, userService, groupService, taskService);
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Tasks' }));
    OPTIONS_COLUMN.popover.action.onClick = this.onActionClick.bind(this);
  }

  /**
   * Initializes the component.
   */
  ngOnInit(): void {
    this.initColumns();
    this.getData(this.#filter);
    this.onTabSelect({ activeId: TabKeys.Upcoming, nextId: TabKeys.Active });
  }

  onTabSelect(event: { activeId: TabKeys; nextId: TabKeys }): void {
    this.searchTextService.setText(this.lastSearched);
    this.lastSearched = '';
    this.#activeTab = event.nextId;
    this.taskListActions = { [ModalId.ChangeAssignment]: 'Change Assignment', [ModalId.ChangePriority]: 'Change Priority' };

    switch (this.#activeTab) {
      case TabKeys.Active:
        // First column will display the Due Date and last column the Assignee
        this.columns = [
          DUE_DATE_COLUMN,
          NAME_COLUMN,
          WORKFLOW_NAME_COLUMN,
          PROJECT_COLUMN,
          STATUS_COLUMN,
          PRIORITY_COLUMN,
          ASSIGNEE_COLUMN,
          OPTIONS_COLUMN,
        ];

        // To Do, In Progress or Blocked status (if not more restrictive filter is applied)
        this.#activeTabStatus = [Status.Todo, Status.InProgress, Status.Blocked];

        // Default sort by Priority (descending) and Due Date (ascending)
        this.sort = [
          { field: 'priority', dir: SortDirection.Descending },
          { field: 'dueDate', dir: SortDirection.Ascending },
        ];
        break;

      case TabKeys.Upcoming:
        // First column will display the Due Date and last column the Assignee
        this.columns = [
          DUE_DATE_COLUMN,
          NAME_COLUMN,
          WORKFLOW_NAME_COLUMN,
          PROJECT_COLUMN,
          STATUS_COLUMN,
          PRIORITY_COLUMN,
          ASSIGNEE_COLUMN,
          OPTIONS_COLUMN,
        ];

        // Pending status (if not more restrictive filter is applied)
        this.#activeTabStatus = [Status.Pending, Status.Blocked];

        // Default sort by Priority (descending) and Due Date (ascending)
        this.sort = [
          { field: 'priority', dir: SortDirection.Descending },
          { field: 'dueDate', dir: SortDirection.Ascending },
        ];
        break;

      case TabKeys.History:
        // First column will display the Completion Date and last column the Completed By
        this.columns = [
          END_TIME_COLUMN,
          NAME_COLUMN,
          WORKFLOW_NAME_COLUMN,
          PROJECT_COLUMN,
          STATUS_COLUMN,
          PRIORITY_COLUMN,
          COMPLETED_BY_COLUMN,
        ];

        // Completed status (if not more restrictive filter is applied)
        this.#activeTabStatus = [Status.Completed];
        this.taskListActions = {};

        // Default sort by Completed Date (descending)
        this.sort = [{ field: 'endTime', dir: SortDirection.Descending }];
        break;
    }

    // Request counter and then the data
    this.refreshTabData();
    this.resetPagination();
  }

  /**
   * Handles the event of the Grid to filter the data
   * @param {TaskFilterRequest} filter
   */
  onFilterEvent(filter: TaskFilterRequest): void {
    this.#filter = Object.assign({}, filter);
    this.getData(this.#filter);
  }

  rowSelected(event: number[]): void {
    this.updateSelectedTasks(this.tasks.filter((task) => event.includes(task.referenceId)));
    this.getProjectIds(event);
  }

  onConfirmPriority(priority: number): void {
    this.changePriorityService
      .updateTaskPriorities(priority, this.selectedTaskReferenceIds)
      .pipe(take(1))
      .subscribe({
        next: () => {
          this.getData(this.#filter);
          this.kmdModalService.close(ModalId.ChangePriority);
          this.gridService.setClearCheckboxes(true);
        },
        error: () => {
          this.priorityErrorMessage = 'Unable to change workflow priority.';
        },
      });
  }

  onSelectedRowsAction(event: string): void {
    this.openItems(event);
  }

  onSelectedItemsChange(event: number[]): void {
    this.#selectedItems = event;
  }

  onConfirmAssignee(event: DefaultAssignmentItems): void {
    this.updateTaskActionItems(
      TaskService.buildAssigneeRequest(event, this.#selectedItems),
      ModalId.ChangeAssignment,
      'Unable to change assignment.'
    );
  }

  onChangeDueDateConfirm(newDueDate: IsoDate): void {
    this.updateTaskActionItems({ dueDate: newDueDate }, ModalId.ChangeDueDate, ChangeDueDateComponent.errorMessage);
  }

  /**
   * Handles the event of the SearchBox to filter the data by
   * task name.
   * @param {string} value
   */
  onSearchEvent(value: string): void {
    this.lastSearched = value || '';
    this.refreshTabData();
    this.resetPagination();
  }

  onPageChanged(): void {
    this.taskListElementRef.nativeElement.scrollIntoView();
  }

  /**
   * Handles the event of the Grid to sort the data.
   * @param {SortDescriptor[]} sort
   */
  onSortChanged(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.refreshTabData();
  }

  protected updateTaskActionItems(request: Omit<ActionItemRequest, 'taskInstanceIds'>, modalId: string, errorMessage: string): void {
    super.updateTaskActionItems(request, modalId, errorMessage, () => {
      this.getData(this.#filter);
      this.gridService.setClearCheckboxes(true);
    });
  }

  /**
   * Initializes the grid columns with external data
   */
  private initColumns(): void {
    this.workflowDefinitionService.filterWorkflowDefinitions().subscribe({
      next: (response) => (WORKFLOW_NAME_COLUMN.filter.values = response),
    });

    this.projectService.filter().subscribe({
      next: (response) => (PROJECT_COLUMN.filter.values = response.items),
    });

    this.assigneeService
      .populateAssigneeFilter()
      .pipe(take(1))
      .subscribe({
        next: (data) => {
          ASSIGNEE_COLUMN.filter.values = COMPLETED_BY_COLUMN.filter.values = data;
        },
      });
  }

  /**
   * Gets the page data from the backend
   * @param {TaskFilterRequest} filterRequest
   */
  private getData(filterRequest: TaskFilterRequest): void {
    this.taskService
      .filter({
        ...filterRequest,
      })
      .pipe(take(1))
      .subscribe({
        next: (response: TaskFilterResponse) => {
          this.tasks = response.items;
          this.refreshTabData();
          this.resetPagination();
        },
      });
  }

  /**
   * Refresh the data displayed in a tab, applying filters and sort
   */
  private refreshTabData(): void {
    // Apply client filters: Tabs and Search Task
    this.tabData = this.tasks.filter(
      (item: TaskFilterItemResponse) =>
        (item.name?.toLowerCase() || '').indexOf(this.lastSearched?.toLowerCase()) !== -1 &&
        this.#activeTabStatus.some(
          (status) =>
            item.status.toLowerCase() === status.toLowerCase() &&
            ((status === Status.Blocked && this.#activeTab === TabKeys.Upcoming && !item.id) ||
              (status === Status.Blocked && this.#activeTab === TabKeys.Active && item.id) ||
              status !== Status.Blocked)
        )
    );

    // Apply default sort and refresh total data count.
    // Note: The History tab is sorted normally but the other two are sorted having in mind the DueDate field.
    this.tabData =
      this.#activeTab === TabKeys.History ? orderBy(this.tabData, this.sort) : this.orderByWithDueDate(this.tabData, this.sort);

    this.refreshPageData();
  }

  /**
   * Sorts the given data by keeping overdue tasks at the top and then applying the
   * current sort. Also, dueDate is sorted to have the empty dates at the bottom.
   * @param {TaskFilterItemResponse[]} data
   * @param {SortDescriptor[]} sort
   * @returns {TaskFilterItemResponse[]}
   */
  private orderByWithDueDate(data: TaskFilterItemResponse[], sort: SortDescriptor[]): TaskFilterItemResponse[] {
    const [overdueData, onTimeData] = data.reduce(
      ([overdue, onTime], item) => {
        // We use the workflow date pipe to get the "real" date value from the stored value
        if (DateUtility.hasDatePassed(this.workflowDatePipe.transform(item.dueDate))) {
          return [[...overdue, item], onTime];
        } else {
          return [overdue, [...onTime, item]];
        }
      },
      [[], []]
    );

    return [...orderBy(overdueData, sort), ...customOrderBy(onTimeData, sort, ['dueDate'])];
  }

  /**
   * Resets pagination
   */
  private resetPagination(): void {
    if (this.grid) {
      this.grid.resetPagination();
    }
  }

  /**
   * Refresh the data displayed in the current page.
   */
  private refreshPageData(): void {
    this.pageData = this.tabData.slice();
  }

  private getProjectIds(arr: number[]): void {
    this.#projectIds = arr.flatMap((id) => {
      const task = this.tasks.find((x) => x.referenceId === id);
      return task.projects.slice();
    });
  }

  private openItems(modalName: string): void {
    switch (modalName) {
      case ModalId.ChangeAssignment:
        super.openChangeAssignment(this.#projectIds);
        break;

      case ModalId.ChangePriority:
        this.kmdModalService.open(modalName);
        break;
    }
  }
}
