export interface WorkflowStatistic {
  id: string;
  name: string;
  activeRunsCount: number;
  tasksInProgressCount: number;
  overdueTasksCount: number;
  blockedTasksCount: number;
  failedTasksCount: number;
  totalTasksCount: number;
  completedTasksCount: number;
}

export interface WorkflowStatisticRequest {
  top: number;
}
