import { ColumnType } from '../../shared/grid/column-type';
import { Status } from '../../shared/status';
import { PriorityType, PriorityNumericRange } from '../../shared/grid/filter/shared/priority-filter';
import { FilterType } from '../../shared/grid/filter/shared/filter-type';
import { FilterListField, FilterRangeField, FilterCategorizedListField } from '../../shared/grid/filter/shared/filter-field';
import { defaultActionPopoverColumn } from '../../shared/grid/popover/action/action-popover';
import { BASE_OPTIONS, popoverCallback } from '../../shared/popover/task-grid-action-column';
import type { Column } from '../../shared/grid/column';

export const DUE_DATE_COLUMN: Readonly<Column> = {
  type: ColumnType.Date,
  field: 'dueDate',
  title: 'Due Date',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.DateRangeFuture,
    field: new FilterRangeField('minDueDate', 'maxDueDate'),
  },
} as const;

export const END_TIME_COLUMN: Readonly<Column> = {
  type: ColumnType.Date,
  field: 'endTime',
  title: 'Completion Date',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.DateRangePast,
    // TODO: Fill with valid fields of the TaskFilterRequest below when available
    field: new FilterRangeField('completedAfter', 'completedBefore'),
  },
} as const;

export const NAME_COLUMN: Readonly<Column> = {
  type: ColumnType.Link,
  field: 'name',
  title: 'Task',
  width: 100,
  sortable: true,
  filterable: false,
} as const;

export const WORKFLOW_NAME_COLUMN: Readonly<Column> = {
  type: ColumnType.String,
  field: 'workflowName',
  title: 'Workflow',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.List,
    field: new FilterListField('processDefinitionId'),
    keyField: 'id',
    displayField: 'name',
  },
} as const;

export const PROJECT_COLUMN: Readonly<Column> = {
  type: ColumnType.String,
  field: 'projects',
  title: 'Project',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.List,
    multiselect: true,
    keyField: 'id',
    field: new FilterListField('projectIds'),
    displayField: 'name',
  },
} as const;

export const STATUS_COLUMN: Readonly<Column> = {
  type: ColumnType.Status,
  field: 'status',
  title: 'Status',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.List,
    multiselect: true,
    values: Object.values(Status).map((value) => ({ name: value })),
    keyField: 'name',
    displayField: 'name',
  },
} as const;

export const PRIORITY_COLUMN: Readonly<Column> = {
  type: ColumnType.Priority,
  field: 'priority',
  title: 'Priority',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.RangeList,
    field: new FilterRangeField('minPriority', 'maxPriority'),
    values: Object.values(PriorityType).map((value) => ({ name: value })),
    keyField: 'name',
    displayField: 'name',
    getRange: PriorityNumericRange.getRange,
  },
} as const;

export const ASSIGNEE_COLUMN: Readonly<Column> = {
  type: ColumnType.BlankString,
  field: 'assignees',
  title: 'Assignee',
  width: 100,
  sortable: true,
  filterable: true,
  displayWithField: 'allAssigneeNames',
  filter: {
    type: FilterType.CategorizedList,
    // eslint-disable-next-line @typescript-eslint/naming-convention
    field: new FilterCategorizedListField({ User: 'assigneeWorkflowUserId', Group: 'assigneeGroupId' }),
    keyField: 'id',
    displayField: 'name',
    groupField: 'category',
    categoryField: 'category',
  },
} as const;

export const COMPLETED_BY_COLUMN: Readonly<Column> = { ...ASSIGNEE_COLUMN, title: 'Completed By' } as const;

export const OPTIONS_COLUMN: Readonly<Column> = {
  ...defaultActionPopoverColumn(BASE_OPTIONS.slice()),
} as const;
OPTIONS_COLUMN.popover.callback = popoverCallback(OPTIONS_COLUMN);
