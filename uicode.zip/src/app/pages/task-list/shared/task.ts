import { Status } from '../../shared/status';
import { UserFilterItemResponse } from '../../users/shared/user';

export interface TaskStartResponse {
  status: Status;
  users: UserFilterItemResponse[];
}
