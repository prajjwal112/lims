import { Status } from '../../shared/status';
import type { IdNamePair, WorkflowCamundaIdPair } from '../../shared/id-name-pair';
import type { UserFilterItemResponse } from '../../users/shared/user';
import type { IsoDate } from '../../../core/app-settings';

export interface TaskFilterRequest {
  taskDefinitionId?: string;
  assigneeWorkflowUserId?: number;
  assigneePlatformUserId?: string;
  assigneeGroupId?: number;
  processDefinitionId?: string;
  processInstanceId?: string;
  createdAfter?: IsoDate;
  completedBefore?: IsoDate;
  completedAfter?: IsoDate;
  status?: Status[];
  minPriority?: number;
  maxPriority?: number;
  minDueDate?: IsoDate;
  maxDueDate?: IsoDate;
  top?: number;
  skip?: number;
}

export interface TaskFilterItemResponse {
  projects: IdNamePair[];
  description: string;
  workflowName: string;
  priority: number;
  dueDate: IsoDate;
  name: string;
  id: string;
  startTime: IsoDate;
  endTime: IsoDate;
  status: Status;
  staleDate: IsoDate;
  referenceId: number;
  assignees: UserFilterItemResponse[];
  groupAssignees: IdNamePair[];
  allAssigneeNames?: string;
  runName: string;
}

export interface TaskFilterResponse {
  items: TaskFilterItemResponse[];
  count: number;
}

export interface ActionItemRequest {
  priority?: number;
  taskInstanceIds: WorkflowCamundaIdPair[];
  assignedUserIds?: number[];
  assignedGroupIds?: number[];
  dueDate?: IsoDate;
}
