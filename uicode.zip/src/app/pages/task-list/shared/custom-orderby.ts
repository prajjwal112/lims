/* Custom comparation functions for sorting data. Based in the Kendo Data Query functions. */

import { isPresent, isBlank } from '@progress/kendo-angular-grid/dist/es2015/utils';
import { getter, SortDescriptor } from '@progress/kendo-data-query';
import { SortDirection } from '../../shared/sort-direction';

const compare = (a, b): any => {
  if (isBlank(a)) {
    return a === b ? 0 : -1;
  }
  if (isBlank(b)) {
    return 1;
  }
  if (a.localeCompare) {
    return a.localeCompare(b);
  }
  return a > b ? 1 : a < b ? -1 : 0;
};

const compareDesc = (a, b): any => compare(b, a);

const customCompare = (a, b): any => {
  if (isBlank(a)) {
    return a === b ? 0 : 1;
  }
  if (isBlank(b)) {
    return -1;
  }
  if (a.localeCompare) {
    return a.localeCompare(b);
  }
  return a > b ? 1 : a < b ? -1 : 0;
};

const customCompareDesc = (a, b): any => customCompare(b, a);

const initial = (): any => 0;

const descriptorAsFunc = (descriptor: SortDescriptor, reverseBlankFields?: string[]): any => {
  const prop = getter(descriptor.field, true);

  // Fields with reverse blank comparation will use the custom comparation algorithm
  if (reverseBlankFields && reverseBlankFields.includes(descriptor.field)) {
    return (a, b): any => (descriptor.dir === SortDirection.Ascending ? customCompare : customCompareDesc)(prop(a), prop(b));
  }

  return (a, b): any => (descriptor.dir === SortDirection.Ascending ? compare : compareDesc)(prop(a), prop(b));
};

const composeSortDescriptors = (descriptors: SortDescriptor[], reverseBlankFields?: string[]): any =>
  descriptors
    .filter((x) => isPresent(x.dir))
    .map((descriptor) => descriptorAsFunc(descriptor, reverseBlankFields))
    .reduce((acc, curr): any => (a, b): any => acc(a, b) || curr(a, b), initial);

/**
 * Function based in the Kendo orderBy but with the option to put blank values of the specified fields
 * at the bottom (or top if they are sorted descending).
 * @param {any[]} data The data to be sorted.
 * @param {SortDescriptor[]} descriptors The descriptors by which the data will be sorted.
 * @param reverseBlankFields The list of fields to reverse the blanks.
 */
export const customOrderBy = (data: any[], descriptors: SortDescriptor[], reverseBlankFields?: string[]): any => {
  if (descriptors.some((x) => isPresent(x.dir))) {
    data = data.slice(0);
    const comparer = composeSortDescriptors(descriptors, reverseBlankFields);
    data = data.sort(comparer);
  }
  return data;
};
