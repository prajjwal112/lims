import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { GridModule } from '../shared/grid/grid.module';
import { ProjectsComponent } from './projects.component';
import { ButtonModule, TabsModule } from 'gds-atom-components';
import { UpdateNameDescriptionModule } from '../shared/update-name-description/update-name-description.module';
import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { MakeObsoleteModule } from '../shared/make-obsolete/make-obsolete.module';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewRunModule } from '../run/new-run/new-run.module';
import { ModalId } from '../shared/modal-id';

describe('ProjectComponent', () => {
  let component: ProjectsComponent;
  let fixture: ComponentFixture<ProjectsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProjectsComponent],
      imports: [
        GridModule,
        HttpClientTestingModule,
        RouterTestingModule,
        ButtonModule,
        DropDownAutoCompleteModule,
        TabsModule,
        UpdateNameDescriptionModule,
        MakeObsoleteModule,
        BrowserAnimationsModule,
        NewRunModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display all tabs', () => {
    expect(fixture.debugElement.query(By.css('kmd-tabs')).nativeElement.textContent.trim()).toBe('Active Obsolete');
  });

  it('should load Active data by default', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[0].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.obsoleted).toBeFalsy();
    expect(component.columns[0].linkPath).toBe('/projects');
  });

  it('should load Obsoleted data', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[1].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.obsoleted).toBeTruthy();
    expect(component.columns[0].linkPath).toBe('/obsoleted-projects');
  });

  it('should switch to Active data', () => {
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[1].triggerEventHandler('click', null);
    fixture.detectChanges();
    fixture.debugElement.queryAll(By.css('kmd-tabs li a'))[0].triggerEventHandler('click', null);
    fixture.detectChanges();

    expect(component.obsoleted).toBeFalsy();
  });

  it('should open a CreateProject modal', () => {
    spyOn(component, 'openModal');
    component.openCreateProjectModal();

    expect(component.openModal).toHaveBeenCalledWith(ModalId.UpdateNameDescription);
  });

  it('should show grid and autocomplete dropdown', () => {
    component.initialProjectCount = 2;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-dropdown-autocomplete'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('app-grid'))).toBeTruthy();
  });

  it('should show create project button if no items to be displayed on grid', () => {
    component.initialProjectCount = 0;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.no-project-container .create-project-body-btn'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('.no-project-container .create-project-body-btn')).nativeElement.textContent.trim()).toBe(
      'Create Project'
    );
  });
});
