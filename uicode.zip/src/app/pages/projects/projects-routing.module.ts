import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectsComponent } from './projects.component';
import { AuthGuard } from '../../auth-guard';

const routes: Routes = [
  {
    path: '',
    component: ProjectsComponent,
    pathMatch: 'full',
    canActivate: [AuthGuard],
  },
  {
    path: ':id',
    loadChildren: () => import('./project-detail/project-detail.module').then(m => m.ProjectDetailModule),
    canActivate: [AuthGuard],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProjectsRoutingModule {}
