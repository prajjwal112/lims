import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SortDescriptor } from '@progress/kendo-data-query';
import { KmdModalService } from 'gds-atom-components';
import { ProjectService } from '../../core/api/project/project.service';
import { StoreService, Action, ActionType } from '../../store.service';
import { SearchTextService } from '../shared/search-text.service';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../shared/common-data-type';
import { SortDirection } from '../shared/sort-direction';
import { GridComponent } from '../shared/grid/grid.component';
import { ComponentWithModalDirective } from '../shared/component-with-modal.directive';
import { ModalId } from '../shared/modal-id';
import {
  ACTIVE_RUNS_COLUMN,
  ACTIVE_TAB_POPOVER_ACTION_COLUMN,
  ACTIVE_TAB_PROJECT_NAME_COLUMN,
  DESCRIPTION_COLUMN,
  GAUGE_COLUMN,
  OBSOLETED_TAB_POPOVER_ACTION_COLUMN,
  OBSOLETED_TAB_PROJECT_NAME_COLUMN,
} from './projects-columns';
import type { OnDestroy, OnInit } from '@angular/core';
import type { Column } from '../shared/grid/column';
import type { Project, ProjectFilterRequest, ProjectResponse } from './shared/project';
import type { ActionClickEvent, OnActionClick } from '../shared/grid/popover/action/action-popover';
import type { Pagination } from '../shared/grid/grid.component';

const TAB_ID = {
  active: 'projects-Active',
  obsoleted: 'projects-Obsoleted',
} as const;

type TabId = typeof TAB_ID[keyof typeof TAB_ID];

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss', '../shared/page-header.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ProjectsComponent extends ComponentWithModalDirective implements OnActionClick, OnInit, OnDestroy {
  readonly tabId = TAB_ID;
  readonly modalId = ModalId;

  readonly #unsubscribe: Readonly<Subject<void>> = new Subject<void>();

  @ViewChild(GridComponent) private grid: GridComponent;

  columns: Column[] = [];
  sort: SortDescriptor[] = [];
  data: Project[] = [];
  searchData: Project[] = [];
  projectReferenceId: number;
  initialProjectCount: number;
  projectDescription: string;
  projectName: string;
  projectCount: number;
  suggest = false;
  obsoleted = false;

  #sortDirection: string;
  #searchName = '';
  #skip = DEFAULT_SKIP;
  #top = DEFAULT_TOP;

  constructor(
    public readonly projectService: ProjectService,
    protected readonly kmdModalService: KmdModalService,
    private readonly store: StoreService,
    private readonly searchTextService: SearchTextService
  ) {
    super(kmdModalService);
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Projects' }));
    ACTIVE_TAB_POPOVER_ACTION_COLUMN.popover.action.onClick = this.onActionClick.bind(this);
  }

  private static buildColumns(activeTab: TabId): Column[] {
    switch (activeTab) {
      case TAB_ID.active:
        return [ACTIVE_TAB_PROJECT_NAME_COLUMN, DESCRIPTION_COLUMN, ACTIVE_RUNS_COLUMN, GAUGE_COLUMN, ACTIVE_TAB_POPOVER_ACTION_COLUMN];
      case TAB_ID.obsoleted:
        return [
          OBSOLETED_TAB_PROJECT_NAME_COLUMN,
          DESCRIPTION_COLUMN,
          ACTIVE_RUNS_COLUMN,
          GAUGE_COLUMN,
          OBSOLETED_TAB_POPOVER_ACTION_COLUMN,
        ];
      default:
        return [];
    }
  }
  ngOnInit(): void {
    this.columns = ProjectsComponent.buildColumns(TAB_ID.active);
    this.sort = [{ field: 'name', dir: SortDirection.Ascending }];
    this.getAllDataOnInit();
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  public sortChanged(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.#sortDirection = sort[0]?.dir;
    this.getAllData();
  }

  public onSelectChange(filterName: string): void {
    this.#searchName = filterName;
    this.#skip = 1;
    this.resetPagination();
    this.getAllData();
  }

  public onTabSelect(event: { nextId: TabId }): void {
    this.searchTextService.setText(this.#searchName);
    this.#searchName = '';
    this.obsoleted = event.nextId === TAB_ID.obsoleted;
    this.columns = ProjectsComponent.buildColumns(event.nextId);
    this.#skip = 1;
    this.resetPagination();
    this.getAllData();
  }

  public onPageChangeHandler(event: Pagination): void {
    this.#skip = event.first;
    this.#top = event.resultsPerPage;
    this.getAllData();
  }

  public onActionClick(event: ActionClickEvent): void {
    const selectedData = this.data.find((data) => data.referenceId === event.dataItem.id);
    this.projectReferenceId = selectedData.referenceId;
    this.projectName = selectedData.name;
    this.projectDescription = selectedData.description;
    this.openModal(event.name as ModalId);
  }

  public confirmedAction(): void {
    this.getAllData();
  }

  public openCreateProjectModal(): void {
    this.projectReferenceId = 0;
    this.projectName = '';
    this.projectDescription = '';
    this.openModal(ModalId.UpdateNameDescription);
  }

  private resetPagination(): void {
    this.#skip = DEFAULT_SKIP;
    this.#top = DEFAULT_TOP;
    if (this.grid) {
      this.grid.resetPagination();
    }
  }

  private getProjectRequestData(): ProjectFilterRequest {
    return {
      top: this.#top,
      skip: this.#skip,
      projectName: (this.#searchName || '').trim(),
      sort: this.#sortDirection || '',
      archived: this.obsoleted,
    };
  }

  private getAllDataOnInit(): void {
    const requestData = this.getProjectRequestData();
    this.projectService
      .filter(requestData)
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: ProjectResponse) => {
          this.projectCount = data.count;
          this.initialProjectCount = data.count;
          const projects = (data && data.items) || [];
          this.data = projects.map((obj) => (obj.referenceId = obj.id) && obj);
          this.searchData = this.data.slice();
        },
      });
  }

  private getAllData(): void {
    const requestData = this.getProjectRequestData();
    this.projectService
      .filter(requestData)
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: ProjectResponse) => {
          this.projectCount = data.count;
          const projects = (data && data.items) || [];
          this.data = projects.map((obj) => (obj.referenceId = obj.id) && obj);
          this.searchData = this.data.slice();
        },
        error: () => {
          this.data = [];
          this.searchData = [];
          this.projectCount = 0;
        },
      });
  }
}
