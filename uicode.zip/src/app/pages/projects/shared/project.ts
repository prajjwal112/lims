import { WorkflowInstanceStatus } from '../../workflow-definitions/shared/workflow-instance';

export interface Project {
  referenceId?: number;
  id: number;
  name: string;
  description: string;
  activeRun: string;
  tasks: string;
}

export interface ProjectDetailResponse {
  id: number;
  name: string;
  processDefinitionId: string;
  workflowCount: number;
  activeRuns: number;
}

export interface UpdateProjectRequest {
  id?: number;
  name?: string;
  description?: string;
  archived?: boolean;
}

export interface ProjectFilterRequest {
  top?: number;
  skip?: number;
  projectName?: string;
  sort?: string;
  archived?: boolean;
  projectId?: number;
  groupId?: number;
  processDefinitionId?: string;
  processInstanceStatus?: WorkflowInstanceStatus;
  processInstanceIds?: string[];
}

export interface UpdateProjectResponse {
  id: number;
}

export interface ProjectItemRequest {
  projectReferenceId: number;
  updateIds: number[];
}
export interface ProjectGroups {
  id: number;
  name: string;
  description: string;
  usersCount: string;
  projects: {
    id: number;
  }[];
}

export interface ProjectResponse {
  count: number;
  items: Project[];
}
