import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GridModule } from '../shared/grid/grid.module';
import { ProjectsRoutingModule } from './projects-routing.module';
import { ProjectsComponent } from './projects.component';
import { ButtonModule, TabsModule } from 'gds-atom-components';
import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { MakeObsoleteModule } from '../shared/make-obsolete/make-obsolete.module';
import { UpdateNameDescriptionModule } from '../shared/update-name-description/update-name-description.module';
import { NewRunModule } from '../run/new-run/new-run.module';
@NgModule({
  declarations: [ProjectsComponent],
  imports: [
    ButtonModule,
    CommonModule,
    ProjectsRoutingModule,
    GridModule,
    DropDownAutoCompleteModule,
    TabsModule,
    MakeObsoleteModule,
    UpdateNameDescriptionModule,
    NewRunModule,
  ],
  providers: [],
})
export class ProjectsModule {}
