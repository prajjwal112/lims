import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ButtonModule, AlertsModule, PopoverModule, ModalsModule } from 'gds-atom-components';
import { ProjectDetailComponent } from './project-detail.component';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { MakeObsoleteModule } from '../../shared/make-obsolete/make-obsolete.module';
import { UpdateNameDescriptionModule } from '../../shared/update-name-description/update-name-description.module';
import { CardsModule } from '../../shared/cards/cards.module';
import { GroupListModule } from '../../groups/shared/group-list/group-list.module';
import { UserListModule } from '../../users/shared/user-list/user-list.module';
import { NewRunModule } from '../../run/new-run/new-run.module';

@NgModule({
  declarations: [ProjectDetailComponent],
  imports: [
    CommonModule,
    ButtonModule,
    AlertsModule,
    PopoverModule,
    ModalsModule,
    ManageItemsModule,
    MakeObsoleteModule,
    UpdateNameDescriptionModule,
    NewRunModule,
    CardsModule,
    GroupListModule,
    UserListModule,
    RouterModule.forChild([{ path: '', component: ProjectDetailComponent, pathMatch: 'full' }]),
  ],
})
export class ProjectDetailModule {}
