import { Component, Output, EventEmitter, ViewChild } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { switchMap, takeUntil } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';

import { StoreService, Action, ActionType } from '../../../store.service';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../../shared/common-data-type';
import { RoleService } from '../../../core/api/role/role.service';
import { ProjectService } from '../../../core/api/project/project.service';
import { UserService } from '../../../core/api/user/user.service';
import { GroupService } from '../../../core/api/group/group.service';
import {
  GROUP_NAME_COLUMN,
  GROUP_DESCRIPTION_COLUMN,
  USERS_COUNT_COLUMN,
  GROUP_OPTIONS_COLUMN,
} from '../../groups/shared/group-grid-columns';
import { NAME_COLUMN, ROLES_COLUMN, OPTIONS_COLUMN } from '../../users/shared/user-grid-columns';
import { UnassociatedService } from '../../shared/unassociated/unassociated.service';
import { ComponentWithModalDirective } from '../../shared/component-with-modal.directive';
import { SortDirection } from '../../shared/sort-direction';
import { GroupListComponent } from '../../groups/shared/group-list/group-list.component';
import { UserListComponent } from '../../users/shared/user-list/user-list.component';
import { bindActionClick } from '../../shared/grid/popover/action/action-popover';
import { ModalId } from '../../shared/modal-id';
import type { OnInit, OnDestroy, AfterViewChecked } from '@angular/core';
import type { Group } from '../../groups/shared/group';
import type { ProjectGroups, ProjectItemRequest, ProjectResponse } from '../shared/project';
import type { Column } from '../../shared/grid/column';
import type { Role, RoleListResponse } from '../../roles/shared/role';
import type { WorkflowStatistic } from '../../task-list/workflow-statistic';
import type { UserFilterItem } from '../../users/shared/user';
import type { ConfirmedStatus, ManageItemsRequest } from '../../shared/common-data-type';

@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.scss', '../../shared/page-header.scss'],
})
export class ProjectDetailComponent extends ComponentWithModalDirective implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild(UserListComponent) private userListElement: UserListComponent;
  @ViewChild(GroupListComponent) private groupListElement: GroupListComponent;
  @Output() confirmedAction = new EventEmitter<ConfirmedStatus>();

  public listUsers: UserFilterItem[] = [];
  public listGroups: ProjectGroups[] = [];
  public projectName = '';
  public projectDescription = '';
  public projectObsoleted: boolean;
  public projectUsers: UserFilterItem[];
  public newlyCreated: boolean;
  public posX: number = null;
  public posY: number = null;
  public projectReferenceId: number;
  public roleData: Role[];
  public initUsersCount: number;
  public usersCount: number;
  public groupsCount: number;
  public groupColumns: Column[] = [GROUP_NAME_COLUMN, GROUP_DESCRIPTION_COLUMN, USERS_COUNT_COLUMN, GROUP_OPTIONS_COLUMN];
  public userColumns: Column[] = [NAME_COLUMN, ROLES_COLUMN, OPTIONS_COLUMN];
  public groupSortDirection: string;
  public confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };
  public projectWorkflows: WorkflowStatistic[] = [];
  public projectGroups: Group[];

  public readonly userActions = {
    [ModalId.AddProjects]: 'Add to project',
    [ModalId.AddGroups]: 'Add to group',
    [ModalId.AddRoles]: 'Add role assignment',
  } as const;
  public readonly modalId = ModalId;

  private readonly unsubscribe = new Subject<void>();

  private groupTop: number = DEFAULT_TOP;
  private groupSkip: number = DEFAULT_SKIP;
  private userTop: number = DEFAULT_TOP;
  private userSkip: number = DEFAULT_SKIP;

  constructor(
    public projectService: ProjectService,
    protected kmdModalService: KmdModalService,
    private route: ActivatedRoute,
    private router: Router,
    private store: StoreService,
    private roleService: RoleService,
    private userService: UserService,
    private groupService: GroupService,
    private unassociatedService: UnassociatedService
  ) {
    super(kmdModalService);
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Projects' }));
  }

  private static segregateNames(objectList: Role[]): string[] {
    return objectList.map((obj) => obj.name);
  }

  ngOnInit(): void {
    this.projectObsoleted = this.router.routerState.snapshot.url.includes('obsoleted-projects');
    this.route.queryParams.subscribe({
      next: (queryParam) => {
        this.newlyCreated = queryParam.success === 'true';
      },
    });
    this.route.paramMap
      .pipe(
        switchMap((params: ParamMap) => {
          this.projectReferenceId = parseInt(params.get('id'), 10);
          return this.projectService.filter({
            projectId: this.projectReferenceId,
            archived: this.projectObsoleted,
          });
        })
      )
      .subscribe({
        next: (data: ProjectResponse) => {
          const project = data.items[0];
          if (project) {
            this.projectName = project.name;
            this.projectDescription = project.description;
          }
          this.getGroups();
          this.getWorkflows();
          this.getUsers();
        },
      });
    this.getRolesData();
  }

  ngAfterViewChecked(): void {
    OPTIONS_COLUMN.popover.action.onClick = bindActionClick(OPTIONS_COLUMN, this.userListElement);
    GROUP_OPTIONS_COLUMN.popover.action.onClick = bindActionClick(GROUP_OPTIONS_COLUMN, this.groupListElement);
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  public getUsers(): void {
    this.userService
      .filter({
        top: this.userTop,
        skip: this.userSkip,
        projectIds: [this.projectReferenceId],
      })
      .subscribe({
        next: (data) => {
          this.usersCount = data.count;
          this.projectUsers = data.items.slice();
          if (!this.initUsersCount) {
            this.initUsersCount = this.usersCount;
          }
        },
        error: () => {
          this.projectUsers = [];
        },
      });
  }

  public getGroups(): void {
    this.groupService
      .filter({
        top: this.groupTop,
        skip: this.groupSkip,
        projectIds: [this.projectReferenceId],
        sort: this.groupSortDirection as SortDirection,
      })
      .subscribe({
        next: (data) => {
          this.groupsCount = data.count;
          this.projectGroups = data.items;
        },
        error: () => {
          this.projectGroups = [];
        },
      });
  }

  public getWorkflows(): void {
    this.projectService.getWorkflowStatistics(this.projectReferenceId).subscribe({
      next: (data) => {
        this.projectWorkflows = data;
      },
    });
  }

  public openAddUserModal(): void {
    this.unassociatedService
      .getUnassociatedUsers(undefined, this.projectReferenceId)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data: UserFilterItem[]) => {
          this.listUsers = data.slice();
          this.openModal(ModalId.AddUsers);
        },
      });
  }

  public openAddGroupModal(): void {
    this.unassociatedService
      .getUnassociatedGroups(this.projectReferenceId)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data: ProjectGroups[]) => {
          this.listGroups = data.slice();
          this.openModal(ModalId.AddGroups);
        },
      });
  }

  public showHeadPopover(event: Event): void {
    event.preventDefault();
    const currentTarget = event.currentTarget as HTMLElement;
    this.posX = currentTarget.offsetLeft + currentTarget.clientWidth / 2;
    this.posY = currentTarget.offsetTop + currentTarget.clientHeight / 2;
  }

  public onAddUserConfirm(confirmedData: ManageItemsRequest): void {
    this.projectService
      .addUsersToProject(this.buildProjectItemsRequest(confirmedData))
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: () => {
          this.closeModal(ModalId.AddUsers);
          this.getUsers();
        },
        error: () => {
          this.confirmedStatus = {
            status: false,
            message: 'Unable to add user(s) to group.',
          };
          this.confirmedAction.emit(this.confirmedStatus);
        },
      });
  }

  public onAddGroupConfirm(confirmedData: ManageItemsRequest): void {
    this.projectService
      .addGroupsToProject(this.buildProjectItemsRequest(confirmedData))
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: () => {
          this.closeModal(ModalId.AddGroups);
          this.getGroups();
        },
        error: () => {
          this.confirmedStatus = {
            status: false,
            message: 'Unable to add group(s) to the project.',
          };
          this.confirmedAction.emit(this.confirmedStatus);
        },
      });
  }

  public editProjectConfirmedAction(): void {
    this.getProjectDetail();
  }

  public obsoleteConfirmedAction(): void {
    this.projectObsoleted = true;
    this.getProjectDetail();
  }

  private getRolesData(): void {
    this.roleService
      .getData()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (roleData: RoleListResponse) => {
          this.roleData = roleData.items.slice();
          this.userColumns[this.userColumns.indexOf(ROLES_COLUMN)].filter.values = ProjectDetailComponent.segregateNames(this.roleData);
        },
      });
  }

  private getProjectDetail(): void {
    this.projectService
      .filter({
        projectId: this.projectReferenceId,
        archived: this.projectObsoleted,
      })
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data: ProjectResponse) => {
          this.projectName = data.items && data.items[0]?.name;
          this.projectDescription = data.items && data.items[0]?.description;
        },
      });
  }

  private buildProjectItemsRequest(projectData: ManageItemsRequest): ProjectItemRequest {
    return {
      projectReferenceId: this.projectReferenceId,
      updateIds: projectData.updateIds,
    };
  }
}
