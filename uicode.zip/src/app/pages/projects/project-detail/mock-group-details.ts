import { GroupResponse } from '../../groups/shared/group';

export const mockGroupDetails: GroupResponse = {
  items: [
    {
      id: 7,
      name: 'Smoke Testing',
      description: 'test',
      usersCount: 4,
      projects: [
        {
          id: 1,
          name: 'Project A',
          description: 'Test Project A',
          archived: false,
          countTasks: 0,
        },
        {
          id: 10,
          name: 'Demo Project B',
          description: 'Demo test project',
          archived: false,
          countTasks: 0,
        },
        {
          id: 9,
          name: 'Demo Project A',
          description: 'Demo test project',
          archived: false,
          countTasks: 0,
        },
      ],
    },
  ],
  count: 1,
};
