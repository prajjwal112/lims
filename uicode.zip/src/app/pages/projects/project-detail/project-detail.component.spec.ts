import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { AlertsModule, PopoverModule } from 'gds-atom-components';

import { ProjectService } from '../../../core/api/project/project.service';
import { UnassociatedService } from '../../shared/unassociated/unassociated.service';
import { ProjectDetailComponent } from './project-detail.component';
import { ProjectResponse } from '../shared/project';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { GroupListModule } from '../../groups/shared/group-list/group-list.module';
import { UserListModule } from '../../users/shared/user-list/user-list.module';
import { CardsModule } from '../../shared/cards/cards.module';
import { mockGroupDetails } from './mock-group-details';

const PROJECT: Readonly<ProjectResponse> = Object.freeze({
  items: [{ id: 9, name: 'Demo Project A', description: 'Description', activeRun: '', tasks: '' }],
  count: 1,
});
describe('ProjectDetailComponent', () => {
  let component: ProjectDetailComponent;
  let fixture: ComponentFixture<ProjectDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProjectDetailComponent],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        ManageItemsModule,
        GroupListModule,
        UserListModule,
        CardsModule,
        PopoverModule,
        AlertsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ProjectDetailComponent],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        ManageItemsModule,
        GroupListModule,
        UserListModule,
        CardsModule,
        PopoverModule,
        AlertsModule,
      ],
      providers: [
        ProjectService,
        UnassociatedService,
        {
          provide: ActivatedRoute,
          useValue: {
            paramMap: of(convertToParamMap({ id: '9' })),
            queryParams: of({ success: 'true' }),
          },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(ProjectDetailComponent);
    component = fixture.componentInstance;
    component.projectName = PROJECT.items[0].name;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the name of the Project detail', () => {
    expect(fixture.debugElement.query(By.css('h1.col-8')).nativeElement.textContent.trim()).toBe(PROJECT.items[0].name);
  });

  it('should display Add Users button', () => {
    expect(fixture.debugElement.queryAll(By.css('.title-container button'))[0].nativeElement).toBeTruthy();
  });

  it('should display Add Group button', () => {
    expect(fixture.debugElement.queryAll(By.css('.title-container button'))[1].nativeElement).toBeTruthy();
  });

  it('should display groups table', () => {
    const GROUP_DATA = mockGroupDetails;
    component.groupsCount = GROUP_DATA.count;
    component.projectGroups = GROUP_DATA.items;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-group-list'))).toBeTruthy();
  });

  it('should show Add group button if no groups to be displayed on grid', () => {
    component.groupsCount = 0;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.no-user-container button'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('.no-user-container button')).nativeElement.textContent.trim()).toBe('Add Group');
  });

  it('should show Add Users button if no users to be displayed on grid', () => {
    component.usersCount = 0;
    component.initUsersCount = 0;

    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.add-body-btn'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('button.add-body-btn')).nativeElement.textContent.trim()).toBe('Add Users');
  });

  it('should display project workflows', () => {
    component.projectWorkflows = [
      {
        id: 'tingasadjkasd:1:919074ad-9c54-11e9-b7da-9ebff78ee246',
        name: 'test data',
        activeRunsCount: 1,
        tasksInProgressCount: 1,
        overdueTasksCount: 0,
        blockedTasksCount: 0,
        failedTasksCount: 0,
        totalTasksCount: 1,
        completedTasksCount: 1,
      },
    ];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-cards'))).toBeTruthy();
  });

  it('should display the message if no project workflows to display', () => {
    component.projectWorkflows = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.no-workflow-container h6')).nativeElement.textContent.trim()).toBe(
      'There are no workflows in this project. Create new workflows or link existing ones in the workflow definition section.'
    );
  });
});
