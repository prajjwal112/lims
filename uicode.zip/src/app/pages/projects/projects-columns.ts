import { ColumnType } from '../shared/grid/column-type';
import { defaultActionPopoverColumn } from '../shared/grid/popover/action/action-popover';
import { ModalId } from '../shared/modal-id';
import type { Column } from '../shared/grid/column';
import type { FieldPopoverMenuAction } from '../shared/grid/popover/action/action-popover';

export const DESCRIPTION_COLUMN: Readonly<Column> = {
  type: ColumnType.String,
  field: 'description',
  title: 'Description',
  width: 120,
  sortable: false,
  filterable: false,
} as const;

export const ACTIVE_RUNS_COLUMN: Readonly<Column> = {
  type: ColumnType.String,
  field: 'activeRun',
  title: 'Active runs',
  width: 30,
  sortable: false,
  filterable: false,
} as const;

export const GAUGE_COLUMN: Readonly<Column> = {
  type: ColumnType.Gauge,
  field: 'gauge',
  title: 'Tasks',
  width: 30,
  sortable: false,
  filterable: false,
} as const;

export const ACTIVE_TAB_PROJECT_NAME_COLUMN: Readonly<Column> = {
  type: ColumnType.Link,
  field: 'name',
  title: 'Project Name',
  width: 80,
  sortable: true,
  filterable: false,
  linkPath: '/projects',
} as const;

export const OBSOLETED_TAB_PROJECT_NAME_COLUMN: Readonly<Column> = {
  ...ACTIVE_TAB_PROJECT_NAME_COLUMN,
  linkPath: '/obsoleted-projects',
};

export const OBSOLETE_ACTION: Readonly<FieldPopoverMenuAction> = {
  name: ModalId.MakeProjectObsolete,
  display: 'Obsolete project',
} as const;

export const BASE_POPOVER_ACTIONS: ReadonlyArray<FieldPopoverMenuAction> = [
  { name: ModalId.UpdateNameDescription, display: 'Edit project' },
  { name: ModalId.NewRun, display: 'Start workflow run' },
] as const;

export const ACTIVE_TAB_POPOVER_ACTION_COLUMN: Readonly<Column> = {
  ...defaultActionPopoverColumn([...BASE_POPOVER_ACTIONS, OBSOLETE_ACTION]),
} as const;

export const OBSOLETED_TAB_POPOVER_ACTION_COLUMN: Readonly<Column> = {
  ...defaultActionPopoverColumn([...BASE_POPOVER_ACTIONS, { ...OBSOLETE_ACTION, disabled: true }]),
} as const;
