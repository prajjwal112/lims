import { Component } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';

import { WorkflowDefinitionService } from '../../../core/api/workflow-definition/workflow-definition.service';
import { ProjectService } from '../../../core/api/project/project.service';
import { ModalId } from '../../shared/modal-id';
import { ComponentWithModalDirective } from '../../shared/component-with-modal.directive';
import type { OnInit } from '@angular/core';
import type { Project, ProjectResponse } from '../../projects/shared/project';
import type {
  FilteredWorkflowDefinitionWithSimplifiedProjects,
  WorkflowPublishResponse,
} from '../../workflow-definitions/shared/workflow-definition';

@Component({
  selector: 'app-new-workflow',
  templateUrl: './new-workflow.component.html',
  styleUrls: ['./new-workflow.component.scss'],
})
export class NewWorkflowComponent extends ComponentWithModalDirective implements OnInit {
  readonly modalId = ModalId;

  readonly #definitionTemplateId: number;
  readonly #xml = '';
  #isBpmnMissing = false;
  public workflowDefinition: FilteredWorkflowDefinitionWithSimplifiedProjects;
  public projects: Project[] = [];
  public successMessage = false;
  public newWorkflowError: { title: string; message: string } = { title: '', message: '' };

  constructor(
    private readonly workflowDefinitionService: WorkflowDefinitionService,
    private readonly router: Router,
    private readonly projectService: ProjectService,
    protected readonly kmdModalService: KmdModalService
  ) {
    super(kmdModalService);
    const { workflowName, description, projectIds = [], verifiedTaskTemplate } = this.router.getCurrentNavigation().extras.state;
    this.#definitionTemplateId = verifiedTaskTemplate.definitionTemplateId;
    this.#xml = verifiedTaskTemplate.xml;
    this.workflowDefinition = {
      name: workflowName,
      id: '',
      referenceId: this.#definitionTemplateId,
      description,
      trackDueDate: verifiedTaskTemplate.dueDateTracked,
      projects: projectIds,
      lastUpdate: '',
      active: true,
    };
  }

  ngOnInit(): void {
    if (!this.#xml.trim()) {
      this.#isBpmnMissing = true;
      this.newWorkflowError = { title: 'Workflow publish error.', message: 'BPMN file is missing.' };
      this.openModal(ModalId.NewWorkflowError);
    }
    setTimeout(() => (this.successMessage = true), 100);
    this.getProjects();
  }

  private getProjects(): void {
    this.projectService
      .filter({})
      .pipe(take(1))
      .subscribe({
        next: (response: ProjectResponse) => {
          this.projects = response.items.filter((project: Project) =>
            this.workflowDefinition.projects.some((selectedProject) => selectedProject === project.id)
          );
        },
      });
  }

  private formatErrorMessages(response: HttpErrorResponse): void {
    this.newWorkflowError.title = 'Workflow publish failed.';

    if (response.error?.length > 0) {
      for (const workflowError of response.error) {
        if (workflowError.message === 'BPMN error') {
          for (const detail of workflowError.details) {
            if (detail === 'Missing BPMN') {
              this.#isBpmnMissing = true;
              this.newWorkflowError.message = 'BPMN file is missing.';
            }
          }
        }
      }
    } else {
      this.newWorkflowError.message = 'Workflow service could not be reached, please contact your administrator.';
      if (response.error.message === 'BPMN was not valid and will not be deployable' && response.error.details) {
        for (const detail of response.error.details) {
          this.newWorkflowError.message += `<br/> ${detail}`;
        }
      }
    }
  }

  public onErrorModalClose(): void {
    if (this.#isBpmnMissing) {
      this.cancel();
    }
  }

  public cancel(): void {
    this.router.navigate(['/modeler'], {
      state: {
        modelerId: this.workflowDefinition.referenceId,
        modelerName: this.workflowDefinition.name,
        dueDateTracked: this.workflowDefinition.trackDueDate,
      },
    });
  }

  public onSubmit(): void {
    this.workflowDefinitionService.publish(this.#definitionTemplateId).subscribe({
      next: (response: WorkflowPublishResponse) => {
        this.router.navigate(['/workflow-definitions/default-assignment'], {
          state: {
            workflowName: this.workflowDefinition.name,
            processDefinitionId: response.processDefinitionId,
            projectIds: this.workflowDefinition.projects,
          },
        });
      },
      error: (response: HttpErrorResponse) => {
        this.formatErrorMessages(response);
        this.openModal(ModalId.NewWorkflowError);
      },
    });
  }
}
