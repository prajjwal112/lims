import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/auth-guard';

import { NewWorkflowComponent } from './new-workflow.component';
import { PublishAccessGuard } from '../../shared/publish-access.guard';

const routes: Routes = [{ path: '', component: NewWorkflowComponent, pathMatch: 'full', canActivate: [AuthGuard, PublishAccessGuard] }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NewWorkflowRoutingModule {}
