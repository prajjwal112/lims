import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertsModule, ButtonModule, DropdownsModule, InputFieldsModule, ModalsModule, RadioButtonModule } from 'gds-atom-components';

import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DueDateLabelModule } from '../../shared/due-date-label/due-date-label.module';
import { NewWorkflowFieldsModule } from '../../shared/new-workflow-fields/new-workflow-fields.module';
import { NewWorkflowComponent } from './new-workflow.component';
import { NewWorkflowRoutingModule } from './new-workflow-routing.module';
import { ValidationErrorsModule } from '../../shared/validation-errors/validation-errors.module';

@NgModule({
  declarations: [NewWorkflowComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NewWorkflowRoutingModule,
    ModalsModule,
    AlertsModule,
    ButtonModule,
    InputFieldsModule,
    RadioButtonModule,
    DueDateLabelModule,
    WorkflowPipeModule,
    NewWorkflowFieldsModule,
    DropdownsModule,
    ValidationErrorsModule,
  ],
})
export class NewWorkflowModule {}
