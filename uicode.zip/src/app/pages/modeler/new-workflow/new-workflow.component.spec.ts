import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CommonModule } from '@angular/common';
import { Router, RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { AlertsModule, ButtonModule, DropdownsModule, InputFieldsModule, ModalsModule, RadioButtonModule } from 'gds-atom-components';

import { ProjectService } from '../../../core/api/project/project.service';
import { WorkflowDefinitionService } from '../../../core/api/workflow-definition/workflow-definition.service';
import { NewWorkflowComponent } from './new-workflow.component';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DueDateLabelModule } from '../../shared/due-date-label/due-date-label.module';
import { ValidationErrorsModule } from '../../shared/validation-errors/validation-errors.module';
import { NewWorkflowFieldsModule } from '../../shared/new-workflow-fields/new-workflow-fields.module';
import { ModalId } from '../../shared/modal-id';

@Component({ template: '' })
class TestComponent {}

const testRoutes: Routes = [
  {
    path: 'workflow-definitions',
    children: [
      {
        path: 'default-assignment',
        component: TestComponent,
      },
    ],
  },
  {
    path: 'modeler',
    component: TestComponent,
  },
];

describe('NewWorkflowComponent', () => {
  let component: NewWorkflowComponent;
  let fixture: ComponentFixture<NewWorkflowComponent>;
  let router: Router;

  function publish(): void {
    component.onSubmit();
    tick();
    fixture.detectChanges();
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NewWorkflowComponent, TestComponent],
      imports: [
        AlertsModule,
        ButtonModule,
        RadioButtonModule,
        DropdownsModule,
        InputFieldsModule,
        DueDateLabelModule,
        WorkflowPipeModule,
        ModalsModule,
        HttpClientTestingModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        ValidationErrorsModule,
        NewWorkflowFieldsModule,
        RouterModule,
        RouterTestingModule.withRoutes(testRoutes),
        NoopAnimationsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    router = TestBed.inject(Router);
    spyOn(router, 'getCurrentNavigation').and.returnValue({
      id: 0,
      initialUrl: null,
      extractedUrl: null,
      trigger: 'imperative',
      previousNavigation: null,
      extras: {
        state: {
          verifiedTaskTemplate: {
            xml: 'xml',
            definitionTemplateId: 0,
            dueDateTracked: true,
          },
          workflowName: 'test',
          description: 'test description',
          projectIds: [1, 2],
        },
      },
    });

    spyOn(TestBed.inject(ProjectService), 'filter').and.returnValue(
      of({
        count: 3,
        items: [
          {
            referenceId: 1,
            id: 1,
            name: 'test',
            description: 'test description',
            activeRun: '',
            tasks: '',
          },
          {
            referenceId: 2,
            id: 2,
            name: 'test2',
            description: 'test description 2',
            activeRun: '',
            tasks: '',
          },
          {
            referenceId: 3,
            id: 3,
            name: 'test3',
            description: 'test description 3',
            activeRun: '',
            tasks: '',
          },
        ],
      })
    );
    fixture = TestBed.createComponent(NewWorkflowComponent);
    component = fixture.componentInstance;
    fixture.ngZone.run(() => router.initialNavigation());
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should retrieve data when passed in', () => {
    expect(component.workflowDefinition).toEqual({
      name: 'test',
      id: '',
      referenceId: 0,
      description: 'test description',
      trackDueDate: true,
      projects: [1, 2],
      lastUpdate: '',
      active: true,
    });
  });

  it('should preload name', () => {
    expect(fixture.debugElement.queryAll(By.css('label + span'))[0].nativeElement.textContent).toEqual(component.workflowDefinition.name);
  });

  it('should preload description', () => {
    expect(fixture.debugElement.queryAll(By.css('label + span'))[1].nativeElement.textContent).toEqual(
      component.workflowDefinition.description
    );
  });

  it('should preload projects', () => {
    expect(fixture.debugElement.queryAll(By.css('label + span'))[2].nativeElement.textContent).toEqual(
      component.projects[0].name + ', ' + component.projects[1].name
    );
  });

  it('should preload track due date', () => {
    expect(fixture.debugElement.queryAll(By.css('label + span'))[3].nativeElement.textContent).toEqual('true');
  });

  it('should redirect to modeler when cancel', fakeAsync(() => {
    const navigateSpy = spyOn(router, 'navigate').and.stub();
    component.cancel();
    tick();
    fixture.detectChanges();

    expect(navigateSpy).toHaveBeenCalledWith(['/modeler'], {
      state: {
        modelerId: component.workflowDefinition.referenceId,
        modelerName: component.workflowDefinition.name,
        dueDateTracked: component.workflowDefinition.trackDueDate,
      },
    });
  }));

  describe('on publish success', () => {
    it('should redirect to /default-assignment', fakeAsync(() => {
      const navigateSpy = spyOn(router, 'navigate').and.stub();
      spyOn(TestBed.inject(WorkflowDefinitionService), 'publish').and.returnValue(
        of({
          processDefinitionId: '0',
        })
      );
      publish();

      expect(navigateSpy).toHaveBeenCalledWith(['/workflow-definitions/default-assignment'], {
        state: {
          workflowName: component.workflowDefinition.name,
          processDefinitionId: '0',
          projectIds: component.workflowDefinition.projects,
        },
      });
    }));
  });

  describe('on error', () => {
    function closeModal(): void {
      fixture.debugElement.query(By.css(`#${ModalId.NewWorkflowError} button`)).triggerEventHandler('click', null);
      tick();
      fixture.detectChanges();
    }

    it('should show error modal when Publish fails', fakeAsync(() => {
      const error = { error: [{ message: 'BPMN error', details: ['Missing BPMN'] }], message: '', name: 'error' };
      spyOn(TestBed.inject(WorkflowDefinitionService), 'publish').and.returnValue(throwError(error));
      publish();

      expect(fixture.debugElement.queryAll(By.css('.kmd-modal')).length).toEqual(1);
    }));

    it('should close error modal when click modal close and error is not Missing BPMN', fakeAsync(() => {
      const error = { error: [{ message: 'BPMN error', details: ['Missing BPMN'] }], message: '', name: 'error' };
      spyOn(TestBed.inject(WorkflowDefinitionService), 'publish').and.returnValue(throwError(error));
      publish();
      closeModal();

      expect(fixture.debugElement.queryAll(By.css('.kmd-modal')).length).toEqual(0);
    }));

    it('should redirect to modeler when error modal close and error is Missing BPMN', fakeAsync(() => {
      const error = { error: [{ message: 'BPMN error', details: ['Missing BPMN'] }], message: '', name: 'error' };
      const navigateSpy = spyOn(router, 'navigate').and.stub();
      spyOn(TestBed.inject(WorkflowDefinitionService), 'publish').and.returnValue(throwError(error));
      publish();
      closeModal();

      expect(navigateSpy).toHaveBeenCalledWith(['/modeler'], {
        state: {
          modelerId: component.workflowDefinition.referenceId,
          modelerName: component.workflowDefinition.name,
          dueDateTracked: component.workflowDefinition.trackDueDate,
        },
      });
    }));
  });
});
