import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from '../../auth-guard';
import { ModelerComponent } from './modeler.component';
import { AccessGuard } from '../shared/access.guard';
import { PublishAccessGuard } from '../shared/publish-access.guard';
import { DeactivateGuard } from './deactivate.guard';

const routes: Routes = [
  { path: '', component: ModelerComponent, canActivate: [AuthGuard, AccessGuard], canDeactivate: [DeactivateGuard] },
  {
    path: 'publish',
    loadChildren: (): Promise<any> => import('./new-workflow/new-workflow.module').then((m) => m.NewWorkflowModule),
    canActivate: [AuthGuard, PublishAccessGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ModelerRoutingModule {}
