import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { LayoutModule } from '@progress/kendo-angular-layout';
import {
  TooltipModule,
  AlertsModule,
  ButtonModule,
  DropdownsModule,
  InputFieldsModule,
  RadioButtonModule,
  CheckboxModule,
  ModalsModule,
  KmdModalComponent,
  ToggleModule,
  AccordionsModule,
} from 'gds-atom-components';

import { ModelerRoutingModule } from './modeler-routing.module';
import { ModelerComponent } from './modeler.component';

import { PillsModule } from '../shared/pills/pills.module';
import { GridModule } from '../shared/grid/grid.module';
import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';

import { ConfigurationWindowComponent } from './shared/configuration-window/configuration-window.component';
import { GatewayConfigurationComponent } from './gateway-configuration/gateway-configuration.component';
import { GatewayConfigurationTypeComponent } from './gateway-configuration/gateway-configuration-type/gateway-configuration-type.component';
import { GatewayConfigurationConditionsComponent } from './gateway-configuration/gateway-configuration-conditions/gateway-configuration-conditions.component';
import { ConditionFieldsComponent } from './gateway-configuration/gateway-configuration-conditions/condition-fields/condition-fields.component';
import { TaskConfigurationComponent } from './task-configuration/task-configuration.component';
import { TaskDetailComponent } from './task-configuration/task-detail/task-detail.component';
import { TaskActionComponent } from './task-configuration/task-action/task-action.component';
import { TaskInputsComponent } from './task-configuration/task-inputs/task-inputs.component';
import { MappingFieldsComponent } from './task-configuration/task-inputs/mapping-fields/mapping-fields.component';
import { TaskFormComponent } from './task-configuration/task-form/task-form.component';
import { InputFieldComponent } from './task-configuration/task-form/input-field/input-field.component';
import { TaskOutputComponent } from './task-configuration/task-output/task-output.component';
import { ValidationErrorsModule } from '../shared/validation-errors/validation-errors.module';
import { TextNumericRadioGroupComponent } from './task-configuration/task-form/input-field/text-numeric-radio-group/text-numeric-radio-group.component';

@NgModule({
  providers: [KmdModalComponent],
  declarations: [
    ModelerComponent,
    GatewayConfigurationComponent,
    GatewayConfigurationTypeComponent,
    GatewayConfigurationConditionsComponent,
    ConditionFieldsComponent,
    TaskConfigurationComponent,
    ConfigurationWindowComponent,
    TaskDetailComponent,
    TaskActionComponent,
    TaskInputsComponent,
    MappingFieldsComponent,
    TaskFormComponent,
    InputFieldComponent,
    TaskOutputComponent,
    TextNumericRadioGroupComponent,
  ],
  imports: [
    CommonModule,
    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    ModelerRoutingModule,
    AlertsModule,
    ButtonModule,
    CheckboxModule,
    DropdownsModule,
    InputFieldsModule,
    RadioButtonModule,
    ToggleModule,
    DropDownAutoCompleteModule,
    PillsModule,
    GridModule,
    AccordionsModule,
    ButtonsModule,
    LayoutModule,
    WindowModule,
    ModalsModule,
    ValidationErrorsModule,
    TooltipModule,
  ],
})
export class ModelerModule {}
