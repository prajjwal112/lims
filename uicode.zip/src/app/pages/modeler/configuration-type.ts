import { ElementType } from './element-type';
import { PathForm } from './gateway-configuration/gateway-configuration-conditions/path-selection';
import { TaskData } from './task-configuration/task-data';

export interface ConfigurationType {
  open: boolean;
  elementType: '' | ElementType;
  element: ModdleElement;
  shape: ElementShape;
  id: string;
  conditions?: PathForm;
  taskInfo?: TaskData;
}

interface ElementShape {
  id?: string;
  type?: string;
  gatewayType?: 'open' | 'close';
  order?: { level: number };
  businessObject?: ModdleElement;
  default?: ModdleElement;
}

export interface ModdleElement {
  $type: '' | ElementType;
  id?: string;
  name?: string;
  text?: string;
  body?: string;
  $attrs?: any;
  $parent?: ModdleElement;
  documentation?: ModdleElement[];
  extensionElements?: ExtensionElement;
  incoming?: ModdleElement[];
  outgoing?: ModdleElement[];
  targetRef?: ModdleElement;
  sourceRef?: ModdleElement;
  conditionExpression?: ModdleElement;
  default?: ModdleElement;
}

export interface ExtensionElement {
  $type: '' | ElementType.ExtensionElements;
  values: Array<{
    $type: '' | ElementType.Properties;
    values?: Properties[];
  }>;
}

export interface Properties {
  $type: '' | ElementType.Property | ElementType.FormalExpression;
  name: string;
  value: string;
}
