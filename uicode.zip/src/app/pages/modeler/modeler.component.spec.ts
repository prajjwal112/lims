import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';

import { WindowModule } from '@progress/kendo-angular-dialog';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { AlertsModule, DropdownsModule, RadioButtonModule, CheckboxModule, ModalsModule } from 'gds-atom-components';

import { ModelerComponent } from './modeler.component';
import { GatewayConfigurationComponent } from './gateway-configuration/gateway-configuration.component';
import { GatewayConfigurationTypeComponent } from './gateway-configuration/gateway-configuration-type/gateway-configuration-type.component';
import { GatewayConfigurationConditionsComponent } from './gateway-configuration/gateway-configuration-conditions/gateway-configuration-conditions.component';
import { PillsModule } from '../shared/pills/pills.module';
import { ConditionFieldsComponent } from './gateway-configuration/gateway-configuration-conditions/condition-fields/condition-fields.component';
import { TaskConfigurationComponent } from './task-configuration/task-configuration.component';
import { ConfigurationWindowComponent } from './shared/configuration-window/configuration-window.component';
import { TaskDetailComponent } from './task-configuration/task-detail/task-detail.component';
import { TaskFormComponent } from './task-configuration/task-form/task-form.component';
import { WorkflowDefinitionService } from '../../core/api/workflow-definition/workflow-definition.service';
import { newBlankBpmn } from './xml/bpmn_blank';
import { ModalId } from '../shared/modal-id';

describe('ModelerComponent', () => {
  let component: ModelerComponent;
  let fixture: ComponentFixture<ModelerComponent>;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ModelerComponent,
        GatewayConfigurationComponent,
        GatewayConfigurationConditionsComponent,
        GatewayConfigurationTypeComponent,
        ConditionFieldsComponent,
        TaskConfigurationComponent,
        ConfigurationWindowComponent,
        TaskDetailComponent,
        TaskFormComponent,
      ],
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        LayoutModule,
        WindowModule,
        AlertsModule,
        CheckboxModule,
        DropdownsModule,
        RadioButtonModule,
        ModalsModule,
        PillsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    router = TestBed.inject(Router);
    const workflowDefinition = TestBed.inject(WorkflowDefinitionService);
    spyOn(router, 'getCurrentNavigation').and.returnValue({
      id: 0,
      initialUrl: null,
      extractedUrl: null,
      trigger: 'imperative',
      previousNavigation: null,
      extras: { state: { modelerId: 0, modelerName: '' } },
    });
    spyOn(workflowDefinition, 'getWorkflowDefinitionTemplate').and.returnValue(
      of({
        id: 0,
        name: '',
        description: '',
        dueDateTracked: false,
        projectIds: [500],
        xml: newBlankBpmn(),
        lastUpdate: '',
      })
    );
    fixture = TestBed.createComponent(ModelerComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should zoom in', () => {
    const zoomInSpy = spyOn(component, 'zoomIn');
    fixture.debugElement.query(By.css('.gds-icon-zoomin-mono')).nativeElement.dispatchEvent(new Event('click'));

    expect(zoomInSpy).toHaveBeenCalledWith();
  });

  it('should zoom out', () => {
    const zoomInSpy = spyOn(component, 'zoomOut');
    fixture.debugElement.query(By.css('.gds-icon-zoomout-mono')).nativeElement.dispatchEvent(new Event('click'));

    expect(zoomInSpy).toHaveBeenCalledWith();
  });

  it('should reset zoom', () => {
    const zoomInSpy = spyOn(component, 'resetZoom');
    fixture.debugElement.query(By.css('.gds-icon-focus-mono')).nativeElement.dispatchEvent(new Event('click'));

    expect(zoomInSpy).toHaveBeenCalledWith();
  });

  it('should have bpmn logo with link', () => {
    const href = fixture.debugElement.query(By.css('a')).nativeElement.getAttribute('href');

    expect(href).toEqual('http://bpmn.io');
  });

  it('should set workflow name', () => {
    router.getCurrentNavigation().extras.state = { modelerName: 'test' };
    fixture = TestBed.createComponent(ModelerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    expect(component.workflowDefinitionName).toBe('test');
  });

  it('should have error modal', () => {
    expect(fixture.debugElement.query(By.css(`kmd-modal[ng-reflect-id="${ModalId.ModelerError}"]`))).toBeTruthy();
  });

  it('should have unsaved unload modal', () => {
    expect(fixture.debugElement.query(By.css(`kmd-modal[ng-reflect-id="${ModalId.Unload}"]`))).toBeTruthy();
  });
});
