/* eslint-disable max-len */
import { CamundaServerVariable, CamundaCustomVariable } from '../../shared/camunda-variable';

export default `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Definitions_0xtptg0" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="1.16.0">
  <bpmn:collaboration id="Collaboration_1ctrobx">
    <bpmn:participant id="Participant_038bib6" name="Starting Pool" processRef="Process_1" />
  </bpmn:collaboration>
  <bpmn:process id="Process_1" isExecutable="true">
    <bpmn:laneSet id="LaneSet_0y1d6mv">
      <bpmn:lane id="Lane_1ifqvym" name="Starting Lane">
        <bpmn:flowNodeRef>StartEvent_1</bpmn:flowNodeRef>
        <bpmn:flowNodeRef>Activity_1h2vhtp</bpmn:flowNodeRef>
        <bpmn:flowNodeRef>Event_0xtk1w8</bpmn:flowNodeRef>
      </bpmn:lane>
    </bpmn:laneSet>
    <bpmn:startEvent id="StartEvent_1" name="Start">
      <bpmn:outgoing>Flow_0rkjbxs</bpmn:outgoing>
    </bpmn:startEvent>
    <bpmn:userTask id="Activity_1h2vhtp" name="sd">
      <bpmn:documentation>desc</bpmn:documentation>
      <bpmn:extensionElements>
        <camunda:properties>
          <camunda:property name="${CamundaCustomVariable.TaskActionKey}" value="AURORA-tf-tenant/tf-task-template/corelims-eln-apr17-dsbu-cloud/GET_EMPLOYEE/tf-version-0" />
          <camunda:property name="${CamundaCustomVariable.TaskActionTemplateKey}" value="AURORA-tf-tenant/tf-task-template/corelims-eln-apr17-dsbu-cloud/GET_EMPLOYEE/tf-version-0" />
          <camunda:property name="${CamundaCustomVariable.TaskActionName}" value="GET_EMPLOYEE" />
          <camunda:property name="${CamundaCustomVariable.TaskActionType}" value="Integrated" />
          <camunda:property name="${CamundaServerVariable.TaskInputVariable}" value="[&#34;TENANT&#34;]" />
          <camunda:property name="${CamundaServerVariable.TaskOutputVariable}" value="[&#34;EntityTypeName&#34;,&#34;Id&#34;,&#34;Name&#34;,&#34;Barcode&#34;,&#34;Sequence&#34;,&#34;Created&#34;,&#34;Modified&#34;,&#34;Active&#34;,&#34;LikedBy&#34;,&#34;FollowedBy&#34;,&#34;Locked&#34;,&#34;PROJECT&#34;,&#34;CREATED_BY&#34;,&#34;LOCATION&#34;,&#34;EXPERIMENT_SAMPLE_REFS&#34;,&#34;LIST_MEMBER_REFS&#34;,&#34;QUEUE_MEMBER_REFS&#34;,&#34;REV_QUEUE_EMPLOYEE&#34;,&#34;REV_NOTEBOOK_EMPLOYEE&#34;,&#34;REV_QUEUE_EMPLOYEE_SIGNATURE_QUEUE&#34;,&#34;REV_CI_ELN_WITNESSES&#34;,&#34;REV_TEMPLATENOTEBOOK_EMPLOYEE&#34;]" />
          <camunda:property name="${CamundaCustomVariable.TaskActionVariables}" value="[{&#34;name&#34;:&#34;tf_async&#34;,&#34;value&#34;:&#34;false&#34;,&#34;type&#34;:&#34;BOOLEAN&#34;},{&#34;name&#34;:&#34;tf_autoComplete&#34;,&#34;value&#34;:&#34;false&#34;,&#34;type&#34;:&#34;BOOLEAN&#34;},{&#34;name&#34;:&#34;tf_autoExecute&#34;,&#34;value&#34;:&#34;false&#34;,&#34;type&#34;:&#34;BOOLEAN&#34;},{&#34;name&#34;:&#34;tf_httpType&#34;,&#34;value&#34;:&#34;GET&#34;,&#34;type&#34;:&#34;STRING&#34;},{&#34;name&#34;:&#34;tf_timeout&#34;,&#34;value&#34;:&#34;1000&#34;,&#34;type&#34;:&#34;INT&#34;},{&#34;name&#34;:&#34;tf_endpoint&#34;,&#34;value&#34;:&#34;&#34;,&#34;type&#34;:&#34;STRING&#34;},{&#34;name&#34;:&#34;tf_urlTemplate&#34;,&#34;value&#34;:&#34;https://corelims-eln.apr17.dsbu.cloud/odata/EMPLOYEE/(&#39;{{BARCODE}}&#39;)&#34;,&#34;type&#34;:&#34;STRING&#34;},{&#34;name&#34;:&#34;tf_username&#34;,&#34;value&#34;:&#34;&#34;,&#34;type&#34;:&#34;STRING&#34;},{&#34;name&#34;:&#34;tf_password&#34;,&#34;value&#34;:&#34;&#34;,&#34;type&#34;:&#34;STRING&#34;},{&#34;name&#34;:&#34;tf_status&#34;,&#34;value&#34;:&#34;&#34;,&#34;type&#34;:&#34;STRING&#34;},{&#34;name&#34;:&#34;tf_headers&#34;,&#34;value&#34;:&#34;{&#34;odata.metadata&#34;:&#34;full&#34;,&#34;Accept&#34;:&#34;application/json&#34;}&#34;,&#34;type&#34;:&#34;JSON&#34;},{&#34;name&#34;:&#34;tf_dataTypes&#34;,&#34;value&#34;:&#34;{&#34;EntityTypeName&#34;:{&#34;name&#34;:&#34;EntityTypeName&#34;,&#34;type&#34;:&#34;String&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Id&#34;:{&#34;name&#34;:&#34;Id&#34;,&#34;type&#34;:&#34;Int32&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Name&#34;:{&#34;name&#34;:&#34;Name&#34;,&#34;type&#34;:&#34;String&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Barcode&#34;:{&#34;name&#34;:&#34;Barcode&#34;,&#34;type&#34;:&#34;String&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Sequence&#34;:{&#34;name&#34;:&#34;Sequence&#34;,&#34;type&#34;:&#34;Int32&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Created&#34;:{&#34;name&#34;:&#34;Created&#34;,&#34;type&#34;:&#34;DateTimeOffset&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Modified&#34;:{&#34;name&#34;:&#34;Modified&#34;,&#34;type&#34;:&#34;DateTimeOffset&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Active&#34;:{&#34;name&#34;:&#34;Active&#34;,&#34;type&#34;:&#34;Boolean&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;LikedBy&#34;:{&#34;name&#34;:&#34;LikedBy&#34;,&#34;type&#34;:&#34;Int32&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;FollowedBy&#34;:{&#34;name&#34;:&#34;FollowedBy&#34;,&#34;type&#34;:&#34;Int32&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;Locked&#34;:{&#34;name&#34;:&#34;Locked&#34;,&#34;type&#34;:&#34;Boolean&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;PROJECT&#34;:{&#34;name&#34;:&#34;PROJECT&#34;,&#34;type&#34;:&#34;odata/PROJECT&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;CREATED_BY&#34;:{&#34;name&#34;:&#34;CREATED_BY&#34;,&#34;type&#34;:&#34;odata/EMPLOYEE&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;LOCATION&#34;:{&#34;name&#34;:&#34;LOCATION&#34;,&#34;type&#34;:&#34;odata/LOCATION&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;false&#34;},&#34;EXPERIMENT_SAMPLE_REFS&#34;:{&#34;name&#34;:&#34;EXPERIMENT_SAMPLE_REFS&#34;,&#34;type&#34;:&#34;odata/EXPERIMENT_SAMPLE&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;LIST_MEMBER_REFS&#34;:{&#34;name&#34;:&#34;LIST_MEMBER_REFS&#34;,&#34;type&#34;:&#34;odata/LIST_MEMBER&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;QUEUE_MEMBER_REFS&#34;:{&#34;name&#34;:&#34;QUEUE_MEMBER_REFS&#34;,&#34;type&#34;:&#34;odata/QUEUE_MEMBER&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;REV_QUEUE_EMPLOYEE&#34;:{&#34;name&#34;:&#34;REV_QUEUE_EMPLOYEE&#34;,&#34;type&#34;:&#34;odata/ENTITY_SIGNATURE_QUEUE&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;REV_NOTEBOOK_EMPLOYEE&#34;:{&#34;name&#34;:&#34;REV_NOTEBOOK_EMPLOYEE&#34;,&#34;type&#34;:&#34;odata/NOTEBOOK&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;REV_QUEUE_EMPLOYEE_SIGNATURE_QUEUE&#34;:{&#34;name&#34;:&#34;REV_QUEUE_EMPLOYEE_SIGNATURE_QUEUE&#34;,&#34;type&#34;:&#34;odata/SIGNATURE_QUEUE&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;REV_CI_ELN_WITNESSES&#34;:{&#34;name&#34;:&#34;REV_CI_ELN_WITNESSES&#34;,&#34;type&#34;:&#34;odata/SIGNATURE_QUEUE_MEMBER&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;},&#34;REV_TEMPLATENOTEBOOK_EMPLOYEE&#34;:{&#34;name&#34;:&#34;REV_TEMPLATENOTEBOOK_EMPLOYEE&#34;,&#34;type&#34;:&#34;odata/TEMPLATE_NOTEBOOK&#34;,&#34;enums&#34;:[],&#34;collection&#34;:&#34;true&#34;}}&#34;,&#34;type&#34;:&#34;JSON&#34;},{&#34;name&#34;:&#34;tf_taskInput&#34;,&#34;value&#34;:&#34;{}&#34;,&#34;type&#34;:&#34;JSON&#34;},{&#34;name&#34;:&#34;tf_inputVariablesNames&#34;,&#34;value&#34;:&#34;[&#34;TENANT&#34;]&#34;,&#34;type&#34;:&#34;JSON&#34;},{&#34;name&#34;:&#34;tf_outputVariablesNames&#34;,&#34;value&#34;:&#34;[&#34;EntityTypeName&#34;,&#34;Id&#34;,&#34;Name&#34;,&#34;Barcode&#34;,&#34;Sequence&#34;,&#34;Created&#34;,&#34;Modified&#34;,&#34;Active&#34;,&#34;LikedBy&#34;,&#34;FollowedBy&#34;,&#34;Locked&#34;,&#34;PROJECT&#34;,&#34;CREATED_BY&#34;,&#34;LOCATION&#34;,&#34;EXPERIMENT_SAMPLE_REFS&#34;,&#34;LIST_MEMBER_REFS&#34;,&#34;QUEUE_MEMBER_REFS&#34;,&#34;REV_QUEUE_EMPLOYEE&#34;,&#34;REV_NOTEBOOK_EMPLOYEE&#34;,&#34;REV_QUEUE_EMPLOYEE_SIGNATURE_QUEUE&#34;,&#34;REV_CI_ELN_WITNESSES&#34;,&#34;REV_TEMPLATENOTEBOOK_EMPLOYEE&#34;]&#34;,&#34;type&#34;:&#34;JSON&#34;},{&#34;name&#34;:&#34;tf_successBody&#34;,&#34;value&#34;:&#34;{&#34;PROJECT@odata.bind&#34;:&#34;odata/{PROJECT}&#34;,&#34;CREATED_BY@odata.bind&#34;:&#34;odata/{EMPLOYEE}&#34;,&#34;LOCATION@odata.bind&#34;:&#34;odata/{LOCATION}&#34;,&#34;EXPERIMENT_SAMPLE_REFS@odata.bind&#34;:&#34;odata/{EXPERIMENT_SAMPLE}&#34;,&#34;LIST_MEMBER_REFS@odata.bind&#34;:&#34;odata/{LIST_MEMBER}&#34;,&#34;QUEUE_MEMBER_REFS@odata.bind&#34;:&#34;odata/{QUEUE_MEMBER}&#34;,&#34;REV_QUEUE_EMPLOYEE@odata.bind&#34;:&#34;odata/{ENTITY_SIGNATURE_QUEUE}&#34;,&#34;REV_NOTEBOOK_EMPLOYEE@odata.bind&#34;:&#34;odata/{NOTEBOOK}&#34;,&#34;REV_QUEUE_EMPLOYEE_SIGNATURE_QUEUE@odata.bind&#34;:&#34;odata/{SIGNATURE_QUEUE}&#34;,&#34;REV_CI_ELN_WITNESSES@odata.bind&#34;:&#34;odata/{SIGNATURE_QUEUE_MEMBER}&#34;,&#34;REV_TEMPLATENOTEBOOK_EMPLOYEE@odata.bind&#34;:&#34;odata/{TEMPLATE_NOTEBOOK}&#34;}&#34;,&#34;type&#34;:&#34;JSON&#34;}]" />
          <camunda:property name="${CamundaServerVariable.Priority}" value="0" />
          <camunda:property name="${CamundaServerVariable.OutputMappingPrivate}" value="{&#34;Active&#34;:&#34;Active&#34;,&#34;TENANT&#34;:&#34;TENANT&#34;}" />
          <camunda:property name="${CamundaServerVariable.OutputMappingPublic}" value="[&#34;Active&#34;,&#34;TENANT&#34;]" />
          <camunda:property name="${CamundaServerVariable.TaskInput}" value="{&#34;basics&#34;:[{&#34;name&#34;:&#34;TENANT&#34;,&#34;displayName&#34;:&#34;TENANT&#34;,&#34;type&#34;:&#34;numeric&#34;,&#34;sequence&#34;:0}],&#34;dates&#34;:[],&#34;selects&#34;:[]}" />
          <camunda:property name="${CamundaServerVariable.TaskInstructions}" value="asa" />
          <camunda:property name="${CamundaServerVariable.TaskInputMapping}" value="{&#34;TENANT&#34;:{&#34;output&#34;:{}}}" />
        </camunda:properties>
      </bpmn:extensionElements>
      <bpmn:incoming>Flow_0rkjbxs</bpmn:incoming>
      <bpmn:outgoing>Flow_0clkdph</bpmn:outgoing>
    </bpmn:userTask>
    <bpmn:endEvent id="Event_0xtk1w8" name="END">
      <bpmn:incoming>Flow_0clkdph</bpmn:incoming>
    </bpmn:endEvent>
    <bpmn:sequenceFlow id="Flow_0rkjbxs" sourceRef="StartEvent_1" targetRef="Activity_1h2vhtp" />
    <bpmn:sequenceFlow id="Flow_0clkdph" sourceRef="Activity_1h2vhtp" targetRef="Event_0xtk1w8" />
  </bpmn:process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1ctrobx">
      <bpmndi:BPMNShape id="Participant_038bib6_di" bpmnElement="Participant_038bib6">
        <dc:Bounds x="123" y="-38" width="915" height="632" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Lane_1ifqvym_di" bpmnElement="Lane_1ifqvym">
        <dc:Bounds x="153" y="-38" width="885" height="632" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNEdge id="Flow_0clkdph_di" bpmnElement="Flow_0clkdph">
        <di:waypoint x="450" y="325" />
        <di:waypoint x="692" y="325" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0rkjbxs_di" bpmnElement="Flow_0rkjbxs">
        <di:waypoint x="228" y="325" />
        <di:waypoint x="350" y="325" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
        <dc:Bounds x="192" y="307" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="198" y="350" width="24" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1h2vhtp_di" bpmnElement="Activity_1h2vhtp">
        <dc:Bounds x="350" y="285" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_0xtk1w8_di" bpmnElement="Event_0xtk1w8">
        <dc:Bounds x="692" y="307" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="698" y="350" width="24" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</bpmn:definitions>`;
