/* eslint-disable max-len */

import { CamundaServerVariable } from '../../shared/camunda-variable';

export const newBlankBpmn = (enforceDueDates?: boolean): string => {
  return `<?xml version="1.0" encoding="UTF-8"?>
    <bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" id="Definitions_0xtptg0" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="1.16.0">
      <bpmn:collaboration id="Collaboration_1ctrobx">
        <extensionElements>
          <camunda:properties>
            <camunda:property name="${CamundaServerVariable.EnforceDueDates}" value="${enforceDueDates === true}" />
          </camunda:properties>
        </extensionElements>
        <bpmn:participant id="Participant_038bib6" name="Starting Pool" processRef="Process_1" />
      </bpmn:collaboration>
      <bpmn:process id="Process_1" isExecutable="true">
        <bpmn:laneSet id="LaneSet_0y1d6mv">
          <bpmn:lane id="Lane_1ifqvym" name="Starting Lane">
            <bpmn:flowNodeRef>StartEvent_1</bpmn:flowNodeRef>
          </bpmn:lane>
        </bpmn:laneSet>
        <bpmn:startEvent id="StartEvent_1" name="Start" />
      </bpmn:process>
      <bpmndi:BPMNDiagram id="BPMNDiagram_1">
        <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1ctrobx">
          <bpmndi:BPMNShape id="Participant_038bib6_di" bpmnElement="Participant_038bib6" isHorizontal="true">
            <dc:Bounds x="123" y="90" width="947" height="340" />
          </bpmndi:BPMNShape>
          <bpmndi:BPMNShape id="Lane_1ifqvym_di" bpmnElement="Lane_1ifqvym" isHorizontal="true">
            <dc:Bounds x="153" y="90" width="917" height="340" />
          </bpmndi:BPMNShape>
          <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
            <dc:Bounds x="192" y="242" width="36" height="36" />
            <bpmndi:BPMNLabel>
              <dc:Bounds x="198" y="285" width="24" height="14" />
            </bpmndi:BPMNLabel>
          </bpmndi:BPMNShape>
        </bpmndi:BPMNPlane>
      </bpmndi:BPMNDiagram>
    </bpmn:definitions>
  `;
};
