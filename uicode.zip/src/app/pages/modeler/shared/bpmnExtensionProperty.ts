import { ExtensionElement, ModdleElement } from '../configuration-type';
import { ElementType } from '../element-type';

export function getExtensionProperty(field: string, extensionElements?: ExtensionElement): string {
  let propertyValue = '';
  if (extensionElements) {
    for (const item of extensionElements.values) {
      if (item.values) {
        const property = item.values.find((p) => p.name.toLowerCase() === field.toLowerCase());

        if (property) {
          // if value is `undefined` this will fail without `?`
          propertyValue = property.value?.toString();
          break;
        }
      }
    }
  }

  return propertyValue;
}

export interface OutputExtensionVariable {
  name: string;
  value: any;
  sourceId?: string;
  type?: string;
}

export function findExtensionElementArrayValues(
  element: ModdleElement,
  propertyName: string,
  startingTaskId = '',
  accumulator: OutputExtensionVariable[] = []
): OutputExtensionVariable[] {
  if (element.incoming) {
    element.incoming.forEach((item: ModdleElement) => {
      if (
        ['', ElementType.Task, ElementType.CallActivity, ElementType.UserTask].includes(item.sourceRef.$type) &&
        item.sourceRef.extensionElements &&
        item.sourceRef.id !== startingTaskId
      ) {
        item.sourceRef.extensionElements.values.forEach((properties) => {
          if (properties.$type === ElementType.Properties) {
            properties.values.forEach((extensionElement) => {
              if (
                extensionElement.name === propertyName &&
                !accumulator.some((output) => JSON.parse(extensionElement.value).includes(output.value))
              ) {
                if (JSON.parse(extensionElement.value).length !== undefined) {
                  accumulator.push(
                    ...JSON.parse(extensionElement.value).map((output: OutputExtensionVariable['value']) => ({
                      name: `${output} - ${item.sourceRef.name}`,
                      sourceId: item.sourceRef.id,
                      value: output,
                    }))
                  );
                } else {
                  accumulator.push(
                    ...Object.keys(JSON.parse(extensionElement.value)).map((output: OutputExtensionVariable['value']) => ({
                      name: `${JSON.parse(extensionElement.value)[output]} - ${item.sourceRef.name}`,
                      sourceId: item.sourceRef.id,
                      value: output,
                    }))
                  );
                }
              }
            });
          }
        });
      }
      if (item.sourceRef.incoming && item.sourceRef.id !== startingTaskId) {
        accumulator = findExtensionElementArrayValues(item.sourceRef, propertyName, startingTaskId, accumulator);
      }
    });
  }

  return accumulator;
}
