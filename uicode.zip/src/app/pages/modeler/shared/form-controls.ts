import { AbstractControl } from '@angular/forms';

export interface GenericFormControls {
  [s: string]: AbstractControl;
}
