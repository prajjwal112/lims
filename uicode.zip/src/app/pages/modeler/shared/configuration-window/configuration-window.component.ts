import { Component, OnInit, Input, HostListener, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { debounce } from 'lodash';

const OFFSET_WIDTH = 110;
@Component({
  selector: 'app-configuration-window',
  templateUrl: './configuration-window.component.html',
  styleUrls: ['./configuration-window.component.scss'],
})
export class ConfigurationWindowComponent implements OnInit {
  @Input() open: boolean;
  @Output() closeChanges = new EventEmitter<void>();

  public pageWidth = 0;

  @ViewChild('window', { read: ElementRef }) private modal: ElementRef;

  ngOnInit(): void {
    setTimeout(() => {
      this.pageWidth = document.body.offsetWidth - OFFSET_WIDTH;
    }, 1);
    this.onResize = debounce(this.onResize, 150, { leading: false, trailing: true });
  }

  @HostListener('window:resize', ['$event.target'])
  onResize(event?: Window): void {
    this.pageWidth = event.innerWidth - OFFSET_WIDTH;
  }
}
