import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { WindowModule } from '@progress/kendo-angular-dialog';

import { ConfigurationWindowComponent } from './configuration-window.component';

describe('ConfigurationWindowComponent', () => {
  let component: ConfigurationWindowComponent;
  let fixture: ComponentFixture<ConfigurationWindowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConfigurationWindowComponent],
      imports: [WindowModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationWindowComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should hide modal', () => {
    expect(fixture.debugElement.query(By.css('.k-overlay'))).toBeFalsy();
  });

  it('should show modal', () => {
    component.open = true;

    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.k-overlay'))).toBeTruthy();
  });
});
