import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { ElementType } from '../../element-type';
import { ConfigurationType } from '../../configuration-type';

@Component({
  selector: 'app-gateway-configuration-type',
  templateUrl: './gateway-configuration-type.component.html',
  styleUrls: ['./gateway-configuration-type.component.scss'],
})
export class GatewayConfigurationTypeComponent implements OnChanges {
  @Input() gatewayType: ConfigurationType['shape']['gatewayType'];
  @Input() type: ElementType;
  @Output() typeChange = new EventEmitter<ElementType>();

  public parallelImage: HTMLImageElement;
  public exclusiveImage: HTMLImageElement;
  public inclusiveImage: HTMLImageElement;
  readonly bpmnType = ElementType;

  ngOnChanges(): void {
    if (this.gatewayType === 'close') {
      this.parallelImage = require('./images/close-parallel-gateway-config.png').default;
      this.exclusiveImage = require('./images/close-exclusive-gateway-config.png').default;
      this.inclusiveImage = require('./images/close-inclusive-gateway-config.png').default;
    } else {
      this.parallelImage = require('./images/open-parallel-gateway-config.png').default;
      this.exclusiveImage = require('./images/open-exclusive-gateway-config.png').default;
      this.inclusiveImage = require('./images/open-inclusive-gateway-config.png').default;
    }
  }

  changeType(type: ElementType): void {
    this.typeChange.emit(type);
  }
}
