import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GatewayConfigurationTypeComponent } from './gateway-configuration-type.component';
import { By } from '@angular/platform-browser';
import { ElementType } from '../../element-type';

describe('GatewayConfigurationTypeComponent', () => {
  let component: GatewayConfigurationTypeComponent;
  let fixture: ComponentFixture<GatewayConfigurationTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GatewayConfigurationTypeComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatewayConfigurationTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select Parallel Gateway Type', () => {
    component.type = ElementType.ParallelGateway;
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.type-configuration'))[0].classes.active).toBe(true);
  });

  it('should select Exclusive Gateway Type', () => {
    component.type = ElementType.ExclusiveGateway;
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.type-configuration'))[1].classes.active).toBe(true);
  });

  it('should select Inclusive Gateway Type', () => {
    component.type = ElementType.InclusiveGateway;
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.type-configuration'))[2].classes.active).toBe(true);
  });

  it('should show "By default, all paths are active. No gateway condition configuration is required." for open Parallel type', () => {
    const text = 'By default, all paths are active. No gateway condition configuration is required.';
    component.type = ElementType.ParallelGateway;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.type-configuration.active p')).nativeElement.textContent.trim()).toBe(text);
  });

  it(`
    should show
    "A single gateway path that meets the defined conditions becomes the
    active path. If no conditions are met, the default path is the active path."
    for open Exclusive type`, () => {
    const text =
      'A single gateway path that meets the defined conditions becomes the active path.  If no conditions are met, the default path is the active path.';
    component.type = ElementType.ExclusiveGateway;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.type-configuration.active p')).nativeElement.textContent.trim()).toBe(text);
  });

  it(`
    should show
    "All paths that meet the defined conditions become active paths,
    including the default path."
    for open Inclusive type`, () => {
    const text = 'All paths that meet the defined conditions become active paths, including the default path.';
    component.type = ElementType.InclusiveGateway;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.type-configuration.active p')).nativeElement.textContent.trim()).toBe(text);
  });

  it(`
    should show "Close a gateway path that starts with an open Parallel Gateway element."
  `, () => {
    const text = 'Close a gateway path that starts with an open Parallel Gateway element.';
    component.type = ElementType.ParallelGateway;
    component.gatewayType = 'close';
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.type-configuration.active p')).nativeElement.textContent.trim()).toBe(text);
  });
});
