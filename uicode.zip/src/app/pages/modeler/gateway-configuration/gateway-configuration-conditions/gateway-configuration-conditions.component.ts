import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { cloneDeep } from 'lodash';
import { KmdDropdownComponent } from 'gds-atom-components';

import { ModdleElement, ExtensionElement } from '../../configuration-type';
import { ElementType } from '../../element-type';
import { PathSelection, PathForm, PathFormConditions } from './path-selection';
import { findExtensionElementArrayValues, getExtensionProperty, OutputExtensionVariable } from '../../shared/bpmnExtensionProperty';
import { CamundaCustomVariable, CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import type { BasicTaskFormInput, DateTaskFormInput } from '../../../shared/task-detail';
import { TaskFormInputType } from '../../../shared/task-detail';

@Component({
  selector: 'app-gateway-configuration-conditions',
  templateUrl: './gateway-configuration-conditions.component.html',
  styleUrls: ['./gateway-configuration-conditions.component.scss'],
})
export class GatewayConfigurationConditionsComponent implements OnInit {
  @ViewChild('defaultPathDropdown') private defaultPathDropdown: KmdDropdownComponent;
  @Input() element: ModdleElement;
  @Input() type: ElementType;
  @Input() configurationCondition: PathForm;
  @Input() extensionElements: ExtensionElement;
  @Output() configurationConditionChange = new EventEmitter<PathForm>();

  public noConnectionImg = require('./images/gateway-zero.png').default;
  public outgoingTaskPaths: ModdleElement[] = [];
  public taskTypeIsExclusive: boolean;
  public paths: PathSelection[] = [];
  public defaultPathControl: FormControl;
  public pathOptionSelected: PathSelection = {
    path: '',
    taskId: '',
    sequenceId: '',
  };
  public pathVariableOptions: OutputExtensionVariable[] = [];
  public elementCountsForTask = {};
  public savedFormValues: PathForm = Object.assign({});
  public pathFormConditions: Record<string, any> = {};

  private static updateVariables(updatedConditions: string, id: string): PathFormConditions {
    if (updatedConditions) {
      const conditionPaths = JSON.parse(updatedConditions);
      if (Object.keys(conditionPaths).includes(id)) {
        return conditionPaths[id];
      }
    }
    return {
      default: false,
      validateWith: '',
      variableName: { name: '', value: '' },
      variableCondition: '',
      variableValue: { value: '' },
    };
  }
  ngOnInit(): void {
    this.defaultPathControl = new FormControl(this.pathOptionSelected);
    if (this.element.outgoing) {
      this.outgoingTaskPaths = this.element.outgoing.slice();

      this.outgoingTaskPaths.forEach((item) => {
        this.paths.push({
          path: item.targetRef.name,
          taskId: item.targetRef.id,
          sequenceId: item.id,
        });
        this.elementCountsForTask[item.id] = this.fillDefaultElementCountForTask();
      });

      if (this.element.incoming && this.element.incoming.length > 0) {
        this.pathVariableOptions = findExtensionElementArrayValues(this.element, CamundaServerVariable.OutputMappingPublic);
        const pathVariableMapping = findExtensionElementArrayValues(this.element, CamundaServerVariable.OutputMappingPrivate);
        if (this.pathVariableOptions.length > 0) {
          this.pathVariableOptions = this.pathVariableOptions.map((variable) => {
            if (variable.sourceId) {
              const extensionElement = this.retrieveUpstreamExtensionElement(this.element, variable.sourceId);
              const typeStructure = getExtensionProperty(CamundaServerVariable.TaskInput, extensionElement);
              let dataType: TaskFormInputType;
              if (typeStructure) {
                const basics: BasicTaskFormInput[] = JSON.parse(typeStructure)?.basics && Object.values(JSON.parse(typeStructure)?.basics);
                const dates: DateTaskFormInput[] = JSON.parse(typeStructure)?.dates && Object.values(JSON.parse(typeStructure)?.dates);
                const mappedValue = pathVariableMapping.find((mapped) => mapped.name === variable.name);
                const predicate = (formTypeArray: BasicTaskFormInput | DateTaskFormInput): boolean =>
                  mappedValue.value === formTypeArray.name;
                dataType = basics?.find(predicate)?.type || dates?.find(predicate)?.type;
              }

              return {
                ...variable,
                type:
                  dataType === TaskFormInputType.Text ||
                  dataType === TaskFormInputType.Numeric ||
                  TaskFormInputType.Boolean ||
                  TaskFormInputType.Date
                    ? dataType
                    : '',
              };
            }
            return variable;
          });
        }
      }
      if (this.paths.length === 1) {
        this.pathOptionSelected = Object.assign({}, this.paths[0]);
      }
    }
    this.taskTypeIsExclusive = this.type === ElementType.ExclusiveGateway;
    this.onFormControlChange();
  }

  selectDefault(value: PathSelection): void {
    Object.keys(this.savedFormValues).forEach((key) => {
      this.savedFormValues[key] = {
        ...this.savedFormValues[key],
        default: false,
      };
    });
    if (Object.keys(value).length > 0) {
      this.savedFormValues[value.sequenceId] = {
        ...this.savedFormValues[value.sequenceId],
        default: true,
      };
    }
    this.pathOptionSelected = value;
    this.configurationConditionChange.emit(this.savedFormValues);
  }

  onChange(value: PathForm): void {
    Object.keys(value).forEach((item) => {
      this.savedFormValues[item] = cloneDeep(value[item]);
    });
    this.elementCountsForTask = this.updateElementCountForTask(value);

    this.configurationConditionChange.emit(this.savedFormValues);
  }

  loadSavedValues(value: PathForm): void {
    Object.keys(value).forEach((item) => {
      this.savedFormValues[item] = cloneDeep(value[item]);
    });

    if (this.paths.length === 1) {
      this.selectDefault(this.pathOptionSelected);
    } else {
      this.savedFormValues = this.retrieveConditionValues(this.savedFormValues);

      this.retrieveDefaultFlow();
    }
  }

  private onFormControlChange(): void {
    this.defaultPathControl.valueChanges.subscribe({
      next: (val: PathSelection) => {
        this.selectDefault(val);
      },
    });
  }

  private fillDefaultElementCountForTask(): string[] {
    return Array.from(Array(this.outgoingTaskPaths.length).keys()).map((i) => `${i + 1}`);
  }

  private updateElementCountForTask(value: PathForm): Record<string, unknown> {
    const selection = Object.keys(this.savedFormValues).reduce(
      (prev, sequenceId) => ({
        ...prev,
        [sequenceId]: this.savedFormValues[sequenceId].priority,
      }),
      {}
    );
    const counts = cloneDeep(this.elementCountsForTask);
    Object.keys(counts).forEach((sequenceId) => {
      if (!value[sequenceId]) {
        counts[sequenceId] = this.fillDefaultElementCountForTask().filter((item: PathFormConditions['priority']) => {
          const values = Object.keys(selection)
            .filter((key) => key !== sequenceId)
            .map((key) => selection[key]);

          return !values.includes(item);
        });
      }
    });
    return counts;
  }

  private retrieveDefaultFlow(): void {
    if (this.element.default) {
      const path = this.element.default.targetRef.name;
      const taskId = this.element.default.targetRef.id;
      const sequenceId = this.element.default.id;
      this.defaultPathDropdown.selectByKey(path, 'path');

      this.selectDefault({
        path,
        taskId,
        sequenceId,
      });
    }
  }

  private populateConditions(updatedElements: PathFormConditions): void {
    this.pathFormConditions['validateWith'] = updatedElements?.validateWith;
    this.pathFormConditions['variableName'] = `${updatedElements?.variableName?.name}|${updatedElements?.variableName?.value}`;
    this.pathFormConditions['variableCondition'] = updatedElements?.variableCondition;
    this.pathFormConditions['variableValue'] = `${updatedElements?.variableValue?.value}|${updatedElements?.variableValue?.name}`;
    this.pathFormConditions['priority'] = updatedElements?.priority;
    this.pathFormConditions['default'] = updatedElements?.default;
  }

  private isValidateCondition(): boolean {
    return (
      this.pathFormConditions['validateWith'] &&
      this.pathFormConditions['variableName'] &&
      this.pathFormConditions['variableCondition'] &&
      this.pathFormConditions['variableValue']
    );
  }

  private retrieveConditionValues(value: PathForm): PathForm {
    const savedValues: PathForm = cloneDeep(value);
    this.outgoingTaskPaths.forEach((item) => {
      if (item.conditionExpression && item.conditionExpression.body && this.extensionElements?.values) {
        let updatedConditions = '';
        let found = false;
        for (const extensionElement of this.extensionElements.values) {
          if (extensionElement.$type === ElementType.Properties) {
            for (const extensionElementValue of extensionElement.values) {
              if (extensionElementValue.name === CamundaCustomVariable.AllConditions) {
                updatedConditions = extensionElementValue.value;
              }
              const isValidateElement = updatedConditions.length > 0;
              const updatedElements = GatewayConfigurationConditionsComponent.updateVariables(updatedConditions, item.id);
              this.populateConditions(updatedElements);
              if (isValidateElement && this.isValidateCondition() && this.pathFormConditions['priority']) {
                found = true;
                break;
              }
            }
          }
          if (found) {
            break;
          }
        }

        if (this.isValidateCondition()) {
          const variableNameValues = this.pathFormConditions['variableName'].split('|');
          const variableValues = this.pathFormConditions['variableValue'].split('|');
          savedValues[item.id] = {
            ...savedValues[item.id],
            validateWith: this.pathFormConditions['validateWith'],
            default: this.pathFormConditions['default'],
            variableName: {
              name: variableNameValues[0],
              value: variableNameValues[1],
            },
            variableCondition: this.pathFormConditions['variableCondition'],
            variableValue: {
              value: variableValues[0],
              name: variableValues[1] || '',
            },
          };
        }
        if (this.pathFormConditions['priority'] && this.taskTypeIsExclusive) {
          savedValues[item.id].priority = this.pathFormConditions['priority'];
        }
      }
    });

    return savedValues;
  }

  private retrieveUpstreamExtensionElement(element: ModdleElement, id: string): ExtensionElement {
    let extensionElement: ExtensionElement;
    element.incoming.forEach((item: ModdleElement) => {
      if (item.sourceRef.id === id) {
        extensionElement = item.sourceRef.extensionElements;
      } else if (item.sourceRef.incoming?.length > 0) {
        extensionElement = this.retrieveUpstreamExtensionElement(item.sourceRef, id);
      }
    });
    return extensionElement;
  }
}
