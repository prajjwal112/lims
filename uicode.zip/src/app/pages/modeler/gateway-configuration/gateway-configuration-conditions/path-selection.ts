export interface PathSelection {
  path: string;
  taskId: string;
  sequenceId: string;
}

export interface PathForm {
  [s: string]: PathFormConditions;
}

export interface PathFormConditions {
  default: boolean;
  validateWith: '' | 'variable' | 'value';
  variableName: { name: string; value: string };
  variableCondition: '' | '>' | '>=' | '<' | '<=' | '=' | '!=';
  variableValue: { name?: string; value: string };
  priority?: string;
}
