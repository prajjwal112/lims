import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { AlertsModule, DropdownsModule, RadioButtonModule } from 'gds-atom-components';

import { GatewayConfigurationConditionsComponent } from './gateway-configuration-conditions.component';
import { PillsModule } from '../../../shared/pills/pills.module';
import { ConditionFieldsComponent } from './condition-fields/condition-fields.component';
import { ElementType } from '../../element-type';
import { CamundaCustomVariable, CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import { PathForm } from './path-selection';

describe('GatewayConfigurationConditionsComponent with no paths', () => {
  let component: GatewayConfigurationConditionsComponent;
  let fixture: ComponentFixture<GatewayConfigurationConditionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GatewayConfigurationConditionsComponent, ConditionFieldsComponent],
      imports: [FormsModule, AlertsModule, DropdownsModule, RadioButtonModule, PillsModule, ReactiveFormsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatewayConfigurationConditionsComponent);
    component = fixture.componentInstance;
    component.type = ElementType.ExclusiveGateway;
    component.element = {
      $type: ElementType.ExclusiveGateway,
      incoming: [],
      outgoing: [],
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show "no path" message', () => {
    expect(fixture.debugElement.query(By.css('.no-flows-container h3')).nativeElement.textContent).toEqual(
      'There are no paths after the gateway'
    );

    expect(fixture.debugElement.query(By.css('.no-flows-container p')).nativeElement.textContent.trim()).toEqual(
      'To configure the gateway, first add a path or paths after the gateway'
    );
  });
});

describe('GatewayConfigurationConditionsComponent with multiple flows', () => {
  let component: GatewayConfigurationConditionsComponent;
  let fixture: ComponentFixture<GatewayConfigurationConditionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GatewayConfigurationConditionsComponent, ConditionFieldsComponent],
      imports: [FormsModule, AlertsModule, DropdownsModule, RadioButtonModule, PillsModule, ReactiveFormsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatewayConfigurationConditionsComponent);
    component = fixture.componentInstance;
    component.type = ElementType.ExclusiveGateway;
    component.taskTypeIsExclusive = true;
    component.element = {
      $type: ElementType.ExclusiveGateway,
      incoming: [
        {
          $type: ElementType.Task,
          incoming: [],
          targetRef: {
            name: 'test',
            $type: ElementType.Task,
            incoming: [],
          },
          sourceRef: {
            $type: ElementType.Task,
            incoming: [],
          },
        },
      ],
      outgoing: [
        {
          $type: ElementType.Task,
          incoming: [],
          targetRef: {
            name: 'test',
            $type: ElementType.Task,
            incoming: [],
          },
        },
      ],
    };
    fixture.detectChanges();
  });

  it('should show "no upstream variables" message', () => {
    expect(fixture.debugElement.query(By.css('.kmd-error')).nativeElement.textContent).toContain(
      'There are no variables defined in the workflow. Configure previous tasks prior to defining gateway conditions.'
    );
  });

  it('should show exclusive type message', () => {
    component.pathVariableOptions = [{ name: 'test', value: 123 }];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.kmd-info')).nativeElement.textContent).toContain(
      'If multiple paths meet the defined condition, the path with the higher priority becomes active. Priority 1 is the highest priority level.'
    );
  });

  it('should show inclusive type message', () => {
    component.type = ElementType.InclusiveGateway;
    component.ngOnInit();
    component.pathVariableOptions = [{ name: 'test', value: 123 }];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.kmd-info')).nativeElement.textContent).toContain(
      'The selected default path always becomes active.'
    );
  });

  it('should show Default label next to single path on render', () => {
    component.pathVariableOptions = [{ name: 'test', value: 123 }];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.badge'))).toBeTruthy();
  });

  it('should show Default label next to selected default path', () => {
    component.element.outgoing.push({
      $type: ElementType.SequenceFlow,
      id: 'sequenceId',
      incoming: [],
      targetRef: {
        name: 'test2',
        id: 'test2',
        $type: ElementType.Task,
        incoming: [],
      },
    });
    component.pathOptionSelected = {
      path: 'test2',
      taskId: 'test2',
      sequenceId: 'sequenceId',
    };
    component.ngOnInit();
    component.pathVariableOptions = [{ name: 'test', value: 123 }];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('h3.col-auto:nth-last-child(2) + h5'))).toBeTruthy();
  });
});

describe('GatewayConfigurationConditions data', () => {
  let component: GatewayConfigurationConditionsComponent;
  let fixture: ComponentFixture<GatewayConfigurationConditionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GatewayConfigurationConditionsComponent, ConditionFieldsComponent],
      imports: [FormsModule, AlertsModule, DropdownsModule, RadioButtonModule, PillsModule, ReactiveFormsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatewayConfigurationConditionsComponent);
    component = fixture.componentInstance;
    component.type = ElementType.ExclusiveGateway;
    component.taskTypeIsExclusive = true;
    component.element = {
      $type: ElementType.ExclusiveGateway,
      id: 'exclusive_1',
      incoming: [
        {
          $type: ElementType.SequenceFlow,
          incoming: [],
          targetRef: {
            name: 'test',
            $type: ElementType.Task,
            incoming: [],
          },
          sourceRef: {
            $type: ElementType.Task,
            id: 'source',
            name: 'source',
            incoming: [
              {
                $type: ElementType.SequenceFlow,
                incoming: [],
                targetRef: {
                  name: 'prev-test1',
                  $type: ElementType.Task,
                  incoming: [],
                },
                sourceRef: {
                  $type: ElementType.Task,
                  id: 'source 1',
                  name: 'source 1',
                  incoming: [
                    {
                      $type: ElementType.SequenceFlow,
                      incoming: [],
                      targetRef: {
                        name: 'prev-test2',
                        $type: ElementType.Task,
                        incoming: [],
                      },
                      sourceRef: {
                        $type: ElementType.Task,
                        id: 'source 2',
                        name: 'source 2',
                        incoming: [],
                        extensionElements: {
                          $type: ElementType.ExtensionElements,
                          values: [
                            {
                              $type: ElementType.Properties,
                              values: [
                                {
                                  $type: ElementType.Property,
                                  name: CamundaServerVariable.OutputMappingPublic,
                                  value: '["test 3"]',
                                },
                              ],
                            },
                          ],
                        },
                      },
                    },
                  ],
                  extensionElements: {
                    $type: ElementType.ExtensionElements,
                    values: [
                      {
                        $type: ElementType.Properties,
                        values: [
                          {
                            $type: ElementType.Property,
                            name: CamundaServerVariable.OutputMappingPublic,
                            value: '["test 2"]',
                          },
                        ],
                      },
                    ],
                  },
                },
              },
            ],
            extensionElements: {
              $type: ElementType.ExtensionElements,
              values: [
                {
                  $type: ElementType.Properties,
                  values: [
                    {
                      $type: ElementType.Property,
                      name: CamundaServerVariable.OutputMappingPublic,
                      value: '["test"]',
                    },
                    {
                      $type: ElementType.Property,
                      name: CamundaServerVariable.OutputMappingPrivate,
                      value: '{ "inputVar": "test", "inputVar3": "test 2", "inputVar2": "test 3" }',
                    },
                    {
                      $type: ElementType.Property,
                      name: CamundaServerVariable.TaskInput,
                      value:
                        /* eslint-disable-next-line max-len */
                        '{"basics":[{"name":"inputVar","displayName":"inputVar","type":"numeric","sequence":2,"mandatory":true,"defaultValue":""},{"name":"inputVar3","displayName":"inputVar3","type":"text","sequence":1,"mandatory":true,"defaultValue":""},{"name":"inputVar2","displayName":"inputVar2","type":"numeric","sequence":0,"mandatory":true,"defaultValue":""}]}',
                    },
                  ],
                },
              ],
            },
          },
        },
      ],
      outgoing: [
        {
          $type: ElementType.SequenceFlow,
          id: 'sequence1',
          incoming: [],
          targetRef: {
            $type: ElementType.Task,
            name: 'test',
            id: 'test1',
            incoming: [],
          },
          sourceRef: {
            $type: ElementType.Task,
            id: 'test1',
            name: 'test',
          },
          conditionExpression: {
            $type: ElementType.FormalExpression,
            body: '<![CDATA[${ text != \'hfhghf\' }]]>',
          },
        },
        {
          $type: ElementType.SequenceFlow,
          id: 'sequence2',
          incoming: [],
          targetRef: {
            $type: ElementType.Task,
            name: 'test',
            id: 'test2',
            incoming: [],
          },
          sourceRef: {
            $type: ElementType.Task,
            id: 'test2',
            name: 'test',
          },
          conditionExpression: {
            $type: ElementType.FormalExpression,
            body: '<![CDATA[${ number > 7 }]]>',
          },
        },
      ],
    };
    fixture.detectChanges();
  });

  it('should build path array to match outgoing elements', () => {
    expect(component.paths).toEqual([
      { path: 'test', taskId: 'test1', sequenceId: 'sequence1' },
      { path: 'test', taskId: 'test2', sequenceId: 'sequence2' },
    ]);
  });

  it('should have two options for priority', () => {
    expect(component.elementCountsForTask).toEqual({
      sequence1: ['1', '2'],
      sequence2: ['1', '2'],
    });
  });

  it('should filter Priority values from sibling form fields', () => {
    component.onChange({
      sequence1: {
        default: false,
        validateWith: 'value',
        variableName: { name: 'property 1', value: 'property 1' },
        variableCondition: '!=',
        variableValue: { name: '', value: 'test' },
        priority: '2',
      },
    });

    expect(component.elementCountsForTask).toEqual({
      sequence1: ['1', '2'],
      sequence2: ['1'],
    });
  });

  it('should build path variables from upstream tasks', () => {
    expect(component.pathVariableOptions).toEqual([
      { name: 'test - source', value: 'test', sourceId: 'source', type: 'numeric' },
      { name: 'test 2 - source 1', value: 'test 2', sourceId: 'source 1', type: undefined },
      { name: 'test 3 - source 2', value: 'test 3', sourceId: 'source 2', type: undefined },
    ]);
  });

  it('should fetch from tf_allConditions variable', () => {
    const value: PathForm = {
      sequence2: {
        default: false,
        validateWith: 'value',
        variableCondition: '>',
        variableName: { name: 'number - 1', value: 'number' },
        variableValue: { value: '7' },
      },
    };
    component.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.AllConditions,
              value:
                /* eslint-disable-next-line max-len */
                '{"sequence2":{"default":false,"validateWith":"value","variableName":{"name":"number - 1","sourceId":"Activity_1jkib8o","value":"number","type":"numeric"},"variableCondition":">","variableValue":{"value":"7"},"priority":""},"sequence1":{"default":false,"validateWith":"value","variableName":{"name":"text - 1","sourceId":"Activity_1jkib8o","value":"text","type":"text"},"variableCondition":"!=","variableValue":{"value":"hfhghf"},"priority":""}}',
            },
          ],
        },
      ],
    };
    component.loadSavedValues(value);
    fixture.detectChanges();

    expect(component.savedFormValues).toEqual({
      sequence1: {
        validateWith: 'value',
        variableCondition: '!=',
        variableName: { name: 'text - 1', value: 'text' },
        variableValue: { name: 'undefined', value: 'hfhghf' },
        default: false,
      },
      sequence2: {
        validateWith: 'value',
        variableCondition: '>',
        variableName: { name: 'number - 1', value: 'number' },
        variableValue: { name: 'undefined', value: '7' },
        default: false,
      },
    } as PathForm);
  });
});
