import { SimpleChange } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DropdownsModule, RadioButtonModule, TooltipModule } from 'gds-atom-components';
import { TaskFormInputType } from 'src/app/pages/shared/task-detail';
import { ValidationErrorsModule } from 'src/app/pages/shared/validation-errors/validation-errors.module';

import { ConditionFieldsComponent } from './condition-fields.component';

describe('ConditionFieldsComponent', () => {
  let component: ConditionFieldsComponent;
  let fixture: ComponentFixture<ConditionFieldsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConditionFieldsComponent],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        DropdownsModule,
        RadioButtonModule,
        TooltipModule,
        ValidationErrorsModule,
        NoopAnimationsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConditionFieldsComponent);
    component = fixture.componentInstance;
    component.sequenceId = 'test';
    component.formValues = {
      default: false,
      validateWith: 'value',
      variableName: { name: 'number - 1', value: 'number' },
      variableCondition: '>',
      variableValue: { value: '100', name: 'undefined' },
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show validate radio options', () => {
    expect(fixture.debugElement.queryAll(By.css('input[type=radio]')).length).toBe(2);
  });

  it('should show Variable Name, Condition, Value form fields', () => {
    expect(fixture.debugElement.queryAll(By.css('.kmd-dropdown-select, input[kmdforminput]')).length).toBe(3);
  });

  it('should switch value to dropdown', () => {
    const options: HTMLInputElement = fixture.debugElement.queryAll(By.css('input[name=validatetest]'))[1].nativeElement;
    options.checked = true;
    options.dispatchEvent(new Event('change'));
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.kmd-dropdown-select')).length).toBe(3);
  });

  it('should show Priority field', () => {
    expect(fixture.debugElement.queryAll(By.css('.kmd-dropdown-select')).length).toBe(2);
    component.enablePriority = true;
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.kmd-dropdown-select')).length).toBe(3);
  });

  it('status should not be valid if text field contains special characters', () => {
    component.conditionField = new FormGroup({
      default: new FormControl(false),
      validateWith: new FormControl('value'),
      variableName: new FormControl({ name: 'property 1', value: 'property 1' }),
      variableCondition: new FormControl('!='),
      variableValue: new FormGroup({
        value: new FormControl({ value: '', disabled: false }),
      }),
      priority: new FormControl(''),
    });
    component.inputType = 'text';
    component.conditionField.controls.variableValue.get('value').setValue('some @text');
    component['addDynamicValidationToFormFields'](TaskFormInputType.Text);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input[type=text]'))).toBeTruthy();
    expect(component.conditionField.controls.variableValue.get('value').valid).toBeFalsy();
  });

  it('status should not be valid if text field does not contain boolean values', () => {
    component.conditionField = new FormGroup({
      default: new FormControl(false),
      validateWith: new FormControl('value'),
      variableName: new FormControl({ name: 'property 1', value: 'property 1' }),
      variableCondition: new FormControl('!='),
      variableValue: new FormGroup({
        value: new FormControl({ value: '', disabled: false }),
      }),
      priority: new FormControl(''),
    });
    component.inputType = 'text';
    component.conditionField.controls.variableValue.get('value').setValue('not boolean');
    component['addDynamicValidationToFormFields'](TaskFormInputType.Boolean);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input[type=text]'))).toBeTruthy();
    expect(component.conditionField.controls.variableValue.get('value').valid).toBeFalsy();
  });

  it('status should not be valid if numeric field does not contain any values', () => {
    component.conditionField = new FormGroup({
      default: new FormControl(false),
      validateWith: new FormControl('value'),
      variableName: new FormControl({ name: 'property 1', value: 'property 1' }),
      variableCondition: new FormControl('!='),
      variableValue: new FormGroup({
        value: new FormControl({ value: '', disabled: false }),
      }),
      priority: new FormControl(''),
    });
    component.inputType = 'number';
    component.conditionField.controls.variableValue.get('value').setValue(null);
    component['addDynamicValidationToFormFields'](TaskFormInputType.Numeric);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input[type=number]'))).toBeTruthy();
    expect(component.conditionField.controls.variableValue.get('value').valid).toBeFalsy();
  });

  it('status should not be valid if date field does not contain any values', () => {
    component.conditionField = new FormGroup({
      default: new FormControl(false),
      validateWith: new FormControl('value'),
      variableName: new FormControl({ name: 'property 1', value: 'property 1' }),
      variableCondition: new FormControl('!='),
      variableValue: new FormGroup({
        value: new FormControl({ value: '', disabled: false }),
      }),
      priority: new FormControl(''),
    });
    component.inputType = 'date';
    component.conditionField.controls.variableValue.get('value').setValue(null);
    component['addDynamicValidationToFormFields'](TaskFormInputType.Date);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input[type=date]'))).toBeTruthy();
    expect(component.conditionField.controls.variableValue.get('value').valid).toBeFalsy();
  });

  it('value field should get reflected from formValues variableValue', () => {
    component.inputType = 'number';
    component.ngOnChanges({
      formValues: new SimpleChange(null, component.formValues, false),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input[type=number]')).nativeElement.value).toBe('100');
  });

  it('should display tooltip on variable name if pathOptionSelected is empty', () => {
    component.pathOptionSelected = {
      path: '',
      taskId: '',
      sequenceId: '',
    };
    component.selected = false;
    fixture.debugElement.query(By.css('div kmd-dropdown')).nativeElement.dispatchEvent(
      new MouseEvent('mouseenter', {
        bubbles: true,
      })
    );
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('span[ng-reflect-kmd-tooltip]'))).toBeTruthy();
  });
});
