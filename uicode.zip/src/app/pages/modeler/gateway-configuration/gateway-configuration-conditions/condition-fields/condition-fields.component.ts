import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChange, SimpleChanges, ViewChild } from '@angular/core';
import { differenceWith, isEqual } from 'lodash';
import { KmdDropdownComponent } from 'gds-atom-components';

import type { PathForm, PathFormConditions, PathSelection } from '../path-selection';
import { TaskFormInputType } from '../../../../shared/task-detail';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/pages/shared/custom-validators';

const NUMBER_CONDITIONS = Object.freeze(['>', '>=', '<', '<=', '==', '!=']);
const STRING_CONDITIONS = Object.freeze(['==', '!=']);

@Component({
  selector: 'app-condition-fields',
  templateUrl: './condition-fields.component.html',
  styleUrls: ['./condition-fields.component.scss'],
})
export class ConditionFieldsComponent implements OnInit, OnChanges {
  @Input() sequenceId: string;
  @Input() selected: boolean;
  @Input() variableOptions = [];
  @Input() enablePriority: boolean;
  @Input() priorityOptions: any[];
  @Input() formValues: PathFormConditions;
  @Input() pathOptionSelected: PathSelection = {
    path: '',
    taskId: '',
    sequenceId: '',
  };
  @Output() formChange = new EventEmitter<PathForm>();
  @Output() initLoadFormValues = new EventEmitter<PathForm>();
  public conditionField: FormGroup;
  public inputType: '' | 'number' | 'date' | 'text' = '';
  public selectedType: TaskFormInputType;

  @ViewChild('variableValueDropdown') valueInputRef: KmdDropdownComponent;
  public variableConditions = NUMBER_CONDITIONS.slice();
  public variableOptionsCompare = [];
  readonly #allowBooleanCharactersPattern = /^(true|false)$/i;

  ngOnInit(): void {
    this.conditionField = new FormGroup({
      default: new FormControl(false),
      validateWith: new FormControl('value'),
      variableName: new FormControl({ name: '', value: '' }),
      variableCondition: new FormControl(''),
      variableValue: new FormGroup({
        value: new FormControl({ value: '', disabled: true }),
      }),
      priority: new FormControl(''),
    });
    /*
     * Due to 2 way data binding in `gateway-configuration` component emitting this value
     * causes Angular error ExpressionHasChanged without SetTimeout
     */
    setTimeout(() => {
      this.initLoadFormValues.emit({
        [this.sequenceId]: this.conditionField.value,
      });
    }, 0);
  }

  ngOnChanges(changes: SimpleChanges): void {
    const variableOptions: SimpleChange = changes.variableOptions;
    const formValues: SimpleChange = changes.formValues;
    if (
      formValues &&
      formValues.currentValue &&
      !formValues.currentValue.default &&
      differenceWith(formValues.previousValue, formValues.currentValue, isEqual)
    ) {
      if (formValues.currentValue.variableValue?.value) {
        this.conditionField.get('variableValue').enable();
      }
      this.conditionField.patchValue(changes.formValues.currentValue);
    }
    if (variableOptions && differenceWith(variableOptions.previousValue, variableOptions.currentValue)) {
      this.variableOptionsCompare = variableOptions.currentValue.slice();
    }
  }

  onChange(field: string, value: any): void {
    if (field === 'variableName') {
      this.variableOptionsCompare = this.variableOptions.filter((item) => item.name !== value.selectedOption.name);
      this.selectedType = value.selectedOption.type;
      this.addDynamicValidationToFormFields(this.selectedType);
      if (this.conditionField.controls.variableName.value.name === value.selectedOption.name) {
        if (this.valueInputRef) {
          this.valueInputRef.resetDropdown();
        }
      }
    } else if (field === 'variableCondition') {
      this.conditionField.controls.variableCondition.setValue(value.selectedOption);
      this.setVariableValueState();
    } else if (field === 'priority' && this.enablePriority) {
      this.conditionField.controls.priority.setValue(value.selectedOption);
    } else if (field === 'variableValue') {
      this.conditionField.controls.variableValue.setValue({ value: value.target.value });
    }

    this.formChange.emit({
      [this.sequenceId]: this.conditionField.value,
    });
  }

  private setVariableValueState(): void {
    const control = this.conditionField.get('variableValue');
    if (this.selected || !this.conditionField.controls.variableCondition.value) {
      control.disable();
    } else {
      control.enable();
    }
  }

  private addDynamicValidationToFormFields(type: TaskFormInputType): void {
    switch (type) {
      case TaskFormInputType.Text:
        this.validateInput('text', [Validators.required, Validators.pattern(CustomValidators.disallowSpecialCharactersPattern)]);
        break;
      case TaskFormInputType.Numeric:
        this.validateInput('number', [Validators.required]);
        break;
      case TaskFormInputType.Boolean:
        this.validateInput('text', [Validators.required, Validators.pattern(this.#allowBooleanCharactersPattern)]);
        break;
      case TaskFormInputType.Date:
        this.validateInput('date', [Validators.required]);
        break;
    }
  }

  private validateInput(type: '' | 'number' | 'date' | 'text', validators: ValidatorFn[]): void {
    this.variableConditions = type === 'number' ? NUMBER_CONDITIONS.slice() : STRING_CONDITIONS.slice();
    this.inputType = type;
    this.conditionField.controls.variableValue.get('value').setValidators(validators);
  }
}
