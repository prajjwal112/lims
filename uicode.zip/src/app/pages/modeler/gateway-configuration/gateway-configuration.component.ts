import { Component, Input, SimpleChanges, Output, EventEmitter, OnChanges, ViewChild, ElementRef } from '@angular/core';
import { merge } from 'lodash';

import { ElementType } from '../element-type';
import { ConfigurationType } from '../configuration-type';
import { PathForm, PathFormConditions } from './gateway-configuration-conditions/path-selection';
import { CamundaCustomVariable } from '../../shared/camunda-variable';

@Component({
  selector: 'app-gateway-configuration',
  templateUrl: './gateway-configuration.component.html',
  styleUrls: ['./gateway-configuration.component.scss'],
})
export class GatewayConfigurationComponent implements OnChanges {
  @Input() configuration: ConfigurationType;
  @Output() configurationChange = new EventEmitter<ConfigurationType>();

  @ViewChild('resetView') private modalView: ElementRef;
  public readonly bpmnType = ElementType;
  public configurationWindowOpen: boolean;
  public configurationElementType: ElementType;
  public configurationElement: ConfigurationType['element'];
  public enableConditions: boolean;
  public configurationCondition: PathForm = {};
  public isClosingType: boolean;
  public disableSubmit = false;
  private saveConfigurationTypeValue: ElementType;

  private static isVariablePropertyMissing(task: PathFormConditions): boolean {
    return !task.variableName.name || !task.variableCondition || !task.variableValue.value;
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.disableSubmit = this.checkToDisableSubmit();
    this.configurationWindowOpen = changes.configuration.currentValue.open;
    this.configurationElementType = changes.configuration.currentValue.elementType;
    this.configurationElement = changes.configuration.currentValue.element;
    if (this.configurationElement.extensionElements) {
      this.isClosingType = changes.configuration.currentValue.element.extensionElements?.values.some((element) => {
        if (element.$type.toLowerCase() === ElementType.Properties.toLowerCase()) {
          return element.values.some((value) => value.name === CamundaCustomVariable.GatewayType && value.value === 'close');
        }
      });
    }
  }

  close(conditions?: PathForm): void {
    this.changeTab(0);

    this.onConfigurationChange({
      ...this.configuration,
      elementType: this.saveConfigurationTypeValue || this.configuration.elementType,
      open: false,
      conditions,
    });
  }

  changeTab(index: number): void {
    switch (index) {
      case 0:
        this.enableConditions = false;
        break;
      case 1:
        this.enableConditions = true;
        break;
    }
    this.restoreView();
  }

  goBack(): void {
    this.changeTab(0);
  }

  saveAndClose(): void {
    let conditions = {};
    if (this.enableConditions && this.configurationCondition) {
      conditions = merge({}, this.configuration.conditions, this.configurationCondition);
    }
    this.saveConfigurationTypeValue = this.configurationElementType;
    this.close(conditions);
  }

  openConditions(): void {
    this.changeTab(1);
    this.saveConfigurationTypeValue = this.configurationElementType;
    this.onConfigurationChange({
      ...this.configuration,
      elementType: this.saveConfigurationTypeValue,
    });
  }

  updateConfigurationCondition(event: PathForm): void {
    Object.assign(this.configurationCondition, event);
    this.disableSubmit = this.checkToDisableSubmit();
  }

  updateConfigurationElementType(type: ElementType): void {
    this.configurationElementType = type;
    this.disableSubmit = this.checkToDisableSubmit();
  }

  private checkToDisableSubmit(): boolean {
    let unfinished = this.configurationElementType !== ElementType.ParallelGateway;
    if (this.configurationCondition) {
      Object.keys(this.configurationCondition).forEach((tasks) => {
        const task = this.configurationCondition[tasks];
        if (!task.default) {
          unfinished =
            GatewayConfigurationComponent.isVariablePropertyMissing(task) ||
            (this.configuration.elementType === ElementType.ExclusiveGateway && !task.priority);
        }
      });
    }
    return unfinished;
  }

  private onConfigurationChange(config: ConfigurationType): void {
    this.configurationChange.emit(config);
  }

  private restoreView(): void {
    this.modalView.nativeElement.scrollIntoView();
  }
}
