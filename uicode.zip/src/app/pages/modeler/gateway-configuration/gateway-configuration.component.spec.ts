import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { SimpleChange } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { AlertsModule, ButtonModule, DropdownsModule, ModalsModule, RadioButtonModule, TooltipModule } from 'gds-atom-components';

import { PillsModule } from '../../shared/pills/pills.module';
import { ConfigurationWindowComponent } from '../shared/configuration-window/configuration-window.component';
import { GatewayConfigurationComponent } from './gateway-configuration.component';
import { GatewayConfigurationTypeComponent } from './gateway-configuration-type/gateway-configuration-type.component';
import { GatewayConfigurationConditionsComponent } from '../gateway-configuration/gateway-configuration-conditions/gateway-configuration-conditions.component';
import { ConditionFieldsComponent } from './gateway-configuration-conditions/condition-fields/condition-fields.component';
import { ElementType } from '../element-type';
import { CamundaCustomVariable } from '../../shared/camunda-variable';
import { ValidationErrorsModule } from '../../shared/validation-errors/validation-errors.module';
import { TextNumericRadioGroupComponent } from '../task-configuration/task-form/input-field/text-numeric-radio-group/text-numeric-radio-group.component';

const DECLARATIONS = [
  GatewayConfigurationComponent,
  GatewayConfigurationTypeComponent,
  GatewayConfigurationConditionsComponent,
  ConditionFieldsComponent,
  ConfigurationWindowComponent,
  TextNumericRadioGroupComponent,
];
const IMPORTS = [
  CommonModule,
  BrowserAnimationsModule,
  FormsModule,
  ReactiveFormsModule,
  WindowModule,
  LayoutModule,
  AlertsModule,
  ButtonModule,
  DropdownsModule,
  RadioButtonModule,
  PillsModule,
  WindowModule,
  ModalsModule,
  ValidationErrorsModule,
  TooltipModule,
];

describe('GatewayConfigurationComponent for Open Gateway', () => {
  let component: GatewayConfigurationComponent;
  let fixture: ComponentFixture<GatewayConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: DECLARATIONS,
      imports: IMPORTS,
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatewayConfigurationComponent);
    component = fixture.componentInstance;
    component.configuration = {
      open: true,
      id: 'ParallelGateway_15s1gow',
      elementType: ElementType.ParallelGateway,
      element: {
        $type: ElementType.ParallelGateway,
        incoming: [
          {
            $type: ElementType.Task,
            incoming: [],
            targetRef: {
              name: 'test 1',
              $type: ElementType.Task,
              incoming: [],
            },
            sourceRef: {
              $type: ElementType.Task,
              incoming: [],
            },
          },
        ],
        outgoing: [
          {
            $type: ElementType.Task,
            incoming: [],
            targetRef: {
              name: 'test 2',
              $type: ElementType.Task,
              incoming: [],
            },
          },
        ],
        id: 'ParallelGateway_15s1gow',
      },
      shape: {
        id: 'ParallelGateway_15s1gow',
        gatewayType: 'open',
      },
    };
    component.ngOnChanges({
      configuration: new SimpleChange(null, component.configuration, true),
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should disable condition tab', () => {
    expect(fixture.debugElement.query(By.css('#k-tabstrip-tab-1')).classes['k-state-disabled']).toBe(true);
  });

  it('should have enabled button for parallel gateway type', () => {
    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeFalse();
  });

  it('should switch button to transition to conditions section', () => {
    expect(fixture.debugElement.query(By.css('button.kmd-btn-featured')).nativeElement.textContent.trim()).toBe('Save and Close');
    component.configuration.elementType = ElementType.ExclusiveGateway;
    component.ngOnChanges({
      configuration: new SimpleChange(null, component.configuration, false),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.textContent.trim()).toBe('Save and Next');
  });

  it('should disable button if default path is not selected', () => {
    component.ngOnChanges({
      configuration: new SimpleChange(
        null,
        {
          ...component.configuration,
          elementType: ElementType.InclusiveGateway,
        },
        true
      ),
    });
    component.enableConditions = true;
    component.updateConfigurationCondition({
      'test 2': {
        default: false,
        validateWith: 'value',
        variableName: { name: 'variable', value: 'variable' },
        variableCondition: '=',
        variableValue: { value: 'test', name: '' },
      },
    });
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeTrue();
    pending('default path validation');
  });

  it('should not disable button if default path is selected for single path', () => {
    component.ngOnChanges({
      configuration: new SimpleChange(
        null,
        {
          ...component.configuration,
          elementType: ElementType.InclusiveGateway,
        },
        true
      ),
    });
    component.configurationCondition = {};
    component.enableConditions = true;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeFalsy();
  });
});

describe('GatewayConfigurationComponent for Closed Gateway', () => {
  let component: GatewayConfigurationComponent;
  let fixture: ComponentFixture<GatewayConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: DECLARATIONS,
      imports: IMPORTS,
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatewayConfigurationComponent);
    component = fixture.componentInstance;
    component.configuration = {
      open: true,
      id: 'ParallelGateway_15s1gow',
      elementType: ElementType.ExclusiveGateway,
      element: {
        $type: ElementType.ExclusiveGateway,
        incoming: [],
        id: 'ParallelGateway_15s1gow',
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [{ $type: ElementType.Property, name: CamundaCustomVariable.GatewayType, value: 'close' }],
            },
          ],
        },
      },
      shape: {
        id: 'ParallelGateway_15s1gow',
      },
    };
    component.ngOnChanges({
      configuration: new SimpleChange(null, component.configuration, true),
    });
    fixture.detectChanges();
  });

  it('should save and close for closed gateway types', () => {
    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.textContent.trim()).toBe('Save and Close');
  });
});
