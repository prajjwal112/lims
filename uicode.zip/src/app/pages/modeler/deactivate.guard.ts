import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';

export interface CanComponentDeactivate {
  confirmComponentDeactivation: () => Observable<boolean>;
}

@Injectable({
  providedIn: 'root',
})
export class DeactivateGuard implements CanDeactivate<CanComponentDeactivate> {
  /* eslint-disable class-methods-use-this */
  canDeactivate(component: CanComponentDeactivate): Observable<boolean> {
    return component.confirmComponentDeactivation();
  }
}
