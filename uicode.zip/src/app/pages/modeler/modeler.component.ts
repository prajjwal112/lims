import { Component, ElementRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subject, Observable, of } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { isEqual } from 'lodash';
import { KmdModalService } from 'gds-atom-components';
import camundaExtensionModule from 'camunda-bpmn-moddle/lib';
import camundaModdleDescriptor from 'camunda-bpmn-moddle/resources/camunda.json';
import lintModule from 'bpmn-js-bpmnlint';
import { is } from 'bpmn-js/lib/util/ModelUtil';
import modelerOverride from './modeler-override';
import { configurationWindow } from './modeler-override/CustomContextPadProvider';
import { Action, ActionType, StoreService } from '../../store.service';
import { BpmnWorkflowModeler } from './shared/BpmnWorkflowModeler';
import { ElementType } from './element-type';
import { ModalId } from '../shared/modal-id';
import { CamundaCustomVariable, CamundaServerVariable } from '../shared/camunda-variable';
import { CamundaVariablePipe } from '../../core/pipe/variable-readability/camunda-variable.pipe';
import { WorkflowDefinitionService } from '../../core/api/workflow-definition/workflow-definition.service';
import { getExtensionProperty } from './shared/bpmnExtensionProperty';
import { TaskInputType } from '../shared/task-detail';
import { CanComponentDeactivate } from './deactivate.guard';
import { ComponentWithModalDirective } from '../shared/component-with-modal.directive';
import { newBlankBpmn } from './xml/bpmn_blank';
import { NumberUtility } from '../../core/api/number-utility';
import type { AfterContentInit, OnDestroy, OnInit } from '@angular/core';
import type { PathForm } from './gateway-configuration/gateway-configuration-conditions/path-selection';
import type { ConfigurationType, ExtensionElement, Properties } from './configuration-type';
import type { TaskData } from './task-configuration/task-data';
import type { BasicTaskFormInput, DateTaskFormInput, SelectTaskFormInput } from '../shared/task-detail';
import type { WorkflowDefinitionTemplateResponse } from '../workflow-definitions/shared/workflow-definition';

// Import requires custom webpack override
const bpmnlintConfig = require('bpmnlint-loader!../../../../.bpmnlintrc');
enum ClosingValue {
  Close = 'close',
}
enum DiagramAction {
  SaveTemplate = 'saveTemplate',
  VerifyDiagram = 'verifyDiagram',
}

interface ExtensionProperties {
  name: string;
  value: any;
}

@Component({
  selector: 'app-modeler',
  templateUrl: './modeler.component.html',
  styleUrls: ['./app.less', './modeler.component.scss', '../shared/page-header.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [CamundaVariablePipe],
})
export class ModelerComponent extends ComponentWithModalDirective implements OnInit, AfterContentInit, OnDestroy, CanComponentDeactivate {
  @ViewChild('diagram', { static: true }) private bpmnElement: ElementRef;

  public readonly elementType = ElementType;
  public readonly modalId = ModalId;
  public readonly workflowDefinitionName = '';
  public validationErrorMessage: string;
  public bpmnModeler: BpmnWorkflowModeler;
  public configurationWindowProperties: ConfigurationType = {
    open: false,
    id: '',
    elementType: '',
    element: { $type: '', id: '', incoming: [] },
    shape: {},
  };
  public enforceDueDates = false;
  public workflowSuccessAlert = '';
  public workflowErrorAlert = '';
  public successMessage = false;
  public errorMessage = false;

  readonly #unsubscribe = new Subject<void>();
  readonly #unloadComponent = new Subject<boolean>();
  readonly #dueDateTracked: boolean;
  #workflowDefinitionTemplate: WorkflowDefinitionTemplateResponse;
  #workflowDefinitionTemplateId: ReturnType<typeof NumberUtility.toNumber>;
  #showAlertModal = false;

  constructor(
    protected readonly kmdModalService: KmdModalService,
    private readonly store: StoreService,
    private readonly camundaVariablePipe: CamundaVariablePipe,
    private readonly router: Router,
    private readonly workflowDefinitionsService: WorkflowDefinitionService
  ) {
    super(kmdModalService);
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Modeler' }));

    const state = this.router.getCurrentNavigation().extras.state;

    if (state?.modelerName) {
      this.workflowDefinitionName = state.modelerName;
    }

    this.#workflowDefinitionTemplateId = NumberUtility.toNumber(state?.modelerId);
    this.#dueDateTracked = state?.dueDateTracked === true;
  }

  private static getValidationErrorMessage(customMessage: string): string {
    return `${customMessage}<br/> Please address the error(s) to publish your workflow`;
  }

  private static hasGatewayTypeProperty(extensionElement: ExtensionElement): boolean {
    return extensionElement?.values.some((element) => {
      if (element.$type.toLowerCase() === ElementType.Properties.toLowerCase()) {
        return element.values.some((value) => value.name === CamundaCustomVariable.GatewayType);
      }
    });
  }

  private static getCamundaVariableValue(
    form: TaskData['form'],
    variable: CamundaServerVariable,
    extensionElements: ExtensionElement
  ): ExtensionProperties | undefined {
    const value = form[variable];

    if (value && value !== getExtensionProperty(variable, extensionElements)) {
      return {
        name: variable,
        value,
      };
    }
  }

  public ngOnInit(): void {
    configurationWindow.pipe(takeUntil(this.#unsubscribe)).subscribe({
      next: (config: ConfigurationType) => {
        if (config.shape.gatewayType && !ModelerComponent.hasGatewayTypeProperty(config.shape.businessObject.extensionElements)) {
          this.extendPropertiesToElement(config.shape, [{ name: CamundaCustomVariable.GatewayType, value: config.shape.gatewayType }]);
        } else if (
          ['', ElementType.ExclusiveGateway, ElementType.InclusiveGateway, ElementType.ParallelGateway].includes(config.shape.type)
        ) {
          const element: ConfigurationType['shape'] = this.bpmnModeler.modeler.get('elementRegistry').get(config.shape.id);
          if (element.businessObject.extensionElements) {
            const closingTypeGateway = element.businessObject.extensionElements.values.some((el) => {
              if (el.$type.toLowerCase() === ElementType.Properties.toLowerCase()) {
                return el.values.some((item) => item.name === CamundaCustomVariable.GatewayType && item.value === ClosingValue.Close);
              }
              return false;
            });
            if (closingTypeGateway) {
              config.shape.gatewayType = ClosingValue.Close;
            }
          }
        }
        this.configurationWindowProperties = Object.assign({}, config);
      },
    });
  }

  public ngAfterContentInit(): void {
    this.initializeTemplate();
  }

  public ngOnDestroy(): void {
    this.bpmnModeler.modeler.destroy();
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
    this.#unloadComponent.complete();
  }

  public confirmComponentDeactivation(): Observable<boolean> {
    if (this.#showAlertModal) {
      this.openModal(ModalId.Unload);
      return this.#unloadComponent.asObservable();
    }
    return of(true);
  }

  public bpmnInit(xml?: string): void {
    this.bpmnModeler = new BpmnWorkflowModeler(this.bpmnElement, {
      additionalModules: [modelerOverride, lintModule, camundaExtensionModule],
      linting: {
        bpmnlint: bpmnlintConfig,
      },
      // needed if you'd like to maintain camunda:XXX properties in the properties panel
      moddleExtensions: {
        camunda: camundaModdleDescriptor,
      },
    });

    if (!xml) {
      return;
    }

    this.bpmnModeler.openDiagram(xml);
    this.bpmnModeler.modeler.attachTo(this.bpmnElement.nativeElement);

    this.bpmnModeler.modeler.on('linting.toggle', (event) => {
      // Disable turning linting off
      const linting = this.bpmnModeler.modeler.get('linting');
      if (!event.active) {
        linting._setActive(true);
      }
    });
    this.bpmnModeler.modeler.on('import.done', () => {
      const linting = this.bpmnModeler.modeler.get('linting');
      linting._setActive(true);

      // Check if we need to save the EnforceDueDate xml property
      if (this.#workflowDefinitionTemplate?.dueDateTracked) {
        const rootElement = this.bpmnModeler.modeler.get('canvas').getRootElement();
        const camundaProperties: ExtensionProperties[] = [
          {
            name: CamundaServerVariable.EnforceDueDates,
            value: 'true',
          },
        ];

        this.extendPropertiesToElement(rootElement, camundaProperties);
      }

      this.setEnforceDueDates();
    });

    this.bpmnModeler.modeler.get('eventBus').on('commandStack.changed', () => this.setUnsavedChanges(true));
  }

  public zoomIn(): void {
    this.zoomModel('stepZoom', 1);
  }

  public zoomOut(): void {
    this.zoomModel('stepZoom', -1);
  }

  public resetZoom(): void {
    this.zoomModel('reset');
  }

  public saveWorkflowDefinitionTemplate(): void {
    this.setUnsavedChanges(false);
    this.kmdModalService.close(ModalId.Unload);
    this.saveDiagramForTemplateAction(DiagramAction.SaveTemplate);
  }

  public verifyDiagram(): void {
    this.setUnsavedChanges(false);
    this.saveDiagramForTemplateAction(DiagramAction.VerifyDiagram);
  }

  public closeModal(id: ModalId): void {
    super.closeModal(id);
    this.#unloadComponent.next(true);
  }

  public updateGateway(config: ConfigurationType): void {
    const modeler = this.bpmnModeler.modeler;
    let element: ConfigurationType['shape'] = modeler.get('elementRegistry').get(config.element.id);
    const conditions: PathForm = config.conditions;

    if (!isEqual(this.configurationWindowProperties.elementType, config.elementType)) {
      const newElementData = {
        type: config.elementType,
        gatewayType: config.shape.gatewayType,
      };
      let defaultId = '';
      if (element.businessObject.default && config.elementType !== ElementType.ParallelGateway) {
        defaultId = element.businessObject.default.id;
      }

      const replace = modeler.get('replace');
      replace.replaceElement(element, newElementData);
      // need new reference to element after it's replaced
      element = modeler.get('elementRegistry').get(config.element.id);

      this.updatePropertyOnElement(element, [
        {
          name: 'default',
          value: modeler.get('elementRegistry').get(defaultId),
        },
      ]);

      configurationWindow.next({
        ...this.configurationWindowProperties,
        elementType: config.elementType,
        shape: element,
        element: element.businessObject,
      });
    }

    this.configurationWindowProperties = {
      ...config,
      element: element.businessObject,
      shape: element,
    };

    if (conditions) {
      this.generateGatewayConditions(element, conditions);
    }

    this.saveXML();
  }

  public updateTask(data: TaskData): void {
    const element: ConfigurationType['shape'] = this.bpmnModeler.modeler.get('elementRegistry').get(this.configurationWindowProperties.id);
    if (data.detail) {
      this.updateTaskDetails(
        element,
        data.detail.name,
        data.detail.description,
        data.detail.priority,
        data.detail.queueTime,
        data.detail.executionTime,
        data.detail.overrideBusinessHours
      );
    } else if (data.action?.variables) {
      this.updateTaskActionData(element, data.action);
    } else if (data.input) {
      this.updateTaskInputData(element, data.input);
    } else if (data.form) {
      this.updateTaskFormData(element, data.form);
    } else if (data.output) {
      this.updateTaskOutputData(element, data.output);
    }

    this.saveXML();
  }

  public closeAlert(): void {
    this.successMessage = false;
    this.errorMessage = false;
  }

  private initializeTemplate(): void {
    this.setEnforceDueDates();

    if (this.#workflowDefinitionTemplateId === null) {
      this.bpmnInit(newBlankBpmn(this.enforceDueDates));
      return;
    }

    this.workflowDefinitionsService
      .getWorkflowDefinitionTemplate(this.#workflowDefinitionTemplateId)
      .pipe(take(1))
      .subscribe({
        next: (data: WorkflowDefinitionTemplateResponse) => {
          this.#workflowDefinitionTemplate = data;

          this.bpmnInit(data.xml);
        },
      });
  }

  private setEnforceDueDates(): void {
    this.enforceDueDates = this.#dueDateTracked || this.isEnforcingDueDates() || this.#workflowDefinitionTemplate?.dueDateTracked;
  }

  private saveDiagramForTemplateAction(diagramAction: DiagramAction): void {
    this.bpmnModeler.saveDiagram((xml) => {
      if (!xml) {
        this.validationErrorMessage = ModelerComponent.getValidationErrorMessage('Error saving template');
      } else {
        this.saveWorkflowDefinitionTemplateXml(xml).subscribe({
          next: (response: WorkflowDefinitionTemplateResponse) => {
            this.#workflowDefinitionTemplate = response;
            this.#unloadComponent.next(true);
            if (diagramAction === DiagramAction.SaveTemplate) {
              this.processSuccessOnSaveWorkflowDefinitionTemplateXml();
            } else if (diagramAction === DiagramAction.VerifyDiagram) {
              this.verifyTemplateXml(xml);
            }
          },
          error: () => {
            this.processErrorOnSaveWorkflowDefinitionTemplateXml();
          },
        });
      }
    });
  }

  private processErrorOnSaveWorkflowDefinitionTemplateXml(): void {
    this.errorMessage = true;
    this.setWorkflowErrorAlertMessage();
  }

  private processSuccessOnSaveWorkflowDefinitionTemplateXml(): void {
    this.successMessage = true;
    this.setWorkflowSuccessAlertMessage();
  }

  private saveWorkflowDefinitionTemplateXml(xml: string): Observable<WorkflowDefinitionTemplateResponse> {
    return this.workflowDefinitionsService.saveWorkflowDefinitionTemplate({ name: this.workflowDefinitionName, xml }).pipe(take(1));
  }

  private verifyTemplateXml(xml: string): void {
    this.workflowDefinitionsService.verifyTemplate(xml).subscribe({
      next: () => {
        this.router.navigate(['/modeler/publish'], {
          state: {
            verifiedTaskTemplate: {
              xml,
              definitionTemplateId: this.#workflowDefinitionTemplate.id,
              dueDateTracked: this.#workflowDefinitionTemplate.dueDateTracked,
            },
            workflowName: this.workflowDefinitionName,
            description: this.#workflowDefinitionTemplate.description,
            projectIds: this.#workflowDefinitionTemplate.projectIds,
          },
        });
      },
      error: (error: HttpErrorResponse) => {
        console.error('error verifying diagram', error.message);
        let validationErrorMessage = '';
        for (const detail of error.error.details) {
          validationErrorMessage += `<br/> ${this.camundaVariablePipe.transform(detail)}`;
        }
        this.validationErrorMessage = ModelerComponent.getValidationErrorMessage(validationErrorMessage.substr(5));
        this.openModal(ModalId.ModelerError);
      },
    });
  }

  private updatePropertyOnElement(shape: ConfigurationType['shape'], properties: ExtensionProperties[]): void {
    const modeling = this.bpmnModeler.modeler.get('modeling');
    properties.forEach((property) => {
      modeling.updateProperties(shape, {
        [property.name]: property.value,
      });
    });
  }

  private extendPropertiesToElement(shape: ConfigurationType['shape'], properties: ExtensionProperties[], toRemove: string[] = []): void {
    const moddle = this.bpmnModeler.modeler.get('moddle');

    const camundaProperties: Properties[] = properties.map((property) =>
      moddle.create(ElementType.Property, {
        name: property.name,
        value: property.value,
      })
    );

    shape.businessObject?.extensionElements?.values.forEach((element) => {
      if (element.$type.toLowerCase() === ElementType.Properties.toLowerCase()) {
        element.values.forEach((property) => {
          if (property.$type.toLowerCase() === ElementType.Property.toLowerCase()) {
            let propertyExists = false;
            for (const newProperty of camundaProperties) {
              if (newProperty.name === property.name) {
                propertyExists = true;
                break;
              }
            }
            if (!propertyExists && !toRemove.includes(property.name)) {
              camundaProperties.push(property);
            }
          }
        });
      }
    });

    this.updatePropertyOnElement(shape, [
      {
        name: 'extensionElements',
        value: moddle.create(ElementType.ExtensionElements, {
          values: [
            moddle.create(ElementType.Properties, {
              values: camundaProperties,
            }),
          ],
        }),
      },
    ]);
  }

  private isEnforcingDueDates(): boolean {
    let enforceDate = false;
    const extensionElement: ExtensionElement = this.bpmnModeler?.modeler.get('elementRegistry').getAll()[0]?.businessObject
      ?.extensionElements;

    if (extensionElement) {
      extensionElement.values.forEach((extension) => {
        if (is(extension, ElementType.Properties)) {
          enforceDate = extension.values.some(
            (item: Properties) => item.name.toLowerCase() === CamundaServerVariable.EnforceDueDates.toLowerCase() && item.value === 'true'
          );
        }
      });
    }

    return enforceDate;
  }

  private generateGatewayConditions(element: ConfigurationType['shape'], conditions: PathForm): void {
    const moddle = this.bpmnModeler.modeler.get('moddle');
    this.extendPropertiesToElement(element, [
      {
        name: CamundaCustomVariable.AllConditions,
        value: JSON.stringify(conditions),
      },
    ]);
    Object.keys(conditions).forEach((id) => {
      const condition = conditions[id];
      const defaultPath = condition.default;
      const variableName = condition.variableName;
      const variableCondition = condition.variableCondition;
      const variableValue = condition.variableValue;
      const sequenceFlow = this.bpmnModeler.modeler.get('elementRegistry').get(id);
      const properties: ExtensionProperties[] = [];
      if (defaultPath) {
        this.updatePropertyOnElement(this.configurationWindowProperties.shape, [
          {
            name: 'default',
            value: sequenceFlow,
          },
        ]);
      } else if (variableName?.name && variableValue?.value && variableCondition) {
        const value = ['!=', '=='].includes(condition.variableCondition) ? `'${variableValue.value}'` : variableValue.value;

        const conditionExpressionTag = moddle.create(ElementType.FormalExpression, {
          body: `<![CDATA[\${ ${variableName.value} ${variableCondition} ${value} }]]>`,
        });
        properties.push({ name: 'conditionExpression', value: conditionExpressionTag });
      }
      this.updatePropertyOnElement(sequenceFlow, properties);
    });
  }

  private updateTaskDetails(
    element: ConfigurationType['shape'],
    name: string,
    description: string,
    priority: number,
    queueTime: number,
    completionTime: number,
    overrideBusinessHours: boolean
  ): void {
    const moddle = this.bpmnModeler.modeler.get('moddle');
    const modeling = this.bpmnModeler.modeler.get('modeling');
    // Modeling module allows to update and re-render BPMN xml
    modeling.updateLabel(element, name);

    // Documentation created as a ModdleElement needs to be an array
    // https://github.com/bpmn-io/bpmn-js-example-model-extension
    const documentationTag = moddle.create(ElementType.Documentation, { text: description });
    const camundaProperties: ExtensionProperties[] = [
      {
        name: CamundaServerVariable.Priority,
        value: priority,
      },
    ];

    if (this.enforceDueDates) {
      camundaProperties.push(
        {
          name: CamundaServerVariable.QueueTimeHours,
          value: queueTime,
        },
        {
          name: CamundaServerVariable.ExecutionTimeHours,
          value: completionTime,
        },
        {
          name: CamundaServerVariable.OverrideBusinessHours,
          value: overrideBusinessHours,
        }
      );
    }
    let toRemove = [];
    if (!this.enforceDueDates) {
      toRemove = [
        CamundaServerVariable.QueueTimeHours,
        CamundaServerVariable.ExecutionTimeHours,
        CamundaServerVariable.OverrideBusinessHours,
      ];
    }
    this.extendPropertiesToElement(element, camundaProperties, toRemove);
    this.updatePropertyOnElement(element, [{ name: 'documentation', value: [documentationTag] }]);
  }

  private updateTaskActionData(element: ConfigurationType['shape'], variables: TaskData['action']): void {
    let changingToBlankType = true;
    const camundaProperties: ExtensionProperties[] = Object.keys(variables).map((action) => {
      let value = variables[action];
      if (typeof variables[action] === 'object') {
        value = JSON.stringify(value);
      }
      if (action === CamundaCustomVariable.TaskActionName) {
        changingToBlankType = false;
      }
      return {
        name: action,
        value,
      };
    });
    const existingKey = getExtensionProperty(CamundaCustomVariable.TaskActionKey, element.businessObject.extensionElements);
    let toRemove: string[] = [];

    if (changingToBlankType || variables.key !== existingKey) {
      toRemove = [
        CamundaCustomVariable.TaskActionKey,
        CamundaCustomVariable.TaskActionTemplateKey,
        CamundaCustomVariable.TaskActionName,
        CamundaCustomVariable.TaskActionType,
        CamundaCustomVariable.TaskActionVariables,
        CamundaServerVariable.TaskInputMapping,
        CamundaServerVariable.TaskInput,
        CamundaServerVariable.TaskInstructions,
        CamundaServerVariable.TaskAutoExecute,
        CamundaServerVariable.Endpoint,
        CamundaServerVariable.EndpointLabel,
        CamundaServerVariable.OutputMappingPrivate,
        CamundaServerVariable.OutputMappingPublic,
      ];
    }

    this.extendPropertiesToElement(element, camundaProperties, toRemove);
  }

  private updateTaskInputData(element: ConfigurationType['shape'], input: TaskData['input']): void {
    const savedValue = getExtensionProperty(CamundaServerVariable.TaskInputMapping, element.businessObject.extensionElements);
    const currentValue = JSON.stringify(input);
    const toRemove: CamundaServerVariable[] = [];
    if (currentValue !== savedValue) {
      const camundaProperties: ExtensionProperties = {
        name: CamundaServerVariable.TaskInputMapping,
        value: currentValue,
      };
      toRemove.push(
        CamundaServerVariable.TaskAutoExecute,
        CamundaServerVariable.TaskInstructions,
        CamundaServerVariable.TaskInput,
        CamundaServerVariable.Endpoint,
        CamundaServerVariable.EndpointLabel,
        CamundaServerVariable.OutputMappingPrivate,
        CamundaServerVariable.OutputMappingPublic
      );
      this.extendPropertiesToElement(element, [camundaProperties], toRemove);
    }
  }

  private updateTaskFormData(element: ConfigurationType['shape'], form: TaskData['form']): void {
    const extensionElements = element.businessObject.extensionElements;
    const camundaProperties: ExtensionProperties[] = [];
    const toRemove: CamundaServerVariable[] = [];

    if (
      form[CamundaServerVariable.TaskAutoExecute] !== undefined &&
      form[CamundaServerVariable.TaskAutoExecute]?.toString() !==
        getExtensionProperty(CamundaServerVariable.TaskAutoExecute, extensionElements)
    ) {
      toRemove.push(
        CamundaServerVariable.TaskInput,
        CamundaServerVariable.TaskInstructions,
        CamundaServerVariable.Endpoint,
        CamundaServerVariable.EndpointLabel
      );

      camundaProperties.push({
        name: CamundaServerVariable.TaskAutoExecute,
        value: form[CamundaServerVariable.TaskAutoExecute],
      });
    } else if (form[CamundaServerVariable.TaskAutoExecute] === undefined) {
      toRemove.push(CamundaServerVariable.TaskAutoExecute);

      const variablesToIgnore = [
        CamundaServerVariable.TaskInstructions,
        CamundaServerVariable.Endpoint,
        CamundaServerVariable.EndpointLabel,
      ];
      const mapper = (input: string): any => {
        const { taskInputType, ...rest } = form[input];
        return rest;
      };

      const basics: BasicTaskFormInput[] = Object.keys(form)
        .filter((input: CamundaServerVariable) => !variablesToIgnore.includes(input) && form[input].taskInputType === TaskInputType.Basic)
        .map((input: string) => mapper(input));
      const dates: DateTaskFormInput[] = Object.keys(form)
        .filter((input: CamundaServerVariable) => !variablesToIgnore.includes(input) && form[input].taskInputType === TaskInputType.Date)
        .map((input: string) => mapper(input));
      const selects: SelectTaskFormInput[] = Object.keys(form)
        .filter((input: CamundaServerVariable) => !variablesToIgnore.includes(input) && form[input].taskInputType === TaskInputType.Select)
        .map((input: string) => mapper(input));

      if (JSON.stringify({ basics, dates, selects }) !== getExtensionProperty(CamundaServerVariable.TaskInput, extensionElements)) {
        camundaProperties.push({
          name: CamundaServerVariable.TaskInput,
          value: JSON.stringify({
            basics,
            dates,
            selects,
          }),
        });
      }

      const taskInstructionsValue = ModelerComponent.getCamundaVariableValue(
        form,
        CamundaServerVariable.TaskInstructions,
        extensionElements
      );
      if (taskInstructionsValue) {
        camundaProperties.push(taskInstructionsValue);
      }

      const endpointValue = ModelerComponent.getCamundaVariableValue(form, CamundaServerVariable.Endpoint, extensionElements);
      if (endpointValue) {
        camundaProperties.push(endpointValue);
      }

      const endpointLabelValue = ModelerComponent.getCamundaVariableValue(form, CamundaServerVariable.EndpointLabel, extensionElements);
      if (endpointLabelValue) {
        camundaProperties.push(endpointLabelValue);
      }
    }

    if (camundaProperties.length > 0) {
      toRemove.push(CamundaServerVariable.OutputMappingPrivate, CamundaServerVariable.OutputMappingPublic);
      this.extendPropertiesToElement(element, camundaProperties, toRemove);
    }
  }

  private updateTaskOutputData(element: ConfigurationType['shape'], outputs: TaskData['output']): void {
    const savedValue = getExtensionProperty(CamundaServerVariable.OutputMappingPrivate, element.businessObject.extensionElements);
    const currentValue = JSON.stringify(outputs);
    const camundaProperties: ExtensionProperties[] = [];
    const toRemove: CamundaServerVariable[] = [];
    if (currentValue !== savedValue && Object.keys(outputs).length > 0) {
      camundaProperties.push(
        {
          name: CamundaServerVariable.OutputMappingPrivate,
          value: currentValue,
        },
        {
          name: CamundaServerVariable.OutputMappingPublic,
          value: JSON.stringify(Object.values(outputs)),
        }
      );
    } else if (Object.keys(outputs).length === 0) {
      toRemove.push(CamundaServerVariable.OutputMappingPublic, CamundaServerVariable.OutputMappingPrivate);
    }

    this.extendPropertiesToElement(element, camundaProperties, toRemove);
  }

  private saveXML(): void {
    // For debugging XML until this method is complete
    this.bpmnModeler.saveDiagram((xml) => {
      if (xml) {
        // eslint-disable-next-line no-restricted-syntax,no-console
        console.debug(xml);
      }
    });
  }

  private zoomModel(how: 'stepZoom' | 'reset', step?: number): void {
    this.bpmnModeler.modeler.get('zoomScroll')[how](step);
  }

  private setWorkflowSuccessAlertMessage(): void {
    this.workflowSuccessAlert = 'Your changes were saved.';
  }

  private setWorkflowErrorAlertMessage(): void {
    this.workflowErrorAlert = 'An error occurred while saving the workflow. Please contact your system administrator.';
  }

  private setUnsavedChanges(bool: boolean): void {
    this.#showAlertModal = bool;
  }
}
