/* eslint-disable */

/**
 * Copied from diagram-js/lib/features/context-pad/ContextPad
 * This file overrides modeler's context pad container
 */

import ContextPad from 'diagram-js/lib/features/context-pad/ContextPad';

import { forEach } from 'min-dash';

import {
  attr as domAttr,
  classes as domClasses,
  domify,
  query as domQuery
} from 'min-dom';

export default class CustomContextPad extends ContextPad {
  _updateAndOpen(element) {
    var entries = this.getEntries(element),
      pad = this.getPad(element),
      html = pad.html;

    forEach(entries, function(entry, id) {
      var grouping = entry.group || 'default',
        control = domify(
          entry.html ||
            `
              <div class="entry ${
                entry.separator ? 'separator' : ''
              }" draggable="true">
                <i class="${entry.className}"></i>
                ${entry.title || ''}
              </div>
            `
        ),
        container;

      domAttr(control, 'data-action', id);

      container = domQuery('[data-group=' + grouping + ']', html);
      if (!container) {
        container = domify(
          '<div class="group" data-group="' + grouping + '"></div>'
        );
        html.appendChild(container);
      }

      container.appendChild(control);

      // if (entry.className) {
      //   addClasses(control, entry.className);
      // }

      if (entry.title) {
        domAttr(control, 'title', entry.title);
      }

      if (entry.imageUrl) {
        control.appendChild(domify('<img src="' + entry.imageUrl + '">'));
      }
    });

    domClasses(html).add('open');

    this._current = {
      element: element,
      pad: pad,
      entries: entries
    };

    this._eventBus.fire('contextPad.open', { current: this._current });
  }
}