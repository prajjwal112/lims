import CustomPaletteProvider from './CustomPaletteProvider';
import CustomContextPadProvider from './CustomContextPadProvider';
import CustomContextPad from './CustomContextPad';
import BpmnRules from './BpmnRules';

export default {
  __init__: ['customBpmnRules', 'paletteProvider', 'contextPad'],
  paletteProvider: ['type', CustomPaletteProvider],
  contextPad: ['type', CustomContextPad],
  contextPadProvider: ['type', CustomContextPadProvider],
  customBpmnRules: ['type', BpmnRules]
};
