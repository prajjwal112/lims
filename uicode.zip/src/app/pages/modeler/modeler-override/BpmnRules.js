/* eslint-disable */

import inherits from 'inherits';

import RuleProvider from 'diagram-js/lib/features/rules/RuleProvider';
import { isAny } from 'bpmn-js/lib/features/modeling/util/ModelingUtil';

/**
 *
 * See {@link BpmnRules} for the default implementation
 * of BPMN 2.0 modeling rules provided by bpmn-js.
 *
 * @param {EventBus} eventBus
 */
export default function CustomRules(eventBus) {
  RuleProvider.call(this, eventBus);
}

inherits(CustomRules, RuleProvider);

CustomRules.$inject = ['eventBus'];

CustomRules.prototype.init = function() {
  /*
   * Disallow deletion of start event
   */
  this.addRule('elements.delete', function(context) {
    var elements = context.elements;

    for (const element of elements) {
      if (
        isAny(element.businessObject, ['bpmn:StartEvent', 'bpmn:Participant'])
      ) {
        return false;
      }
    }
  });
};
