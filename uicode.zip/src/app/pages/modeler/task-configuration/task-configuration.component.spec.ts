import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SimpleChange } from '@angular/core';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { WindowModule } from '@progress/kendo-angular-dialog';
import {
  RadioButtonModule,
  CheckboxModule,
  InputFieldsModule,
  ButtonModule,
  AlertsModule,
  ToggleModule,
  TooltipModule,
} from 'gds-atom-components';

import { TaskConfigurationComponent } from './task-configuration.component';
import { ConfigurationWindowComponent } from '../shared/configuration-window/configuration-window.component';
import { TaskDetailComponent } from './task-detail/task-detail.component';
import { TaskActionComponent } from './task-action/task-action.component';
import { TaskInputsComponent } from './task-inputs/task-inputs.component';
import { TaskFormComponent } from './task-form/task-form.component';
import { TaskOutputComponent } from './task-output/task-output.component';
import { ElementType } from '../element-type';
import { CamundaServerVariable } from '../../shared/camunda-variable';
import { DropDownAutoCompleteModule } from '../../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { GridModule } from '../../shared/grid/grid.module';
import { CustomValidators } from '../../shared/custom-validators';

describe('TaskConfigurationComponent', () => {
  let component: TaskConfigurationComponent;
  let fixture: ComponentFixture<TaskConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TaskConfigurationComponent,
        ConfigurationWindowComponent,
        TaskDetailComponent,
        TaskActionComponent,
        TaskInputsComponent,
        TaskFormComponent,
        TaskOutputComponent,
      ],
      imports: [
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        ButtonModule,
        CheckboxModule,
        InputFieldsModule,
        RadioButtonModule,
        ToggleModule,
        AlertsModule,
        ButtonsModule,
        DropDownAutoCompleteModule,
        GridModule,
        LayoutModule,
        WindowModule,
        TooltipModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskConfigurationComponent);
    component = fixture.componentInstance;
    component.configuration = {
      open: true,
      id: 'task_id_123',
      elementType: ElementType.Task,
      shape: {},
      element: {
        id: 'task_id_123',
        $type: ElementType.Task,
        name: 'Task name',
        documentation: [{ $type: ElementType.Documentation, text: 'description' }],
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [{ $type: ElementType.Property, name: CamundaServerVariable.Priority, value: '75' }],
            },
          ],
        },
      },
    };
    component.ngOnChanges({ configuration: new SimpleChange(null, component.configuration, true) });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show task name in window', () => {
    expect(fixture.debugElement.query(By.css('h2')).nativeElement.textContent.trim()).toBe('Configure Task - Task name');
  });

  it('should not show task name in window', () => {
    component.ngOnChanges({
      configuration: new SimpleChange(
        null,
        {
          open: true,
          id: 'task_id_123',
          elementType: 'bpmn:Task',
          element: {
            $type: 'bpmn:Task',
          },
        },
        false
      ),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('h2')).nativeElement.textContent.trim()).toBe('Configure Task');
  });

  it('should display 5 steps', () => {
    expect(fixture.debugElement.queryAll(By.css('kendo-tabstrip li')).length).toBe(5);
  });

  it('should have save button disabled if detail form is invalid', () => {
    component.formData.detail.controls.name.setValue('');
    component.onUpdateForm('detail', component.formData.detail.controls);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.disabled).toBeTrue();
  });

  it('should have save button disabled if action form is invalid', () => {
    component.changeTab(component.tab.Action);
    const action = new FormGroup({
      key: new FormControl('', Validators.required),
    });
    component.onUpdateForm('action', action.controls);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.disabled).toBeTrue();
  });

  it('should have save button disabled if input form is invalid', () => {
    component.changeTab(component.tab.Input);
    fixture.detectChanges();
    const input = new FormGroup({
      key: new FormControl('', [Validators.required, CustomValidators.notBlank]),
    });
    component.onUpdateForm('input', input.controls);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.disabled).toBeTrue();
  });

  it('should have save button disabled if form form is invalid', () => {
    component.changeTab(component.tab.Form);
    fixture.detectChanges();
    const form = new FormGroup({
      key: new FormControl('', Validators.required),
    });
    component.onUpdateForm('form', form.controls);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.disabled).toBeTrue();
  });

  it('should have save button disabled if output form is invalid', () => {
    component.changeTab(component.tab.Output);
    fixture.detectChanges();
    const output = new FormGroup({
      key: new FormControl('', Validators.required),
    });
    component.onUpdateForm('output', output.controls);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-featured')).nativeElement.disabled).toBeTrue();
  });

  it('should have save button enabled if output form is disabled', () => {
    component.changeTab(component.tab.Output);
    fixture.detectChanges();
    const output = new FormGroup({
      key: new FormControl({ value: 'test', disabled: true }, Validators.required),
    });
    component.onUpdateForm('output', output.controls);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-featured')).nativeElement.disabled).toBeFalse();
  });

  it('should have save button enabled if form is valid', () => {
    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.disabled).toBeFalsy();
  });

  it('should show back button when past first tab', () => {
    expect(fixture.debugElement.query(By.css('button.kmd-btn-primary'))).toBeFalsy();
    component.activeTab = component.tab.Action;
    fixture.detectChanges();

    expect(component.activeTab).toBeGreaterThan(component.tab.Detail);
    expect(fixture.debugElement.query(By.css('button.kmd-btn-primary'))).toBeTruthy();
  });

  it('should show next button if not on last tab', () => {
    component.activeTab = component.tab.Form;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.textContent.trim()).toBe('Save and Next');
  });

  it('should show close button when on last tab', () => {
    expect(fixture.debugElement.query(By.css('button.kmd-btn-secondary')).nativeElement.textContent.trim()).toBe('Save and Next');
    component.activeTab = component.tab.Output;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button.kmd-btn-featured')).nativeElement.textContent.trim()).toBe('Save and Close');
  });
});
