import { InputType } from '../../task-data';
/* eslint-disable @typescript-eslint/naming-convention */
const UNMAPPED_INPUT_VARIABLES = Object.seal({
  inputVar: {
    output: {},
    type: InputType.Mandatory,
  },
  inputVar2: {
    output: {},
    type: InputType.Mandatory,
  },
  inputVar3: {
    output: {},
    type: InputType.Mandatory,
  },
});

const MAPPED_INPUT_VARIABLES = Object.seal({
  inputVar: {
    output: {
      name: 'a',
      value: 'a',
    },
    type: InputType.Mandatory,
  },
  inputVar2: {
    output: {
      name: 'b',
      value: 'b',
    },
    type: InputType.Mandatory,
  },
  inputVar3: {
    output: {
      name: 'c',
      value: 'c',
    },
    type: InputType.Mandatory,
    tf_backingEntityLabel: 'test label',
    tf_backingEntityType: 'manual',
    tf_backingEntityEndpoint: null,
  },
});

const PARTIAL_MAPPED_INPUT_VARIABLES = Object.seal({
  inputVar: {
    output: {},
    type: InputType.Mandatory,
  },
  inputVar2: {
    output: {
      name: 'b',
      value: 'b',
    },
    type: InputType.Mandatory,
  },
  inputVar3: {
    output: {
      name: 'c',
      value: 'c',
    },
    type: InputType.Mandatory,
    tf_backingEntityLabel: 'test label',
    tf_backingEntityType: 'manual',
    tf_backingEntityEndpoint: null,
  },
});

export { UNMAPPED_INPUT_VARIABLES, PARTIAL_MAPPED_INPUT_VARIABLES, MAPPED_INPUT_VARIABLES };
