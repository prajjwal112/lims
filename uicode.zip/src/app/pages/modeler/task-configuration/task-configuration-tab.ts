export enum TaskTab {
  Detail,
  Action,
  Input,
  Form,
  Output,
}
