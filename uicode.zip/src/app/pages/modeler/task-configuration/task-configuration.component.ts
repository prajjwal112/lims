import {
  Component,
  Input,
  Output,
  EventEmitter,
  SimpleChanges,
  OnChanges,
  SimpleChange,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  AfterViewChecked,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { cloneDeep } from 'lodash';

import { ConfigurationType } from '../configuration-type';
import { TaskTab } from './task-configuration-tab';
import { GenericFormControls } from '../shared/form-controls';

interface TaskConfigForm {
  detail: FormGroup;
  action: FormGroup;
  input: FormGroup;
  form: FormGroup;
  output: FormGroup;
}

@Component({
  selector: 'app-task-configuration',
  templateUrl: './task-configuration.component.html',
  styleUrls: ['./task-configuration.component.scss'],
})
export class TaskConfigurationComponent implements OnChanges, AfterViewChecked {
  @Input() enforceDueDates: boolean;
  @Input() configuration: ConfigurationType = {
    open: false,
    elementType: '',
    element: Object.assign({}),
    shape: {},
    id: '',
  };
  @Output() configurationChange = new EventEmitter<ConfigurationType['taskInfo']>();

  @ViewChild('resetView') private modalView: ElementRef;

  public readonly tab = TaskTab;
  public readonly numberOfTabs = Object.keys(TaskTab).length / 2;
  public configurationWindowOpen = false;
  public windowTitle = '';
  public previousTab = TaskTab.Detail;
  public activeTab = TaskTab.Detail;
  public formData: TaskConfigForm = TaskConfigurationComponent.returnEmptyForms();
  public validForm = true;

  constructor(private readonly changeDetector: ChangeDetectorRef) {}

  private static returnEmptyForms(): TaskConfigForm {
    return {
      detail: new FormGroup({}),
      action: new FormGroup({}),
      input: new FormGroup({}),
      form: new FormGroup({}),
      output: new FormGroup({}),
    };
  }

  ngOnChanges(changes: SimpleChanges): void {
    const configChanges: SimpleChange = changes.configuration;
    this.configurationWindowOpen = configChanges.currentValue.open;
    this.formData = TaskConfigurationComponent.returnEmptyForms();

    if (configChanges.currentValue.element.name) {
      this.windowTitle = `- ${configChanges.currentValue.element.name}`;
    } else {
      this.windowTitle = '';
    }
  }

  ngAfterViewChecked(): void {
    this.changeDetector.detectChanges();
  }

  public changeTab(index: TaskTab): void {
    this.previousTab = this.activeTab;
    this.activeTab = index;
    this.restoreView();
  }

  public nextStep(): void {
    if (this.checkFormIsValid()) {
      this.restoreView();
      this.saveTaskInfo();
    }
  }

  public finishTaskConfiguration(): void {
    this.saveTaskInfo();
    this.close();
  }

  public close(): void {
    this.formData = TaskConfigurationComponent.returnEmptyForms();
    this.configurationWindowOpen = false;
    this.changeTab(0);
  }

  public onUpdateForm(formName: keyof TaskConfigForm, formValues: GenericFormControls): void {
    Object.keys(formValues).forEach((field) => {
      this.formData[formName].setControl(field, cloneDeep(formValues[field]));
    });
    this.validForm = this.checkFormIsValid();
  }

  public onRemoveFromForm(formName: keyof TaskConfigForm, formKeys: string[] = []): void {
    if (formKeys.length > 0) {
      for (const keys of formKeys) {
        this.formData[formName].removeControl(keys);
      }
    } else {
      this.formData[formName] = new FormGroup({});
    }
    this.validForm = this.checkFormIsValid();
  }

  private checkFormIsValid(): boolean {
    switch (this.activeTab) {
      case TaskTab.Detail:
        return this.formData.detail.valid;
      case TaskTab.Action:
        return this.formData.action.valid;
      case TaskTab.Input:
        return this.formData.input.valid;
      case TaskTab.Form:
        return this.formData.form.valid;
      case TaskTab.Output:
        return this.formData.output.valid || this.formData.output.disabled;
      default:
        return false;
    }
  }

  private saveTaskInfo(): void {
    if (this.activeTab === TaskTab.Output && this.formData.output.disabled) {
      this.configurationChange.emit({ output: {} });
    } else {
      this.configurationChange.emit(this.getCurrentFormValue());
    }
    this.activeTab++;
  }

  private getCurrentFormValue(): ConfigurationType['taskInfo'] {
    let form: keyof TaskConfigForm;
    switch (this.activeTab) {
      case TaskTab.Detail:
        form = 'detail';
        break;
      case TaskTab.Action:
        form = 'action';
        break;
      case TaskTab.Input:
        form = 'input';
        break;
      case TaskTab.Form:
        form = 'form';
        break;
      case TaskTab.Output:
        form = 'output';
        break;
    }

    return {
      [form]: this.formData[form].value,
    };
  }

  private restoreView(): void {
    this.modalView.nativeElement.scrollIntoView();
  }
}
