import { CamundaServerVariable } from '../../shared/camunda-variable';
import type { WorkflowTaskInput } from '../../shared/task-detail';
import type { TaskActionVariable } from './task-action/task-template';

export enum InputType {
  Mandatory = 'mandatory',
  Optional = 'optional',
  Custom = 'custom',
}

export interface TaskData {
  detail?: Detail;
  action?: Action;
  input?: Input;
  form?: Form | FormInputs;
  output?: Output;
}

interface Detail {
  name: string;
  description: string;
  priority: number;
  queueTime: number;
  executionTime: number;
  overrideBusinessHours: boolean;
  date?: Date;
}

interface Action {
  key: string;
  variables: TaskActionVariable[];
  templateKey: string;
  taskName?: string;
  taskType?: 'Manual' | 'Embedded' | 'Integrated';
}

interface Input {
  [s: string]: {
    output: {
      name?: string;
      value?: string;
    };
    type: InputType;
    [CamundaServerVariable.BackingEntityLabel]?: string;
    [CamundaServerVariable.BackingEntityType]?: string;
    [CamundaServerVariable.BackingEntityEndpoint]?: string;
  };
}

interface Form {
  [CamundaServerVariable.TaskInstructions]?: string;
  [CamundaServerVariable.TaskAutoExecute]?: boolean;
  [CamundaServerVariable.Endpoint]?: string;
  [CamundaServerVariable.EndpointLabel]?: string;
}

interface FormInputs {
  [s: string]: WorkflowTaskInput;
}

interface Output {
  [CamundaServerVariable.OutputMappingPrivate]?: string;
  [CamundaServerVariable.OutputMappingPublic]?: string;
}
