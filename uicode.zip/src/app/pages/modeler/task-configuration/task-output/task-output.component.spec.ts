import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormGroup, FormArray } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { sortBy } from 'lodash';
import { CheckboxModule, AlertsModule, InputFieldsModule } from 'gds-atom-components';

import { TaskOutputComponent } from './task-output.component';
import { PARTIAL_MAPPED_INPUT_VARIABLES } from '../shared/test/input-mappings';
import { ElementType } from '../../element-type';
import { CamundaServerVariable, CamundaCustomVariable } from 'src/app/pages/shared/camunda-variable';
import { ValidationErrorsModule } from 'src/app/pages/shared/validation-errors/validation-errors.module';
import { InputType } from '../task-data';

describe('TaskOutputComponent', () => {
  let component: TaskOutputComponent;
  let fixture: ComponentFixture<TaskOutputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskOutputComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, AlertsModule, CheckboxModule, InputFieldsModule, ValidationErrorsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskOutputComponent);
    component = fixture.componentInstance;
    component.task = {
      open: true,
      id: 'Activity_1h2vhtp',
      elementType: ElementType.UserTask,
      shape: {},
      element: {
        id: 'Activity_1h2vhtp',
        $type: ElementType.UserTask,
        name: 'sd',
        documentation: [{ $type: ElementType.Documentation, text: 'desc' }],
      },
    };
    component.inputVariables = PARTIAL_MAPPED_INPUT_VARIABLES;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display headers with no template', () => {
    expect(fixture.debugElement.queryAll(By.css('h3')).length).toBe(3);
  });

  /* eslint-disable max-len */
  it('should display headers with template', () => {
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.TaskActionVariables,
              value: JSON.stringify([
                {
                  name: 'tf_outputVariablesNames',
                  type: 'JSON',
                  value:
                    '["EntityTypeName","Id","Name","Barcode","Sequence","Created","Modified","Active","LikedBy","FollowedBy","Locked","PROJECT","CREATED_BY","LOCATION","EXPERIMENT_SAMPLE_REFS","LIST_MEMBER_REFS","QUEUE_MEMBER_REFS","REV_QUEUE_EMPLOYEE","REV_NOTEBOOK_EMPLOYEE","REV_QUEUE_EMPLOYEE_SIGNATURE_QUEUE","REV_CI_ELN_WITNESSES","REV_TEMPLATENOTEBOOK_EMPLOYEE"]',
                },
              ]),
            },
          ],
        },
      ],
    };
    component.outputKeys = [];
    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('h3')).length).toBe(25);
  });

  it('should display output fields in alphabetical order', () => {
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.TaskActionVariables,
              value: JSON.stringify([
                {
                  name: 'tf_outputVariablesNames',
                  type: 'JSON',
                  value:
                    '["EntityTypeName","Id","Name","Barcode","Sequence","Created","Modified","Active","LikedBy","FollowedBy","Locked","PROJECT","CREATED_BY","LOCATION","EXPERIMENT_SAMPLE_REFS","LIST_MEMBER_REFS","QUEUE_MEMBER_REFS","REV_QUEUE_EMPLOYEE","REV_NOTEBOOK_EMPLOYEE","REV_QUEUE_EMPLOYEE_SIGNATURE_QUEUE","REV_CI_ELN_WITNESSES","REV_TEMPLATENOTEBOOK_EMPLOYEE"]',
                },
              ]),
            },
          ],
        },
      ],
    };
    component.outputKeys = [];
    component.ngOnInit();
    const sorting = sortBy(component.outputKeys, (val) => val.toLowerCase());

    expect(component.outputKeys).toEqual(sorting);
  });

  it('should not display duplicate fields with variables property and action template', () => {
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.TaskActionVariables,
              value: JSON.stringify([
                {
                  name: 'tf_outputVariablesNames',
                  type: 'JSON',
                  value: '["Id","Name","Barcode"]',
                },
              ]),
            },
          ],
        },
      ],
    };

    component.inputVariables = {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      Barcode: { output: {}, type: InputType.Mandatory },
    };
    component.outputKeys = [];
    component.ngOnInit();

    expect(component.outputKeys).toEqual(['Barcode', 'Id', 'Name']);
  });
  /* eslint-enable max-len */

  it('should not display output field if checkbox is not checked', () => {
    expect(fixture.debugElement.queryAll(By.css('input[type="text"]')).length).toBe(0);
  });

  it('should show enabled output field when checkbox is checked', () => {
    fixture.debugElement.queryAll(By.css('input[type="checkbox"]'))[0].nativeElement.dispatchEvent(
      new Event('click', {
        bubbles: true,
      })
    );
    fixture.debugElement.queryAll(By.css('input[type="checkbox"]'))[1].nativeElement.dispatchEvent(
      new Event('click', {
        bubbles: true,
      })
    );
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('input[type="text"]')).length).toBe(2);
  });

  it('should prefill fields with bpmn data', () => {
    component.outputKeys = [];
    component.trackOutputs = new FormGroup({
      outputs: new FormGroup({}),
      checkboxes: new FormArray([]),
    });
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            { $type: ElementType.Property, name: CamundaServerVariable.OutputMappingPrivate, value: '{ "inputVar": "inputVarRenamed" }' },
          ],
        },
      ],
    };
    component.ngOnInit();
    fixture.detectChanges();
    const field: HTMLInputElement = fixture.debugElement.query(By.css('input[type="text"]')).nativeElement;

    expect(field.value).toBe('inputVarRenamed');
  });
});

describe('TaskOutputComponent Validation', () => {
  let component: TaskOutputComponent;
  let fixture: ComponentFixture<TaskOutputComponent>;
  let field: HTMLInputElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskOutputComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, AlertsModule, CheckboxModule, InputFieldsModule, ValidationErrorsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskOutputComponent);
    component = fixture.componentInstance;
    component.task = {
      open: true,
      id: 'task_id_123',
      elementType: ElementType.Task,
      shape: {},
      element: {
        id: 'task_id_123',
        $type: ElementType.Task,
        name: 'Task name',
        documentation: [{ $type: ElementType.Documentation, text: 'description' }],
      },
    };
    component.inputVariables = PARTIAL_MAPPED_INPUT_VARIABLES;

    fixture.detectChanges();
    const enableField: HTMLInputElement = fixture.debugElement.query(By.css('input[type="checkbox"]')).nativeElement;
    enableField.click();
    fixture.detectChanges();
    field = fixture.debugElement.query(By.css('app-validation-errors input')).nativeElement;
  });

  it('should show error message for same name', () => {
    updateFieldValue('inputVar2');
    fixture.detectChanges();

    expect(getValidationElement().textContent.trim()).toBe('Output name already exists. Please enter a different name.');
  });

  it('should show error message for special characters in name', () => {
    updateFieldValue('inputVar!@#');
    fixture.detectChanges();

    expect(getValidationElement().textContent.trim()).toBe(
      'Invalid name. An output name can only include underscore and alphanumeric characters. Name cannot start with numbers.'
    );
  });

  it('should show error message for tf_ prefix', () => {
    updateFieldValue('tf_inputVar');
    fixture.detectChanges();

    expect(getValidationElement().textContent.trim()).toBe('Output name cannot have tf_ prefix.');
  });

  it('should show error message for empty name', () => {
    updateFieldValue('');
    fixture.detectChanges();

    expect(getValidationElement().textContent.trim()).toBe('Output name is required.');

    updateFieldValue(' ');
    fixture.detectChanges();

    expect(getValidationElement().textContent.trim()).toBe('Output name is required.');
  });

  function updateFieldValue(value: string): void {
    field.value = value;
    field.dispatchEvent(new Event('input'));
  }

  function getValidationElement(): HTMLElement {
    return fixture.debugElement.query(By.css('app-validation-errors p')).nativeElement;
  }
});
