import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray, ValidatorFn, AbstractControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, takeUntil, distinctUntilChanged } from 'rxjs/operators';
import { isEqual } from 'lodash';

import { ConfigurationType } from '../../configuration-type';
import { TaskData } from '../task-data';
import { GenericFormControls } from '../../shared/form-controls';
import { getExtensionProperty } from '../../shared/bpmnExtensionProperty';
import { CamundaServerVariable, CamundaCustomVariable } from 'src/app/pages/shared/camunda-variable';
import { CustomValidators } from 'src/app/pages/shared/custom-validators';

@Component({
  selector: 'app-task-output',
  templateUrl: './task-output.component.html',
  styleUrls: ['./task-output.component.scss'],
})
export class TaskOutputComponent implements OnInit, OnDestroy {
  @Input() task: ConfigurationType;
  @Input() inputVariables: TaskData['input'];
  @Output() updateForm = new EventEmitter<GenericFormControls>();
  @Output() removeFromForm = new EventEmitter<string[]>();

  trackOutputs = new FormGroup({
    outputs: new FormGroup({}),
    checkboxes: new FormArray([]),
  });
  outputKeys: string[] = [];

  private unsubscribe = new Subject<void>();
  private actionOutputs: string[] = [];

  private static getControlName(control: AbstractControl): string {
    const formGroup = control.parent.controls;
    return Object.keys(formGroup).find((name) => control === formGroup[name]) || '';
  }

  private static onUpdateValidation(controls: GenericFormControls): void {
    Object.keys(controls).forEach((control) => controls[control].updateValueAndValidity());
  }

  ngOnInit(): void {
    this.removeFromForm.emit();
    const actionOutputs = getExtensionProperty(CamundaCustomVariable.TaskActionVariables, this.task.element.extensionElements);
    if (actionOutputs) {
      const variablesArray = JSON.parse(actionOutputs);
      if (variablesArray && variablesArray.length > 0) {
        const actionOutputString = variablesArray.find((val) => val.name === CamundaServerVariable.TaskOutputVariable)?.value;
        this.actionOutputs = actionOutputString ? JSON.parse(actionOutputString) : [];
      }
    }
    this.loadOutputs();
    const outputGroup = this.trackOutputs.controls.outputs as FormGroup;

    outputGroup.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged((first, second) => isEqual(first, second)),
        takeUntil(this.unsubscribe)
      )
      .subscribe({
        next: () => {
          TaskOutputComponent.onUpdateValidation(outputGroup.controls);
          this.updateForm.emit(outputGroup.controls);
        },
      });

    outputGroup.statusChanges.pipe(distinctUntilChanged(), takeUntil(this.unsubscribe)).subscribe({
      next: (res: 'VALID' | 'INVALID' | 'DISABLED') => {
        TaskOutputComponent.onUpdateValidation(outputGroup.controls);
        if (res === 'VALID') {
          this.updateForm.emit(outputGroup.controls);
        } else if (res === 'DISABLED') {
          this.removeFromForm.emit();
        }
      },
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  toggleTrackOutput(field: string): void {
    const control = this.trackOutputs.get(`outputs.${field}`);
    if (control.disabled) {
      control.enable();
    } else {
      control.disable();
      control.setValue(this.outputKeys.find((output) => output === field));
    }
  }

  private loadOutputs(): void {
    const outputGroup = this.trackOutputs.controls.outputs as FormGroup;
    const checkboxArray = this.trackOutputs.controls.checkboxes as FormArray;
    const values = getExtensionProperty(CamundaServerVariable.OutputMappingPrivate, this.task.element.extensionElements);
    const outputs = Object.keys(this.inputVariables).filter((input) => !this.actionOutputs.includes(input));
    if (this.actionOutputs.length > 0) {
      outputs.push(...this.actionOutputs);
    }

    outputs
      .sort((a, b) => (a.toLowerCase() > b.toLowerCase() ? 1 : -1))
      .forEach((output, index) => {
        const control = new FormControl({ value: output, disabled: true });

        checkboxArray.push(new FormControl(false));
        this.outputKeys.push(output);
        if (values && Object.keys(JSON.parse(values)).includes(output)) {
          control.enable();
          const value: { [s: string]: string } = JSON.parse(values);
          Object.keys(value).forEach((val) => {
            if (val === output) {
              checkboxArray.at(index).setValue(true);
              control.setValue(value[val]);
            }
          });
        }
        // setting here due to enabling control above runs validators before attaching to FormGroup
        control.setValidators([
          Validators.required,
          Validators.pattern(CustomValidators.disallowSpecialCharactersPattern),
          CustomValidators.notBlank,
          CustomValidators.noTFPrefix,
          this.uniqueNameValidator(),
        ]);
        outputGroup.addControl(output, control);
      });

    if (values) {
      this.updateForm.emit(outputGroup.controls);
    }
  }

  /**
   * Checks if control value exists in current form.
   *
   * Use `unique` key to check for errors.
   * @returns ValidatorFn
   */
  private uniqueNameValidator(): ValidatorFn {
    return (control: AbstractControl): { unique: true } | null => {
      const name = TaskOutputComponent.getControlName(control);
      const valueExists = this.valueExistsInForm(control.parent, name, control.value);
      const isValid = control.value.toLowerCase() === name.toLowerCase() || !valueExists;

      return isValid ? null : { unique: true };
    };
  }

  private valueExistsInForm(form: FormGroup | FormArray, name: string, value: string): boolean {
    return Object.keys(form.controls)
      .filter((v) => v !== name)
      .map((v: string) => form.controls[v].value.toLowerCase())
      .includes(value.toLowerCase());
  }
}
