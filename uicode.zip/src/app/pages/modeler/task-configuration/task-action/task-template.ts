export interface TaskTemplate {
  name: string;
  sourceService: string;
  version?: number;
  type: string;
  description: string;
  createdBy: string;
  variables: TaskActionVariable[];
}

export interface TaskTemplateData extends TaskTemplate {
  key: string;
  system: string;
}

export interface TaskActionVariable {
  name: string;
  value: string;
  type: string;
}
