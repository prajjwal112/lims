/* eslint-disable max-len */
import type { TaskTemplate } from '../task-template';

export const TASK_TEMPLATE_DATA: TaskTemplate[] = [
  {
    name: 'Blank Manual Task',
    type: 'MANUAL',
    sourceService: null,
    version: 0,
    createdBy: null,
    description: 'Build a form or instructions',
    variables: [],
  },
  {
    name: 'Blank Embedded Task',
    type: 'EMBEDDED',
    createdBy: null,
    sourceService: null,
    version: 0,
    description: 'Build a task with an embedded interface',
    variables: [
      {
        name: 'tf_endpoint',
        value: '',
        type: 'STRING',
      },
    ],
  },
  {
    name: 'GET_MOCK_TEMPLATE',
    type: 'INTEGRATED',
    sourceService: 'corelims',
    createdBy: 'Thermo Fisher Scientific',
    version: 10,
    description: '',
    variables: [
      {
        name: 'tf_async',
        value: 'false',
        type: 'boolean',
      },
      {
        name: 'tf_autoComplete',
        value: 'false',
        type: 'boolean',
      },
      {
        name: 'tf_httpType',
        value: 'GET',
        type: 'string',
      },
      {
        name: 'tf_timeout',
        value: '1000',
        type: 'integer',
      },
      {
        name: 'tf_urlTemplate',
        value: 'https://mock-corelims.cloud',
        type: 'string',
      },
      {
        name: 'tf_username',
        value: '',
        type: 'string',
      },
      {
        name: 'tf_headers',
        value: '{"odata.metadata":"full","Accept":"application/json"}',
        type: 'json',
      },
      {
        name: 'tf_dataTypes',
        value:
          '{"Barcode":{"name":"Barcode","type":"STRING","enums":[],"collection":"false","decimals":""},"Name":{"name":"Name","type":"STRING","enums":[],"collection":"false","decimals":""},"Id":{"name":"Id","type":"INTEGER","enums":[],"collection":"false","decimals":""},"CONTAINER_FORMAT":{"name":"CONTAINER_FORMAT","type":"STRING","enums":[],"collection":"false","decimals":""},"LIBRARY_PREP_TYPE":{"name":"LIBRARY_PREP_TYPE","type":"STRING","enums":[],"collection":"false","decimals":""},"APPS_WORKFLOW_TOBEREVIEWED":{"name":"APPS_WORKFLOW_TOBEREVIEWED","type":"BOOLEAN","enums":[],"collection":"false","decimals":""},"APPS_NGS_WORKFLOWSTEP":{"name":"APPS_NGS_WORKFLOWSTEP","type":"STRING","enums":[],"collection":"false","decimals":""},"EXPERIMENT_FAILED":{"name":"EXPERIMENT_FAILED","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""},"WORKFLOW ASSOCIATION":{"name":"WORKFLOW ASSOCIATION","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""}}',
        type: 'json',
      },
      {
        name: 'tf_requestTemplate',
        value: '{}',
        type: 'json',
      },
      {
        name: 'tf_taskInput',
        value: '{"basics":[{"name":"Barcode","displayName":"Barcode","mandatory":true,"sequence":0,"type":"text"}]}',
        type: 'json',
      },
      {
        name: 'tf_outputVariablesNames',
        value:
          '["Id","Name","Barcode","CONTAINER_FORMAT","LIBRARY_PREP_TYPE","APPS_WORKFLOW_TOBEREVIEWED","APPS_NGS_WORKFLOWSTEP","EXPERIMENT_FAILED","WORKFLOW ASSOCIATION"]',
        type: 'json',
      },
      {
        name: 'tf_successBody',
        value:
          '{"Id" : {Id},"Name" : "{Name}","Barcode" : "{Barcode}", "CONTAINER_FORMAT" : "{CONTAINER_FORMAT}", "LIBRARY_PREP_TYPE" : "{LIBRARY_PREP_TYPE}", "APPS_WORKFLOW_TOBEREVIEWED" : {APPS_WORKFLOW_TOBEREVIEWED}, "APPS_NGS_WORKFLOWSTEP" : "{APPS_NGS_WORKFLOWSTEP}", "EXPERIMENT_FAILED@odata.bind" : {"Barcode": "{EXPERIMENT_FAILED}"}, "WORKFLOW ASSOCIATION@odata.bind" : {"Barcode": "{WORKFLOW ASSOCIATION}"}}',
        type: 'json',
      },
    ],
  },
  {
    name: 'POST_MOCK_TEMPLATE',
    type: 'INTEGRATED',
    sourceService: 'corelims',
    createdBy: 'Thermo Fisher Scientific',
    version: 10,
    description: '',
    variables: [
      {
        name: 'tf_async',
        value: 'false',
        type: 'boolean',
      },
      {
        name: 'tf_autoComplete',
        value: 'false',
        type: 'boolean',
      },
      {
        name: 'tf_httpType',
        value: 'POST',
        type: 'string',
      },
      {
        name: 'tf_timeout',
        value: '1000',
        type: 'integer',
      },
      {
        name: 'tf_urlTemplate',
        value: 'https://mock-corelims.cloud',
        type: 'string',
      },
      {
        name: 'tf_username',
        value: '',
        type: 'string',
      },
      {
        name: 'tf_headers',
        value: '{"odata.metadata":"full","Accept":"application/json"}',
        type: 'json',
      },
      {
        name: 'tf_dataTypes',
        value:
          '{"Barcode":{"name":"Barcode","type":"STRING","enums":[],"collection":"false","decimals":""},"Name":{"name":"Name","type":"STRING","enums":[],"collection":"false","decimals":""},"Id":{"name":"Id","type":"INTEGER","enums":[],"collection":"false","decimals":""},"CONTAINER_FORMAT":{"name":"CONTAINER_FORMAT","type":"STRING","enums":[],"collection":"false","decimals":""},"LIBRARY_PREP_TYPE":{"name":"LIBRARY_PREP_TYPE","type":"STRING","enums":[],"collection":"false","decimals":""},"APPS_WORKFLOW_TOBEREVIEWED":{"name":"APPS_WORKFLOW_TOBEREVIEWED","type":"BOOLEAN","enums":[],"collection":"false","decimals":""},"APPS_NGS_WORKFLOWSTEP":{"name":"APPS_NGS_WORKFLOWSTEP","type":"STRING","enums":[],"collection":"false","decimals":""},"EXPERIMENT_FAILED":{"name":"EXPERIMENT_FAILED","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""},"WORKFLOW ASSOCIATION":{"name":"WORKFLOW ASSOCIATION","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""}}',
        type: 'json',
      },
      {
        name: 'tf_requestTemplate',
        value:
          '{"CONTAINER_FORMAT":"{{CONTAINER_FORMAT}}","LIBRARY_PREP_TYPE":"{{LIBRARY_PREP_TYPE}}","APPS_WORKFLOW_TOBEREVIEWED":"{{APPS_WORKFLOW_TOBEREVIEWED}}","APPS_NGS_WORKFLOWSTEP":"{{APPS_NGS_WORKFLOWSTEP}}","EXPERIMENT_FAILED@odata.bind":"/EXPERIMENT_LIMITED(\'{{EXPERIMENT_FAILED}}\')","WORKFLOW ASSOCIATION@odata.bind":"/WORKFLOW_LIMITED(\'{{WORKFLOW ASSOCIATION}}\')"}',
        type: 'json',
      },
      {
        name: 'tf_taskInput',
        value:
          '{"basics":[{"name":"CONTAINER_FORMAT","mandatory":true,"displayName":"CONTAINER_FORMAT","defaultValue":"96 Well","sequence":100,"type":"text"},{"name":"APPS_WORKFLOW_TOBEREVIEWED","mandatory":false,"displayName":"APPS_WORKFLOW_TOBEREVIEWED","defaultValue":"0","sequence":10,"type":"boolean"},{"name":"EXPERIMENT_FAILED","mandatory":false,"displayName":"EXPERIMENT_FAILED","defaultValue":"","sequence":2,"type":"text"},{"name":"WORKFLOW ASSOCIATION","mandatory":false,"displayName":"WORKFLOW ASSOCIATION","defaultValue":"","sequence":1,"type":"text"}],"selects":[{"name":"LIBRARY_PREP_TYPE","mandatory":false,"displayName":"LIBRARY_PREP_TYPE","defaultValue":"","sequence":2,"type":"text","multiple":false,"items":["AmpliSeq","Amplicon","DNA","RNA","Targeted Gene Capture"]},{"name":"APPS_NGS_WORKFLOWSTEP","mandatory":true,"displayName":"APPS_NGS_WORKFLOWSTEP","defaultValue":"Initial QC","sequence":1,"type":"text","multiple":false,"items":["AmpliSeq Library Prep","Amplicon Library Prep","DNA Library Prep","DNA Normalization","Extraction","Initial QC","Library Pooling","Library QC","Post Capture QC","Post Library Prep Normalization","Pre Capture Normalization","Pre Capture Pooling","Pre Library Prep Normalization","Processed","RNA Library Prep","RNA Normalization","RT PCR","Targeted Capture"]}]}',
        type: 'json',
      },
      {
        name: 'tf_outputVariablesNames',
        value: '["Id","Name","Barcode"]',
        type: 'json',
      },
      {
        name: 'tf_successBody',
        value:
          '{"Id" : {Id},"Name" : "{Name}","Barcode" : "{Barcode}", "CONTAINER_FORMAT" : "{CONTAINER_FORMAT}", "LIBRARY_PREP_TYPE" : "{LIBRARY_PREP_TYPE}", "APPS_WORKFLOW_TOBEREVIEWED" : {APPS_WORKFLOW_TOBEREVIEWED}, "APPS_NGS_WORKFLOWSTEP" : "{APPS_NGS_WORKFLOWSTEP}", "EXPERIMENT_FAILED@odata.bind" : {"Barcode": "{EXPERIMENT_FAILED}"}, "WORKFLOW ASSOCIATION@odata.bind" : {"Barcode": "{WORKFLOW ASSOCIATION}"}}',
        type: 'json',
      },
    ],
  },
  {
    name: 'PUT_MOCK_TEMPLATE',
    type: 'INTEGRATED',
    sourceService: 'corelims',
    createdBy: 'Thermo Fisher Scientific',
    version: 10,
    description: '',
    variables: [
      {
        name: 'tf_async',
        value: 'false',
        type: 'boolean',
      },
      {
        name: 'tf_autoComplete',
        value: 'false',
        type: 'boolean',
      },
      {
        name: 'tf_httpType',
        value: 'POST',
        type: 'string',
      },
      {
        name: 'tf_timeout',
        value: '1000',
        type: 'integer',
      },
      {
        name: 'tf_urlTemplate',
        value: 'https://mock-corelims.cloud',
        type: 'string',
      },
      {
        name: 'tf_username',
        value: '',
        type: 'string',
      },
      {
        name: 'tf_headers',
        value: '{"odata.metadata":"full","Accept":"application/json"}',
        type: 'json',
      },
      {
        name: 'tf_dataTypes',
        value:
          '{"Barcode":{"name":"Barcode","type":"STRING","enums":[],"collection":"false","decimals":""},"Name":{"name":"Name","type":"STRING","enums":[],"collection":"false","decimals":""},"Id":{"name":"Id","type":"INTEGER","enums":[],"collection":"false","decimals":""},"CONTAINER_FORMAT":{"name":"CONTAINER_FORMAT","type":"STRING","enums":[],"collection":"false","decimals":""},"LIBRARY_PREP_TYPE":{"name":"LIBRARY_PREP_TYPE","type":"STRING","enums":[],"collection":"false","decimals":""},"APPS_WORKFLOW_TOBEREVIEWED":{"name":"APPS_WORKFLOW_TOBEREVIEWED","type":"BOOLEAN","enums":[],"collection":"false","decimals":""},"APPS_NGS_WORKFLOWSTEP":{"name":"APPS_NGS_WORKFLOWSTEP","type":"STRING","enums":[],"collection":"false","decimals":""},"EXPERIMENT_FAILED":{"name":"EXPERIMENT_FAILED","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""},"WORKFLOW ASSOCIATION":{"name":"WORKFLOW ASSOCIATION","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""}}',
        type: 'json',
      },
      {
        name: 'tf_requestTemplate',
        value:
          '{"CONTAINER_FORMAT":"{{CONTAINER_FORMAT}}","LIBRARY_PREP_TYPE":"{{LIBRARY_PREP_TYPE}}","APPS_WORKFLOW_TOBEREVIEWED":"{{APPS_WORKFLOW_TOBEREVIEWED}}","APPS_NGS_WORKFLOWSTEP":"{{APPS_NGS_WORKFLOWSTEP}}","EXPERIMENT_FAILED@odata.bind":"/EXPERIMENT_LIMITED(\'{{EXPERIMENT_FAILED}}\')","WORKFLOW ASSOCIATION@odata.bind":"/WORKFLOW_LIMITED(\'{{WORKFLOW ASSOCIATION}}\')"}',
        type: 'json',
      },
      {
        name: 'tf_taskInput',
        value:
          '{"basics":[{"name":"CONTAINER_FORMAT","mandatory":true,"displayName":"CONTAINER_FORMAT","defaultValue":"96 Well","sequence":100,"type":"text"},{"name":"APPS_WORKFLOW_TOBEREVIEWED","mandatory":false,"displayName":"APPS_WORKFLOW_TOBEREVIEWED","defaultValue":"0","sequence":10,"type":"boolean"},{"name":"EXPERIMENT_FAILED","mandatory":false,"displayName":"EXPERIMENT_FAILED","defaultValue":"","sequence":2,"type":"text"},{"name":"WORKFLOW ASSOCIATION","mandatory":false,"displayName":"WORKFLOW ASSOCIATION","defaultValue":"","sequence":1,"type":"text"}],"selects":[{"name":"LIBRARY_PREP_TYPE","mandatory":false,"displayName":"LIBRARY_PREP_TYPE","defaultValue":"","sequence":2,"type":"text","multiple":false,"items":["AmpliSeq","Amplicon","DNA","RNA","Targeted Gene Capture"]},{"name":"APPS_NGS_WORKFLOWSTEP","mandatory":true,"displayName":"APPS_NGS_WORKFLOWSTEP","defaultValue":"Initial QC","sequence":1,"type":"text","multiple":false,"items":["AmpliSeq Library Prep","Amplicon Library Prep","DNA Library Prep","DNA Normalization","Extraction","Initial QC","Library Pooling","Library QC","Post Capture QC","Post Library Prep Normalization","Pre Capture Normalization","Pre Capture Pooling","Pre Library Prep Normalization","Processed","RNA Library Prep","RNA Normalization","RT PCR","Targeted Capture"]}]}',
        type: 'json',
      },
      {
        name: 'tf_outputVariablesNames',
        value: '[]',
        type: 'json',
      },
      {
        name: 'tf_successBody',
        value: '',
        type: 'json',
      },
    ],
  },
];
