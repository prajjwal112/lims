import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

import { StoreService, Action, ActionType } from 'src/app/store.service';
import { environment } from 'src/environments/environment';
import type { TaskTemplate } from './task-template';

const URL = `${environment.endpoint}/task-templates`;

@Injectable({
  providedIn: 'root',
})
export class TaskActionService {
  #data: TaskTemplate[];
  constructor(private http: HttpClient, private store: StoreService) {
    this.store.select('taskActionData').subscribe({
      next: (data) => {
        if (data) {
          this.#data = data;
        }
      },
    });
  }

  getTaskTemplate(): Observable<TaskTemplate[]> {
    return this.http.get<TaskTemplate[]>(URL).pipe(
      tap({
        next: (response: TaskTemplate[]) => {
          this.store.dispatch(new Action(ActionType.Update, { taskActionData: response }));
        },
      })
    );
  }
}
