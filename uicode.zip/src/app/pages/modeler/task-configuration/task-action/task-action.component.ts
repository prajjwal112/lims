import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TitleCasePipe } from '@angular/common';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { take } from 'rxjs/operators';

import { ColumnType } from 'src/app/pages/shared/grid/column-type';
import { FilterType } from 'src/app/pages/shared/grid/filter/shared/filter-type';
import { FilterListField } from 'src/app/pages/shared/grid/filter/shared/filter-field';
import { TaskActionService } from './task-action.service';
import { getExtensionProperty } from '../../shared/bpmnExtensionProperty';
import { SearchTextService } from 'src/app/pages/shared/search-text.service';
import type { Column } from 'src/app/pages/shared/grid/column';
import type { TaskTemplate, TaskTemplateData } from './task-template';
import type { ConfigurationType } from '../../configuration-type';

enum TaskTemplateFields {
  Key = 'key',
  Name = 'name',
  Type = 'type',
  SourceService = 'sourceService',
  Description = 'description',
}

interface Filter {
  [TaskTemplateFields.Key]?: string;
  [TaskTemplateFields.Name]?: string;
  [TaskTemplateFields.Type]?: string;
  [TaskTemplateFields.SourceService]?: string;
}

interface ActionForm {
  key?: AbstractControl;
  variables?: AbstractControl;
  templateKey?: AbstractControl;
  taskType?: AbstractControl;
  inputVariablesNames?: AbstractControl;
  createdById?: AbstractControl;
  description?: AbstractControl;
  taskName?: AbstractControl;
  outputVariablesNames?: AbstractControl;
}

const GRID_KEY = 'key';
const FORM_VALIDATORS = [Validators.required];
const BLANK_TEMPLATE_VALUES = ['Blank Embedded Task', 'Blank Manual Task'];

@Component({
  selector: 'app-task-action',
  templateUrl: './task-action.component.html',
  styleUrls: ['./task-action.component.scss'],
  providers: [TitleCasePipe],
})
export class TaskActionComponent implements OnInit {
  @Input() task: ConfigurationType;
  @Input() form: FormGroup;
  @Output() updateForm = new EventEmitter<ActionForm>();
  @Output() removeFromForm = new EventEmitter<void>();

  public columns: Column[] = [
    {
      type: ColumnType.String,
      field: TaskTemplateFields.Name,
      title: 'Name',
      width: 300,
    },
    {
      type: ColumnType.String,
      field: TaskTemplateFields.SourceService,
      title: 'System',
      width: 200,
      filterable: true,
      filter: {
        type: FilterType.List,
        field: new FilterListField(TaskTemplateFields.SourceService),
        keyField: 'name',
        displayField: 'name',
        values: [],
      },
    },
    {
      type: ColumnType.String,
      field: TaskTemplateFields.Type,
      title: 'Type',
      width: 100,
      filterable: true,
      filter: {
        type: FilterType.List,
        field: new FilterListField(TaskTemplateFields.Type),
        keyField: 'name',
        displayField: 'name',
        values: [],
      },
    },
    {
      type: ColumnType.String,
      field: TaskTemplateFields.Description,
      title: 'Description',
      width: 450,
    },
  ];
  public tableData: TaskTemplateData[] = [];
  public selectedValue: string[] = [];
  public hasSavedData = false;
  #searchText = '';

  #filters: Filter = {
    [GRID_KEY]: '',
  };
  #cacheData: TaskTemplateData[] = [];
  #isBlankTab = false;

  constructor(
    private readonly taskActionService: TaskActionService,
    private readonly titleCasePipe: TitleCasePipe,
    private readonly searchTextService: SearchTextService
  ) {}

  private static sortData(a: TaskTemplateData, b: TaskTemplateData): number {
    const firstTemplateKey = a[TaskTemplateFields.SourceService]?.toLowerCase();
    const secondTemplateKey = b[TaskTemplateFields.SourceService]?.toLowerCase();
    const firstType = a[TaskTemplateFields.Type]?.toLowerCase();
    const secondType = b[TaskTemplateFields.Type]?.toLowerCase();
    const firstName = a[TaskTemplateFields.Name]?.toLowerCase();
    const secondName = b[TaskTemplateFields.Name]?.toLowerCase();
    if (firstTemplateKey === secondTemplateKey) {
      if (firstType === secondType) {
        return firstName < secondName ? -1 : firstName > secondName ? 1 : 0;
      } else {
        return firstType < secondType ? -1 : 1;
      }
    }
    return firstTemplateKey < secondTemplateKey ? -1 : 1;
  }

  ngOnInit(): void {
    const keyControl = new FormControl(null, FORM_VALIDATORS);
    const savedKeyValue = getExtensionProperty(GRID_KEY, this.task.element.extensionElements);

    if (savedKeyValue) {
      this.hasSavedData = true;
      keyControl.setValue(savedKeyValue);
    }

    this.fetchTaskTemplates(keyControl);
  }

  filterBlankData(): void {
    this.#isBlankTab = true;
    this.filterData({ key: '' });
  }

  filterAllData(): void {
    this.#isBlankTab = false;
    this.filterData({ key: '' });
  }

  filterData(data: Filter): void {
    this.removeEmptyFilterKeys(data);
    this.searchTextService.setText(this.#searchText);
    delete this.#filters[TaskTemplateFields.Name];
    const filter: Filter = Object.assign({}, this.#filters, data);
    this.tableData = this.getFilteredData(filter);
  }

  onFilterSelectChange(filter: string): void {
    this.#searchText = filter;
    const data: Filter = { [TaskTemplateFields.Name]: filter.toLowerCase() };
    if (filter) {
      this.tableData = this.getFilteredData(Object.assign({}, this.#filters, data));
    } else {
      delete this.#filters[TaskTemplateFields.Name];
      this.tableData = this.getFilteredData({ [TaskTemplateFields.Key]: '' });
    }
  }

  onRowSelect(rows: string[]): void {
    const row = this.#cacheData.find((item) => item[GRID_KEY] === rows[0]);

    // pass variables object to save
    const clonedForm = new FormGroup({
      [GRID_KEY]: this.form.controls[GRID_KEY],
    });
    this.removeFromForm.emit();
    if (row) {
      this.selectedValue = [row[GRID_KEY]];
      clonedForm.controls[GRID_KEY].setValue(row[GRID_KEY]);
      Object.keys(row)
        .filter((key) => key !== GRID_KEY)
        .forEach((rowItem) => {
          clonedForm.setControl(rowItem, new FormControl(row[rowItem]));
        });
    } else {
      clonedForm.addControl('validator', new FormControl(false, Validators.requiredTrue));
      this.selectedValue = [];
    }
    this.updateForm.emit(clonedForm.controls);
  }

  private removeEmptyFilterKeys(data: Filter): void {
    if (Object.prototype.hasOwnProperty.call(data, TaskTemplateFields.Key)) {
      if (!Object.prototype.hasOwnProperty.call(data, TaskTemplateFields.Type) && !this.#filters[TaskTemplateFields.Type]) {
        delete this.#filters[TaskTemplateFields.Type];
      }
      if (
        !Object.prototype.hasOwnProperty.call(data, TaskTemplateFields.SourceService) &&
        !this.#filters[TaskTemplateFields.SourceService]
      ) {
        delete this.#filters[TaskTemplateFields.Type];
      }
    } else {
      if (!Object.prototype.hasOwnProperty.call(data, TaskTemplateFields.Type)) {
        delete this.#filters[TaskTemplateFields.Type];
      }
      if (!Object.prototype.hasOwnProperty.call(data, TaskTemplateFields.SourceService)) {
        delete this.#filters[TaskTemplateFields.SourceService];
      }
    }
  }

  private fetchTaskTemplates(keyControl: FormControl): void {
    this.taskActionService
      .getTaskTemplate()
      .pipe(take(1))
      .subscribe({
        next: (data) => {
          this.#cacheData = this.transformData(data).sort(TaskActionComponent.sortData.bind(this));
          this.tableData = this.getFilteredData(this.#filters);
        },
      })
      .add(() => {
        this.updateForm.emit({
          [GRID_KEY]: keyControl,
        });
        this.onRowSelect([keyControl.value]);
      });
  }

  private transformData(taskTemplates: TaskTemplate[]): TaskTemplateData[] {
    const templates = taskTemplates.map((item: TaskTemplate) => {
      const system = item[TaskTemplateFields.SourceService] ?? '-';
      const key = `${item[TaskTemplateFields.Name]}/${system}`;

      if (item[TaskTemplateFields.Type]) {
        item[TaskTemplateFields.Type] = this.titleCasePipe.transform(item[TaskTemplateFields.Type]);
      }

      this.columns = this.columns.map((col) => {
        if ((item[col.field] || system !== '-') && col.filterable) {
          if (col.field === TaskTemplateFields.SourceService) {
            col.filter.values.push(system);
          } else if (col.field !== TaskTemplateFields.SourceService) {
            col.filter.values.push(item[col.field]);
          }
          col.filter.values = [...new Set(col.filter.values)];
        }
        return col;
      });

      return {
        ...item,
        key,
        system,
      };
    });

    this.columns = this.columns.map((col) => {
      if (col.filterable) {
        col.filter.values = col.filter.values.map((name) => ({
          name,
        }));
      }
      return col;
    });

    return templates;
  }

  private getFilteredData(filters: Filter): TaskTemplateData[] {
    this.#filters = Object.assign({}, filters);
    let data: TaskTemplateData[] = this.#cacheData.slice();

    Object.keys(this.#filters).forEach((filter) => {
      data = data.filter((item: TaskTemplateData) => {
        return this.isFilterBlankTaskTemplateOrGetAllTaskTemplates(item) && this.hasKeyOrFilterIsBlank(filter, item);
      });
    });
    return data.slice();
  }

  private isFilterBlankTaskTemplateOrGetAllTaskTemplates(item: TaskTemplateData): boolean {
    return (this.#isBlankTab && BLANK_TEMPLATE_VALUES.includes(item[TaskTemplateFields.Name])) || !this.#isBlankTab;
  }

  private hasKeyOrFilterIsBlank(filter: string, item: TaskTemplateData): boolean {
    return (filter === GRID_KEY && this.#filters[filter] === '') || item[filter]?.toLowerCase() === this.#filters[filter].toLowerCase();
  }
}
