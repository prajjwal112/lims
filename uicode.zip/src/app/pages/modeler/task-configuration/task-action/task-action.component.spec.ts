import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormGroup } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { AlertsModule } from 'gds-atom-components';

import { TaskActionComponent } from './task-action.component';
import { GridModule } from 'src/app/pages/shared/grid/grid.module';
import { DropDownAutoCompleteModule } from 'src/app/pages/shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { ElementType } from '../../element-type';
import { TaskActionService } from './task-action.service';
import { TASK_TEMPLATE_DATA } from './test/task-template';
import type { TaskTemplateData } from './task-template';

let TRANSFORMED_TASK_TEMPLATE_DATA: TaskTemplateData[] = [];

describe('TaskActionComponent', () => {
  let component: TaskActionComponent;
  let fixture: ComponentFixture<TaskActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskActionComponent],
      providers: [TaskActionService],
      imports: [HttpClientTestingModule, BrowserAnimationsModule, DropDownAutoCompleteModule, GridModule, AlertsModule, ButtonsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskActionComponent);
    spyOn(TestBed.inject(TaskActionService), 'getTaskTemplate').and.returnValue(of(TASK_TEMPLATE_DATA));
    component = fixture.componentInstance;
    TRANSFORMED_TASK_TEMPLATE_DATA = component['transformData'](TASK_TEMPLATE_DATA).sort(TaskActionComponent['sortData']);
    component.updateForm.subscribe({
      next: (controls) => {
        Object.keys(controls).forEach((field) => {
          component.form.setControl(field, controls[field]);
        });
      },
    });
    component.removeFromForm.subscribe({
      next: () => {
        component.form = new FormGroup({});
      },
    });
    component.task = {
      open: true,
      element: {
        $type: ElementType.Task,
      },
      elementType: ElementType.Task,
      shape: {},
      id: 'test',
    };
    component.form = new FormGroup({});
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display table', () => {
    expect(fixture.debugElement.query(By.css('app-grid'))).toBeTruthy();
  });

  it('should select only one row in table', () => {
    expect(component.selectedValue.length).toBe(0);
    const checkboxes = fixture.debugElement.queryAll(By.css('.k-checkbox'));
    checkboxes[0].nativeElement.click();

    expect(component.selectedValue.length).toBe(1);
    checkboxes[1].nativeElement.click();

    expect(component.selectedValue.length).toBe(1);
  });

  it('should display all blank and non blank actions', () => {
    expect(component.tableData.length).toBe(TRANSFORMED_TASK_TEMPLATE_DATA.length);
    component.filterAllData();

    expect(component.tableData.length).toBe(5);
    expect(component.tableData).toEqual(TRANSFORMED_TASK_TEMPLATE_DATA);
  });

  it('should display blank actions', () => {
    expect(component.tableData.length).toBe(TRANSFORMED_TASK_TEMPLATE_DATA.length);
    component.filterBlankData();

    expect(component.tableData.length).toBe(2);
    expect(component.tableData).toEqual(
      TRANSFORMED_TASK_TEMPLATE_DATA.filter((item) => ['Blank Manual Task/-', 'Blank Embedded Task/-'].includes(item.key))
    );
  });

  it('should filter table based on System column', () => {
    expect(component.tableData.length).toBe(TRANSFORMED_TASK_TEMPLATE_DATA.length);
    component.filterData({ sourceService: 'corelims' });

    expect(component.tableData.length).toBe(3);
    expect(component.tableData).toEqual(TRANSFORMED_TASK_TEMPLATE_DATA.filter((item) => item.sourceService === 'corelims'));
  });

  it('should filter table based on Type column', () => {
    expect(component.tableData.length).toBe(TRANSFORMED_TASK_TEMPLATE_DATA.length);
    component.filterData({ type: 'Integrated' });

    expect(component.tableData.length).toBe(3);
    expect(component.tableData).toEqual(TRANSFORMED_TASK_TEMPLATE_DATA.filter((item) => item.type === 'Integrated'));
  });

  it('should filter table based column and user input', () => {
    expect(component.tableData.length).toBe(TRANSFORMED_TASK_TEMPLATE_DATA.length);
    component.filterData({ type: 'Integrated', name: 'GET_MOCK_TEMPLATE', key: '' });

    expect(component.tableData.length).toBe(1);
    expect(component.tableData).toEqual(
      TRANSFORMED_TASK_TEMPLATE_DATA.filter((item) => item.type === 'Integrated' && item.name === 'GET_MOCK_TEMPLATE')
    );
  });

  it('should filter table based on user input', () => {
    expect(component.tableData.length).toBe(TRANSFORMED_TASK_TEMPLATE_DATA.length);
    component.onFilterSelectChange('GET_MOCK_TEMPLATE');

    expect(component.tableData.length).toBe(1);
    expect(component.tableData).toEqual(TRANSFORMED_TASK_TEMPLATE_DATA.filter((item) => item.name === 'GET_MOCK_TEMPLATE'));
  });

  it('should fail validation if no rows are selected', () => {
    expect(fixture.debugElement.queryAll(By.css('.k-checkbox:checked')).length).toBe(0);
    expect(component.form.valid).toBe(false);
  });

  it('should validate form on row select', (done: DoneFn) => {
    component.updateForm.subscribe({
      next: () => {
        expect(component.form.valid).toBe(true);
        done();
      },
    });

    expect(component.form.valid).toBe(false);
    component.onRowSelect(['GET_MOCK_TEMPLATE/corelims']);
  });

  it('should save data based on selection', (done: DoneFn) => {
    component.updateForm.subscribe({
      next: () => {
        expect(component.form.value).toEqual({
          /* eslint-disable max-len */
          key: 'GET_MOCK_TEMPLATE/corelims',
          name: 'GET_MOCK_TEMPLATE',
          sourceService: 'corelims',
          system: 'corelims',
          version: 10,
          type: 'Integrated',
          createdBy: 'Thermo Fisher Scientific',
          description: '',
          variables: [
            {
              name: 'tf_async',
              value: 'false',
              type: 'boolean',
            },
            {
              name: 'tf_autoComplete',
              value: 'false',
              type: 'boolean',
            },
            {
              name: 'tf_httpType',
              value: 'GET',
              type: 'string',
            },
            {
              name: 'tf_timeout',
              value: '1000',
              type: 'integer',
            },
            {
              name: 'tf_urlTemplate',
              value: 'https://mock-corelims.cloud',
              type: 'string',
            },
            {
              name: 'tf_username',
              value: '',
              type: 'string',
            },
            {
              name: 'tf_headers',
              value: '{"odata.metadata":"full","Accept":"application/json"}',
              type: 'json',
            },
            {
              name: 'tf_dataTypes',
              value:
                '{"Barcode":{"name":"Barcode","type":"STRING","enums":[],"collection":"false","decimals":""},"Name":{"name":"Name","type":"STRING","enums":[],"collection":"false","decimals":""},"Id":{"name":"Id","type":"INTEGER","enums":[],"collection":"false","decimals":""},"CONTAINER_FORMAT":{"name":"CONTAINER_FORMAT","type":"STRING","enums":[],"collection":"false","decimals":""},"LIBRARY_PREP_TYPE":{"name":"LIBRARY_PREP_TYPE","type":"STRING","enums":[],"collection":"false","decimals":""},"APPS_WORKFLOW_TOBEREVIEWED":{"name":"APPS_WORKFLOW_TOBEREVIEWED","type":"BOOLEAN","enums":[],"collection":"false","decimals":""},"APPS_NGS_WORKFLOWSTEP":{"name":"APPS_NGS_WORKFLOWSTEP","type":"STRING","enums":[],"collection":"false","decimals":""},"EXPERIMENT_FAILED":{"name":"EXPERIMENT_FAILED","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""},"WORKFLOW ASSOCIATION":{"name":"WORKFLOW ASSOCIATION","type":"TYPE_ASSOCIATIONS","enums":[],"collection":"false","decimals":""}}',
              type: 'json',
            },
            {
              name: 'tf_requestTemplate',
              value: '{}',
              type: 'json',
            },
            {
              name: 'tf_taskInput',
              value: '{"basics":[{"name":"Barcode","displayName":"Barcode","mandatory":true,"sequence":0,"type":"text"}]}',
              type: 'json',
            },
            {
              name: 'tf_outputVariablesNames',
              value:
                '["Id","Name","Barcode","CONTAINER_FORMAT","LIBRARY_PREP_TYPE","APPS_WORKFLOW_TOBEREVIEWED","APPS_NGS_WORKFLOWSTEP","EXPERIMENT_FAILED","WORKFLOW ASSOCIATION"]',
              type: 'json',
            },
            {
              name: 'tf_successBody',
              value:
                '{"Id" : {Id},"Name" : "{Name}","Barcode" : "{Barcode}", "CONTAINER_FORMAT" : "{CONTAINER_FORMAT}", "LIBRARY_PREP_TYPE" : "{LIBRARY_PREP_TYPE}", "APPS_WORKFLOW_TOBEREVIEWED" : {APPS_WORKFLOW_TOBEREVIEWED}, "APPS_NGS_WORKFLOWSTEP" : "{APPS_NGS_WORKFLOWSTEP}", "EXPERIMENT_FAILED@odata.bind" : {"Barcode": "{EXPERIMENT_FAILED}"}, "WORKFLOW ASSOCIATION@odata.bind" : {"Barcode": "{WORKFLOW ASSOCIATION}"}}',
              type: 'json',
            },
          ],
        });
        done();
      },
    });
    const checkboxes = fixture.debugElement.queryAll(By.css('.k-checkbox'));
    checkboxes[2].nativeElement.click();
    fixture.detectChanges();
  });

  it('should preselect rows saved on task', () => {
    component.removeFromForm.emit();
    component.task = {
      shape: {},
      open: true,
      id: '1',
      elementType: ElementType.Task,
      element: {
        $type: ElementType.Task,
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [
                {
                  $type: ElementType.Property,
                  name: 'key',
                  value: 'GET_MOCK_TEMPLATE/corelims',
                },
              ],
            },
          ],
        },
      },
    };

    component.ngOnInit();

    expect(component.selectedValue).toEqual(['GET_MOCK_TEMPLATE/corelims']);
  });

  it('should not preselect rows if not saved to bpmn', () => {
    const checkboxes = fixture.debugElement.queryAll(By.css('.k-checkbox'));
    checkboxes[0].nativeElement.dispatchEvent(new Event('click'));
    fixture.detectChanges();

    expect(checkboxes[0].nativeElement.checked).toBeTrue();
    component.ngOnInit();
    fixture.detectChanges();

    expect(checkboxes[0].nativeElement.checked).toBeFalse();
  });

  it('should preselect previously saved rows after changing selection and navigating back', () => {
    component.removeFromForm.emit();
    component.task = {
      shape: {},
      open: true,
      id: '1',
      elementType: ElementType.Task,
      element: {
        $type: ElementType.Task,
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [
                {
                  $type: ElementType.Property,
                  name: 'key',
                  value: 'GET_MOCK_TEMPLATE/corelims',
                },
              ],
            },
          ],
        },
      },
    };
    component.ngOnInit();
    fixture.detectChanges();

    expect(component.selectedValue).toEqual(['GET_MOCK_TEMPLATE/corelims']);

    const checkboxes = fixture.debugElement.queryAll(By.css('.k-checkbox'));
    checkboxes[0].nativeElement.click();
    fixture.detectChanges();

    expect(component.selectedValue).toEqual(['Blank Embedded Task/-']);

    expect(checkboxes[0].nativeElement.checked).toBeTrue();
    component.ngOnInit();
    fixture.detectChanges();

    expect(component.selectedValue).toEqual(['GET_MOCK_TEMPLATE/corelims']);
    expect(checkboxes[0].nativeElement.checked).toBeFalse();
  });

  it('should show alert message if value is saved prior', () => {
    expect(fixture.debugElement.query(By.css('.kmd-alerts-container'))).toBeFalsy();
    component.form = new FormGroup({});
    component.task = {
      shape: {},
      open: true,
      id: '1',
      elementType: ElementType.Task,
      element: {
        $type: ElementType.Task,
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [
                {
                  $type: ElementType.Property,
                  name: 'key',
                  value: 'GET_MOCK_TEMPLATE',
                },
              ],
            },
          ],
        },
      },
    };
    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.kmd-alerts-container'))).toBeTruthy();
  });
});
