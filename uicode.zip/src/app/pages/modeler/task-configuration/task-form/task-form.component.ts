import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { merge, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { cloneDeep } from 'lodash';
import { CdkDragDrop, moveItemInArray, CdkDropList } from '@angular/cdk/drag-drop';

import { TaskData, InputType } from '../task-data';
import { GenericFormControls } from '../../shared/form-controls';
import { CamundaCustomVariable, CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import { getExtensionProperty } from '../../shared/bpmnExtensionProperty';
import { ConfigurationType } from '../../configuration-type';
import { CustomValidators } from 'src/app/pages/shared/custom-validators';
import { BasicTaskFormInput, TaskFormInput, TaskInputType, WorkflowTaskInput } from '../../../shared/task-detail';

const TASK_INPUT_FIELD = {
  basics: TaskInputType.Basic,
  dates: TaskInputType.Date,
  selects: TaskInputType.Select,
};
@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./draggable.scss', './task-form.component.scss'],
})
export class TaskFormComponent implements OnInit {
  @Input() task: ConfigurationType;
  @Input() inputVariables: TaskData['input'];
  @Output() updateForm = new EventEmitter<GenericFormControls>();
  @Output() removeFromForm = new EventEmitter<string[]>();

  public readonly maxCharacterLimit = 255;
  public readonly camundaServerVariable = CamundaServerVariable;
  public hasAllInputsMapped = false;
  public embeddedTaskType = false;
  public unmappedInputs: WorkflowTaskInput[] = [];
  public inputForm = new FormGroup({
    [CamundaServerVariable.TaskInstructions]: new FormControl('', [
      Validators.required,
      Validators.maxLength(this.maxCharacterLimit),
      CustomValidators.notBlank,
    ]),
    [CamundaServerVariable.TaskAutoExecute]: new FormControl(false),
    [CamundaServerVariable.EndpointLabel]: new FormControl('Open application', [
      Validators.required,
      Validators.maxLength(30),
      CustomValidators.notBlank,
    ]),
    [CamundaServerVariable.Endpoint]: new FormControl('', [Validators.required, Validators.maxLength(4000), CustomValidators.notBlank]),
  });
  public hasEmbeddedURL = false;

  private readonly unsubscribe = new Subject<void>();

  ngOnInit(): void {
    let allInputsMapped = true;
    const taskVariables = getExtensionProperty(CamundaCustomVariable.TaskActionVariables, this.task.element.extensionElements);
    let templateTaskInputs: TaskFormInput;

    if (taskVariables) {
      const taskInputs = JSON.parse(taskVariables).find((item) => item.name === CamundaServerVariable.TaskInput);
      if (taskInputs) {
        templateTaskInputs = JSON.parse(taskInputs.value);
      }
    }
    this.unmappedInputs = Object.keys(this.inputVariables)
      .filter((input: string) => !this.inputVariables[input].output.value)
      .map(
        (input: string, i: number): WorkflowTaskInput => {
          let unmappedInputTemplate: WorkflowTaskInput;
          let taskInputType: TaskInputType;
          if (templateTaskInputs) {
            Object.keys(templateTaskInputs).forEach((inputType) => {
              if (templateTaskInputs[inputType].some((item: WorkflowTaskInput) => item.name === input)) {
                taskInputType = TASK_INPUT_FIELD[inputType];
                unmappedInputTemplate = templateTaskInputs[inputType].find((item: WorkflowTaskInput) => item.name === input);
              }
            });
          }

          return {
            name: input,
            displayName: unmappedInputTemplate?.displayName ?? input,
            sequence: unmappedInputTemplate?.sequence ?? i,
            type: unmappedInputTemplate?.type ?? null,
            mandatory: this.inputVariables[input].type === InputType.Mandatory,
            defaultValue: unmappedInputTemplate?.defaultValue ?? '',
            taskInputType: taskInputType ?? null,
          };
        }
      );

    let form$;
    if (this.unmappedInputs.length > 0) {
      this.hasEmbeddedURL = this.isDeepLinkingTask();
      this.inputForm.removeControl(CamundaServerVariable.TaskAutoExecute);
      const formSubscriptions = [this.inputForm.get(CamundaServerVariable.TaskInstructions).valueChanges];
      allInputsMapped = false;

      if (this.hasEmbeddedURL) {
        formSubscriptions.push(
          this.inputForm.get(CamundaServerVariable.Endpoint).valueChanges,
          this.inputForm.get(CamundaServerVariable.EndpointLabel).valueChanges
        );
      }

      form$ = merge(...formSubscriptions).pipe(debounceTime(300));
    } else {
      // for embedded task when mapped
      this.hasEmbeddedURL = this.isDeepLinkingTask();
      if (!this.hasEmbeddedURL) {
        this.inputForm.removeControl(CamundaServerVariable.TaskInstructions);
        form$ = this.inputForm.get(CamundaServerVariable.TaskAutoExecute).valueChanges;
      } else {
        this.inputForm.removeControl(CamundaServerVariable.TaskAutoExecute);
        this.inputForm.removeControl(CamundaServerVariable.TaskInstructions);
        allInputsMapped = true;
        const formSubscriptions = [];
        formSubscriptions.push(
          this.inputForm.get(CamundaServerVariable.Endpoint).valueChanges,
          this.inputForm.get(CamundaServerVariable.EndpointLabel).valueChanges
        );

        form$ = merge(...formSubscriptions).pipe(debounceTime(300));
      }
    }
    if (!this.hasEmbeddedURL) {
      this.inputForm.removeControl(CamundaServerVariable.EndpointLabel);
      this.inputForm.removeControl(CamundaServerVariable.Endpoint);
    }

    this.preLoadData(allInputsMapped);
    this.hasAllInputsMapped = allInputsMapped;

    form$.pipe(distinctUntilChanged(), takeUntil(this.unsubscribe)).subscribe({
      next: () => {
        this.updateForm.emit(this.inputForm.controls);
      },
    });
    this.removeFromForm.emit();
    this.updateForm.emit(this.inputForm.controls);
  }

  updateParentForm(inputName: string, controls: GenericFormControls): void {
    this.inputForm.removeControl(inputName);
    this.inputForm.setControl(inputName, new FormGroup(cloneDeep(controls)));
    this.updateForm.emit(this.inputForm.controls);
  }

  onDropList(event: CdkDragDrop<CdkDropList>): void {
    if (event.previousIndex !== event.currentIndex) {
      this.unmappedInputs[event.previousIndex].sequence = event.currentIndex;
      this.unmappedInputs[event.currentIndex].sequence = event.previousIndex;
      moveItemInArray(this.unmappedInputs, event.previousIndex, event.currentIndex);
    }
  }

  private isDeepLinkingTask(): boolean {
    const type = getExtensionProperty(CamundaCustomVariable.TaskActionType, this.task.element.extensionElements);
    this.embeddedTaskType = type.toLowerCase() === 'embedded';
    return type.toLowerCase() === 'embedded';
  }

  private preLoadData(allInputsMapped: boolean): void {
    const extensionElements = this.task.element.extensionElements;
    const instructions = getExtensionProperty(CamundaServerVariable.TaskInstructions, extensionElements);
    let inputString = '';
    const tfInput = getExtensionProperty(CamundaServerVariable.TaskInput, extensionElements);
    if (tfInput) {
      inputString = tfInput;
      this.unmappedInputs = [];
    }
    const autoExecute = getExtensionProperty(CamundaServerVariable.TaskAutoExecute, extensionElements);
    const endpointLabel = getExtensionProperty(CamundaServerVariable.EndpointLabel, extensionElements);
    let endpoint = getExtensionProperty(CamundaServerVariable.Endpoint, extensionElements);
    if (this.inputForm.get(CamundaServerVariable.TaskAutoExecute) && autoExecute === 'true') {
      this.inputForm.get(CamundaServerVariable.TaskAutoExecute).setValue(true);
    } else if (!allInputsMapped || this.hasEmbeddedURL) {
      if (instructions && this.inputForm.get(CamundaServerVariable.TaskInstructions)) {
        this.inputForm.controls[CamundaServerVariable.TaskInstructions].setValue(instructions);
      }
      if (this.hasEmbeddedURL) {
        if (endpoint) {
          this.inputForm.controls[CamundaServerVariable.Endpoint].setValue(endpoint);
        } else {
          endpoint = getExtensionProperty(CamundaCustomVariable.TaskActionVariables, extensionElements);
          this.inputForm.controls[this.camundaServerVariable.Endpoint].setValue(JSON.parse(endpoint)[CamundaServerVariable.Endpoint]);
        }
        if (endpointLabel) {
          this.inputForm.controls[CamundaServerVariable.EndpointLabel].setValue(endpointLabel);
        }
      }

      if (inputString && Object.keys(JSON.parse(inputString)).length > 0) {
        const taskInput: TaskFormInput = JSON.parse(inputString);
        this.unmappedInputs = this.unmappedInputs
          .concat(taskInput.basics?.map((input) => ({ ...input, taskInputType: TaskInputType.Basic })) || [])
          .concat(taskInput.dates?.map((input) => ({ ...input, taskInputType: TaskInputType.Date })) || [])
          .concat(taskInput.selects?.map((input) => ({ ...input, taskInputType: TaskInputType.Select })) || [])
          .sort((a: BasicTaskFormInput, b: BasicTaskFormInput) => a.sequence - b.sequence);
      }
    }
  }
}
