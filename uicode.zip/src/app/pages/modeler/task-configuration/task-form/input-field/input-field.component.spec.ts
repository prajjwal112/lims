import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { CheckboxModule, DropdownsModule, InputFieldsModule, RadioButtonModule } from 'gds-atom-components';

import { InputFieldComponent } from './input-field.component';
import { TaskFormInputType, TaskInputType } from '../../../../shared/task-detail';
import { FieldType } from './shared/field-type';
import { TextNumericRadioGroupComponent } from './text-numeric-radio-group/text-numeric-radio-group.component';
import { ValidationErrorsModule } from 'src/app/pages/shared/validation-errors/validation-errors.module';

describe('TaskFormInputFieldComponent', () => {
  let component: InputFieldComponent;
  let fixture: ComponentFixture<InputFieldComponent>;
  const changeFieldType = (type: FieldType): void => {
    component.inputForm.controls.fieldType.setValue(type);
    fixture.debugElement.query(By.css('[formControlName=fieldType]')).triggerEventHandler('onChange', { selectedOption: type });
    fixture.detectChanges();
  };
  const changeTextNumericType = (taskFormInputType: TaskFormInputType): void => {
    fixture.debugElement.query(By.css('app-text-numeric-radio-group')).triggerEventHandler('change', taskFormInputType);
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InputFieldComponent, TextNumericRadioGroupComponent],
      imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        InputFieldsModule,
        DropdownsModule,
        RadioButtonModule,
        CheckboxModule,
        ValidationErrorsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputFieldComponent);
    component = fixture.componentInstance;
    component.data = {
      name: 'input',
      displayName: 'input',
      type: null,
      sequence: 0,
      taskInputType: TaskInputType.Basic,
      mandatory: true,
      defaultValue: '',
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('validation with field type', () => {
    it('should fail by default', () => {
      expect(component.inputForm.valid).toBeFalse();
    });

    describe(FieldType.Text, () => {
      beforeEach(() => {
        changeFieldType(FieldType.Text);
      });

      it('should fail when text/numeric type is unselected', () => {
        expect(component.inputForm.valid).toBeFalse();
      });

      it('should pass when text/numeric type is selected', () => {
        changeTextNumericType(TaskFormInputType.Numeric);

        expect(component.inputForm.valid).toBeTrue();
      });
    });

    describe(FieldType.DatePicker, () => {
      beforeEach(() => {
        changeFieldType(FieldType.DatePicker);
      });

      it('should pass', () => {
        expect(component.inputForm.valid).toBeTrue();
      });
    });

    describe(FieldType.Dropdown, () => {
      beforeEach(() => {
        changeFieldType(FieldType.Dropdown);
      });

      /* eslint-disable-next-line jasmine/no-spec-dupes */
      it('should fail when text/numeric type is unselected', () => {
        component.inputForm.controls.items.setValue('A');
        fixture.detectChanges();

        expect(component.inputForm.valid).toBeFalse();
      });

      it('should fail when items are not filled in', () => {
        changeTextNumericType(TaskFormInputType.Text);

        expect(component.inputForm.valid).toBeFalse();
      });

      it(`should fail when text/numeric type is ${TaskFormInputType.Text} and a nonnumeric item exists`, () => {
        changeTextNumericType(TaskFormInputType.Numeric);
        component.inputForm.controls.items.setValue('1\n2\nC');
        fixture.detectChanges();

        expect(component.inputForm.valid).toBeFalse();
      });

      it(`should pass when text/numeric type is ${TaskFormInputType.Text} and all items are numeric`, () => {
        changeTextNumericType(TaskFormInputType.Numeric);
        component.inputForm.controls.items.setValue('1\n2\n3');
        fixture.detectChanges();

        expect(component.inputForm.valid).toBeTrue();
      });

      it(`should pass when text/numeric type is ${TaskFormInputType.Text} and items are filled in`, () => {
        changeTextNumericType(TaskFormInputType.Text);
        component.inputForm.controls.items.setValue('A\nB\nC');
        fixture.detectChanges();

        expect(component.inputForm.valid).toBeTrue();
      });

      it('should pass when blank lines are given in items', () => {
        changeTextNumericType(TaskFormInputType.Text);
        component.inputForm.controls.items.setValue('\t\n\nA\nB\nC\n\n\n');
        fixture.detectChanges();

        expect(component.inputForm.valid).toBeTrue();
      });
    });
  });

  describe('additional fields', () => {
    describe('should not show when field type is', () => {
      const expectNoAdditionalFields = (): void => {
        expect(fixture.debugElement.query(By.css('app-text-numeric-radio-group'))).toBeFalsy();
        expect(fixture.debugElement.query(By.css('[formControlName=defaultToCurrentDate]'))).toBeFalsy();
        expect(fixture.debugElement.query(By.css('[formControlName=multiple]'))).toBeFalsy();
        expect(fixture.debugElement.query(By.css('[formControlName=items]'))).toBeFalsy();
      };

      it('not selected', () => {
        expectNoAdditionalFields();
      });

      it(FieldType.Textarea, () => {
        changeFieldType(FieldType.Textarea);

        expectNoAdditionalFields();
      });

      it(FieldType.Boolean, () => {
        changeFieldType(FieldType.Boolean);

        expectNoAdditionalFields();
      });
    });

    describe('should show when field type is', () => {
      it(FieldType.Text, () => {
        changeFieldType(FieldType.Text);

        expect(fixture.debugElement.query(By.css('app-text-numeric-radio-group'))).toBeTruthy();
      });

      it(FieldType.DatePicker, () => {
        changeFieldType(FieldType.DatePicker);

        expect(fixture.debugElement.query(By.css('[formControlName=defaultToCurrentDate]'))).toBeTruthy();
      });

      it(FieldType.Dropdown, () => {
        changeFieldType(FieldType.Dropdown);

        expect(fixture.debugElement.query(By.css('[formControlName=multiple]'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('app-text-numeric-radio-group'))).toBeTruthy();
        expect(fixture.debugElement.query(By.css('[formControlName=items]'))).toBeTruthy();
      });
    });
  });

  it('should display required fields', () => {
    expect(fixture.debugElement.queryAll(By.css('input')).length).toBe(1);
    expect(fixture.debugElement.queryAll(By.css('kmd-dropdown')).length).toBe(1);
  });

  it('should update parent with form values', fakeAsync(() => {
    spyOn(component.formChange, 'emit');
    component.inputForm.get('displayName').setValue('name');
    tick(400);
    fixture.detectChanges();

    // eslint-disable-next-line dot-notation
    expect(component.formChange.emit['calls'].mostRecent().args[0]).toEqual({
      name: jasmine.objectContaining({ value: 'input' }),
      displayName: jasmine.objectContaining({ value: 'name' }),
      type: jasmine.objectContaining({ value: null }),
      sequence: jasmine.objectContaining({ value: 0 }),
      taskInputType: jasmine.objectContaining({ value: TaskInputType.Basic }),
      mandatory: jasmine.objectContaining({ value: true }),
      defaultValue: jasmine.objectContaining({ value: '' }),
    });
  }));

  it('should ignore empty lines when emitting items', fakeAsync(() => {
    spyOn(component.formChange, 'emit');
    changeFieldType(FieldType.Dropdown);
    changeTextNumericType(TaskFormInputType.Text);
    component.inputForm.controls.items.setValue('\t\n\nA\nB\nC\n\n\n');
    tick(400);
    fixture.detectChanges();

    // eslint-disable-next-line dot-notation
    expect(component.formChange.emit['calls'].mostRecent().args[0]).toEqual({
      name: jasmine.objectContaining({ value: 'input' }),
      displayName: jasmine.objectContaining({ value: 'input' }),
      type: jasmine.objectContaining({ value: TaskFormInputType.Text }),
      sequence: jasmine.objectContaining({ value: 0 }),
      taskInputType: jasmine.objectContaining({ value: TaskInputType.Select }),
      multiple: jasmine.objectContaining({ value: false }),
      items: jasmine.objectContaining({ value: ['A', 'B', 'C'] }),
      mandatory: jasmine.objectContaining({ value: true }),
      defaultValue: jasmine.objectContaining({ value: '' }),
    });
  }));

  it('should update sequence field', () => {
    expect(component.inputForm.controls.sequence.value).toBe(0);
    component.data = {
      name: 'input',
      displayName: 'input',
      type: null,
      sequence: 1,
      taskInputType: TaskInputType.Basic,
      mandatory: true,
      defaultValue: '',
    };
    fixture.detectChanges();

    expect(component.inputForm.controls.sequence.value).toBe(1);
  });

  it('should preload name field', () => {
    expect(fixture.debugElement.query(By.css('input')).nativeElement.value).toBe('input');
    expect(component.inputForm.get('name').value).toBe('input');
  });

  it('should have undefined fieldType by default', () => {
    expect(component.inputForm.get('fieldType').value).toBeUndefined();
  });

  it('should preload fieldType field when data is initially given', () => {
    component.data = {
      name: 'input',
      displayName: 'input',
      type: TaskFormInputType.Text,
      sequence: 1,
      taskInputType: TaskInputType.Basic,
      mandatory: true,
      defaultValue: '',
    };
    component.ngOnInit();
    fixture.detectChanges();

    expect(component.inputForm.get('fieldType').value).toBe(FieldType.Text);
  });

  it('should have null type by default', () => {
    expect(component.inputForm.get('type').value).toBeNull();
  });

  it('should preload type field when data is initially given', () => {
    component.data = {
      name: 'input',
      displayName: 'input',
      type: TaskFormInputType.Text,
      sequence: 1,
      taskInputType: TaskInputType.Basic,
      mandatory: true,
      defaultValue: '',
    };
    component.ngOnInit();
    fixture.detectChanges();

    expect(component.inputForm.get('type').value).toBe(TaskFormInputType.Text);
  });
});
