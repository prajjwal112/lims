export enum FieldType {
  Text = 'Text field',
  Dropdown = 'Dropdown',
  // eslint-disable-next-line id-blacklist
  Boolean = 'Boolean selector',
  Textarea = 'Text area',
  DatePicker = 'Date picker',
}
