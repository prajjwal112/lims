import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TextNumericRadioGroupComponent } from './text-numeric-radio-group.component';
import { RadioButtonModule } from 'gds-atom-components';
import { FormsModule } from '@angular/forms';

describe('TextNumericRadioGroupComponent', () => {
  let component: TextNumericRadioGroupComponent;
  let fixture: ComponentFixture<TextNumericRadioGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TextNumericRadioGroupComponent],
      imports: [FormsModule, RadioButtonModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextNumericRadioGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
