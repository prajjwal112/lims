import { Component, EventEmitter, Input, Output } from '@angular/core';
import { TaskFormInputType } from '../../../../../shared/task-detail';

type TextOrNumeric = TaskFormInputType.Text | TaskFormInputType.Numeric;

@Component({
  selector: 'app-text-numeric-radio-group',
  templateUrl: './text-numeric-radio-group.component.html',
  styleUrls: ['./text-numeric-radio-group.component.scss'],
})
export class TextNumericRadioGroupComponent {
  @Input() radioName: string;
  @Output() readonly change = new EventEmitter<TextOrNumeric>();

  readonly taskInputFormType = TaskFormInputType;

  selectedValue: TextOrNumeric;

  onRadioChange(value: TextOrNumeric): void {
    this.change.emit(value);
  }

  setValue(value: TextOrNumeric): void {
    this.selectedValue = value;
  }
}
