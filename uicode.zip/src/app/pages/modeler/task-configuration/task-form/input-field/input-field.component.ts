import {
  AfterViewInit,
  Component,
  DoCheck,
  EventEmitter,
  Input,
  KeyValueDiffer,
  KeyValueDiffers,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import {
  DateTaskFormInput,
  SelectTaskFormInput,
  TaskFormInputType,
  TaskInputType,
  WorkflowTaskInput,
} from '../../../../shared/task-detail';
import { FieldType } from './shared/field-type';
import { CustomValidators } from '../../../../shared/custom-validators';
import { TextNumericRadioGroupComponent } from './text-numeric-radio-group/text-numeric-radio-group.component';

type FormControls = { [key in keyof WorkflowTaskInput]: AbstractControl };
type DateControls = { [key in keyof DateTaskFormInput]: AbstractControl };
type SelectControls = { [key in keyof SelectTaskFormInput]: AbstractControl };

@Component({
  selector: 'app-input-field',
  templateUrl: './input-field.component.html',
  styleUrls: ['./input-field.component.scss'],
})
export class InputFieldComponent implements OnInit, DoCheck, OnDestroy, AfterViewInit {
  @Input() data: WorkflowTaskInput;
  @Output() formChange = new EventEmitter<FormControls>();
  @ViewChild(TextNumericRadioGroupComponent) private textNumericRadioGroup: TextNumericRadioGroupComponent;

  readonly fieldTypeOptions: ReadonlyArray<'' | FieldType> = Object.freeze([
    '',
    FieldType.Text,
    FieldType.Dropdown,
    FieldType.Boolean,
    FieldType.Textarea,
    FieldType.DatePicker,
  ]);
  readonly fieldType = FieldType;
  readonly taskFormInputType = TaskFormInputType;
  readonly characterLimitPerLine = 50;
  readonly maxCharacterLimit = 255;

  inputForm = new FormGroup({
    name: new FormControl('', Validators.required),
    displayName: new FormControl('', [Validators.required, Validators.maxLength(this.maxCharacterLimit), CustomValidators.notBlank]),
    type: new FormControl('', Validators.required),
    sequence: new FormControl(0, Validators.required),
    fieldType: new FormControl('', Validators.required),
    textOrNumericType: new FormControl(''),
    mandatory: new FormControl(false),
    defaultValue: new FormControl(''),
    taskInputType: new FormControl(''),
  });

  #unsubscribe = new Subject<void>();
  #differ: KeyValueDiffer<string, any>;
  #selectedFieldType: FieldType;

  constructor(private differs: KeyValueDiffers) {}

  private static newFormControl(formControl: AbstractControl): AbstractControl {
    const validators = [];
    if (formControl.validator) {
      validators.push(formControl.validator);
    }

    return new FormControl(formControl.value, validators);
  }

  private static getTaskInputType(fieldType: FieldType): TaskInputType {
    switch (fieldType) {
      case FieldType.Dropdown:
        return TaskInputType.Select;
      case FieldType.DatePicker:
        return TaskInputType.Date;
      default:
        return TaskInputType.Basic;
    }
  }

  ngOnInit(): void {
    this.#differ = this.differs.find(this.data).create();
    this.initializePrimaryControls();
    this.initializeAdditionalControls(this.data.taskInputType);
    this.initializeValueChangeSubscriptions();
    this.emitFormChange();
  }

  ngDoCheck(): void {
    const changes = this.#differ.diff(this.data);
    if (changes) {
      this.inputForm.controls.sequence.setValue(this.data.sequence);
    }
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this.textNumericRadioGroup) {
        this.textNumericRadioGroup.setValue(this.data.type as TaskFormInputType.Text | TaskFormInputType.Numeric);
      }
    });
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  onFieldTypeChange(event: { selectedOption: FieldType }): void {
    this.#selectedFieldType = event.selectedOption;

    this.inputForm.controls.type.setValue(this.getTaskInputFormType(this.#selectedFieldType));
    this.inputForm.controls.taskInputType.setValue(InputFieldComponent.getTaskInputType(this.#selectedFieldType));

    if (InputFieldComponent.getTaskInputType(this.#selectedFieldType) !== TaskInputType.Basic) {
      this.initializeAdditionalControls(InputFieldComponent.getTaskInputType(this.#selectedFieldType));
    }
    if (this.#selectedFieldType === FieldType.Text || this.#selectedFieldType === FieldType.Dropdown) {
      this.setTextOrNumericTypeValue('');
    } else {
      this.inputForm.controls.textOrNumericType.clearValidators();
      this.inputForm.controls.textOrNumericType.setValue('');
      this.inputForm.controls.textOrNumericType.updateValueAndValidity();
    }
  }

  onTextOrNumericTypeChange(event: TaskFormInputType.Text | TaskFormInputType.Numeric): void {
    this.setTextOrNumericTypeValue(event);
    if (this.inputForm.controls.items) {
      this.setItemsControlValidator(event);
    }
  }

  private initializePrimaryControls(): void {
    this.#selectedFieldType = this.getSelectedFieldType();

    this.inputForm.controls.name.setValue(this.data.name);
    this.inputForm.controls.displayName.setValue(this.data.displayName);
    this.inputForm.controls.type.setValue(this.data.type);
    this.inputForm.controls.sequence.setValue(this.data.sequence);
    this.inputForm.controls.fieldType.setValue(this.#selectedFieldType);
    this.inputForm.controls.mandatory.setValue(this.data.mandatory);
    this.inputForm.controls.defaultValue.setValue(this.data.defaultValue);
    this.inputForm.controls.taskInputType.setValue(InputFieldComponent.getTaskInputType(this.#selectedFieldType));
  }

  private initializeAdditionalControls(taskInputType: TaskInputType): void {
    this.inputForm.removeControl('defaultToCurrentDate');
    this.inputForm.removeControl('multiple');
    this.inputForm.removeControl('items');
    switch (taskInputType) {
      case TaskInputType.Date: {
        const input = this.data as DateTaskFormInput;
        this.inputForm.addControl('defaultToCurrentDate', new FormControl(input.defaultToCurrentDate));
        break;
      }
      case TaskInputType.Select: {
        const input = this.data as SelectTaskFormInput;
        const items = input.items ? input.items.join('\n') : '';
        this.inputForm.addControl('multiple', new FormControl(input.multiple ?? false));
        this.inputForm.addControl('items', new FormControl(items));
        break;
      }
    }

    this.initializeTextOrNumericTypeValue();
  }

  private initializeValueChangeSubscriptions(): void {
    this.inputForm.controls.textOrNumericType.valueChanges.pipe(distinctUntilChanged(), takeUntil(this.#unsubscribe)).subscribe({
      next: () => {
        this.inputForm.controls.type.setValue(this.getTaskInputFormType(this.#selectedFieldType));
      },
    });
    this.inputForm.valueChanges.pipe(debounceTime(300), distinctUntilChanged(), takeUntil(this.#unsubscribe)).subscribe({
      next: () => {
        this.emitFormChange();
      },
    });
  }

  private getSelectedFieldType(): FieldType {
    switch (this.data.type) {
      case TaskFormInputType.Boolean:
        return FieldType.Boolean;
      case TaskFormInputType.Textarea:
        return FieldType.Textarea;
      case TaskFormInputType.Date:
        return FieldType.DatePicker;
      case TaskFormInputType.Text:
      case TaskFormInputType.Numeric:
        return this.data.taskInputType === TaskInputType.Select ? FieldType.Dropdown : FieldType.Text;
    }
  }

  private initializeTextOrNumericTypeValue(): void {
    if (this.data.type === TaskFormInputType.Text || this.data.type === TaskFormInputType.Numeric) {
      this.setTextOrNumericTypeValue(this.data.type);
    }
  }

  private setTextOrNumericTypeValue(state: '' | TaskFormInputType.Text | TaskFormInputType.Numeric): void {
    this.inputForm.controls.textOrNumericType.setValidators(Validators.required);
    this.inputForm.controls.textOrNumericType.setValue(state);
    this.inputForm.controls.textOrNumericType.updateValueAndValidity();
  }

  private setItemsControlValidator(taskFormInputType: TaskFormInputType.Text | TaskFormInputType.Numeric): void {
    const control = this.inputForm.controls.items;

    if (this.#selectedFieldType === FieldType.Dropdown) {
      const validators = [
        Validators.required,
        CustomValidators.notBlank,
        CustomValidators.maxCharactersPerLine(this.characterLimitPerLine),
      ];

      if (taskFormInputType === TaskFormInputType.Numeric) {
        validators.push(CustomValidators.numericLinesOnly);
      }

      control.setValidators(validators);
    } else {
      control.clearValidators();
    }
    control.updateValueAndValidity();
  }

  private getTaskInputFormType(fieldType: FieldType): TaskFormInputType {
    switch (fieldType) {
      case FieldType.Text:
      case FieldType.Dropdown:
        return this.inputForm.controls.textOrNumericType.value as TaskFormInputType;
      case FieldType.Boolean:
        return TaskFormInputType.Boolean;
      case FieldType.Textarea:
        return TaskFormInputType.Textarea;
      case FieldType.DatePicker:
        return TaskFormInputType.Date;
    }
  }

  private emitFormChange(): void {
    const formControls: FormControls = {
      name: InputFieldComponent.newFormControl(this.inputForm.controls.name),
      displayName: InputFieldComponent.newFormControl(this.inputForm.controls.displayName),
      type: InputFieldComponent.newFormControl(this.inputForm.controls.type),
      sequence: InputFieldComponent.newFormControl(this.inputForm.controls.sequence),
      mandatory: InputFieldComponent.newFormControl(this.inputForm.controls.mandatory),
      defaultValue: InputFieldComponent.newFormControl(this.inputForm.controls.defaultValue),
      taskInputType: InputFieldComponent.newFormControl(this.inputForm.controls.taskInputType),
    };

    if (this.#selectedFieldType === FieldType.Dropdown) {
      const selectControls = this.buildSelectControlsForEmit();
      const convertedFormControls = (formControls as unknown) as SelectControls;
      convertedFormControls.multiple = selectControls.multiple;
      convertedFormControls.items = selectControls.items;
    } else if (this.#selectedFieldType === FieldType.DatePicker) {
      const convertedFormControls = (formControls as unknown) as DateControls;
      convertedFormControls.defaultToCurrentDate = InputFieldComponent.newFormControl(this.inputForm.controls.defaultToCurrentDate);
    }

    this.formChange.emit(formControls);
  }

  private buildSelectControlsForEmit(): Record<'multiple' | 'items', AbstractControl> {
    const controls: Record<'multiple' | 'items', AbstractControl> = {
      multiple: InputFieldComponent.newFormControl(this.inputForm.controls.multiple),
      items: InputFieldComponent.newFormControl(this.inputForm.controls.items),
    };

    if (controls.items.value) {
      controls.items.setValue(controls.items.value.split('\n').filter((item: string) => !!item.trim()));
    }

    return controls;
  }
}
