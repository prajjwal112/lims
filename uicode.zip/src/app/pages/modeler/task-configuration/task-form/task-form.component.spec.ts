import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { FormControl, FormsModule, ReactiveFormsModule, FormGroup, AbstractControl, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { cloneDeep } from 'lodash';
import { DropdownsModule, InputFieldsModule, ToggleModule } from 'gds-atom-components';

import { TaskFormComponent } from './task-form.component';
import { InputFieldComponent } from './input-field/input-field.component';
import { CamundaCustomVariable, CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import { ElementType } from '../../element-type';
import { MAPPED_INPUT_VARIABLES, PARTIAL_MAPPED_INPUT_VARIABLES, UNMAPPED_INPUT_VARIABLES } from '../shared/test/input-mappings';
import { TaskFormInputType, TaskInputType } from '../../../shared/task-detail';
import { ValidationErrorsModule } from 'src/app/pages/shared/validation-errors/validation-errors.module';
import { CustomValidators } from 'src/app/pages/shared/custom-validators';

describe('TaskFormComponent', () => {
  let component: TaskFormComponent;
  let fixture: ComponentFixture<TaskFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskFormComponent, InputFieldComponent],
      imports: [CommonModule, ReactiveFormsModule, FormsModule, InputFieldsModule, ToggleModule, DropdownsModule, ValidationErrorsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskFormComponent);
    component = fixture.componentInstance;

    component.task = {
      open: true,
      id: 'task_id_123',
      elementType: ElementType.Task,
      shape: {},
      element: {
        id: 'task_id_123',
        $type: ElementType.Task,
        name: 'Task name',
        documentation: [{ $type: ElementType.Documentation, text: 'description' }],
      },
    };
    component.inputVariables = cloneDeep(UNMAPPED_INPUT_VARIABLES);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('form validation', () => {
    let form: FormGroup;
    let field: AbstractControl;
    beforeEach(() => {
      form = component.inputForm;
    });
    /* eslint-disable jasmine/no-spec-dupes */
    describe('instruction validator', () => {
      beforeEach(() => {
        field = form.controls[CamundaServerVariable.TaskInstructions];
      });

      it('required', () => {
        expect(field.valid).toBeFalse();
      });

      it('blank', () => {
        field.setValue(' ');

        expect(field.valid).toBeFalse();
      });

      it('max length', () => {
        field.setValue('a'.repeat(256));

        expect(field.valid).toBeFalse();
      });

      describe('endpoint', () => {
        beforeEach(() => {
          component.inputForm.addControl(CamundaServerVariable.TaskAutoExecute, new FormControl(false));
          component.inputForm.addControl(
            CamundaServerVariable.Endpoint,
            new FormControl('', [Validators.required, Validators.maxLength(4000), CustomValidators.notBlank])
          );
          component.inputForm.addControl(
            CamundaServerVariable.EndpointLabel,
            new FormControl('Open Application', [Validators.required, Validators.maxLength(30), CustomValidators.notBlank])
          );
        });

        describe('label', () => {
          beforeEach(() => {
            field = form.controls[CamundaServerVariable.EndpointLabel];
          });

          it('required', () => {
            field.setValue('');

            expect(field.valid).toBeFalse();
          });

          it('blank', () => {
            field.setValue(' ');

            expect(field.valid).toBeFalse();
          });

          it('max length', () => {
            field.setValue('a'.repeat(31));

            expect(field.valid).toBeFalse();
          });
        });

        describe('url', () => {
          beforeEach(() => {
            field = form.controls[CamundaServerVariable.Endpoint];
          });

          it('required', () => {
            field.setValue('');

            expect(field.valid).toBeFalse();
          });

          it('blank', () => {
            field.setValue(' ');

            expect(field.valid).toBeFalse();
          });

          it('max length', () => {
            field.setValue('a'.repeat(4001));

            expect(field.valid).toBeFalse();
          });
        });
      });
    });
  });

  it('should display instructions field', () => {
    expect(fixture.debugElement.query(By.css('textarea'))).toBeTruthy();
  });

  it('should display auto execute section for non embedded tasks', () => {
    component.inputForm.addControl(CamundaServerVariable.TaskAutoExecute, new FormControl(false));
    component.inputVariables = MAPPED_INPUT_VARIABLES;

    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-toggle'))).toBeTruthy();
  });

  it('should not display auto execute section for embedded tasks', () => {
    component.inputForm.removeControl(CamundaServerVariable.TaskAutoExecute);
    component.inputForm.addControl(CamundaServerVariable.Endpoint, new FormControl(''));
    component.inputForm.addControl(CamundaServerVariable.EndpointLabel, new FormControl(''));
    component.inputVariables = MAPPED_INPUT_VARIABLES;
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            { $type: ElementType.Property, name: CamundaCustomVariable.TaskActionType, value: 'embedded' },
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.TaskActionVariables,
              value: JSON.stringify([{ [CamundaServerVariable.Endpoint]: 'www.google.com' }]),
            },
          ],
        },
      ],
    };
    component.ngOnInit();
    fixture.detectChanges();

    expect(component.hasEmbeddedURL).toEqual(true);
    expect(fixture.debugElement.query(By.css('kmd-toggle'))).toBeFalsy();
  });

  it('should not display instructions field for mapped embedded tasks', () => {
    component.inputForm.removeControl(CamundaServerVariable.TaskAutoExecute);
    component.inputForm.removeControl(CamundaServerVariable.TaskInstructions);
    component.inputForm.addControl(CamundaServerVariable.Endpoint, new FormControl(''));
    component.inputForm.addControl(CamundaServerVariable.EndpointLabel, new FormControl(''));
    component.inputVariables = MAPPED_INPUT_VARIABLES;
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            { $type: ElementType.Property, name: CamundaCustomVariable.TaskActionType, value: 'embedded' },
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.TaskActionVariables,
              value: JSON.stringify([{ [CamundaServerVariable.Endpoint]: 'www.google.com' }]),
            },
          ],
        },
      ],
    };
    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css(`textarea#${CamundaServerVariable.TaskInstructions}`))).toBeFalsy();
  });

  it('should not display unmapped inputs', () => {
    component.inputForm.addControl(CamundaServerVariable.TaskAutoExecute, new FormControl(false));
    component.inputVariables = PARTIAL_MAPPED_INPUT_VARIABLES;
    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('app-input-field')).length).toBe(1);

    expect(component.unmappedInputs).toEqual([
      {
        name: 'inputVar',
        displayName: 'inputVar',
        sequence: 0,
        type: null,
        taskInputType: null,
        mandatory: true,
        defaultValue: '',
      },
    ]);
  });

  it('should display unmapped inputs', () => {
    expect(fixture.debugElement.queryAll(By.css('app-input-field')).length).toBe(3);
  });

  it('should display embedded url', () => {
    expect(fixture.debugElement.query(By.css('input[type="url"]'))).toBeFalsy();
    component.inputForm.addControl(CamundaServerVariable.TaskAutoExecute, new FormControl(false));
    component.inputForm.addControl(CamundaServerVariable.Endpoint, new FormControl(false));
    component.inputForm.addControl(CamundaServerVariable.EndpointLabel, new FormControl(false));
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            { $type: ElementType.Property, name: CamundaCustomVariable.TaskActionType, value: 'embedded' },
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.TaskActionVariables,
              value: JSON.stringify([{ [CamundaServerVariable.Endpoint]: 'www.google.com' }]),
            },
          ],
        },
      ],
    };
    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('input[type="url"]'))).toBeTruthy();
  });

  it('should emit form controls when form is updated', () => {
    spyOn(component.updateForm, 'emit');

    expect(component.updateForm.emit).not.toHaveBeenCalled();
    component.updateParentForm('inputVar', {
      displayName: new FormControl('input'),
    });

    expect(component.updateForm.emit).toHaveBeenCalledTimes(1);
  });

  it('should preload auto execute value from bpmn', () => {
    component.inputForm.addControl(CamundaServerVariable.TaskAutoExecute, new FormControl(false));
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [{ $type: ElementType.Property, name: CamundaServerVariable.TaskAutoExecute, value: 'true' }],
        },
      ],
    };
    component.inputVariables = MAPPED_INPUT_VARIABLES;
    component.ngOnInit();

    expect(component.inputForm.get(CamundaServerVariable.TaskAutoExecute).value).toBeTrue();
  });

  it('should preload embedded url values from bpmn', () => {
    component.inputForm.addControl(CamundaServerVariable.TaskAutoExecute, new FormControl(false));
    component.inputForm.addControl(CamundaServerVariable.Endpoint, new FormControl(false));
    component.inputForm.addControl(CamundaServerVariable.EndpointLabel, new FormControl(false));
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            { $type: ElementType.Property, name: CamundaCustomVariable.TaskActionType, value: 'embedded' },
            { $type: ElementType.Property, name: CamundaServerVariable.Endpoint, value: 'www.google.com' },
            { $type: ElementType.Property, name: CamundaServerVariable.EndpointLabel, value: 'endpoint label' },
          ],
        },
      ],
    };
    component.ngOnInit();

    expect(component.inputForm.controls[CamundaServerVariable.Endpoint].value).toBe('www.google.com');
    expect(component.inputForm.controls[CamundaServerVariable.EndpointLabel].value).toBe('endpoint label');
  });

  it('should preload instruction value from bpmn', () => {
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [{ $type: ElementType.Property, name: CamundaServerVariable.TaskInstructions, value: 'instruction details' }],
        },
      ],
    };
    component.ngOnInit();

    expect(component.inputForm.get(CamundaServerVariable.TaskInstructions).value).toBe('instruction details');
  });

  it('should preload unmapped values from bpmn', () => {
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            {
              $type: ElementType.Property,
              name: CamundaServerVariable.TaskInput,
              value:
                /* eslint-disable-next-line max-len */
                '{"basics":[{"name":"inputVar","displayName":"inputVar","type":"numeric","sequence":2,"mandatory":true,"defaultValue":""},{"name":"inputVar3","displayName":"inputVar3","type":"text","sequence":1,"mandatory":true,"defaultValue":""},{"name":"inputVar2","displayName":"inputVar2","type":"numeric","sequence":0,"mandatory":true,"defaultValue":""}]}',
            },
          ],
        },
      ],
    };
    component.ngOnInit();

    expect(component.unmappedInputs).toEqual([
      {
        name: 'inputVar2',
        displayName: 'inputVar2',
        type: TaskFormInputType.Numeric,
        sequence: 0,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
      {
        name: 'inputVar3',
        displayName: 'inputVar3',
        type: TaskFormInputType.Text,
        sequence: 1,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
      {
        name: 'inputVar',
        displayName: 'inputVar',
        type: TaskFormInputType.Numeric,
        sequence: 2,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
    ]);
  });

  it('should preload template values if there is no unmapped values', () => {
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            {
              $type: ElementType.Property,
              name: CamundaServerVariable.TaskInput,

              value:
                /* eslint-disable-next-line max-len */
                '{"basics":[{"name":"inputVar","displayName":"inputVar","type":"text","sequence":2, "mandatory": true, "defaultValue": ""},{"name":"inputVar3","displayName":"inputVar3","type":"text","sequence":1, "mandatory": true, "defaultValue": ""},{"name":"inputVar2","displayName":"inputVar2","type":"text","sequence":0, "mandatory": true, "defaultValue": ""}]}',
            },
          ],
        },
      ],
    };

    component.unmappedInputs = [];
    component.ngOnInit();

    expect(component.unmappedInputs).toEqual([
      {
        name: 'inputVar2',
        displayName: 'inputVar2',
        type: TaskFormInputType.Text,
        sequence: 0,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
      {
        name: 'inputVar3',
        displayName: 'inputVar3',
        type: TaskFormInputType.Text,
        sequence: 1,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
      {
        name: 'inputVar',
        displayName: 'inputVar',
        type: TaskFormInputType.Text,
        sequence: 2,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
    ]);
  });

  it('should load user saved values instead of action template vlues', () => {
    component.task.element.extensionElements = {
      $type: ElementType.ExtensionElements,
      values: [
        {
          $type: ElementType.Properties,
          values: [
            {
              $type: ElementType.Property,
              name: CamundaServerVariable.TaskInput,

              value:
                /* eslint-disable-next-line max-len */
                '{"basics":[{"name":"BARCODE","displayName":"BARCODE","type":"numeric","sequence":0, "mandatory": true, "defaultValue": ""},{"name":"var1","displayName":"var1","type":"numeric","sequence":1, "mandatory": true, "defaultValue": ""}],"dates":[],"selects":[]}',
            },
            {
              $type: ElementType.Property,
              name: CamundaCustomVariable.TaskActionVariables,
              value: JSON.stringify([
                {
                  name: 'tf_taskInput',
                  type: 'JSON',
                  value:
                    '{"basics":[{"name":"BARCODE","displayName":"BARCODE","mandatory":true,"sequence":0,"type":"String", "defaultValue": ""}]}',
                },
              ]),
            },
          ],
        },
      ],
    };
    component.ngOnInit();

    expect(component.unmappedInputs).toEqual([
      {
        name: 'BARCODE',
        displayName: 'BARCODE',
        type: TaskFormInputType.Numeric,
        sequence: 0,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
      {
        name: 'var1',
        displayName: 'var1',
        type: TaskFormInputType.Numeric,
        sequence: 1,
        taskInputType: TaskInputType.Basic,
        mandatory: true,
        defaultValue: '',
      },
    ]);
  });
});
