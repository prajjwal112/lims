import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { cloneDeep } from 'lodash';

import type { ConfigurationType } from '../../configuration-type';
import { TaskData, InputType } from '../task-data';
import type { TaskFormInput } from '../../../shared/task-detail';
import type { GenericFormControls } from '../../shared/form-controls';
import { CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import { findExtensionElementArrayValues, getExtensionProperty, OutputExtensionVariable } from '../../shared/bpmnExtensionProperty';
import { CustomValidators } from 'src/app/pages/shared/custom-validators';

const MIN_VARIABLE_NAME_LENGTH = 2;
const MAX_VARIABLE_NAME_LENGTH = 50;

@Component({
  selector: 'app-task-inputs',
  templateUrl: './task-inputs.component.html',
  styleUrls: ['./task-inputs.component.scss'],
})
export class TaskInputsComponent implements OnInit {
  @Input() task: ConfigurationType;
  @Input() form: FormGroup;
  @Input() data: TaskData['action'];
  @Output() updateForm = new EventEmitter<GenericFormControls>();
  @Output() removeFromForm = new EventEmitter<string[]>();

  readonly minVariableNameLength = MIN_VARIABLE_NAME_LENGTH;
  readonly maxVariableNameLength = MAX_VARIABLE_NAME_LENGTH;
  readonly addInputForm = new FormGroup({
    tempVariableName: new FormControl('', [
      Validators.required,
      Validators.minLength(this.minVariableNameLength),
      Validators.pattern(CustomValidators.disallowSpecialCharactersPattern),
      Validators.maxLength(this.maxVariableNameLength),
      CustomValidators.notBlank,
      CustomValidators.noTFPrefix,
    ]),
  });

  public infoText = '';
  public inputMapping = true;
  public outputValues: OutputExtensionVariable[] = [];
  public savedValues: TaskData['input'] = {};
  public mandatoryInputVariables: string[] = [];
  public optionalAddedInputVariables: string[] = [];
  public optionalInputVariables: string[] = [];
  public customInputVariables: string[] = [];

  private static filterByMandatoryField(
    inputValue: TaskFormInput,
    key: keyof TaskFormInput,
    mandatory?: boolean,
    defaultValue = false
  ): string[] {
    const values = inputValue[key];
    if (!values) {
      return [];
    }

    return values
      .filter((item) => {
        const itemValue = item.defaultValue?.trim();
        if (item.mandatory === !!mandatory) {
          return (mandatory && !!itemValue === defaultValue) || !mandatory;
        }
        return false;
      })
      .map((val) => val.name);
  }

  private static getActionInputNames(inputValue: TaskFormInput, mandatory?: boolean, defaultValue = false): string[] {
    return Object.keys(inputValue).flatMap((key: keyof TaskFormInput) =>
      TaskInputsComponent.filterByMandatoryField(inputValue, key, mandatory, defaultValue)
    );
  }

  ngOnInit(): void {
    const inputValueString = this.data.variables?.find((val) => val.name === CamundaServerVariable.TaskInput)?.value;
    if (inputValueString) {
      this.mandatoryInputVariables = TaskInputsComponent.getActionInputNames(JSON.parse(inputValueString), true);
      this.optionalInputVariables = [
        ...TaskInputsComponent.getActionInputNames(JSON.parse(inputValueString)),
        ...TaskInputsComponent.getActionInputNames(JSON.parse(inputValueString), true, true),
      ];
    }
    this.inputMapping = this.mandatoryInputVariables.length > 0;
    this.infoText = 'Input variables represent the information needed to execute the task.';
    if (this.inputMapping) {
      this.infoText += `
        <br/>
        If an input variable is <strong>not mapped</strong> to a variable available in the workflow,
        the variable will require user input and a
        form field will be configured in the <strong>next step</strong>.
      `;
    }
    const savedValue = getExtensionProperty(CamundaServerVariable.TaskInputMapping, this.task.element.extensionElements);
    this.initForm(savedValue);

    this.outputValues = findExtensionElementArrayValues(this.task.element, CamundaServerVariable.OutputMappingPublic, this.task.id);
    this.addInputForm.controls.tempVariableName.setValidators([
      this.duplicateCustomInputName.bind(this),
      this.addInputForm.controls.tempVariableName.validator,
    ]);
    this.addInputForm.controls.tempVariableName.updateValueAndValidity();
  }

  addOptionalInput(index: number): void {
    const optionalInput = this.optionalInputVariables.splice(index, 1)[0];
    this.optionalAddedInputVariables.push(optionalInput);
  }

  addCustomInput(): void {
    const control: AbstractControl = this.addInputForm.controls.tempVariableName;
    control.setValue(control.value.trim());
    if (this.addInputForm.valid) {
      this.customInputVariables.push(control.value);
      control.setValue('');

      const resetOptions = { onlySelf: true };
      this.addInputForm.markAsUntouched(resetOptions);
      this.addInputForm.markAsPristine(resetOptions);
    }
  }

  removeCustomInput(key: string, index: number): void {
    this.customInputVariables.splice(index, 1);
    delete this.savedValues[key];
    this.removeFromParentForm([key]);
  }

  removeOptionalInput(key: string, index: number): void {
    const optionalInput = this.optionalAddedInputVariables.splice(index, 1)[0];
    this.optionalInputVariables.push(optionalInput);
    delete this.savedValues[key];
    this.removeFromParentForm([key]);
  }

  updateParentForm(controls: GenericFormControls): void {
    this.updateForm.emit(controls);
  }

  private duplicateCustomInputName(control: AbstractControl): { duplicate: true } | null {
    const unparsedInputs = this.data.variables?.find((val) => val.name === CamundaServerVariable.TaskInputVariable)?.value.toLowerCase();
    const inputs = this.data.variables?.length > 0 && unparsedInputs ? JSON.parse(unparsedInputs) : [];
    const isValid =
      !this.customInputVariables.some((name) => name.toLowerCase() === control.value.toLowerCase()) &&
      !inputs?.includes(control.value.toLowerCase());
    return isValid ? null : { duplicate: true };
  }

  private initForm(savedValue: string): void {
    const parseValue: TaskData['input'] = savedValue && JSON.parse(savedValue);
    this.savedValues = cloneDeep(parseValue);

    if (this.checkIfInputVariableExists((input: string) => parseValue[input])) {
      const optionalInputs = this.optionalInputVariables.slice();
      optionalInputs.forEach((input, i) => {
        if (parseValue[input]) {
          this.addOptionalInput(i);
        }
      });
      this.optionalAddedInputVariables = this.separateInputValues(Object.keys(parseValue), InputType.Optional);
    }
    this.customInputVariables = this.separateInputValues(Object.keys(parseValue), InputType.Custom);
  }

  private removeFromParentForm(keys: string[] = []): void {
    this.removeFromForm.emit(keys);
  }

  private checkIfInputVariableExists(qualifier: Parameters<string[]['some']>[0]): boolean {
    const templateInputs = this.mandatoryInputVariables.concat(this.optionalInputVariables);

    return templateInputs.length && templateInputs.some(qualifier);
  }

  private separateInputValues(search: string[], key: InputType): string[] {
    return search.filter((input) => this.savedValues[input].type === key);
  }
}
