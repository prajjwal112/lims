import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DropdownsModule, AlertsModule, InputFieldsModule, CheckboxModule, ButtonModule, AccordionsModule } from 'gds-atom-components';
import { ReactiveFormsModule, FormsModule, FormGroup } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { TaskInputsComponent } from './task-inputs.component';
import { MappingFieldsComponent } from './mapping-fields/mapping-fields.component';
import { ElementType } from '../../element-type';
import { CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import { InputType } from '../task-data';

/* eslint-disable max-len */
const ACTION_TEMPLATE = Object.freeze({
  templateKey: 'AURORA-tf-tenant/tf-task-template/corelims-eln-apr17-dsbu-cloud/GET_EDIT_EVENT/tf-version-1',
  taskName: 'GET_EDIT_EVENT',
  taskType: 'Integrated',
  createdById: 'Thermo Fisher Scientific',
  description: '',
  variables: [
    {
      name: 'tf_async',
      value: 'false',
      type: 'BOOLEAN',
    },
    {
      name: 'tf_autoComplete',
      value: 'false',
      type: 'BOOLEAN',
    },
    {
      name: 'tf_autoExecute',
      value: 'false',
      type: 'BOOLEAN',
    },
    {
      name: 'tf_httpType',
      value: 'GET',
      type: 'STRING',
    },
    {
      name: 'tf_timeout',
      value: '1000',
      type: 'INT',
    },
    {
      name: 'tf_endpoint',
      value: '',
      type: 'STRING',
    },
    {
      name: 'tf_urlTemplate',
      value: 'https://corelims-eln.apr17.dsbu.cloud/odata/EDIT_EVENT/(\'{{BARCODE}}\')',
      type: 'STRING',
    },
    {
      name: 'tf_username',
      value: '',
      type: 'STRING',
    },
    {
      name: 'tf_password',
      value: '',
      type: 'STRING',
    },
    {
      name: 'tf_status',
      value: '',
      type: 'STRING',
    },
    {
      name: 'tf_headers',
      value: '{"odata.metadata":"full","Accept":"application/json"}',
      type: 'JSON',
    },
    {
      name: 'tf_dataTypes',
      value:
        '{"EntityTypeName":{"name":"EntityTypeName","type":"String","enums":[],"collection":"false"},"Id":{"name":"Id","type":"Int32","enums":[],"collection":"false"},"Name":{"name":"Name","type":"String","enums":[],"collection":"false"},"Barcode":{"name":"Barcode","type":"String","enums":[],"collection":"false"},"Sequence":{"name":"Sequence","type":"Int32","enums":[],"collection":"false"},"Created":{"name":"Created","type":"DateTimeOffset","enums":[],"collection":"false"},"Modified":{"name":"Modified","type":"DateTimeOffset","enums":[],"collection":"false"},"Active":{"name":"Active","type":"Boolean","enums":[],"collection":"false"},"LikedBy":{"name":"LikedBy","type":"Int32","enums":[],"collection":"false"},"FollowedBy":{"name":"FollowedBy","type":"Int32","enums":[],"collection":"false"},"Locked":{"name":"Locked","type":"Boolean","enums":[],"collection":"false"},"PROJECT":{"name":"PROJECT","type":"odata/PROJECT","enums":[],"collection":"true"},"CREATED_BY":{"name":"CREATED_BY","type":"odata/EMPLOYEE","enums":[],"collection":"false"},"LOCATION":{"name":"LOCATION","type":"odata/LOCATION","enums":[],"collection":"false"},"EXPERIMENT_SAMPLE_REFS":{"name":"EXPERIMENT_SAMPLE_REFS","type":"odata/EXPERIMENT_SAMPLE","enums":[],"collection":"true"},"LIST_MEMBER_REFS":{"name":"LIST_MEMBER_REFS","type":"odata/LIST_MEMBER","enums":[],"collection":"true"},"QUEUE_MEMBER_REFS":{"name":"QUEUE_MEMBER_REFS","type":"odata/QUEUE_MEMBER","enums":[],"collection":"true"}}',
      type: 'JSON',
    },
    {
      name: 'tf_taskInput',
      value: `{
          "basics": [
            {"name":"inputVar","displayName":"inputVar","type":"text","sequence":2, "mandatory": true, "defaultValue": "1"},
            {"name":"inputVar3","displayName":"inputVar3","type":"text","sequence":1, "mandatory": true, "defaultValue": ""},
            {"name":"inputVar2","displayName":"inputVar2","type":"text","sequence":0, "mandatory": false, "defaultValue": ""},
            {"name":"inputVar4","displayName":"inputVar4","type":"text","sequence":0, "mandatory": false, "defaultValue": "test"}
          ],
          "selects": [
            {"name":"inputVarSelect","displayName":"inputVarSelect","type":"text","sequence":9, "mandatory": true, "defaultValue": ""},
            {"name":"inputVarSelect2","displayName":"inputVarSelect2","type":"text","sequence":9, "mandatory": true, "defaultValue": "test"},
            {"name":"inputVarSelect3","displayName":"inputVarSelect3","type":"text","sequence":9, "mandatory": false, "defaultValue": ""},
            {"name":"inputVarSelect4","displayName":"inputVarSelect4","type":"text","sequence":9, "mandatory": false, "defaultValue": "test"}
          ]
        }`,
      type: 'JSON',
    },
    {
      name: 'tf_inputVariablesNames',
      value: '["TENANT"]',
      type: 'JSON',
    },
    {
      name: 'tf_outputVariablesNames',
      value:
        '["EntityTypeName","Id","Name","Barcode","Sequence","Created","Modified","Active","LikedBy","FollowedBy","Locked","PROJECT","CREATED_BY","LOCATION","EXPERIMENT_SAMPLE_REFS","LIST_MEMBER_REFS","QUEUE_MEMBER_REFS"]',
      type: 'JSON',
    },
    {
      name: 'tf_successBody',
      value:
        '{"PROJECT@odata.bind":"odata/{PROJECT}","CREATED_BY@odata.bind":"odata/{EMPLOYEE}","LOCATION@odata.bind":"odata/{LOCATION}","EXPERIMENT_SAMPLE_REFS@odata.bind":"odata/{EXPERIMENT_SAMPLE}","LIST_MEMBER_REFS@odata.bind":"odata/{LIST_MEMBER}","QUEUE_MEMBER_REFS@odata.bind":"odata/{QUEUE_MEMBER}"}',
      type: 'JSON',
    },
  ],
  key: 'AURORA-tf-tenant/tf-task-template/corelims-eln-apr17-dsbu-cloud/GET_EDIT_EVENT/tf-version-1',
  system: 'corelims-eln-apr17-dsbu-cloud',
});
/* eslint-disable @typescript-eslint/naming-convention */
const BLANK_TEMPLATE = Object.freeze({
  templateKey: 'Blank Manual Task',
  taskName: 'Blank Manual Task',
  taskType: 'Manual',
  inputVariablesNames: [],
  outputVariablesNames: [],
  createdById: null,
  description: 'Build a form or instructions',
  variables: [],
  key: 'Blank Manual Task',
  system: '-',
});
/* eslint-enable @typescript-eslint/naming-convention */

describe('TaskInputsComponent', () => {
  let component: TaskInputsComponent;
  let fixture: ComponentFixture<TaskInputsComponent>;

  const changeTempVariableNameValue = (value: string): void => {
    fixture.debugElement.query(By.css('input[formControlName=tempVariableName]')).nativeElement.value = value;
    fixture.debugElement.query(By.css('input[formControlName=tempVariableName]')).nativeElement.dispatchEvent(new Event('input'));
    component.addInputForm.markAsTouched();
    fixture.detectChanges();
  };

  const checkErrorMessage = (expectedErrorMessage: string): void => {
    fixture.debugElement.query(By.css('button')).nativeElement.dispatchEvent(new Event('click'));
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div.text-danger')).nativeElement.textContent).toContain(expectedErrorMessage);
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskInputsComponent, MappingFieldsComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        FormsModule,
        AlertsModule,
        ButtonModule,
        DropdownsModule,
        InputFieldsModule,
        CheckboxModule,
        AccordionsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskInputsComponent);
    component = fixture.componentInstance;

    spyOn(component.updateForm, 'emit');
    spyOn(component.removeFromForm, 'emit');

    component.task = {
      open: true,
      element: {
        $type: ElementType.Task,
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [],
            },
          ],
        },
      },
      elementType: ElementType.Task,
      shape: {},
      id: 'test',
    };
    component.data = Object.create(ACTION_TEMPLATE);
    component.form = new FormGroup({});
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show info alert for actions with input variables', () => {
    component.data = Object.create(ACTION_TEMPLATE);
    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-alerts')).nativeElement.innerText).toContain(
      'Informational: Input variables represent the information needed to execute the task.' +
        `
` +
        // eslint-disable-next-line max-len
        'If an input variable is not mapped to a variable available in the workflow, the variable will require user input and a form field will be configured in the next step.'
    );
  });

  it('should show info alert for actions without input variables', () => {
    component.data = Object.create(BLANK_TEMPLATE);
    component.ngOnInit();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-alerts')).nativeElement.innerText).toContain(
      'Informational: Input variables represent the information needed to execute the task.'
    );
  });

  it('should display user input variables', () => {
    component.data = Object.create({
      ...ACTION_TEMPLATE,
      inputVariablesNames: '',
    });
    component.customInputVariables = ['inputVar'];
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).length).toBe(3);
  });

  it('should have disabled button with empty input', () => {
    const button = fixture.debugElement.query(By.css('button[kmdPrimaryButton]'));

    expect(button.nativeElement.disabled).toBeTruthy();
    component.addInputForm.controls.tempVariableName.setValue('');
    fixture.detectChanges();

    expect(button.nativeElement.disabled).toBeTruthy();
  });

  it('should enable button when input has value', () => {
    const button = fixture.debugElement.query(By.css('button[kmdPrimaryButton]'));

    expect(button.nativeElement.disabled).toBeTruthy();
    component.addInputForm.controls.tempVariableName.setValue('input name');
    fixture.detectChanges();

    expect(button.nativeElement.disabled).toBeFalsy();
  });

  it('should add user input to display', () => {
    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).length).toBe(2);
    fixture.debugElement.query(By.css('input[type=text]')).nativeElement.value = 'sampleVar';
    fixture.debugElement.query(By.css('input[type=text]')).nativeElement.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    fixture.debugElement.query(By.css('button')).nativeElement.click();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).length).toBe(3);
  });

  it('should not have any errors by default', () => {
    expect(fixture.debugElement.query(By.css('div.text-danger'))).toBeFalsy();
  });

  it('should show error when user inputs tf_ prefix', async(() => {
    changeTempVariableNameValue('tf_sampleVar');
    checkErrorMessage('tf_ prefix is not allowed');
  }));

  it('should show error when user inputs special characters', async(() => {
    changeTempVariableNameValue('test!@#');
    checkErrorMessage('Contain special characters');
  }));

  it('should show error when user inputs numbers as prefix', async(() => {
    changeTempVariableNameValue('123test');
    checkErrorMessage('Start with Numbers');
  }));

  it('should show error when user inputs less than min characters', async(() => {
    changeTempVariableNameValue('a');
    checkErrorMessage('Name must be at least 2 characters');
  }));

  it('should show error when user inputs more than max characters', async(() => {
    changeTempVariableNameValue('test1234567test1234567test1234567test1234567test1234567');
    checkErrorMessage('Name must be no more than 50 characters');
  }));

  it('should not show error when user inputs a space at the end', async(() => {
    changeTempVariableNameValue('newVariable ');

    expect(fixture.debugElement.query(By.css('div.text-danger'))).toBeFalsy();
  }));

  it('should show error when user inputs a tab in between words', async(() => {
    changeTempVariableNameValue('new\tVariable');
    checkErrorMessage('Contain spaces');
  }));

  it('should not show error when user inputs a tab at the beginning', async(() => {
    changeTempVariableNameValue('\tnew Variable');

    expect(fixture.debugElement.query(By.css('div.text-danger'))).toBeFalsy();
  }));

  it('should not show error when user inputs a tab at the end', async(() => {
    changeTempVariableNameValue('new Variable\t');

    expect(fixture.debugElement.query(By.css('div.text-danger'))).toBeFalsy();
  }));

  it('should not show error when user inputs variable name with space', async(() => {
    changeTempVariableNameValue('var1 and var2');

    expect(fixture.debugElement.query(By.css('div.text-danger'))).toBeFalsy();
  }));

  it('should not update form with bpmn values', () => {
    spyOn(component, 'updateParentForm');

    expect(component.form.value).toEqual({});
    component.task = {
      open: true,
      element: {
        $type: ElementType.Task,
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [
                {
                  $type: ElementType.Property,
                  name: CamundaServerVariable.TaskInputMapping,
                  value: '{ "sampleVar": { "output": "b" } }',
                },
              ],
            },
          ],
        },
      },
      elementType: ElementType.Task,
      shape: {},
      id: 'test',
    };
    component.ngOnInit();

    expect(component.updateParentForm).not.toHaveBeenCalled();
  });

  it('should load user input values from bpmn', () => {
    component.task = {
      open: true,
      element: {
        $type: ElementType.Task,
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [
                {
                  $type: ElementType.Property,
                  name: CamundaServerVariable.TaskInputMapping,
                  value: '{ "sampleVar": { "output": {}, "type": "mandatory" }, "inputVar": { "output": {}, "type": "mandatory" } }',
                },
              ],
            },
          ],
        },
      },
      elementType: ElementType.Task,
      shape: {},
      id: 'test',
    };
    component.ngOnInit();

    expect(component.updateForm.emit).toHaveBeenCalled();
    expect(component.savedValues).toEqual({
      sampleVar: { output: {}, type: InputType.Mandatory },
      inputVar: { output: {}, type: InputType.Mandatory },
    });
  });

  it('should show mandatory inputs', () => {
    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).length).toBe(2);
    expect(component.mandatoryInputVariables).toEqual(['inputVar3', 'inputVarSelect']);
  });

  it('should show optional inputs', () => {
    expect(fixture.debugElement.queryAll(By.css('#optionalInputs kmd-accordion .row')).length).toBe(6);
    expect(component.optionalInputVariables).toEqual([
      'inputVar2',
      'inputVar4',
      'inputVarSelect3',
      'inputVarSelect4',
      'inputVar',
      'inputVarSelect2',
    ]);
  });

  it('should add optional inputs', () => {
    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).length).toBe(2);
    expect(fixture.debugElement.queryAll(By.css('#optionalInputs a')).length).toBe(6);
    fixture.debugElement.query(By.css('#optionalInputs a')).nativeElement.dispatchEvent(new Event('click'));
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).length).toBe(3);
    expect(fixture.debugElement.queryAll(By.css('#optionalInputs a')).length).toBe(5);
  });

  it('should show remove for optional input', () => {
    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).every((node) => node.context.userDefined)).toBeFalse();
    fixture.debugElement.query(By.css('#optionalInputs a')).nativeElement.dispatchEvent(new Event('click'));
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('app-mapping-fields')).filter((node) => node.context.userDefined).length).toBe(1);
  });
});
