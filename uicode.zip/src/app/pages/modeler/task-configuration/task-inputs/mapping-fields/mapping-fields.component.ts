import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subject } from 'rxjs';

import { CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import { GenericFormControls } from '../../../shared/form-controls';
import { CustomValidators } from 'src/app/pages/shared/custom-validators';
import { TaskData, InputType } from '../../task-data';

@Component({
  selector: 'app-mapping-fields',
  templateUrl: './mapping-fields.component.html',
  styleUrls: ['./mapping-fields.component.scss'],
})
export class MappingFieldsComponent implements OnInit, OnDestroy {
  @Input() savedValue: TaskData['input']['key'];
  @Input() variableName = '';
  @Input() userDefined = false;
  @Input() outputVariables: any[] = [];
  @Input() inputType: InputType;
  @Output() updateForm = new EventEmitter<GenericFormControls>();
  @Output() removeChange = new EventEmitter<string>();

  toggleReferenceEntity = new FormGroup({
    toggle: new FormControl({
      value: false,
      disabled: true,
    }),
  });
  showTaskEntityFields = false;
  taskEntityApiOptions = [
    {
      name: 'Text Only',
      value: 'manual',
      endpoint: '',
    },
    {
      name: 'CoreLims Hyperlink',
      value: 'embedded',
      endpoint: '{{TF_PFS}}/corelims?cmd=get-barcode&headerBarcode={{tf_backingEntityIdentifiersPlaceholder}}&headerEntityType=0',
    },
  ];
  taskEntityOption = new FormControl(this.taskEntityApiOptions[0]);
  formData = new FormGroup({
    output: new FormControl({}),
    type: new FormControl(''),
  });

  readonly camundaServerVariable = CamundaServerVariable;

  private unsubscribe = new Subject<void>();

  ngOnInit(): void {
    this.formData.controls.type.setValue(this.inputType);
    if (this.savedValue?.output?.name) {
      this.toggleReferenceEntity.controls.toggle.enable();
      this.formData.controls.output.setValue(this.savedValue?.output);
    }
    if (this.savedValue?.[CamundaServerVariable.BackingEntityLabel]) {
      this.formData.addControl(
        CamundaServerVariable.BackingEntityLabel,
        new FormControl(this.savedValue[CamundaServerVariable.BackingEntityLabel])
      );
      this.formData.addControl(
        CamundaServerVariable.BackingEntityType,
        new FormControl(this.savedValue[CamundaServerVariable.BackingEntityType])
      );
      this.formData.addControl(
        CamundaServerVariable.BackingEntityEndpoint,
        new FormControl(this.savedValue[CamundaServerVariable.BackingEntityEndpoint])
      );
      this.toggleReferenceEntity.controls.toggle.setValue(true);
      this.taskEntityOption.setValue(
        this.taskEntityApiOptions.find((item) => item.value === this.savedValue[CamundaServerVariable.BackingEntityType])
      );
      this.showTaskEntityFields = true;
    }
    this.updateParentForm();
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  removeInput(): void {
    this.formData.removeControl('output');
    if (this.showTaskEntityFields) {
      this.removeBackingEntityFields();
    }
    this.removeChange.emit(this.variableName);
  }

  enableToggle(): void {
    this.toggleReferenceEntity.controls.toggle.enable();
    this.updateParentForm();
  }

  toggleTaskEntityFields(): void {
    const showFields = !this.showTaskEntityFields;
    if (showFields) {
      this.formData.addControl(
        CamundaServerVariable.BackingEntityLabel,
        new FormControl('', [Validators.required, CustomValidators.notBlank])
      );
      this.formData.addControl(CamundaServerVariable.BackingEntityType, new FormControl(this.taskEntityOption.value));
      this.formData.addControl(CamundaServerVariable.BackingEntityEndpoint, new FormControl(null));
    } else {
      this.removeBackingEntityFields();
    }
    // Can't show form until it's been created above
    this.showTaskEntityFields = showFields;
    this.updateParentForm();
  }

  onTaskEntityApi(event: { name: string; value: string; endpoint: string }): void {
    this.formData.patchValue({
      [CamundaServerVariable.BackingEntityType]: event.value,
      [CamundaServerVariable.BackingEntityEndpoint]: event.endpoint,
    });
    this.updateParentForm();
  }

  updateParentForm(): void {
    this.updateForm.emit({
      [this.variableName]: new FormGroup(this.formData.controls),
    });
  }

  private removeBackingEntityFields(): void {
    this.formData.removeControl(CamundaServerVariable.BackingEntityLabel);
    this.formData.removeControl(CamundaServerVariable.BackingEntityType);
    this.formData.removeControl(CamundaServerVariable.BackingEntityEndpoint);

    this.updateParentForm();
  }
}
