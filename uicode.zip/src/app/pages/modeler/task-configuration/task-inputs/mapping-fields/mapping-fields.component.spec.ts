import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DropdownsModule, CheckboxModule, InputFieldsModule } from 'gds-atom-components';

import { MappingFieldsComponent } from './mapping-fields.component';
import { CamundaServerVariable } from 'src/app/pages/shared/camunda-variable';
import { InputType } from '../../task-data';

describe('MappingFieldsComponent', () => {
  let component: MappingFieldsComponent;
  let fixture: ComponentFixture<MappingFieldsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MappingFieldsComponent],
      imports: [ReactiveFormsModule, FormsModule, CheckboxModule, DropdownsModule, InputFieldsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MappingFieldsComponent);
    component = fixture.componentInstance;
    component.variableName = 'inputVar';
    component.outputVariables = [{ name: 'b' }];
    component.inputType = InputType.Mandatory;
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have task checkbox disabled', () => {
    expect(component.toggleReferenceEntity.controls.toggle.disabled).toBe(true);
  });

  it('should enable task checkbox after dropdown vaue is selected', () => {
    expect(component.toggleReferenceEntity.controls.toggle.disabled).toBe(true);
    component.enableToggle();

    expect(component.toggleReferenceEntity.controls.toggle.disabled).toBe(false);
  });

  it('should add reference fields when checkbox checked', () => {
    expect(fixture.debugElement.queryAll(By.css('kmd-dropdown, input[kmdFormInput]')).length).toBe(1);
    component.toggleReferenceEntity.controls.toggle.enable();
    fixture.detectChanges();
    fixture.debugElement.query(By.css('input[type=checkbox]')).nativeElement.click();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('kmd-dropdown, input[kmdFormInput]')).length).toBe(3);
  });

  it('should have Text Only option as default', () => {
    expect(component.taskEntityOption.value).toEqual({
      name: 'Text Only',
      value: 'manual',
      endpoint: '',
    });
  });

  it('should add reference form controls when checkbox checked', () => {
    expect(component.formData.value).toEqual({
      output: {},
      type: InputType.Mandatory,
    });
    component.toggleReferenceEntity.controls.toggle.enable();
    fixture.detectChanges();
    fixture.debugElement.query(By.css('input[type=checkbox]')).nativeElement.click();

    expect(component.formData.value).toEqual({
      output: {},
      type: InputType.Mandatory,
      [CamundaServerVariable.BackingEntityLabel]: '',
      [CamundaServerVariable.BackingEntityType]: { name: 'Text Only', value: 'manual', endpoint: '' },
      [CamundaServerVariable.BackingEntityEndpoint]: null,
    });
  });

  it('should remove reference form controls when checkbox is toggled', () => {
    component.toggleReferenceEntity.controls.toggle.enable();
    fixture.detectChanges();
    fixture.debugElement.query(By.css('input[type=checkbox]')).nativeElement.click();

    expect(component.formData.value).toEqual({
      output: {},
      [CamundaServerVariable.BackingEntityLabel]: '',
      [CamundaServerVariable.BackingEntityType]: { name: 'Text Only', value: 'manual', endpoint: '' },
      [CamundaServerVariable.BackingEntityEndpoint]: null,
      type: InputType.Mandatory,
    });
    fixture.debugElement.query(By.css('input[type=checkbox]')).nativeElement.click();

    expect(component.formData.value).toEqual({
      output: {},
      type: InputType.Mandatory,
    });
  });

  it('should show removal', () => {
    expect(fixture.debugElement.query(By.css('span.link'))).toBeFalsy();
    component.userDefined = true;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('span.link'))).toBeTruthy();
  });

  it('should remove form control for input', () => {
    expect(component.formData.value).toEqual({
      output: {},
      type: InputType.Mandatory,
    });
    component.userDefined = true;
    fixture.detectChanges();
    fixture.debugElement.query(By.css('span.link')).nativeElement.dispatchEvent(new Event('click'));
    fixture.detectChanges();

    expect(component.formData.value).toEqual({ type: InputType.Mandatory });
  });

  it('should preload saved value into form', () => {
    expect(component.formData.value).toEqual({
      output: {},
      type: InputType.Mandatory,
    });
    component.savedValue = {
      output: { name: 'b', value: '' },
      [CamundaServerVariable.BackingEntityEndpoint]: null,
      [CamundaServerVariable.BackingEntityLabel]: 'test',
      [CamundaServerVariable.BackingEntityType]: 'manual',
      type: InputType.Mandatory,
    };
    component.ngOnInit();

    expect(component.formData.value).toEqual({
      output: { name: 'b', value: '' },
      [CamundaServerVariable.BackingEntityEndpoint]: null,
      [CamundaServerVariable.BackingEntityLabel]: 'test',
      [CamundaServerVariable.BackingEntityType]: 'manual',
      type: InputType.Mandatory,
    });
  });
});
