import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { RadioButtonModule, CheckboxModule } from 'gds-atom-components';

import { TaskDetailComponent } from './task-detail.component';
import { ElementType } from '../../element-type';
import { CamundaServerVariable } from '../../../shared/camunda-variable';

describe('TaskDetailComponent', () => {
  let component: TaskDetailComponent;
  let fixture: ComponentFixture<TaskDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaskDetailComponent],
      imports: [FormsModule, ReactiveFormsModule, RadioButtonModule, CheckboxModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskDetailComponent);
    component = fixture.componentInstance;
    component.task = {
      open: true,
      elementType: ElementType.Task,
      shape: {},
      id: 'Task:1234',
      element: {
        name: 'test task',
        $type: ElementType.Task,
        incoming: [],
        documentation: [
          {
            text: 'description of test task',
            $type: ElementType.Documentation,
            incoming: [],
          },
        ],
        extensionElements: {
          $type: ElementType.ExtensionElements,
          values: [
            {
              $type: ElementType.Properties,
              values: [
                {
                  $type: ElementType.Property,
                  name: CamundaServerVariable.Priority,
                  value: '76',
                },
                {
                  $type: ElementType.Property,
                  name: CamundaServerVariable.QueueTimeHours,
                  value: '1',
                },
                {
                  $type: ElementType.Property,
                  name: CamundaServerVariable.ExecutionTimeHours,
                  value: '2',
                },
                {
                  $type: ElementType.Property,
                  name: CamundaServerVariable.OverrideBusinessHours,
                  value: 'true',
                },
              ],
            },
          ],
        },
      },
    };
    component.enforceDueDates = true;
    component.form = new FormGroup({});
    component.updateForm.subscribe({
      next: (controls) => {
        Object.keys(controls).forEach((field) => {
          component.form.setControl(field, controls[field]);
        });
      },
    });
    component.ngOnChanges();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display name field', () => {
    expect(fixture.debugElement.query(By.css('input[name=taskName]'))).toBeTruthy();
  });

  it('should display description field', () => {
    expect(fixture.debugElement.query(By.css('input[name=taskDescription]'))).toBeTruthy();
  });

  it('should display priority field', () => {
    expect(fixture.debugElement.queryAll(By.css('input[name=taskPriority]')).length).toBe(4);
  });

  it('should display enforce date fields', () => {
    expect(fixture.debugElement.queryAll(By.css('input[type=number], input[type=checkbox]')).length).toBe(3);
  });

  it('should hide enforce date fields', () => {
    component.enforceDueDates = false;
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('input[type=number], input[type=checkbox]')).length).toBe(0);
  });

  it('should create form control for Name field', () => {
    expect(component.form.get('name')).toBeTruthy();
  });

  it('should create form control for Description field', () => {
    expect(component.form.get('description')).toBeTruthy();
  });

  it('should create form control for Priority field', () => {
    expect(component.form.get('priority')).toBeTruthy();
  });

  it('should create form control for due date fields', () => {
    expect(component.form.get('queueTime')).toBeTruthy();
  });

  it('should populate name field value', () => {
    expect(fixture.debugElement.query(By.css('input[name=taskName]')).nativeElement.value).toBe('test task');
  });

  it('should populate description field value', () => {
    expect(fixture.debugElement.query(By.css('input[name=taskDescription]')).nativeElement.value).toBe('description of test task');
  });

  it('should populate priority field value', () => {
    expect(component.form.get('priority').value).toBe('76');
  });

  it('should populate queue time field value', () => {
    expect(component.form.get('queueTime').value).toBe('1');
  });

  it('should populate execution time field value', () => {
    expect(component.form.get('executionTime').value).toBe('2');
  });

  it('should populate override field value', () => {
    expect(component.form.get('overrideBusinessHours').value).toBe('true');
  });
});
