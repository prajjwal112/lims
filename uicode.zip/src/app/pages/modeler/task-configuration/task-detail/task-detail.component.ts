import { Component, Input, Output, EventEmitter, OnInit, OnChanges, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil, debounceTime } from 'rxjs/operators';
import { cloneDeep, isEqual } from 'lodash';

import { ConfigurationType } from '../../configuration-type';
import { getExtensionProperty } from '../../shared/bpmnExtensionProperty';
import { CamundaServerVariable } from '../../../shared/camunda-variable';
import { GenericFormControls } from '../../shared/form-controls';

enum DetailField {
  Name = 'name',
  Description = 'description',
  Priority = 'priority',
  QueueTime = 'queueTime',
  ExecutionTime = 'executionTime',
  OverrideBusinessHours = 'overrideBusinessHours',
}

const FORM_MIN_PROPERTIES_LENGTH = 3;

@Component({
  selector: 'app-task-detail',
  templateUrl: './task-detail.component.html',
  styleUrls: ['./task-detail.component.scss'],
})
export class TaskDetailComponent implements OnInit, OnChanges, OnDestroy {
  @Input() enforceDueDates: boolean;
  @Input() task: ConfigurationType;
  @Input() form: FormGroup;
  @Output() updateForm = new EventEmitter<GenericFormControls>();

  detailForm = new FormGroup({});

  private unsubscribe = new Subject<void>();

  ngOnInit(): void {
    this.detailForm.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged((first, second) => isEqual(first, second)),
        takeUntil(this.unsubscribe)
      )
      .subscribe({
        next: () => {
          this.updateForm.emit(this.detailForm.controls);
        },
      });
    this.updateForm.emit(this.detailForm.controls);
  }

  ngOnChanges(): void {
    if (Object.keys(this.form.controls).length >= FORM_MIN_PROPERTIES_LENGTH) {
      this.detailForm = cloneDeep(this.form);
    } else {
      this.detailForm.setControl(DetailField.Name, new FormControl('', [Validators.required]));
      if (!this.form.get(DetailField.Description) || !this.form.get(DetailField.Priority)) {
        this.detailForm.setControl(DetailField.Description, new FormControl('', [Validators.required]));
        this.detailForm.setControl(DetailField.Priority, new FormControl('', [Validators.required]));
        if (this.enforceDueDates) {
          this.detailForm.setControl(DetailField.QueueTime, new FormControl('', [Validators.required]));
          this.detailForm.setControl(DetailField.ExecutionTime, new FormControl('', [Validators.required]));
          this.detailForm.setControl(DetailField.OverrideBusinessHours, new FormControl(''));
        }
      }
    }

    if (this.task.element.name) {
      this.detailForm.controls[DetailField.Name].setValue(this.task.element.name);
    }

    if (this.task.element.documentation) {
      this.detailForm.controls[DetailField.Description].setValue(this.task.element.documentation[0].text);
    }
    if (this.task.element.extensionElements) {
      this.detailForm.controls[DetailField.Priority].setValue(
        getExtensionProperty(CamundaServerVariable.Priority, this.task.element.extensionElements)
      );

      if (this.enforceDueDates) {
        this.detailForm.controls[DetailField.QueueTime].setValue(
          getExtensionProperty(CamundaServerVariable.QueueTimeHours, this.task.element.extensionElements)
        );
        this.detailForm.controls[DetailField.ExecutionTime].setValue(
          getExtensionProperty(CamundaServerVariable.ExecutionTimeHours, this.task.element.extensionElements)
        );
        this.detailForm.controls[DetailField.OverrideBusinessHours].setValue(
          getExtensionProperty(CamundaServerVariable.OverrideBusinessHours, this.task.element.extensionElements)
        );
      }
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
