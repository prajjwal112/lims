export enum ElementType {
  Task = 'bpmn:Task',
  UserTask = 'bpmn:UserTask',
  CallActivity = 'bpmn:CallActivity',
  ParallelGateway = 'bpmn:ParallelGateway',
  ExclusiveGateway = 'bpmn:ExclusiveGateway',
  InclusiveGateway = 'bpmn:InclusiveGateway',
  SequenceFlow = 'bpmn:SequenceFlow',
  Documentation = 'bpmn:Documentation',
  FormalExpression = 'bpmn:FormalExpression',
  ExtensionElements = 'bpmn:ExtensionElements',
  Properties = 'camunda:Properties',
  Property = 'camunda:Property',
}
