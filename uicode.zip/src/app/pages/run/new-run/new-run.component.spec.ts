import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { ModalsModule, AlertsModule, ButtonModule, InputFieldsModule, FiltersModule, RadioButtonModule } from 'gds-atom-components';
import { NewRunComponent } from './new-run.component';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DueDateLabelModule } from '../../shared/due-date-label/due-date-label.module';
import { ValidationErrorsModule } from '../../shared/validation-errors/validation-errors.module';
import { WorkflowDefinitionService } from '../../../core/api/workflow-definition/workflow-definition.service';
import { ModalId } from '../../shared/modal-id';
import type { FilteredWorkflowDefinition, WorkflowDefinitionDetail } from '../../workflow-definitions/shared/workflow-definition';

describe('NewRunComponent', () => {
  let component: NewRunComponent;
  let fixture: ComponentFixture<NewRunComponent>;
  let workflowDefinitionService: WorkflowDefinitionService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NewRunComponent],
      providers: [WorkflowDefinitionService],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        HttpClientTestingModule,
        ReactiveFormsModule,
        RouterTestingModule,
        AlertsModule,
        ButtonModule,
        FiltersModule,
        InputFieldsModule,
        ModalsModule,
        RadioButtonModule,
        DueDateLabelModule,
        WorkflowPipeModule,
        ValidationErrorsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewRunComponent);
    component = fixture.componentInstance;
    workflowDefinitionService = TestBed.inject(WorkflowDefinitionService);

    const sampleWorkflowDefinition: FilteredWorkflowDefinition = {
      id: '0',
      name: 'Workflow name',
      referenceId: 0,
      description: '',
      projects: [{ id: 1, name: 'Project name' }],
      trackDueDate: true,
      active: true,
      lastUpdate: '2020-02-11T11:00:00',
    };
    const workflowDefinitionDetail: WorkflowDefinitionDetail = {
      id: sampleWorkflowDefinition.id,
      name: sampleWorkflowDefinition.name,
      archived: false,
      estimatedCompletionDate: sampleWorkflowDefinition.lastUpdate,
      projects: sampleWorkflowDefinition.projects.slice(),
    };

    spyOn(workflowDefinitionService, 'filterWorkflowDefinitions').and.returnValue(of([sampleWorkflowDefinition]));
    spyOn(workflowDefinitionService, 'getWorkflowDefinitionDetail').and.returnValue(of(workflowDefinitionDetail));
    component.workflowRunData = sampleWorkflowDefinition;
    fixture.detectChanges();
    // eslint-disable-next-line dot-notation
    component['kmdModalService'].open(ModalId.NewRun);
    fixture.detectChanges();

    component.ngOnInit();
    component.onModelChange('runName', '123456');
    component.onModelChange('priorityName', '100');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the closeModal method called when cancel button is clicked on', () => {
    spyOn(component, 'closeModal');
    fixture.debugElement.query(By.css('#cancelButton')).nativeElement.click();
    fixture.detectChanges();

    expect(component.closeModal).toHaveBeenCalledWith(ModalId.NewRun);
  });

  it('should have close icon button exist in the form', () => {
    expect(fixture.debugElement.query(By.css('.kmd-icon-close-mono')).nativeElement).toBeTruthy();
  });

  it('should have cancel button enabled when modal is opened', () => {
    expect(fixture.debugElement.query(By.css('#cancelButton')).nativeElement.disabled).toBe(false);
  });

  it('should have due date when definition is configured for due dates', () => {
    const dateText = fixture.debugElement.query(By.css('app-date-label')).nativeElement.textContent.trim();

    expect(new Date(dateText).toLocaleString('en-US', { timeZone: 'America/New_York' })).toBe('2/11/2020, 6:00:00 AM');
  });

  it('should have default message for due date when definition is not selected', () => {
    component.selectedWorkflowDetail = null;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.text-muted')).nativeElement.textContent.trim()).toBe(
      'Select a workflow to calculate due date.'
    );
  });

  it('should have message for unconfigured due dates when definition is not configured for due dates', () => {
    delete component.selectedWorkflowDetail.estimatedCompletionDate;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div')).nativeElement.textContent).toContain(
      'The selected workflow is not configured to track due dates.'
    );
  });

  describe('action buttons', () => {
    it('should have confirm button disabled when no workflow is provided', () => {
      component.onModelChange('workflowDefinition', null);
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('#confirmButton')).nativeElement.disabled).toBe(true);
    });

    describe('run name validation', () => {
      const invalidValues = [
        'a'.repeat(51),
        '',
        ' ',
        '@test',
        'tf-tenant',
        'tf-global-tenant',
        'tf-workflow-definition-template',
        'tf-task-template',
      ];
      invalidValues.forEach((test) => {
        it(`should fail for '${test}' value`, () => {
          const runName = component.startWorkflowRun.get('runName');
          runName.setValue(test);

          expect(runName.valid).toBeFalse();
        });
      });

      it('should have confirm button disabled when invalid run name is provided', () => {
        component.onModelChange('runName', '');

        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('#confirmButton')).nativeElement.disabled).toBe(true);
      });
    });

    it('should have confirm button disabled when blank run name is provided', () => {
      component.onModelChange('runName', ' ');

      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('#confirmButton')).nativeElement.disabled).toBe(true);
    });

    it('should have confirm button disabled when no project is provided', () => {
      component.onModelChange('projectName', null);

      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('#confirmButton')).nativeElement.disabled).toBe(true);
    });

    it('should have confirm button enabled when priority is null because default priority is null', () => {
      component.onModelChange('priorityName', null);
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('#confirmButton')).nativeElement.disabled).toBe(false);
    });

    it('should have confirm button enabled when all fields are filled out correctly', () => {
      expect(fixture.debugElement.query(By.css('#confirmButton')).nativeElement.disabled).toBe(false);
    });
  });

  describe('project field', () => {
    const fieldIsEnabled = (): boolean =>
      !fixture.debugElement.query(By.css('#project')).query(By.css('.kmd-multi-select-dropdown')).classes['kmd-disable-drop-down'];

    const getPlaceHolderText = (): string =>
      fixture.debugElement.query(By.css('#project')).query(By.css('.kmd-multi-select-placeholder')).nativeElement.textContent.trim();

    it('should be enabled when a workflow with projects is selected', () => {
      expect(fieldIsEnabled()).toBe(true);
    });

    it('should be disabled when no workflow is selected', () => {
      component.selectedWorkflowDetail = null;
      fixture.detectChanges();

      expect(fieldIsEnabled()).toBe(false);
    });

    it('should be disabled when a workflow with missing projects is selected', () => {
      delete component.selectedWorkflowDetail.projects;
      fixture.detectChanges();

      expect(fieldIsEnabled()).toBe(false);
    });

    it('should be disabled when a workflow with zero projects is selected', () => {
      component.selectedWorkflowDetail.projects = [];
      fixture.detectChanges();

      expect(fieldIsEnabled()).toBe(false);
    });

    it('should clear when Workflow Definition changed', fakeAsync(() => {
      const project = [component.selectedWorkflowDetail.projects[0]];
      component.projectData = project;
      component.startWorkflowRun.get('projectName').setValue(project);

      expect(component.projectData).toEqual(project);
      expect(component.startWorkflowRun.get('projectName').value).toEqual(project);

      component.onWorkflowDefinitionChange(component.workflows[0]);

      tick(10000);
      fixture.detectChanges();

      expect(workflowDefinitionService.getWorkflowDefinitionDetail).toHaveBeenCalledWith(component.selectedWorkflowDetail.id);
      expect(component.projectData).toEqual([]);
      expect(component.startWorkflowRun.get('projectName').value).toBeNull();
    }));

    it('should clear when Workflow Definition resets', () => {
      const project = [component.selectedWorkflowDetail.projects[0]];
      component.projectData = project;
      component.startWorkflowRun.get('projectName').setValue(project);

      expect(component.projectData).toEqual(project);
      expect(component.startWorkflowRun.get('projectName').value).toEqual(project);

      component.onWorkflowDefinitionReset();

      fixture.detectChanges();

      expect(component.projectData).toEqual([]);
      expect(component.startWorkflowRun.get('projectName').value).toBeNull();
    });

    // TODO: below default label tests will go away with tooltip UX
    it('should show proper default label for when workflow with projects is selected', () => {
      expect(getPlaceHolderText()).toMatch(/Select applicable Project\(s\).*/);
    });

    it('should show proper default label for when no workflow is selected', () => {
      component.selectedWorkflowDetail = null;
      fixture.detectChanges();

      expect(getPlaceHolderText()).toMatch(/Select a Workflow Definition.*/);
    });

    it('should show proper default label for when workflow with missing projects is selected', () => {
      delete component.selectedWorkflowDetail.projects;
      fixture.detectChanges();

      expect(getPlaceHolderText()).toMatch(/Selected definition has no associated projects.*/);
    });

    it('should show proper default label for when workflow with zero projects is selected', () => {
      component.selectedWorkflowDetail.projects = [];
      fixture.detectChanges();

      expect(getPlaceHolderText()).toMatch(/Selected definition has no associated projects.*/);
    });
  });

  describe('workflow data', () => {
    it('should have workflow data loaded', () => {
      expect(component.startWorkflowRun.value).toEqual({
        priorityName: '100',
        projectName: [{ id: 1, name: 'Project name' }],
        runName: '123456',
        workflowDefinition: {
          active: true,
          description: '',
          id: '0',
          lastUpdate: '2020-02-11T11:00:00',
          name: 'Workflow name',
          projects: [{ id: 1, name: 'Project name' }],
          referenceId: 0,
          trackDueDate: true,
        },
      });
    });

    it('should render fields without workflow data', () => {
      component.workflowRunData = null;
      component.ngOnInit();
      fixture.detectChanges();

      expect(
        fixture.debugElement.queryAll(By.css('kmd-dropdown-filter, input.kmd-form-control, kmd-multi-select, input[type=radio]')).length
      ).toBe(8);

      expect(component.startWorkflowRun.value).toEqual({
        priorityName: '',
        projectName: null,
        runName: '',
        workflowDefinition: null,
      });
    });
  });
});
