import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { debounceTime, switchMap, catchError, map, distinctUntilChanged, take } from 'rxjs/operators';
import { isEqual } from 'lodash';
import { KmdModalService } from 'gds-atom-components';
import { WorkflowDefinitionService } from '../../../core/api/workflow-definition/workflow-definition.service';
import { CustomValidators } from '../../shared/custom-validators';
import { WorkflowInstanceService } from '../../workflow-definitions/shared/workflow-instance.service';
import { ModalId } from '../../shared/modal-id';
import type { OnInit } from '@angular/core';
import type { IdNamePair } from '../../shared/id-name-pair';
import type { FilteredWorkflowDefinition, WorkflowDefinitionDetail } from '../../workflow-definitions/shared/workflow-definition';
import type { StartRunResponse } from '../start-run-response';

const MAX_CHARACTERS_FOR_WORKFLOW_RUN_NAME = 50;
const DEFAULT_PRIORITY_VALUE = 0;

@Component({
  selector: 'app-new-run',
  templateUrl: './new-run.component.html',
  styleUrls: ['./new-run.component.scss'],
})
export class NewRunComponent implements OnInit {
  @Input() workflowRunData: FilteredWorkflowDefinition;
  @Output() close = new EventEmitter<void>();

  startWorkflowRun: FormGroup;
  workflows: FilteredWorkflowDefinition[] = [];
  selectedWorkflowDetail: WorkflowDefinitionDetail;
  projectData: WorkflowDefinitionDetail['projects'];
  modelInvalid = true;
  readonly modalId = ModalId;
  readonly missingNameError = NewRunComponent.getMissingErrorMessage('Run name');
  readonly missingWorkflowError = NewRunComponent.getMissingWorkflowDefErrorMessage('Workflow selection');
  readonly missingProjectError = NewRunComponent.getMissingErrorMessage('Project');
  readonly longNameError: string = NewRunComponent.getErrorMessageForExceedingCharactersLimit(
    'Run name',
    MAX_CHARACTERS_FOR_WORKFLOW_RUN_NAME
  );
  workflowDefinitionDropdownClicked = false;
  readonly reservedKeywordErrorMessage = 'Run name can contain alphanumerical characters, spaces, hyphens (-), and underscores (_).';
  readonly duplicateNameErrorMessage = 'A workflow run with this name already exists. Please select a new name.';
  readonly asyncValidatorDebounceTime = 1000;

  constructor(
    private readonly router: Router,
    private readonly kmdModalService: KmdModalService,
    private readonly workflowDefinitionService: WorkflowDefinitionService,
    private readonly workflowInstanceService: WorkflowInstanceService
  ) {}

  private static getMissingErrorMessage(param: string): string {
    return `${param} is required.`;
  }
  private static getMissingWorkflowDefErrorMessage(param: string): string {
    return `${param} is required.`;
  }
  private static getErrorMessageForExceedingCharactersLimit(param: string, max: number): string {
    return `${param} cannot exceed ${max} characters.`;
  }

  ngOnInit(): void {
    this.startWorkflowRun = this.initializeFormControls();
    this.workflowDefinitionService.filterWorkflowDefinitions({ archived: false }).subscribe({
      next: (data: FilteredWorkflowDefinition[]) => {
        this.workflows = data;
        if (this.workflowRunData?.id) {
          const initialWorkflowDefinition = this.workflows.find((idNamePair) => idNamePair.id === this.workflowRunData.id);
          this.onWorkflowDefinitionChange(initialWorkflowDefinition, false);
        }
      },
    });
    this.onFormChanges();
  }

  onSubmit(): void {
    if (this.isModelInvalid()) {
      return;
    }
    this.workflowInstanceService
      .startRun({
        workflowDefinitionId: this.startWorkflowRun.get('workflowDefinition').value.id as string,
        workflowRunName: this.startWorkflowRun.get('runName').value,
        projects: this.startWorkflowRun.get('projectName').value,
        priority: this.startWorkflowRun.get('priorityName').value
          ? +this.startWorkflowRun.get('priorityName').value
          : DEFAULT_PRIORITY_VALUE,
      })
      .subscribe({
        next: (data: StartRunResponse) => {
          this.router.navigate(['/workflow-definitions/run-details', data.workflowInstanceId], { state: { showAlert: true } });
        },
      });
  }

  onFormChanges(): void {
    this.startWorkflowRun
      .get('runName')
      .valueChanges.pipe(distinctUntilChanged((first, second) => isEqual(first, second)))
      .subscribe((val) => {
        this.onModelChange('runName', val);
      });
    this.startWorkflowRun
      .get('projectName')
      .valueChanges.pipe(distinctUntilChanged((first, second) => isEqual(first, second)))
      .subscribe((val) => {
        this.onModelChange('projectName', val);
      });
    this.startWorkflowRun
      .get('priorityName')
      .valueChanges.pipe(distinctUntilChanged((first, second) => isEqual(first, second)))
      .subscribe((val) => {
        this.onModelChange('priorityName', val);
      });
  }

  onWorkflowDefinitionChange(workflowDefinition?: FilteredWorkflowDefinition, shouldClearProject = true): void {
    this.onModelChange('workflowDefinition', workflowDefinition);
    if (!workflowDefinition || Object.keys(workflowDefinition).length === 0) {
      return;
    }
    this.workflowDefinitionService
      .getWorkflowDefinitionDetail(workflowDefinition.id)
      .pipe(take(1))
      .subscribe({
        next: (data: WorkflowDefinitionDetail) => {
          this.selectedWorkflowDetail = data;
          if (shouldClearProject) {
            this.clearProject();
          } else {
            this.projectData = this.workflowRunData.projects?.slice();
            this.startWorkflowRun.controls.projectName.setValue(this.workflowRunData.projects);
          }
        },
      });
  }

  onWorkflowDefinitionReset(): void {
    this.workflowDefinitionDropdownClicked = true;
    this.onModelChange('workflowDefinition', null);
    this.selectedWorkflowDetail = null;
    this.clearProject();
  }

  onModelChange(controlName: 'workflowDefinition' | 'runName' | 'projectName' | 'priorityName', value: any): void {
    this.startWorkflowRun.controls[controlName]?.setValue(value);
    this.modelInvalid = this.isModelInvalid();
    if (this.validateWorkflowDefinition()) {
      this.workflowDefinitionDropdownClicked = false;
    }
  }

  /*
   * TODO: labels referring to fields that are not Project are temporary. they will eventually be removed in favor of tooltip UX.
   *       this method should eventually go away.
   */
  getDefaultLabelForProject(): string {
    if (!this.selectedWorkflowDetail) {
      return 'Select a Workflow Definition';
    }

    return !this.selectedWorkflowDetail.projects || this.selectedWorkflowDetail.projects.length === 0
      ? 'Selected definition has no associated projects'
      : 'Select applicable Project(s)';
  }

  closeModal(id: string): void {
    this.kmdModalService.close(id);
    this.close.emit();
  }

  onProjectsChange(event: { selectedOptions: IdNamePair[] }): void {
    this.startWorkflowRun.patchValue({ projectName: event.selectedOptions });
    this.modelInvalid = this.isModelInvalid();
  }

  onProjectNameReset(): void {
    this.onModelChange('projectName', null);
    this.clearProject();
  }

  publishedNameAsyncValidator(control: AbstractControl): Observable<ValidationErrors | null> {
    return of(control.value).pipe(
      debounceTime(this.asyncValidatorDebounceTime),
      switchMap(() =>
        this.workflowInstanceService.filter({ processInstanceNames: [control.value] }).pipe(
          map((res) => {
            return res.items?.length > 0 ? { duplicatePublishedName: true } : null;
          }),
          catchError((e: HttpErrorResponse) => throwError(e))
        )
      )
    );
  }

  private initializeFormControls(): FormGroup {
    return new FormGroup({
      workflowDefinition: new FormControl(null, [Validators.required]),
      runName: new FormControl(
        '',
        [
          Validators.maxLength(MAX_CHARACTERS_FOR_WORKFLOW_RUN_NAME),
          Validators.required,
          Validators.pattern(CustomValidators.disallowWorkflowNameCharactersPattern),
          CustomValidators.notContainObjectStoreKeywords,
          CustomValidators.notBlank,
        ],
        [this.publishedNameAsyncValidator.bind(this)]
      ),
      projectName: new FormControl(null, [Validators.required]),
      priorityName: new FormControl(''),
    });
  }

  private clearProject(): void {
    this.startWorkflowRun.controls.projectName.setValue(null);
    this.projectData = [];
  }

  private isModelInvalid(): boolean {
    return !this.validateRunName() || !this.validateWorkflowDefinition() || !this.validateProject();
  }

  private validateRunName(): boolean {
    return this.startWorkflowRun.get('runName').value !== '' && !this.startWorkflowRun.controls.runName.errors?.whitespace;
  }

  private validateWorkflowDefinition(): boolean {
    return this.startWorkflowRun.get('workflowDefinition').value !== null;
  }

  private validateProject(): boolean {
    return this.startWorkflowRun.get('projectName').value !== null && this.startWorkflowRun.get('projectName').value.length > 0;
  }
}
