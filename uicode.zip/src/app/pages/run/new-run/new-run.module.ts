import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import {
  ModalsModule,
  AlertsModule,
  ButtonModule,
  KmdModalComponent,
  InputFieldsModule,
  FiltersModule,
  RadioButtonModule,
} from 'gds-atom-components';

import { NewRunComponent } from './new-run.component';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DueDateLabelModule } from '../../shared/due-date-label/due-date-label.module';
import { ValidationErrorsModule } from '../../shared/validation-errors/validation-errors.module';

@NgModule({
  declarations: [NewRunComponent],
  providers: [KmdModalComponent],
  imports: [
    CommonModule,
    ModalsModule,
    ReactiveFormsModule,
    AlertsModule,
    ButtonModule,
    InputFieldsModule,
    FiltersModule,
    RadioButtonModule,
    FormsModule,
    DueDateLabelModule,
    WorkflowPipeModule,
    ValidationErrorsModule,
  ],
  exports: [NewRunComponent],
})
export class NewRunModule {}
