import { ColumnType } from '../../shared/grid/column-type';
import { Status } from '../../shared/status';
import { PriorityType, PriorityNumericRange } from '../../shared/grid/filter/shared/priority-filter';
import { FilterType } from '../../shared/grid/filter/shared/filter-type';
import { FilterRangeField, FilterCategorizedListField } from '../../shared/grid/filter/shared/filter-field';
import { defaultActionPopoverColumn } from '../../shared/grid/popover/action/action-popover';
import type { Column } from '../../shared/grid/column';
import { BASE_OPTIONS, popoverCallback } from '../../shared/popover/task-grid-action-column';

export const DUE_DATE_COLUMN: Readonly<Column> = {
  type: ColumnType.Date,
  field: 'dueDate',
  title: 'Due Date',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.DateRangeFuture,
    field: new FilterRangeField('minDueDate', 'maxDueDate'),
  },
} as const;

export const NAME_COLUMN: Readonly<Column> = {
  type: ColumnType.Link,
  field: 'name',
  title: 'Task',
  width: 100,
  sortable: true,
  filterable: false,
} as const;

export const STATUS_COLUMN: Readonly<Column> = {
  type: ColumnType.Status,
  field: 'status',
  title: 'Status',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.List,
    multiselect: true,
    values: Object.values(Status).map((value) => ({ name: value })),
    keyField: 'name',
    displayField: 'name',
  },
} as const;

export const PRIORITY_COLUMN: Readonly<Column> = {
  type: ColumnType.Priority,
  field: 'priority',
  title: 'Priority',
  width: 100,
  sortable: true,
  filterable: true,
  filter: {
    type: FilterType.RangeList,
    field: new FilterRangeField('minPriority', 'maxPriority'),
    values: Object.values(PriorityType).map((value) => ({ name: value })),
    keyField: 'name',
    displayField: 'name',
    getRange: PriorityNumericRange.getRange,
  },
} as const;

export const ASSIGNEE_COLUMN: Readonly<Column> = {
  type: ColumnType.BlankString,
  field: 'assignees',
  title: 'Assignee',
  width: 100,
  sortable: true,
  filterable: true,
  displayWithField: 'allAssigneeNames',
  filter: {
    type: FilterType.CategorizedList,
    // eslint-disable-next-line @typescript-eslint/naming-convention
    field: new FilterCategorizedListField({ User: 'assigneeWorkflowUserId', Group: 'group' }),
    keyField: 'id',
    displayField: 'name',
    groupField: 'category',
    categoryField: 'category',
  },
} as const;

export const TASK_ACTIONS_COLUMN: Readonly<Column> = {
  ...defaultActionPopoverColumn([...BASE_OPTIONS]),
} as const;
TASK_ACTIONS_COLUMN.popover.callback = popoverCallback(TASK_ACTIONS_COLUMN);

export const COMPLETED_BY_COLUMN: Readonly<Column> = { ...ASSIGNEE_COLUMN, title: 'Completed By' };
