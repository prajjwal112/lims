import { customOrderBy } from './custom-orderby';
import { SortDirection } from '../../shared/sort-direction';

const data = [{ name: 'Tom' }, { name: 'Sam' }, { name: null }, { name: 'Mike' }, { name: 'Alice' }];

describe('customOrderBy', () => {
  it('empty data', () => {
    const result = customOrderBy([], []);

    expect(result).toEqual([]);
  });

  it('sort ascending', () => {
    const result = customOrderBy(data, [{ field: 'name', dir: SortDirection.Ascending }]);

    expect(result).toEqual([{ name: null }, { name: 'Alice' }, { name: 'Mike' }, { name: 'Sam' }, { name: 'Tom' }]);
  });

  it('sort descending', () => {
    const result = customOrderBy(data, [{ field: 'name', dir: SortDirection.Descending }]);

    expect(result).toEqual([{ name: 'Tom' }, { name: 'Sam' }, { name: 'Mike' }, { name: 'Alice' }, { name: null }]);
  });

  it('sort ascending with reverse blanks', () => {
    const result = customOrderBy(data, [{ field: 'name', dir: SortDirection.Ascending }], ['name']);

    expect(result).toEqual([{ name: 'Alice' }, { name: 'Mike' }, { name: 'Sam' }, { name: 'Tom' }, { name: null }]);
  });
});
