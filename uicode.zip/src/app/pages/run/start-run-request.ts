import { IdNamePair } from '../shared/id-name-pair';

export interface StartRunRequest {
  workflowDefinitionId: string;
  workflowRunName: string;
  projects: IdNamePair[];
  priority?: number;
}
