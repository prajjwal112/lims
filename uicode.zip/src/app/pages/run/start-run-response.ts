export interface StartRunResponse {
  workflowInstanceId: string;
}
