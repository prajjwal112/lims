import { Component, ElementRef, ViewChild } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';
import { orderBy, SortDescriptor } from '@progress/kendo-data-query';
import { TaskService } from '../../core/api/task/task.service';
import { Action, ActionType, StoreService } from '../../store.service';
import { AuthService } from '../../auth.service';
import { ProjectService } from '../../core/api/project/project.service';
import { Status } from '../shared/status';
import { SortDirection } from '../shared/sort-direction';
import {
  DUE_DATE_COLUMN,
  END_TIME_COLUMN,
  NAME_COLUMN,
  PRIORITY_COLUMN,
  PROJECT_COLUMN,
  STATUS_COLUMN,
  WORKFLOW_NAME_COLUMN,
} from '../task-list/shared/task-grid-columns';
import { GridComponent } from '../shared/grid/grid.component';
import { WorkflowDefinitionService } from '../../core/api/workflow-definition/workflow-definition.service';
import { customOrderBy } from '../task-list/shared/custom-orderby';
import { WorkflowDatePipe } from 'src/app/core/pipe/date/workflow-date.pipe';
import { DateUtility } from '../shared/utility/date-utility';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../shared/common-data-type';
import { ComponentWithModalDirective } from '../shared/component-with-modal.directive';
import { TabKeys, TabValues } from '../shared/tab-name';
import { ModalId } from '../shared/modal-id';
import type { OnDestroy, OnInit } from '@angular/core';
import type { TaskFilterResponse, TaskFilterItemResponse, TaskFilterRequest } from '../task-list/shared/task-filter';
import type { Column } from '../shared/grid/column';
import type { WorkflowStatistic } from '../task-list/workflow-statistic';

@Component({
  selector: 'app-tasks',
  templateUrl: './my-tasks.component.html',
  styleUrls: ['./my-tasks.component.scss', '../shared/page-header.scss'],
  providers: [WorkflowDatePipe],
})
export class MyTasksComponent extends ComponentWithModalDirective implements OnInit, OnDestroy {
  @ViewChild(GridComponent) private grid: GridComponent;
  @ViewChild('mytasks', { read: ElementRef }) private myTasksElementRef: ElementRef;

  tabDataCount: number;
  pageData: TaskFilterItemResponse[] = [];
  sort: SortDescriptor[] = [];
  columns: Column[] = [];
  workflows: WorkflowStatistic[] = [];

  readonly tabKey = TabKeys;
  readonly tabValue = TabValues;
  readonly modalId = ModalId;

  private activeTab: TabKeys = TabKeys.Active;
  private activeTabStatus: Status[];
  private unsubscribe = new Subject<void>();
  private filter: TaskFilterRequest = {};
  private skip: number = DEFAULT_SKIP;
  private top: number = DEFAULT_TOP;
  private fullData: TaskFilterItemResponse[] = [];
  private tabData: TaskFilterItemResponse[] = [];

  constructor(
    protected kmdModalService: KmdModalService,
    private authService: AuthService,
    private taskService: TaskService,
    private workflowDefinitionService: WorkflowDefinitionService,
    private projectService: ProjectService,
    private store: StoreService,
    private workflowDatePipe: WorkflowDatePipe
  ) {
    super(kmdModalService);
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Home' }));
  }

  /**
   * Initializes the component.
   */
  ngOnInit(): void {
    this.initColumns();
    this.getData(this.filter).subscribe({
      next: (response: TaskFilterResponse) => {
        this.fullData = response.items;
        // On initializing we also retrieve workflows information.
        this.getWorkflowStatistics();
        // Refresh data in the current tab and pagination
        this.refreshTabData();
        this.resetPagination();
      },
    });
    this.onTabSelect({ activeId: TabKeys.Upcoming, nextId: TabKeys.Active });
  }

  /**
   * Cleanup the component.
   */
  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  // Events

  onTabSelect(event: { activeId: TabKeys; nextId: TabKeys }): void {
    this.activeTab = event.nextId;

    switch (this.activeTab) {
      case TabKeys.Active:
        // First column will display the Due Date and last column the Assignee
        this.columns = [DUE_DATE_COLUMN, NAME_COLUMN, WORKFLOW_NAME_COLUMN, PROJECT_COLUMN, STATUS_COLUMN, PRIORITY_COLUMN];

        // To Do, In Progress or Blocked status (if not more restrictive filter is applied)
        this.activeTabStatus = [Status.Todo, Status.InProgress, Status.Blocked];

        // Default sort by Priority (descending) and Due Date (ascending)
        this.sort = [
          { field: 'priority', dir: SortDirection.Descending },
          { field: 'dueDate', dir: SortDirection.Ascending },
        ];
        break;

      case TabKeys.Upcoming:
        // First column will display the Due Date and last column the Assignee
        this.columns = [DUE_DATE_COLUMN, NAME_COLUMN, WORKFLOW_NAME_COLUMN, PROJECT_COLUMN, STATUS_COLUMN, PRIORITY_COLUMN];

        // Pending status (if not more restrictive filter is applied)
        this.activeTabStatus = [Status.Pending];

        // Default sort by Priority (descending) and Due Date (ascending)
        this.sort = [
          { field: 'priority', dir: SortDirection.Descending },
          { field: 'dueDate', dir: SortDirection.Ascending },
        ];
        break;

      case TabKeys.History:
        // First column will display the Completion Date and last column the Completed By
        this.columns = [END_TIME_COLUMN, NAME_COLUMN, WORKFLOW_NAME_COLUMN, PROJECT_COLUMN, STATUS_COLUMN, PRIORITY_COLUMN];

        // Completed status (if not more restrictive filter is applied)
        this.activeTabStatus = [Status.Completed];

        // Default sort by Completed Date (descending)
        this.sort = [{ field: 'endTime', dir: SortDirection.Descending }];
        break;
    }

    // Request counter and then the data
    this.refreshTabData();
    this.resetPagination();
  }

  /**
   * Handles the event of the Grid to filter the data.
   * @param {TaskFilterRequest} filter
   */
  onFilterEvent(filter: TaskFilterRequest): void {
    this.filter = Object.assign({}, filter);
    this.getData(this.filter).subscribe({
      next: (response: TaskFilterResponse) => {
        this.fullData = response.items;
        // Refresh data in the current tab and pagination
        this.refreshTabData();
        this.resetPagination();
      },
    });
  }

  /**
   * Handles the event of the Grid to sort the data.
   * @param {SortDescriptor[]} sort
   */
  onSortChanged(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.refreshTabData();
  }

  onPageChanged(): void {
    this.myTasksElementRef.nativeElement.scrollIntoView();
  }

  /**
   * Initializes the grid columns with external data
   */
  private initColumns(): void {
    // Workflows
    this.workflowDefinitionService.filterWorkflowDefinitions().subscribe({
      next: (response) => (WORKFLOW_NAME_COLUMN.filter.values = response),
    });

    this.projectService.filter().subscribe({
      next: (response) => (PROJECT_COLUMN.filter.values = response.items),
    });
  }

  /**
   * Retrieves the data from the backend updating the component and returning
   * the request results.
   * @param {TaskFilterRequest} filterRequest
   * @returns {Observable<TaskFilterResponse>}
   */
  private getData(filterRequest: TaskFilterRequest): Observable<TaskFilterResponse> {
    return this.taskService
      .filter({
        assigneePlatformUserId: this.authService.sessionData.tfsPlatformUserID,
        ...filterRequest,
      })
      .pipe(takeUntil(this.unsubscribe));
  }

  private getWorkflowStatistics(): void {
    this.workflowDefinitionService
      .getStatistics({
        top: 3,
      })
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (workflowData: WorkflowStatistic[]) => {
          // Sort descending by the # of active runs and then by name
          this.workflows = workflowData.slice().sort((a, b) => {
            if (a.activeRunsCount === b.activeRunsCount) {
              return a.name?.toUpperCase()?.localeCompare(b.name?.toUpperCase());
            }
            return b.activeRunsCount - a.activeRunsCount;
          });
        },
      });
  }

  /**
   * Refresh the data displayed in a tab, applying filters and sort.
   */
  private refreshTabData(): void {
    // Apply client filters: Tabs
    this.tabData = this.fullData.filter((item: TaskFilterItemResponse) =>
      this.activeTabStatus.some(
        (status) =>
          item.status.toLowerCase() === status.toLowerCase() &&
          ((status === Status.Blocked && this.activeTab === TabKeys.Upcoming && !item.id) ||
            (status === Status.Blocked && this.activeTab === TabKeys.Active && item.id) ||
            status !== Status.Blocked)
      )
    );

    // Apply default sort and refresh total data count.
    // Note: The History tab is sorted normally but the other two are sorted having in mind the DueDate field.
    this.tabData = this.activeTab === TabKeys.History ? orderBy(this.tabData, this.sort) : this.orderByWithDueDate(this.tabData, this.sort);
    this.tabDataCount = this.tabData.length;

    this.refreshPageData();
  }

  /**
   * Sorts the given data by keeping overdue tasks at the top and then applying the
   * current sort. Also, dueDate is sorted to have the empty dates at the bottom.
   * @param {TaskFilterItemResponse[]} data
   * @param {SortDescriptor[]} sort
   * @returns {TaskFilterItemResponse[]}
   */
  private orderByWithDueDate(data: TaskFilterItemResponse[], sort: SortDescriptor[]): TaskFilterItemResponse[] {
    const [overdueData, onTimeData] = data.reduce(
      ([overdue, onTime], item) => {
        // We use the workflow date pipe to get the "real" date value from the stored value
        if (DateUtility.hasDatePassed(this.workflowDatePipe.transform(item.dueDate))) {
          return [[...overdue, item], onTime];
        } else {
          return [overdue, [...onTime, item]];
        }
      },
      [[], []]
    );

    return [...orderBy(overdueData, sort), ...customOrderBy(onTimeData, sort, ['dueDate'])];
  }

  /**
   * Resets pagination
   */
  private resetPagination(): void {
    this.skip = DEFAULT_SKIP;
    this.top = DEFAULT_TOP;
    if (this.grid) {
      this.grid.resetPagination();
    }
  }

  /**
   * Refresh the data displayed in the current page.
   */
  private refreshPageData(): void {
    this.pageData = this.tabData.slice();
  }
}
