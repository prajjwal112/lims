import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { GaugesModule } from '@progress/kendo-angular-gauges';

import { GridModule } from '../shared/grid/grid.module';

import { MyTasksRoutingModule } from './my-tasks-routing.module';

import { MyTasksComponent } from './my-tasks.component';
import { ModalsModule, ButtonModule, TabsModule } from 'gds-atom-components';
import { NewRunModule } from '../run/new-run/new-run.module';
import { CardsModule } from '../shared/cards/cards.module';
import { DueDateLabelModule } from '../shared/due-date-label/due-date-label.module';
import { DateLabelModule } from '../shared/date-label/date-label.module';

@NgModule({
  declarations: [MyTasksComponent],
  imports: [
    CommonModule,
    MyTasksRoutingModule,
    GridModule,
    LayoutModule,
    GaugesModule,
    CardsModule,
    TabsModule,
    ModalsModule,
    NewRunModule,
    ButtonModule,
    DateLabelModule,
    DueDateLabelModule,
  ],
})
export class MyTasksModule {}
