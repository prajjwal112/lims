import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { GaugesModule } from '@progress/kendo-angular-gauges';

import { GridModule } from '../shared/grid/grid.module';
import { MyTasksComponent } from './my-tasks.component';
import { NewRunModule } from '../run/new-run/new-run.module';
import { CardsModule } from '../shared/cards/cards.module';
import { AuthService } from '../../auth.service';
import { TabsModule } from 'gds-atom-components';
import { By } from '@angular/platform-browser';
import { TabKeys } from '../shared/tab-name';

describe('MyTasksComponent', () => {
  let component: MyTasksComponent;
  let fixture: ComponentFixture<MyTasksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MyTasksComponent],
      imports: [
        GridModule,
        LayoutModule,
        GaugesModule,
        TabsModule,
        CardsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        NewRunModule,
        BrowserAnimationsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyTasksComponent);
    component = fixture.componentInstance;
    spyOnProperty(TestBed.inject(AuthService), 'sessionData').and.returnValue({});
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display `Active, Upcoming, History tabs`', () => {
    expect(fixture.debugElement.query(By.css('kmd-tabs')).nativeElement.textContent.trim()).toMatch(/Active.*Upcoming.*History/);
  });

  it('should use Active tab columns', () => {
    expect(fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[0].nativeElement.getAttribute('id')).toBe(TabKeys.Active);
  });

  it('should use Upcoming tab columns', () => {
    expect(fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[1].nativeElement.getAttribute('id')).toBe(TabKeys.Upcoming);
  });

  it('should use History tab columns', () => {
    expect(fixture.debugElement.queryAll(By.css('kmd-tabs div ul li a'))[2].nativeElement.getAttribute('id')).toBe(TabKeys.History);
  });
});
