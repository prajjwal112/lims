import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ButtonModule } from 'gds-atom-components';

import { GridModule } from '../shared/grid/grid.module';
import { GroupsComponent } from './groups.component';
import { UpdateNameDescriptionModule } from '../shared/update-name-description/update-name-description.module';

import { DropDownAutoCompleteModule } from '../shared/dropdown-autocomplete/dropdown-autocomplete.module';

describe('GroupsComponent', () => {
  let component: GroupsComponent;
  let fixture: ComponentFixture<GroupsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GroupsComponent],
      imports: [
        GridModule,
        HttpClientTestingModule,
        RouterTestingModule,
        ButtonModule,
        DropDownAutoCompleteModule,
        UpdateNameDescriptionModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
