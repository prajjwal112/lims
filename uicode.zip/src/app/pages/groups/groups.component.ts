import { Component, OnInit, OnDestroy, ViewChild, AfterViewChecked } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';

import { GroupService } from '../../core/api/group/group.service';
import { StoreService, Action, ActionType } from '../../store.service';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../shared/common-data-type';
import {
  GROUP_NAME_COLUMN,
  GROUP_DESCRIPTION_COLUMN,
  USERS_COUNT_COLUMN,
  GROUP_PROJECTS_COLUMN,
  GROUP_OPTIONS_COLUMN,
} from './shared/group-grid-columns';
import { SortDirection } from '../shared/sort-direction';
import { GroupListComponent } from './shared/group-list/group-list.component';
import { bindActionClick } from '../shared/grid/popover/action/action-popover';
import { ModalId } from '../shared/modal-id';
import type { GroupRequest, GroupResponse, Group } from './shared/group';
import type { Column } from '../shared/grid/column';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.scss', '../shared/page-header.scss'],
})
export class GroupsComponent implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild(GroupListComponent) groupListElement: GroupListComponent;

  public readonly columns: Column[] = [
    GROUP_NAME_COLUMN,
    GROUP_DESCRIPTION_COLUMN,
    USERS_COUNT_COLUMN,
    GROUP_PROJECTS_COLUMN,
    GROUP_OPTIONS_COLUMN,
  ];

  public data: Group[] = [];
  public searchData: Group[] = [];
  public groupReferenceId: number;
  public groupName = '';
  public groupDescription = '';
  public groupCount: number;
  public initialGroupCount: number;

  private readonly unsubscribe = new Subject<void>();

  private searchName = '';
  private sortDirection = '';

  constructor(public groupService: GroupService, private store: StoreService, private kmdModalService: KmdModalService) {
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Groups' }));
  }

  public openCreateGroupModal(): void {
    this.groupReferenceId = 0;
    this.groupName = '';
    this.groupDescription = '';
    this.kmdModalService.open(ModalId.UpdateNameDescription);
  }

  ngOnInit(): void {
    this.getGroups();
  }

  ngAfterViewChecked(): void {
    GROUP_OPTIONS_COLUMN.popover.action.onClick = bindActionClick(GROUP_OPTIONS_COLUMN, this.groupListElement);
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  public addGroupConfirmedAction(): void {
    this.getGroups();
  }

  public searchNameChanged(searchName: string): void {
    this.searchName = searchName;
  }

  public sortChanged(sortDirection: string): void {
    this.sortDirection = sortDirection;
  }

  private getGroups(): void {
    const requestData = this.getGroupRequestData();
    this.groupService
      .filter(requestData)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data: GroupResponse) => {
          this.groupCount = data.count;
          this.initialGroupCount = data.count;
          this.data = data.items || [];
          this.searchData = this.data.slice();
        },
      });
  }

  private getGroupRequestData(): GroupRequest {
    return {
      top: DEFAULT_TOP,
      skip: DEFAULT_SKIP,
      groupName: this.searchName,
      sort: this.sortDirection as SortDirection,
    };
  }
}
