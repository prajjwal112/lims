import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'gds-atom-components';

import { GroupsRoutingModule } from './groups-routing.module';
import { GroupsComponent } from './groups.component';
import { UpdateNameDescriptionModule } from '../shared/update-name-description/update-name-description.module';
import { GroupListModule } from './shared/group-list/group-list.module';

@NgModule({
  declarations: [GroupsComponent],
  imports: [ButtonModule, CommonModule, GroupsRoutingModule, UpdateNameDescriptionModule, GroupListModule],
  providers: [],
})
export class GroupsModule {}
