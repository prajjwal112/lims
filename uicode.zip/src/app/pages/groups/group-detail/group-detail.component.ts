import { Component, ViewEncapsulation, Output, EventEmitter, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SortDescriptor } from '@progress/kendo-data-query';
import { KmdModalService } from 'gds-atom-components';

import { StoreService, Action, ActionType } from '../../../store.service';
import { RoleService } from '../../../core/api/role/role.service';
import { UserService } from '../../../core/api/user/user.service';
import { ProjectService } from '../../../core/api/project/project.service';
import { GroupService } from '../../../core/api/group/group.service';
import { UnassociatedService } from '../../shared/unassociated/unassociated.service';
import { UserManagementService } from '../../shared/user-management/user-management.service';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../../shared/common-data-type';
import { ColumnType } from '../../shared/grid/column-type';
import { SortDirection } from '../../shared/sort-direction';
import { UserListComponent } from '../../users/shared/user-list/user-list.component';
import { bindActionClick, defaultActionPopoverColumn } from '../../shared/grid/popover/action/action-popover';
import { ModalId } from '../../shared/modal-id';
import type { OnInit, OnDestroy, AfterViewChecked } from '@angular/core';
import type { Column } from '../../shared/grid/column';
import type { Role, RoleListResponse } from '../../roles/shared/role';
import type { Project, ProjectResponse, ProjectDetailResponse } from '../../projects/shared/project';
import type { UserFilter, UserFilterItem } from '../../users/shared/user';
import type { Group, GroupProjects, GroupItemRequest, GroupResponse } from '../shared/group';
import type { ConfirmedStatus, ManageItemsRequest } from '../../shared/common-data-type';

@Component({
  selector: 'app-group-detail',
  templateUrl: './group-detail.component.html',
  styleUrls: ['./group-detail.component.scss', '../../shared/page-header.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class GroupDetailComponent implements OnInit, OnDestroy, AfterViewChecked {
  readonly #popoverActionColumn: Readonly<Column> = {
    ...defaultActionPopoverColumn([
      { name: ModalId.ManageRoles, display: 'Manage roles' },
      { name: ModalId.ManageGroups, display: 'Manage groups' },
      { name: ModalId.ManageProjects, display: 'Manage projects' },
      { name: ModalId.RemoveGroup, display: 'Remove from group' },
    ]),
  } as const;

  @ViewChild(UserListComponent) private userListElement: UserListComponent;
  @Output() confirmedAction = new EventEmitter<ConfirmedStatus>();

  readonly modalId = ModalId;

  public groupName = '';
  public groupDescription = '';
  public groupUsers: UserFilterItem[];
  public searchData: UserFilterItem[];
  public newlyCreated: boolean;
  public posX: number = null;
  public posY: number = null;
  public groupReferenceId: number;
  public roleData: Role[];
  public groupData: Group[];
  public projectData: Project[];
  public groupProjectsData: Project[] = [];
  public listUsers: UserFilterItem[] = [];
  public listProjects: GroupProjects[] = [];
  public columns: Column[] = [
    {
      type: ColumnType.Link,
      field: 'name',
      title: 'Name',
      width: 150,
      sortable: true,
      filterable: false,
      linkPath: '/users',
      displayWithField: 'fullName',
    },
    {
      type: ColumnType.String,
      field: 'roles',
      title: 'Role',
      filter: {
        values: [],
      },
      width: 150,
      sortable: false,
      filterable: true,
    },
    this.#popoverActionColumn,
  ];
  public confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };
  public multiSelect = false;
  public optionItemData: UserFilterItem[];
  public removeErrorMessage: string;
  public usersCount: number;
  public initialUserCount: number;
  public openedProjectCards: number[] = [];
  public projectsData: ProjectDetailResponse[] = [];
  public sort: SortDescriptor[] = [];
  public readonly groupActions = {
    [ModalId.AddProjects]: 'Add to project',
    [ModalId.AddGroups]: 'Add to group',
    [ModalId.AddRoles]: 'Add role assignment',
    [ModalId.RemoveGroup]: 'Remove',
  } as const;

  #unsubscribe = new Subject<void>();
  #roleId: number;

  constructor(
    public groupService: GroupService,
    private readonly route: ActivatedRoute,
    private readonly store: StoreService,
    private readonly kmdModalService: KmdModalService,
    private readonly roleService: RoleService,
    private readonly projectService: ProjectService,
    private readonly userFilterDataService: UserService,
    private readonly unassociatedService: UnassociatedService,
    private readonly userManagementService: UserManagementService
  ) {
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Groups' }));
  }

  private static segregateNames(objectList: Role[]): string[] {
    return objectList.map((obj) => obj.name);
  }

  ngOnInit(): void {
    this.sort = [{ field: 'name', dir: SortDirection.Ascending }];
    this.newlyCreated = this.route.snapshot.queryParamMap.get('success') === 'true';
    this.groupReferenceId = +this.route.snapshot.paramMap.get('id');

    this.getGroupDetail();
    this.getGroupUsers();
    this.getUserRoleData();
    this.getGroupProjects();
  }

  ngAfterViewChecked(): void {
    this.#popoverActionColumn.popover.action.onClick = bindActionClick(this.#popoverActionColumn, this.userListElement);
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  public getGroupProjects(): void {
    this.projectService
      .filter({
        groupId: this.groupReferenceId,
      })
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: ProjectResponse) => {
          const projectData = data.items || [];
          this.groupProjectsData = projectData.slice();
        },
      });
  }

  public getGroupUsers(): void {
    this.userFilterDataService
      .filter({
        top: DEFAULT_TOP,
        skip: DEFAULT_SKIP,
        groupId: this.groupReferenceId,
        roleId: this.#roleId,
        sortColumn: 'name',
        sortOrder: SortDirection.Ascending,
      })
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: UserFilter) => {
          this.usersCount = data.count;
          if (!this.initialUserCount) {
            this.initialUserCount = this.usersCount;
          }
          const usersData = data.items || [];
          this.groupUsers = usersData.slice();
          this.searchData = usersData.slice();
        },
      });
  }

  public openModal(id: string): void {
    this.kmdModalService.open(id);
  }

  public showHeadPopover(event: Event): void {
    event.preventDefault();
    const currentTarget = event.currentTarget as HTMLElement;
    this.posX = currentTarget.offsetLeft + currentTarget.clientWidth / 2;
    this.posY = currentTarget.offsetTop + currentTarget.clientHeight / 2;
  }

  public openAddUserModal(): void {
    this.unassociatedService
      .getUnassociatedUsers(undefined, undefined, this.groupReferenceId)
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: UserFilterItem[]) => {
          this.listUsers = data.slice();
          this.kmdModalService.open(ModalId.AddUsers);
        },
      });
  }

  public openAddProjectModal(): void {
    this.unassociatedService
      .getUnassociatedProjects(this.groupReferenceId)
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: GroupProjects[]) => {
          this.listProjects = data.slice();
          this.kmdModalService.open(ModalId.AddProjects);
        },
      });
  }

  public onAddUserConfirm(confirmedData: ManageItemsRequest): void {
    this.groupService
      .addUsers(this.buildGroupItemsRequest(confirmedData))
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: () => {
          this.kmdModalService.close(ModalId.AddUsers);
          this.getGroupUsers();
        },
        error: () => {
          this.confirmedStatus = {
            status: false,
            message: 'Unable to add user(s) to the group.',
          };
          this.confirmedAction.emit(this.confirmedStatus);
        },
      });
  }

  public onAddProjectConfirm(confirmedData: ManageItemsRequest): void {
    this.groupService
      .addProjects(this.buildGroupItemsRequest(confirmedData))
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: () => {
          this.kmdModalService.close(ModalId.AddProjects);
          this.getGroupProjects();
        },
        error: () => {
          this.confirmedStatus = {
            status: false,
            message: 'Unable to add project(s) to the group.',
          };
          this.confirmedAction.emit(this.confirmedStatus);
        },
      });
  }

  public removeGroupConfirm(): void {
    this.removeErrorMessage = '';
    this.userManagementService
      .removeGroups(this.buildGroupUserRequest(this.optionItemData))
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: () => {
          this.kmdModalService.close(ModalId.RemoveGroup);
          this.getGroupUsers();
        },
        error: () => {
          this.removeErrorMessage = 'Unable to remove user(s) from group.';
        },
      });
  }

  public setSelectedItems(userList: UserFilterItem[]): void {
    this.optionItemData = userList;
    this.multiSelect = this.optionItemData && this.optionItemData.length > 1;
  }

  public closeModal(modalId: string): void {
    this.kmdModalService.close(modalId);
  }

  public getUsersCountOrName(): string {
    const optionDataExists = this.optionItemData && this.optionItemData[0];
    return optionDataExists ? (this.multiSelect ? this.optionItemData.length + ' user(s)' : this.optionItemData[0].fullName) : '';
  }

  public removeModalClosed(): void {
    this.removeErrorMessage = '';
  }

  public editGroupConfirmedAction(): void {
    this.getGroupDetail();
  }

  public getProjectDetails(id: number): void {
    this.projectService.getProjectDetail(id).subscribe({
      next: (data: ProjectDetailResponse) => {
        this.projectsData.push(data);
      },
      complete: () => {
        this.openedProjectCards.push(id);
      },
    });
  }

  private getUserRoleData(): void {
    this.roleService
      .getData()
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (roleData: RoleListResponse) => {
          this.roleData = roleData.items.slice();
          this.columns[1].filter.values = GroupDetailComponent.segregateNames(this.roleData);
        },
      });
  }

  private getGroupDetail(): void {
    this.groupService
      .filter({
        groupId: this.groupReferenceId,
      })
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: GroupResponse) => {
          const group = data.items[0];
          if (group) {
            this.groupName = group.name;
            this.groupDescription = group.description;
          }
        },
      });
  }

  private buildGroupUserRequest(userFilterData: UserFilterItem[]): ManageItemsRequest {
    return {
      userIds: userFilterData.map((response: UserFilterItem) => response.id),
      updateIds: [this.groupReferenceId],
    };
  }

  private buildGroupItemsRequest(requestData: ManageItemsRequest): GroupItemRequest {
    return {
      groupReferenceId: this.groupReferenceId,
      updateIds: requestData.updateIds,
    };
  }
}
