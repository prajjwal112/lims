import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { AlertsModule, ButtonModule, PopoverModule, ModalsModule } from 'gds-atom-components';

import { GroupDetailComponent } from './group-detail.component';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { UpdateNameDescriptionModule } from '../../shared/update-name-description/update-name-description.module';
import { CardsModule } from '../../shared/cards/cards.module';
import { UserListModule } from '../../users/shared/user-list/user-list.module';

describe('GroupDetailComponent', () => {
  let component: GroupDetailComponent;
  let fixture: ComponentFixture<GroupDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GroupDetailComponent],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        ButtonModule,
        AlertsModule,
        PopoverModule,
        ModalsModule,
        ManageItemsModule,
        UpdateNameDescriptionModule,
        CardsModule,
        UserListModule,
      ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ id: 'test' }),
          },
        },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupDetailComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
