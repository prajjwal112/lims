import { ColumnType } from '../../shared/grid/column-type';
import { defaultActionPopoverColumn } from '../../shared/grid/popover/action/action-popover';
import type { Column } from '../../shared/grid/column';

export const GROUP_NAME_COLUMN: Readonly<Column> = {
  type: ColumnType.Link,
  field: 'name',
  title: 'Group Name',
  width: 80,
  sortable: true,
  filterable: false,
  linkPath: '/groups',
} as const;

export const GROUP_DESCRIPTION_COLUMN: Readonly<Column> = {
  type: ColumnType.String,
  field: 'description',
  title: 'Description',
  width: 150,
  sortable: false,
  filterable: false,
} as const;

export const USERS_COUNT_COLUMN: Readonly<Column> = {
  type: ColumnType.String,
  field: 'usersCount',
  title: 'Users',
  width: 30,
  sortable: false,
  filterable: false,
} as const;

export const GROUP_PROJECTS_COLUMN: Readonly<Column> = {
  type: ColumnType.String,
  field: 'projects',
  title: 'Projects',
  width: 30,
  sortable: false,
  filterable: false,
} as const;

export const GROUP_OPTIONS_COLUMN: Readonly<Column> = {
  ...defaultActionPopoverColumn([{ name: 'editGroup', display: 'Edit group' }]),
} as const;
