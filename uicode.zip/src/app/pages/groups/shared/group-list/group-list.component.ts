import { Component, ViewChild, Input, EventEmitter, Output } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';
import { SortDescriptor } from '@progress/kendo-data-query';

import { GroupService } from '../../../../core/api/group/group.service';
import { DEFAULT_SKIP, DEFAULT_TOP } from '../../../shared/common-data-type';
import { SortDirection } from '../../../shared/sort-direction';
import { GridComponent, Pagination } from '../../../shared/grid/grid.component';
import { ModalId } from '../../../shared/modal-id';
import type { OnInit, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import type { GroupRequest, GroupResponse, Group } from '../group';
import type { Column } from '../../../shared/grid/column';
import type { ActionClickEvent, OnActionClick } from '../../../shared/grid/popover/action/action-popover';

@Component({
  selector: 'app-group-list',
  templateUrl: './group-list.component.html',
  styleUrls: ['./group-list.component.scss', '../../../shared/page-header.scss'],
})
export class GroupListComponent implements OnActionClick, OnInit, OnDestroy, OnChanges {
  readonly #unsubscribe: Readonly<Subject<void>> = new Subject();

  @Input() groupInputCount: number;
  @Input() projectId: number;
  @Input() groupsInputData: Group[];
  @Input() showSearch = true;
  @Input() columns: Column[];
  @Output() searchNameChanged = new EventEmitter<string>();
  @Output() sortDirectionChanged = new EventEmitter<string>();
  data: Group[] = [];
  sort: SortDescriptor[] = [];
  searchData: Group[] = [];
  groupReferenceId: number;
  groupName = '';
  groupDescription = '';
  groupCount: number;
  suggest = false;

  @ViewChild(GridComponent) private grid: GridComponent;

  #skip = DEFAULT_SKIP;
  #top = DEFAULT_TOP;
  #searchName = '';
  #sortDirection = '';

  constructor(public readonly groupService: GroupService, private readonly kmdModalService: KmdModalService) {}

  ngOnInit(): void {
    this.sort = [{ field: 'name', dir: SortDirection.Ascending }];
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (simpleChanges.groupInputCount) {
      this.groupCount = simpleChanges.groupInputCount.currentValue;
    }
    if (simpleChanges.groupsInputData) {
      this.data = simpleChanges.groupsInputData.currentValue;
      this.resetPagination();
    }
  }

  public selectChange(event: string): void {
    this.#searchName = (event || '').trim();
    this.searchNameChanged.emit();
    this.#skip = DEFAULT_SKIP;
    this.resetPagination();
    this.getGroups();
  }

  public sortChanged(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.#sortDirection = sort && sort[0]?.dir;
    this.getGroups();
  }

  public onActionClick(event: ActionClickEvent): void {
    const selectedData = this.data.find((data) => data.id === event.dataItem.id);
    this.groupReferenceId = selectedData.id;
    this.groupName = selectedData.name;
    this.groupDescription = selectedData.description;
    this.kmdModalService.open(ModalId.EditGroup);
  }

  public editGroupConfirmedAction(): void {
    this.getGroups();
    this.kmdModalService.close(ModalId.EditGroup);
  }

  onPageChangeHandler(event: Pagination): void {
    this.#skip = event.first;
    this.#top = event.resultsPerPage;
    this.getGroups();
  }

  private resetPagination(): void {
    this.#skip = DEFAULT_SKIP;
    this.#top = DEFAULT_TOP;
    if (this.grid) {
      this.grid.resetPagination();
    }
  }

  private getGroups(): void {
    const requestData = this.getGroupRequestData();
    this.groupService
      .filter(requestData)
      .pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: (data: GroupResponse) => {
          this.groupCount = data.count;
          this.data = data.items || [];
          this.searchData = this.data.slice();
        },
      });
  }

  private getGroupRequestData(): GroupRequest {
    const request: GroupRequest = {
      top: this.#top,
      skip: this.#skip,
      groupName: this.#searchName,
      sort: this.#sortDirection as SortDirection,
    };

    if (this.projectId) {
      request.projectIds = [this.projectId];
    }

    return request;
  }
}
