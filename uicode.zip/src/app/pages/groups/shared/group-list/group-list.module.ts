import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GridModule } from '../../../shared/grid/grid.module';
import { ModalsModule, PopoverModule } from 'gds-atom-components';
import { GroupListComponent } from './group-list.component';
import { DropDownAutoCompleteModule } from '../../../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { UpdateNameDescriptionModule } from '../../../shared/update-name-description/update-name-description.module';

@NgModule({
  declarations: [GroupListComponent],
  imports: [CommonModule, GridModule, DropDownAutoCompleteModule, PopoverModule, ModalsModule, UpdateNameDescriptionModule],
  exports: [GroupListComponent],
})
export class GroupListModule {}
