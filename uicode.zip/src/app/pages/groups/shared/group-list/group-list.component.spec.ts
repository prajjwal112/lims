import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';

import { GroupListComponent } from './group-list.component';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { GridModule } from '../../../shared/grid/grid.module';
import { DropDownAutoCompleteModule } from '../../../shared/dropdown-autocomplete/dropdown-autocomplete.module';
import { UpdateNameDescriptionModule } from '../../../shared/update-name-description/update-name-description.module';
import { GROUP_NAME_COLUMN, GROUP_DESCRIPTION_COLUMN, GROUP_OPTIONS_COLUMN } from '../group-grid-columns';

describe('GroupListComponent', () => {
  let component: GroupListComponent;
  let fixture: ComponentFixture<GroupListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GroupListComponent],
      imports: [HttpClientTestingModule, RouterTestingModule, GridModule, DropDownAutoCompleteModule, UpdateNameDescriptionModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GroupListComponent],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ id: 'test' }),
          },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(GroupListComponent);
    component = fixture.componentInstance;

    component.groupInputCount = 2;
    component.groupsInputData = [
      {
        id: 1,
        name: 'group1',
        description: 'groupDescription',
        usersCount: 0,
      },
      {
        id: 1,
        name: 'group1',
        description: 'groupDescription',
        usersCount: 0,
      },
    ];
    component.columns = [GROUP_NAME_COLUMN, GROUP_DESCRIPTION_COLUMN, GROUP_OPTIONS_COLUMN];
  });

  it('should create component without search box', () => {
    component.showSearch = false;

    expect(component).toBeTruthy();
    fixture.detectChanges();
    const searchBox = fixture.debugElement.queryAll(By.css('app-dropdown-autocomplete'));

    expect(searchBox.length).toBe(0);
  });

  it('should create component with search box', () => {
    component.showSearch = true;

    expect(component).toBeTruthy();
    fixture.detectChanges();
    const searchBox = fixture.debugElement.queryAll(By.css('app-dropdown-autocomplete'));

    expect(searchBox.length).toBe(1);
  });
});
