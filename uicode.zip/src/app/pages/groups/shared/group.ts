import { SortDirection } from '../../shared/sort-direction';
export interface GroupResponse {
  count: number;
  items: Group[];
}

export interface Group {
  id: number;
  name: string;
  description: string;
  usersCount: number;
  projects?: {
    id: number;
    name: string;
    description: string;
    archived: boolean;
    countTasks: number;
  }[];
}

export interface GroupRequest {
  groupId?: number;
  groupName?: string;
  projectIds?: number[];
  skip?: number;
  sort?: SortDirection;
  top?: number;
}

export interface UpdateGroupRequest {
  id?: number;
  name: string;
  description: string;
}

export interface UpdateGroupResponse {
  id: number;
  status: boolean;
}

export interface GroupItemRequest {
  groupReferenceId: number;
  updateIds: number[];
}

export interface GroupProjects {
  id: number;
  name: string;
  description: string;
}
