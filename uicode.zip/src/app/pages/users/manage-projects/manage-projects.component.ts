import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ModalId } from '../../shared/modal-id';
import { UserManagementService } from '../../shared/user-management/user-management.service';
import type { OnDestroy } from '@angular/core';
import type { UserFilterItem } from '../shared/user';
import type { Project } from '../../projects/shared/project';
import type { ConfirmedStatus, ManageItemsRequest } from '../../shared/common-data-type';

@Component({
  selector: 'app-manage-projects',
  templateUrl: './manage-projects.component.html',
  styleUrls: ['./manage-projects.component.scss'],
})
export class ManageProjectsComponent implements OnDestroy {
  readonly modalId = ModalId;

  @Input() selectedData: UserFilterItem[] = [];
  @Input() listItems: Project[];
  @Input() isMultiSelect: boolean;
  @Output() confirmedAction = new EventEmitter<ConfirmedStatus>();

  public confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };

  #unsubscribe = new Subject<void>();

  constructor(private readonly userManagementService: UserManagementService) {}

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  onConfirm(confirmedData: ManageItemsRequest): void {
    if (this.isMultiSelect) {
      this.subscribe(this.userManagementService.addProjects(confirmedData));
    } else {
      this.subscribe(this.userManagementService.updateProjects(confirmedData));
    }
  }

  private subscribe(observable: Observable<void>): void {
    observable.pipe(takeUntil(this.#unsubscribe)).subscribe({
      next: () => {
        this.confirmedStatus = {
          status: true,
          message: '',
        };
        this.confirmedAction.emit(this.confirmedStatus);
      },
      error: () => {
        this.confirmedStatus = {
          status: false,
          message: 'Unable to add project(s) to the user. Please try again later.',
        };
        this.confirmedAction.emit(this.confirmedStatus);
      },
    });
  }
}
