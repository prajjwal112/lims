import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ManageProjectsComponent } from './manage-projects.component';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';

describe('ManageProjectsComponent', () => {
  let component: ManageProjectsComponent;
  let fixture: ComponentFixture<ManageProjectsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ManageProjectsComponent],
      imports: [HttpClientTestingModule, BrowserAnimationsModule, RouterTestingModule, WorkflowPipeModule, ManageItemsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageProjectsComponent);
    component = fixture.componentInstance;
    component.listItems = [
      {
        id: 2,
        name: 'project1',
        description: 'project1 description',
        activeRun: '',
        tasks: '',
      },
      {
        id: 3,
        name: 'project2',
        description: 'project2 description',
        activeRun: '',
        tasks: '',
      },
    ];
    component.selectedData = [
      {
        id: 1,
        firstName: 'Project',
        lastName: 'One',
        fullName: 'Project One',
        email: 'sdfsdf',
        roles: [{ id: 1, name: 'role1' }],
        active: true,
        admin: false,
        groups: [],
        projects: [],
      },
    ];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
