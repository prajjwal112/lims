import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManageGroupsComponent } from './manage-groups.component';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';

@NgModule({
  declarations: [ManageGroupsComponent],
  imports: [CommonModule, WorkflowPipeModule, ManageItemsModule],
  exports: [ManageGroupsComponent],
})
export class ManageGroupsModule {}
