import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserManagementService } from '../../shared/user-management/user-management.service';
import { ModalId } from '../../shared/modal-id';
import type { OnDestroy } from '@angular/core';
import type { UserFilterItem } from '../shared/user';
import type { Group } from '../../groups/shared/group';
import type { WorkflowHttpErrorResponse } from '../../../core/api/workflow-error';
import type { ConfirmedStatus, ManageItemsRequest } from '../../shared/common-data-type';

@Component({
  selector: 'app-manage-groups',
  templateUrl: './manage-groups.component.html',
  styleUrls: ['./manage-groups.component.scss'],
})
export class ManageGroupsComponent implements OnDestroy {
  readonly modalId = ModalId;

  @Input() selectedData: UserFilterItem[] = [];
  @Input() isMultiSelect: boolean;
  @Input() listItems: Group[] = [];
  @Output() confirmedAction = new EventEmitter<ConfirmedStatus>();

  public confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };

  #unsubscribe = new Subject<void>();

  constructor(private readonly userManagementService: UserManagementService) {}

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  onConfirm(confirmedData: ManageItemsRequest): void {
    if (this.isMultiSelect) {
      this.subscribe(this.userManagementService.addGroups(confirmedData));
    } else {
      this.subscribe(this.userManagementService.updateGroups(confirmedData));
    }
  }

  private subscribe(observable: Observable<void>): void {
    observable.pipe(takeUntil(this.#unsubscribe)).subscribe({
      next: () => {
        this.confirmedStatus = {
          status: true,
          message: '',
        };
        this.confirmedAction.emit(this.confirmedStatus);
      },
      error: (error: WorkflowHttpErrorResponse) => {
        if (error.status === 400) {
          this.confirmedStatus = {
            status: false,
            message: (error.error && error.error.message) || 'Duplicate group name',
          };
          this.confirmedAction.emit(this.confirmedStatus);
        } else {
          this.confirmedStatus = {
            status: false,
            message: 'Unable to add group(s) to the user.',
          };
          this.confirmedAction.emit(this.confirmedStatus);
        }
      },
    });
  }
}
