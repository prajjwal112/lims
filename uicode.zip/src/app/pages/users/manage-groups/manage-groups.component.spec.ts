import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ManageGroupsComponent } from './manage-groups.component';
import { ManageItemsModule } from '../../shared/manage-items/manage-items.module';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';

describe('ManageGroupsComponent', () => {
  let component: ManageGroupsComponent;
  let fixture: ComponentFixture<ManageGroupsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ManageGroupsComponent],
      imports: [HttpClientTestingModule, BrowserAnimationsModule, RouterTestingModule, WorkflowPipeModule, ManageItemsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageGroupsComponent);
    component = fixture.componentInstance;
    component.listItems = [
      {
        id: 2,
        name: 'user1',
        description: 'group description',
        usersCount: 0,
      },
      {
        id: 3,
        name: 'user2',
        description: '1group description',
        usersCount: 0,
      },
    ];
    component.selectedData = [
      {
        id: 1,
        firstName: 'First',
        lastName: 'Last',
        fullName: 'First Last',
        email: 'first.last@company.com',
        roles: [{ id: 1, name: 'role1' }],
        active: true,
        admin: false,
        groups: [],
        projects: [],
      },
    ];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
