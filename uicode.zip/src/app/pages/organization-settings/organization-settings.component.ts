import { Component, OnInit, OnDestroy } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { take, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import moment from 'moment-timezone';
import { MS_PER_HOUR, MS_PER_MINUTE } from '@progress/kendo-date-math';

import { Action, ActionType, StoreService } from '../../store.service';
import { OrganizationSettings } from './organization-settings';
import { OrganizationSettingsService } from './organization-settings.service';
import { TIME_INPUT_FORMAT, TIME_API_FORMAT } from '../../core/app-settings';

enum Alert {
  Saved = 'changesSaved',
  Cancelled = 'changesCancelled',
  Errored = 'changesErrored',
}

interface TimeZoneSelection {
  label: string;
  value: string;
  name: string;
}

const startToday = new Date();
const endToday = new Date();
startToday.setHours(9, 0, 0);
endToday.setHours(17, 0, 0);

@Component({
  selector: 'app-settings',
  templateUrl: './organization-settings.component.html',
  styleUrls: ['./organization-settings.component.scss'],
  providers: [DecimalPipe],
})
export class OrganizationSettingsComponent implements OnInit, OnDestroy {
  readonly timeInputFormat = TIME_INPUT_FORMAT;
  readonly alert: Readonly<typeof Alert> = Alert;
  readonly organizationDateSetting: Readonly<FormGroup> = OrganizationSettingsComponent.setForm();
  readonly timeZoneNames: Readonly<TimeZoneSelection[]> = [];
  endTimeMin: Date = startToday;
  changesCancelled = false;
  changesSaved = false;
  changesErrored = false;
  workHours: string;

  readonly #organizationDateSettingCache: FormGroup = OrganizationSettingsComponent.setForm();
  readonly #unsubscribe = new Subject<void>();

  constructor(
    private readonly store: StoreService,
    private readonly settingsService: OrganizationSettingsService,
    private readonly decmialPipe: DecimalPipe
  ) {
    this.store.dispatch(new Action(ActionType.Update, { currentPage: 'Settings' }));
    this.timeZoneNames = OrganizationSettingsComponent.formatTimeZoneNames();
  }

  private static formatTimeZoneNames(): TimeZoneSelection[] {
    const minutesPerHour = MS_PER_HOUR / MS_PER_MINUTE;

    return moment.tz.names().map((name) => {
      const offset: number = moment.tz(name).utcOffset() / minutesPerHour;
      const hourOffset: number = parseInt(offset.toString(), 10);
      const decimal: number = Math.abs(offset) % 1;
      const prefix = hourOffset > 0 ? '+' : '';

      let minuteOffset: number | string = minutesPerHour - minutesPerHour / (100 / ((1 - decimal) * 100));
      if (minuteOffset === 0) {
        minuteOffset = '00';
      }
      const stringOffset = `${hourOffset}:${minuteOffset}`;

      return {
        name,
        label: `${moment.tz(name).zoneAbbr()} - ${name} (UTC ${prefix}${stringOffset})`,
        value: name,
      };
    });
  }

  private static setForm(): FormGroup {
    return new FormGroup({
      startOfDay: new FormControl(startToday),
      endOfDay: new FormControl(endToday),
      includeWeekends: new FormControl(false),
      timeZone: new FormControl('', [Validators.required]),
    });
  }

  private static getTime(startTime: string[]): Date {
    return OrganizationSettingsComponent.setDate(+startTime[0], +startTime[1]);
  }

  private static setDate(hour: number, min = 0): Date {
    const date = new Date();
    date.setHours(hour, 0);
    date.setMinutes(min);
    date.setSeconds(0);

    return date;
  }

  ngOnInit(): void {
    this.workHours = this.calculateWorkHours(this.organizationDateSetting.value);
    this.onWorkHourChange();
    this.getOrgSettings();

    this.onTimeZoneChange();
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  onStartTimeChange(event: Date): void {
    this.endTimeMin = OrganizationSettingsComponent.setDate(event.getHours() + 1);
    const endTimeControl = this.organizationDateSetting.controls.endOfDay;
    if (endTimeControl.value.getTime() <= event.getTime()) {
      endTimeControl.setValue(this.endTimeMin);
    }
  }

  resetForm(): void {
    const formCache = this.#organizationDateSettingCache;

    this.organizationDateSetting.setValue(formCache.value);
    if (!this.changesCancelled) {
      this.changesSaved = false;
      this.changesCancelled = true;
    }
  }

  saveOrgSettings(): void {
    if (!this.changesSaved && this.organizationDateSetting.valid) {
      this.settingsService
        .updateSettings({
          startOfDay: moment(this.organizationDateSetting.controls.startOfDay.value).format(TIME_API_FORMAT),
          endOfDay: moment(this.organizationDateSetting.controls.endOfDay.value).format(TIME_API_FORMAT),
          includeWeekends: this.organizationDateSetting.controls.includeWeekends.value,
          timeZone: this.organizationDateSetting.controls.timeZone.value.value,
        })
        .subscribe({
          next: () => {
            this.#organizationDateSettingCache.setValue(this.organizationDateSetting.value);
            this.changesCancelled = false;
            this.changesErrored = false;
            this.changesSaved = true;
          },
          error: () => {
            this.changesErrored = true;
          },
        });
    } else {
      this.changesErrored = true;
    }
  }

  onCloseAlert(alert: Alert): void {
    this[alert] = false;
  }

  private getOrgSettings(): void {
    this.settingsService
      .getSettings()
      .pipe(take(1))
      .subscribe({
        next: (data: OrganizationSettings) => {
          this.organizationDateSetting.controls.includeWeekends.setValue(data.includeWeekends);
          this.endTimeMin = new Date();
          if (data.startOfDay) {
            const startTime = data.startOfDay.split(':');
            this.endTimeMin.setHours(+startTime[0] + 1, 0);
            this.organizationDateSetting.controls.startOfDay.setValue(OrganizationSettingsComponent.getTime(startTime));
          }
          if (data.endOfDay) {
            const endTime = data.endOfDay.split(':');
            this.organizationDateSetting.controls.endOfDay.setValue(OrganizationSettingsComponent.getTime(endTime));
          }
          if (data.timeZone) {
            const timeZone: TimeZoneSelection = this.timeZoneNames.find((zone) => zone.value === data.timeZone);
            this.organizationDateSetting.controls.timeZone.setValue({
              value: data.timeZone,
              label: timeZone?.label,
              name: timeZone?.name,
            });
          }
          this.#organizationDateSettingCache.setValue(this.organizationDateSetting.value);
        },
      });
  }

  private onWorkHourChange(): void {
    this.organizationDateSetting.valueChanges
      .pipe(
        distinctUntilChanged(
          (first, second) =>
            first.startOfDay.getTime() == second.startOfDay.getTime() && first.endOfDay.getTime() === second.endOfDay.getTime()
        ),
        takeUntil(this.#unsubscribe)
      )
      .subscribe({
        next: (data) => {
          this.workHours = this.calculateWorkHours(data);
        },
      });
  }

  private calculateWorkHours(data: { startOfDay: Date; endOfDay: Date }): string {
    return this.decmialPipe.transform((data.endOfDay.getTime() - data.startOfDay.getTime()) / MS_PER_HOUR, '1.1-1');
  }

  private onTimeZoneChange(): void {
    this.organizationDateSetting.controls.timeZone.valueChanges
      .pipe(
        distinctUntilChanged((first, second) => first === second),
        takeUntil(this.#unsubscribe)
      )
      .subscribe({
        next: (data: TimeZoneSelection | '') => {
          if (Object.keys(data).length === 0) {
            this.organizationDateSetting.controls.timeZone.setValue('');
          }
        },
      });
  }
}
