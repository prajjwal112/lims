import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { AlertsModule, ButtonModule, CheckboxModule, InputFieldsModule, TooltipModule, FiltersModule } from 'gds-atom-components';

import { DetailsHeaderModule } from '../shared/details-header/details-header.module';
import { OrganizationSettingsComponent } from './organization-settings.component';
import { OrganizationSettingsService } from './organization-settings.service';

describe('SettingsComponent', () => {
  let component: OrganizationSettingsComponent;
  let fixture: ComponentFixture<OrganizationSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OrganizationSettingsComponent],
      imports: [
        HttpClientTestingModule,
        FormsModule,
        ReactiveFormsModule,
        DetailsHeaderModule,
        DateInputsModule,
        InputFieldsModule,
        CheckboxModule,
        ButtonModule,
        AlertsModule,
        FiltersModule,
        TooltipModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganizationSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show time fields', () => {
    expect(fixture.debugElement.queryAll(By.css('kendo-timepicker')).length).toBe(2);
  });

  it('should calculate 8 hours between start and end time by default', () => {
    expect(fixture.debugElement.query(By.css('#workHours')).nativeElement.textContent.trim()).toBe('8.0');
  });

  describe('load data from service', () => {
    beforeEach(() => {
      spyOn(TestBed.inject(OrganizationSettingsService), 'getSettings').and.returnValue(
        of({
          startOfDay: '08:30:00',
          endOfDay: '17:00:00',
          includeWeekends: true,
          timeZone: 'Africa/Addis_Ababa',
        })
      );
      component['getOrgSettings']();
      fixture.detectChanges();
    });

    it('should calculate 8.5 hours between start and end time', () => {
      expect(fixture.debugElement.query(By.css('#workHours')).nativeElement.textContent.trim()).toBe('8.5');
    });

    it('should load start time from service', () => {
      expect(component.organizationDateSetting.controls.startOfDay.value.getHours()).toBe(8);
      expect(component.organizationDateSetting.controls.startOfDay.value.getMinutes()).toBe(30);
    });

    it('should load end time from service', () => {
      expect(component.organizationDateSetting.controls.endOfDay.value.getHours()).toBe(17);
      expect(component.organizationDateSetting.controls.endOfDay.value.getMinutes()).toBe(0);
    });

    it('should set weekend flag from service', () => {
      expect(component.organizationDateSetting.controls.includeWeekends.value).toBeTrue();
    });

    it('should set timezone from service', () => {
      expect(component.organizationDateSetting.controls.timeZone.value).toEqual({
        label: 'EAT - Africa/Addis_Ababa (UTC +3:00)',
        name: 'Africa/Addis_Ababa',
        value: 'Africa/Addis_Ababa',
      });
    });
  });

  describe('form changes', () => {
    it('should revert form to default after changes', () => {
      const defaultFormValue = component.organizationDateSetting.value;
      component.organizationDateSetting.setValue({
        startOfDay: new Date(),
        endOfDay: new Date(),
        includeWeekends: false,
        timeZone: {
          label: 'EAT - Africa/Addis_Ababa (UTC +3:00)',
          name: 'Africa/Addis_Ababa',
          value: 'Africa/Addis_Ababa',
        },
      });

      expect(component.organizationDateSetting.value).not.toEqual(defaultFormValue);
      fixture.debugElement.query(By.css('button[kmdInfoButton]')).nativeElement.dispatchEvent(new Event('click'));
      fixture.detectChanges();

      expect(component.organizationDateSetting.value).toEqual(defaultFormValue);
    });

    it('should disable button when timezone is empty', () => {
      expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeTrue();
    });

    it('should enable button when all mandatory fields are filled in', () => {
      component.organizationDateSetting.patchValue({
        timeZone: {
          label: 'EAT - Africa/Addis_Ababa (UTC +3:00)',
          name: 'Africa/Addis_Ababa',
          value: 'Africa/Addis_Ababa',
        },
      });
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeFalse();
    });

    it('should show info alert when reverting changes', () => {
      expect(fixture.debugElement.query(By.css('kmd-alerts[kmd-info]')).nativeElement.getAttribute('ng-reflect-show')).toBe('false');

      fixture.debugElement.query(By.css('button[kmdInfoButton]')).nativeElement.dispatchEvent(new Event('click'));
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('kmd-alerts[kmd-info]')).nativeElement.getAttribute('ng-reflect-show')).toBe('true');
    });

    it('should show success alert when saving changes', () => {
      spyOn(TestBed.inject(OrganizationSettingsService), 'updateSettings').and.returnValue(of(null));

      expect(fixture.debugElement.query(By.css('kmd-alerts[kmd-success]')).nativeElement.getAttribute('ng-reflect-show')).toBe('false');
      component.organizationDateSetting.patchValue({
        timeZone: {
          label: 'EAT - Africa/Addis_Ababa (UTC +3:00)',
          name: 'Africa/Addis_Ababa',
          value: 'Africa/Addis_Ababa',
        },
      });
      fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.dispatchEvent(new Event('click'));
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('kmd-alerts[kmd-success]')).nativeElement.getAttribute('ng-reflect-show')).toBe('true');
    });

    it('should show error alert when saving changes', () => {
      expect(fixture.debugElement.query(By.css('kmd-alerts[kmd-error]')).nativeElement.getAttribute('ng-reflect-show')).toBe('false');

      fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.dispatchEvent(new Event('click'));
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('kmd-alerts[kmd-error]')).nativeElement.getAttribute('ng-reflect-show')).toBe('true');
    });
  });
});
