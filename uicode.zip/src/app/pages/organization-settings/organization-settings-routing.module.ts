import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OrganizationSettingsComponent } from './organization-settings.component';
import { AuthGuard } from '../../auth-guard';
import { OrganizationSettingsGuard } from './organization-settings-guard';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: OrganizationSettingsComponent,
    canActivate: [AuthGuard, OrganizationSettingsGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SettingsRoutingModule {}
