export interface OrganizationSettings {
  startOfDay: string;
  endOfDay: string;
  timeZone: string;
  includeWeekends: boolean;
}
