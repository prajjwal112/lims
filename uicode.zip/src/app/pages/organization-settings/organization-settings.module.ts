import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { InputFieldsModule, CheckboxModule, ButtonModule, AlertsModule, FiltersModule, TooltipModule } from 'gds-atom-components';

import { SettingsRoutingModule } from './organization-settings-routing.module';
import { DetailsHeaderModule } from '../shared/details-header/details-header.module';
import { OrganizationSettingsComponent } from './organization-settings.component';
import { OrganizationSettingsGuard } from './organization-settings-guard';

@NgModule({
  declarations: [OrganizationSettingsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SettingsRoutingModule,
    DetailsHeaderModule,
    DateInputsModule,
    InputFieldsModule,
    CheckboxModule,
    ButtonModule,
    AlertsModule,
    FiltersModule,
    TooltipModule,
  ],
  providers: [OrganizationSettingsGuard],
})
export class OrganizationSettingsModule {}
