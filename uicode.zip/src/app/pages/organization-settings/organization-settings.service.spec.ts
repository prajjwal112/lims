import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { OrganizationSettingsService } from './organization-settings.service';

describe('SettingsService', () => {
  let service: OrganizationSettingsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [OrganizationSettingsService],
    });
    service = TestBed.inject(OrganizationSettingsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
