import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';

import { OrganizationSettings } from './organization-settings';

const URL = `${environment.endpoint}/organization-configuration`;

@Injectable({
  providedIn: 'root',
})
export class OrganizationSettingsService {
  constructor(private readonly http: HttpClient) {}

  getSettings(): Observable<OrganizationSettings> {
    return this.http.get<OrganizationSettings>(URL);
  }

  updateSettings(request: OrganizationSettings): Observable<void> {
    return this.http.put<void>(URL, request);
  }
}
