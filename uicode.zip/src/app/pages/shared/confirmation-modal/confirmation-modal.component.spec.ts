import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { KmdModalService, ModalsModule } from 'gds-atom-components';
import { ConfirmationModalComponent } from './confirmation-modal.component';
import { ModalId } from '../modal-id';
import { SimpleChange } from '@angular/core';
import { of, throwError } from 'rxjs';

describe('ConfirmationModalComponent', () => {
  const modalId: ModalId = ModalId.AddUsers;
  let component: ConfirmationModalComponent;
  let fixture: ComponentFixture<ConfirmationModalComponent>;
  let kmdModalService: KmdModalService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ModalsModule],
      declarations: [ConfirmationModalComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationModalComponent);
    component = fixture.componentInstance;
    component.modalId = modalId;
    component.confirm = of('abc');
    kmdModalService = TestBed.inject(KmdModalService);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have hidden error by default', () => {
    expect(component.showError).toBeFalse();
    expect(component.errorShown).toBeFalse();
  });

  it('should update errorShown when showError is changed', () => {
    component.ngOnChanges({ showError: new SimpleChange(false, true, true) });
    fixture.detectChanges();

    expect(component.errorShown).toBeTrue();
  });

  it('should falsify errorShown when no longer showing error', () => {
    component.errorShown = true;

    component.hideError();
    fixture.detectChanges();

    expect(component.errorShown).toBeFalse();
  });

  it('should hide error and close modal when modal closed', () => {
    const modalCloseSpy = spyOn(kmdModalService, 'close');
    const hideErrorSpy = spyOn(component, 'hideError');
    component.errorShown = true;

    component.closeModal();
    fixture.detectChanges();

    expect(hideErrorSpy).toHaveBeenCalledWith();
    expect(modalCloseSpy).toHaveBeenCalledWith(modalId);
  });

  it('should close modal and emit on success', async(() => {
    const hideErrorSpy = spyOn(component, 'hideError');
    const closeModalSpy = spyOn(component, 'closeModal');
    const successEmitSpy = spyOn(component.success, 'emit');

    component.onConfirmClick();
    fixture.detectChanges();

    expect(hideErrorSpy).toHaveBeenCalledWith();
    expect(closeModalSpy).toHaveBeenCalledWith();
    expect(successEmitSpy).toHaveBeenCalledWith();
  }));

  it('should show error on failure', async(() => {
    const hideErrorSpy = spyOn(component, 'hideError');
    const closeModalSpy = spyOn(component, 'closeModal');
    const successEmitSpy = spyOn(component.success, 'emit');
    component.confirm = throwError({ status: 500 });

    fixture.detectChanges();
    component.onConfirmClick();
    fixture.detectChanges();

    expect(hideErrorSpy).toHaveBeenCalledWith();
    expect(closeModalSpy).not.toHaveBeenCalled();
    expect(successEmitSpy).not.toHaveBeenCalled();
    expect(component.errorShown).toBeTrue();
  }));
});
