import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertsModule, ButtonModule, ModalsModule } from 'gds-atom-components';
import { ConfirmationModalComponent } from './confirmation-modal.component';

@NgModule({
  declarations: [ConfirmationModalComponent],
  imports: [CommonModule, AlertsModule, ButtonModule, ModalsModule],
  exports: [ConfirmationModalComponent],
})
export class ConfirmationModalModule {}
