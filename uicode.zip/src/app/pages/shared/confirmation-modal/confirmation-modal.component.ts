import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ModalId } from '../modal-id';
import { KmdModalService } from 'gds-atom-components';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';
import type { OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-confirmation-modal',
  templateUrl: './confirmation-modal.component.html',
  styleUrls: ['./confirmation-modal.component.scss'],
})
export class ConfirmationModalComponent implements OnChanges {
  @Input() modalId: ModalId;
  @Input() modalSize: 'small' | 'medium' | 'large' = 'medium';
  @Input() headline: string;
  @Input() showError = false;
  @Input() errorMessage: string;
  @Input() confirm: Observable<unknown>;
  @Output() readonly success = new EventEmitter<void>();

  errorShown = this.showError;

  constructor(private readonly kmdModalService: KmdModalService) {}

  ngOnChanges(changes: SimpleChanges): void {
    this.onErrorShownChange(changes);
  }

  hideError(): void {
    this.errorShown = false;
  }

  closeModal(): void {
    this.hideError();
    this.kmdModalService.close(this.modalId);
  }

  onConfirmClick(): void {
    this.hideError();
    this.confirm?.pipe(take(1)).subscribe({
      next: () => {
        this.closeModal();
        this.success.emit();
      },
      error: () => {
        this.errorShown = true;
      },
    });
  }

  private onErrorShownChange(changes: SimpleChanges): void {
    if (changes.showError) {
      this.errorShown = changes.showError.currentValue;
    }
  }
}
