import type { Column } from './grid/column';

export type TabConfig = {
  users: TabDetail;
  groups: TabDetail;
};

export type TabDetail = {
  name: string;
  id: string;
  propertyId: string;
  columns: ListColumn[];
  filterKey: string;
};

export interface ListColumn extends Pick<Column, 'title' | 'sortable'> {
  name: string;
}
