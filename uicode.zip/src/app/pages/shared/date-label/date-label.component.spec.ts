import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DateLabelComponent } from './date-label.component';
import { By } from '@angular/platform-browser';
import { TooltipModule } from 'gds-atom-components';

describe('DateLabelComponent', () => {
  const EXPECTED_DATE = 'Sep 24, 2019';
  const EXPECTED_DATE_TIME = `${EXPECTED_DATE} 12:00 AM`;

  let component: DateLabelComponent;
  let fixture: ComponentFixture<DateLabelComponent>;
  let date: Date;
  const updateComponent = (config: { date?: Date; displayTimeOnElement?: boolean; displayTimeOnTitle?: boolean }): void => {
    Object.keys(config).forEach((key) => (component[key] = config[key]));
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DateLabelComponent],
      imports: [TooltipModule],
    })
      .compileComponents()
      .then(() => {
        fixture = TestBed.createComponent(DateLabelComponent);
        component = fixture.componentInstance;
      });
  }));

  beforeEach(() => {
    date = new Date(2019, 8, 24);
  });

  it('should create', () => {
    updateComponent({ date });

    expect(component).toBeTruthy();
  });

  it('should display date without time portion on the element when not configured to do so', () => {
    updateComponent({ date });

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent.trim()).toBe(EXPECTED_DATE);
  });

  it('should display date without time portion on the title when not configured to do so', () => {
    updateComponent({ date });

    expect(fixture.debugElement.query(By.css('span')).nativeElement.getAttribute('ng-reflect-kmd-tooltip').trim()).toBe(EXPECTED_DATE);
  });

  it('should display time portion of date on the element when configured to do so', () => {
    updateComponent({ date, displayTimeOnElement: true });

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent.trim()).toBe(EXPECTED_DATE_TIME);
  });

  it('should display time portion of date on the title when configured to do so', () => {
    updateComponent({ date, displayTimeOnTitle: true });

    expect(fixture.debugElement.query(By.css('span')).nativeElement.getAttribute('ng-reflect-kmd-tooltip').trim()).toBe(EXPECTED_DATE_TIME);
  });
});
