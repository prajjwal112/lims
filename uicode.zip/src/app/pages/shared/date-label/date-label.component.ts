import { Component, Input } from '@angular/core';
import { DATE_DISPLAY_FORMAT } from '../../../core/app-settings';

@Component({
  selector: 'app-date-label',
  templateUrl: './date-label.component.html',
  styleUrls: ['./date-label.component.scss'],
})
export class DateLabelComponent {
  readonly dateDisplayFormat = DATE_DISPLAY_FORMAT;

  /** The date to display. */
  @Input() date: Date;

  /** Whether or not to display the time on the element. */
  @Input() displayTimeOnElement: boolean;

  /** Whether or not to display the time on the title of the element. */
  @Input() displayTimeOnTitle: boolean;

  /** Whether or not to hide the title. */
  @Input() hideTitle = false;
}
