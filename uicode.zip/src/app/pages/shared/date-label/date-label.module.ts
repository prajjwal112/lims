import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DateLabelComponent } from './date-label.component';
import { TooltipModule } from 'gds-atom-components';

@NgModule({
  declarations: [DateLabelComponent],
  imports: [CommonModule, TooltipModule],
  exports: [DateLabelComponent],
})
export class DateLabelModule {}
