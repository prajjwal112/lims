import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  showLoader = new Subject<boolean>();
  show() {
    this.showLoader.next(true);
  }
  hide() {
    this.showLoader.next(false);
  }
}
