export enum TabKeys {
  Active = 'active',
  Upcoming = 'upcoming',
  History = 'history',
  Permissions = 'permissions',
  Users = 'users',
}

export enum TabValues {
  Active = 'Active',
  Upcoming = 'Upcoming',
  History = 'History',
  Permissions = 'Permissions',
  Users = 'Users',
}
