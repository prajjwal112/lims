import { ComponentWithModalDirective } from './component-with-modal.directive';
import { Component } from '@angular/core';
import { KmdModalService } from 'gds-atom-components';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { ModalId } from './modal-id';

@Component({ template: '' })
class ConcreteComponentWithModalComponent extends ComponentWithModalDirective {
  constructor(protected readonly kmdModalService: KmdModalService) {
    super(kmdModalService);
  }
}

describe('ComponentWithModal', () => {
  let component: ComponentWithModalDirective;
  let fixture: ComponentFixture<ComponentWithModalDirective>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConcreteComponentWithModalComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConcreteComponentWithModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create an instance', () => {
    expect(component).toBeTruthy();
  });

  it('should have no open modal ID by default', () => {
    expect(component.openModalId).toBeNull();
  });

  it('should clear open modal ID when modal is closed', () => {
    component.openModalId = ModalId.ManageProjects;
    component.closeModal();

    expect(component.openModalId).toBeNull();
  });

  /* eslint-disable dot-notation, @typescript-eslint/unbound-method */
  it('should have modal open when modal was opened', fakeAsync(() => {
    spyOn(component['kmdModalService'], 'open');

    const id = ModalId.ManageProjects;

    component.openModal(id);
    tick(50);
    fixture.detectChanges();

    expect(component.openModalId).toBe(id);
    expect(component['kmdModalService'].open).toHaveBeenCalledWith(id);
  }));

  it('should not call service if no id is passed when closing modal', () => {
    spyOn(component['kmdModalService'], 'close');
    component.closeModal();

    expect(component['kmdModalService'].close).not.toHaveBeenCalled();
  });

  it('should have modal closed when modal was closed', fakeAsync(() => {
    spyOn(component['kmdModalService'], 'close');

    const id = ModalId.ManageProjects;
    component.closeModal(id);

    expect(component['kmdModalService'].close).toHaveBeenCalledWith(id);
  }));
  /* eslint-enable dot-notation, @typescript-eslint/unbound-method */
});
