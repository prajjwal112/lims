import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { CheckboxModule, InputFieldsModule, RadioButtonModule } from 'gds-atom-components';

import { ListItemsComponent } from './list-items.component';
import { By } from '@angular/platform-browser';

describe('ListItemsComponent', () => {
  let component: ListItemsComponent;
  let fixture: ComponentFixture<ListItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ListItemsComponent],
      imports: [FormsModule, CheckboxModule, InputFieldsModule, RadioButtonModule],
    })
      .compileComponents()
      .then(() => {
        fixture = TestBed.createComponent(ListItemsComponent);
        component = fixture.componentInstance;
        component.columns = [
          {
            name: 'name',
            title: 'Name',
            sortable: false,
          },
        ];
        component.listItems = [
          {
            id: 1,
            name: 'item 1',
          },
        ];
        component.propertyToSelect = 'id';
        component;
        fixture.detectChanges();
      });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select all', () => {
    expect(fixture.debugElement.queryAll(By.css('input:checked')).length).toBe(0);
    fixture.debugElement.query(By.css('kmd-checkbox input')).nativeElement.click();
    fixture.detectChanges();

    expect(component.selectAllFlag).toBeTrue();
    expect(component.selectedItems).toEqual([1]);
  });

  it('should set select all flag when preselected items match all items', () => {
    expect(component.selectAllFlag).toBeFalse();

    component.selectedItems = [1];
    component.ngOnChanges();

    expect(component.selectAllFlag).toBeTrue();
  });

  it('should show users name in list after passing the names', () => {
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('div.col-auto')).length).toBe(2);
  });
});
