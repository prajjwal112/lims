import { Component, Output, EventEmitter, Input, OnChanges, ViewEncapsulation } from '@angular/core';

import { SortUtility } from '../utility/sort-utility';
import { SortDirection } from '../sort-direction';

import type { ListColumns } from '../common-data-type';

@Component({
  selector: 'app-list-items',
  templateUrl: './list-items.component.html',
  styleUrls: ['./list-items.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ListItemsComponent implements OnChanges {
  @Input() listItems: any[];
  @Input() selectedItems: number[];
  @Input() propertyToSelect = 'id';
  @Input() columns: ListColumns[];
  @Input() displayRadioButton = false;
  @Input() filterKey = 'name';
  @Output() selectedItemsChange = new EventEmitter<number[]>();

  public selectAllFlag = false;
  #sortDirection: SortDirection = SortDirection.Ascending;

  constructor(private readonly sortUtility: SortUtility) {}

  ngOnChanges(): void {
    this.selectAllFlag = this.selectedItems.length === this.listItems.length && !this.displayRadioButton;
  }

  public sortItems(sortable: boolean): void {
    if (sortable) {
      this.listItems = this.sortUtility.sortItems(this.listItems, this.filterKey, this.#sortDirection);
      this.#sortDirection = this.#sortDirection === SortDirection.Ascending ? SortDirection.Descending : SortDirection.Ascending;
    }
  }

  public selectAll(event: HTMLInputElement): void {
    this.selectedItems = event.checked ? this.listItems.map((obj) => obj[this.propertyToSelect]) : [];
    this.selectedItemsChange.emit(this.selectedItems);
  }

  public selectRow(): void {
    let results;
    if (!this.displayRadioButton) {
      this.selectAllFlag = this.selectedItems.length === this.listItems.length;
      results = this.selectedItems.slice();
    } else {
      results = [this.selectedItems];
    }

    this.selectedItemsChange.emit(results.slice());
  }
}
