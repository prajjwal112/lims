import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ListItemsComponent } from './list-items.component';
import { CheckboxModule, InputFieldsModule, RadioButtonModule } from 'gds-atom-components';

@NgModule({
  declarations: [ListItemsComponent],
  imports: [CommonModule, FormsModule, CheckboxModule, InputFieldsModule, RadioButtonModule],
  exports: [ListItemsComponent],
})
export class ListItemsModule {}
