import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MakeProjectObsoleteComponent } from './make-project-obsolete.component';
import { ConfirmationModalModule } from '../../confirmation-modal/confirmation-modal.module';
import { MakeObsoleteModule } from '../make-obsolete.module';

describe('MakeProjectObsoleteComponent', () => {
  let component: MakeProjectObsoleteComponent;
  let fixture: ComponentFixture<MakeProjectObsoleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ConfirmationModalModule, MakeObsoleteModule],
      declarations: [MakeProjectObsoleteComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakeProjectObsoleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
