import { Component } from '@angular/core';
import { ProjectService } from '../../../../core/api/project/project.service';
import { BaseMakeObsoleteComponentDirective } from '../base-make-obsolete-component.directive';
import { ModalId } from '../../modal-id';

@Component({
  selector: 'app-make-project-obsolete',
  templateUrl: './make-project-obsolete.component.html',
  styleUrls: ['./make-project-obsolete.component.scss'],
})
export class MakeProjectObsoleteComponent extends BaseMakeObsoleteComponentDirective {
  readonly modalId = ModalId.MakeProjectObsolete;

  constructor(private readonly projectService: ProjectService) {
    super((projectId: number) => {
      return projectService.update({ id: projectId, archived: true });
    });
  }
}
