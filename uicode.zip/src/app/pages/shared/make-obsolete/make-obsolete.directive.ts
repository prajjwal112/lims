import { Directive, Input } from '@angular/core';
import { ModalId } from '../modal-id';
import { ConfirmationModalComponent } from '../confirmation-modal/confirmation-modal.component';
import type { OnChanges } from '@angular/core';

@Directive({
  selector: `app-confirmation-modal[makeObsolete]`,
})
export class MakeObsoleteDirective implements OnChanges {
  @Input() makeObsolete: ModalId;

  constructor(private readonly modal: ConfirmationModalComponent) {
    modal.modalSize = 'small';
    modal.headline = 'Make Obsolete';
  }

  ngOnChanges(): void {
    this.modal.modalId = this.makeObsolete;
  }
}
