import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MakeObsoleteDirective } from './make-obsolete.directive';
import { ModalId } from '../modal-id';
import { ConfirmationModalModule } from '../confirmation-modal/confirmation-modal.module';
import { MakeObsoleteModule } from './make-obsolete.module';
import { By } from '@angular/platform-browser';
import { ConfirmationModalComponent } from '../confirmation-modal/confirmation-modal.component';

@Component({
  template: '<app-confirmation-modal [makeObsolete]="modalId"></app-confirmation-modal>',
})
class ConcreteMakeObsoleteComponent {
  readonly modalId = ModalId.MakeProjectObsolete;
}

describe('MakeObsoleteDirective', () => {
  const inspectProperties = (confirmationModalFixture: ComponentFixture<unknown>, matcher: 'toBeTruthy' | 'toBeFalsy'): void => {
    expect(confirmationModalFixture.debugElement.query(By.css(`[ng-reflect-id=${ModalId.MakeProjectObsolete}]`))).toBeTruthy();
    expect(confirmationModalFixture.debugElement.query(By.css('[ng-reflect-modal-size=small]')))[matcher]();
    expect(confirmationModalFixture.debugElement.query(By.css('[ng-reflect-headline="Make Obsolete"]')))[matcher]();
  };
  let component: ConcreteMakeObsoleteComponent;
  let fixture: ComponentFixture<ConcreteMakeObsoleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MakeObsoleteModule, ConfirmationModalModule],
      declarations: [ConcreteMakeObsoleteComponent, MakeObsoleteDirective],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConcreteMakeObsoleteComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have additional attributes when MakeObsoleteDirective is added', () => {
    inspectProperties(fixture, 'toBeTruthy');
  });

  it('should not have additional properties when MakeObsoleteDirective is not added', () => {
    const confirmationModalFixture = TestBed.createComponent(ConfirmationModalComponent);
    confirmationModalFixture.componentInstance.modalId = ModalId.MakeProjectObsolete;

    confirmationModalFixture.detectChanges();

    inspectProperties(confirmationModalFixture, 'toBeFalsy');
  });
});
