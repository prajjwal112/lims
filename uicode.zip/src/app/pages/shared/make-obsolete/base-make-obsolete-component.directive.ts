import { Directive, Input } from '@angular/core';
import { Observable } from 'rxjs';
import type { OnChanges, SimpleChanges } from '@angular/core';

@Directive()
export abstract class BaseMakeObsoleteComponentDirective implements OnChanges {
  @Input() itemId: number | string;
  @Input() success: () => void;

  observable: Observable<unknown>;

  protected constructor(private readonly createObservable: (itemId: number | string) => Observable<unknown>) {}

  ngOnChanges(changes: SimpleChanges): void {
    this.onItemIdChange(changes);
  }

  private onItemIdChange(changes: SimpleChanges): void {
    if (changes.itemId?.currentValue) {
      this.observable = this.createObservable(changes.itemId.currentValue);
    }
  }
}
