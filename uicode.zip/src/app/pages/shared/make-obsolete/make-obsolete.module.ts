import { NgModule } from '@angular/core';
import { ConfirmationModalModule } from '../confirmation-modal/confirmation-modal.module';
import { MakeObsoleteDirective } from './make-obsolete.directive';
import { MakeProjectObsoleteComponent } from './project/make-project-obsolete.component';
import { MakeRoleObsoleteComponent } from './role/make-role-obsolete.component';
import { MakeWorkflowDefinitionObsoleteComponent } from './workflow-definition/make-workflow-definition-obsolete.component';

@NgModule({
  declarations: [MakeObsoleteDirective, MakeProjectObsoleteComponent, MakeRoleObsoleteComponent, MakeWorkflowDefinitionObsoleteComponent],
  imports: [ConfirmationModalModule],
  exports: [MakeObsoleteDirective, MakeProjectObsoleteComponent, MakeRoleObsoleteComponent, MakeWorkflowDefinitionObsoleteComponent],
})
export class MakeObsoleteModule {}
