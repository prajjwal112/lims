import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MakeWorkflowDefinitionObsoleteComponent } from './make-workflow-definition-obsolete.component';
import { ConfirmationModalModule } from '../../confirmation-modal/confirmation-modal.module';
import { MakeObsoleteModule } from '../make-obsolete.module';

describe('MakeWorkflowDefinitionObsoleteComponent', () => {
  let component: MakeWorkflowDefinitionObsoleteComponent;
  let fixture: ComponentFixture<MakeWorkflowDefinitionObsoleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ConfirmationModalModule, MakeObsoleteModule],
      declarations: [MakeWorkflowDefinitionObsoleteComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakeWorkflowDefinitionObsoleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
