import { Component } from '@angular/core';
import { BaseMakeObsoleteComponentDirective } from '../base-make-obsolete-component.directive';
import { WorkflowDefinitionService } from '../../../../core/api/workflow-definition/workflow-definition.service';
import { ModalId } from '../../modal-id';

@Component({
  selector: 'app-make-workflow-definition-obsolete',
  templateUrl: './make-workflow-definition-obsolete.component.html',
  styleUrls: ['./make-workflow-definition-obsolete.component.scss'],
})
export class MakeWorkflowDefinitionObsoleteComponent extends BaseMakeObsoleteComponentDirective {
  readonly modalId = ModalId.MakeWorkflowDefinitionObsolete;

  constructor(private readonly workflowDefinitionService: WorkflowDefinitionService) {
    super((workflowDefinitionId: string) => workflowDefinitionService.updateWorkflowDefinition(workflowDefinitionId, { archived: true }));
  }
}
