import { Component, SimpleChange } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BaseMakeObsoleteComponentDirective } from './base-make-obsolete-component.directive';
import { Observable, of } from 'rxjs';

let createObservableSpy: jasmine.Spy<(itemId: string) => Observable<string>>;

@Component({ template: '' })
class ConcreteMakeObsoleteComponent extends BaseMakeObsoleteComponentDirective {
  constructor() {
    super(createObservableSpy);
  }
}

describe('BaseMakeObsoleteComponentDirective', () => {
  let component: BaseMakeObsoleteComponentDirective;
  let fixture: ComponentFixture<BaseMakeObsoleteComponentDirective>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConcreteMakeObsoleteComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    createObservableSpy = jasmine.createSpy('createObservable', (itemId: string) => of(itemId)).and.callThrough();
    fixture = TestBed.createComponent(ConcreteMakeObsoleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create an instance', () => {
    expect(component).toBeTruthy();
  });

  it('should not have an observable by default', () => {
    expect(component.observable).toBeUndefined();
  });

  it('should have an observable when item ID changes', () => {
    const itemId = 'abc';

    component.ngOnChanges({ itemId: new SimpleChange(null, itemId, true) });
    fixture.detectChanges();

    expect(component.observable).toBeDefined();
    expect(createObservableSpy).toHaveBeenCalledWith(itemId);
  });
});
