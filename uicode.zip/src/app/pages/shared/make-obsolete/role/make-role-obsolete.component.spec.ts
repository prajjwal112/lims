import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MakeRoleObsoleteComponent } from './make-role-obsolete.component';
import { ConfirmationModalModule } from '../../confirmation-modal/confirmation-modal.module';
import { MakeObsoleteModule } from '../make-obsolete.module';

describe('MakeRoleObsoleteComponent', () => {
  let component: MakeRoleObsoleteComponent;
  let fixture: ComponentFixture<MakeRoleObsoleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ConfirmationModalModule, MakeObsoleteModule],
      declarations: [MakeRoleObsoleteComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakeRoleObsoleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
