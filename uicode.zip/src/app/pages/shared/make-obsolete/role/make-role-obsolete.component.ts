import { Component } from '@angular/core';
import { RoleService } from '../../../../core/api/role/role.service';
import { BaseMakeObsoleteComponentDirective } from '../base-make-obsolete-component.directive';
import { ModalId } from '../../modal-id';

@Component({
  selector: 'app-make-role-obsolete',
  templateUrl: './make-role-obsolete.component.html',
  styleUrls: ['./make-role-obsolete.component.scss'],
})
export class MakeRoleObsoleteComponent extends BaseMakeObsoleteComponentDirective {
  readonly modalId = ModalId.MakeRoleObsolete;

  constructor(private readonly roleService: RoleService) {
    super((roleId: number) => roleService.update({ id: roleId, archived: true }));
  }
}
