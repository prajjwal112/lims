import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class GridService {
  private clearCheckbox$: Subject<boolean> = new Subject<boolean>();

  constructor() {}

  getClearCheckboxes(): Observable<boolean> {
    return this.clearCheckbox$;
  }

  setClearCheckboxes(data: boolean) {
    this.clearCheckbox$.next(data);
  }
}
