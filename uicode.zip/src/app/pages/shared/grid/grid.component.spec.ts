import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { GridModule as KendoGridModule } from '@progress/kendo-angular-grid';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { PaginationModule } from 'gds-atom-components';

import { PriorityPillModule } from './priority-pill/priority-pill.module';
import { StatusPillModule } from './status-pill/status-pill.module';

import { GridComponent } from './grid.component';
import { PillsModule } from '../pills/pills.module';
import { FilterModule } from './filter/filter.module';
import { FieldTooltipModule } from './field-tooltip/field-tooltip.module';
import { FieldPopoverModule } from './popover/field-popover.module';
import { FieldIconModule } from './field-icon/field-icon.module';
import { FieldGaugeModule } from '../field-gauge/field-gauge.module';
import { SelectedRowContainerModule } from './selected-row-container/selected-row-container.module';
import { ColumnType } from './column-type';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { Status } from '../status';
import { DateLabelModule } from '../date-label/date-label.module';
import { DueDateLabelModule } from '../due-date-label/due-date-label.module';
import type { Column } from './column';
import type { TaskFilterItemResponse } from '../../task-list/shared/task-filter';
import { mockAssigneeValues } from './mock-assignee-values';
import { GridService } from './grid.service';
import { of } from 'rxjs';
import { FieldPopoverComponent } from './popover/field-popover.component';

const TABLE_DATA: TaskFilterItemResponse = Object.seal({
  projects: null,
  parentTaskId: null,
  description: null,
  workflowName: null,
  runName: null,
  priority: 50,
  deleteReason: null,
  duration: 0,
  taskDefinitionKey: 'Task_16f3zdv',
  dueDate: '2019-09-24T14:50:29.280',
  callStatus: 'failed',
  name: 'make container',
  tenantId: 'WORKFLOWD',
  startTime: '2019-07-29T20:36:22.696+0000',
  id: '872bdb33-b240-11e9-8af1-1ed5bcbb47ce',
  assignee: 'EM16',
  endTime: null,
  status: Status.InProgress,
  staleDate: null,
  referenceId: null,
  assignees: [],
  groupAssignees: [],
});
const DATA: TaskFilterItemResponse[] = Array.from(Array(100)).map((x, n) => {
  const data = Object.assign({}, TABLE_DATA);
  data.id += n;
  data.name += n;

  return data;
});
const COLUMNS: Readonly<Column[]> = [
  {
    type: ColumnType.Date,
    field: 'dueDate',
    title: 'Due date',
    width: 100,
    sortable: true,
    filterable: true,
  },
  {
    type: ColumnType.Link,
    field: 'name',
    title: 'Task name',
    width: 100,
    sortable: false,
    filterable: false,
  },
  {
    type: ColumnType.String,
    field: 'workflowName',
    title: 'Workflow',
    width: 100,
    sortable: false,
    filterable: false,
  },
  {
    type: ColumnType.String,
    field: 'status',
    title: 'Status',
    width: 100,
    sortable: false,
    filterable: true,
  },
  {
    type: ColumnType.Number,
    field: 'priority',
    title: 'Priority',
    width: 100,
    sortable: false,
    filterable: true,
  },
  {
    type: ColumnType.Icon,
    field: 'edit',
    title: 'Edit',
    width: 20,
    sortable: false,
    filterable: false,
  },
  {
    type: ColumnType.BlankString,
    field: 'assignee',
    title: 'Profile',
    width: 100,
    sortable: false,
    filterable: false,
    filter: {
      values: mockAssigneeValues,
    },
  },
] as const;

describe('GridComponent', () => {
  let component: GridComponent;
  let fixture: ComponentFixture<GridComponent>;
  let gridService: GridService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GridComponent],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        FormsModule,
        KendoGridModule,
        InputsModule,
        DateLabelModule,
        DueDateLabelModule,
        FilterModule,
        PriorityPillModule,
        StatusPillModule,
        PillsModule,
        FieldTooltipModule,
        FieldPopoverModule,
        FieldIconModule,
        SelectedRowContainerModule,
        FieldGaugeModule,
        WorkflowPipeModule,
        PaginationModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridComponent);
    component = fixture.componentInstance;
    gridService = TestBed.inject(GridService);
    component.recordIdKey = 'id';
    component.columns = COLUMNS.slice();
    component.data = DATA.slice();
    component.ngDoCheck();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show seven columns', () => {
    expect(fixture.debugElement.queryAll(By.css('th')).length).toBe(7);
  });

  it('should show date column', () => {
    const columns: Column[] = [
      {
        type: ColumnType.Date,
        field: 'dueDate',
        title: 'Due date',
        width: 100,
        sortable: true,
        filterable: true,
      },
    ];
    component.columns = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-due-date-label'))).not.toBeTruthy();
    component.columns = columns.slice();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-due-date-label'))).toBeTruthy();
  });

  it('should show link column', () => {
    const columns: Column[] = [
      {
        type: ColumnType.Link,
        field: 'name',
        title: 'Task name',
        width: 100,
        sortable: false,
        filterable: false,
      },
    ];
    component.columns = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('td a'))).not.toBeTruthy();
    component.columns.push(...columns);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('td a'))).toBeTruthy();
  });

  it('should show assignee column', () => {
    const tableRows = fixture.nativeElement.querySelectorAll('tr th');

    expect(tableRows[6].innerText).toBe('Profile');
  });

  it('should show priority pill column', () => {
    const columns: Column[] = [
      {
        type: ColumnType.Priority,
        field: 'priority',
        title: 'Priority',
        width: 100,
        sortable: false,
        filterable: true,
      },
    ];
    component.columns = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-priority-pill'))).not.toBeTruthy();
    component.columns.push(...columns);
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-priority-pill'))).toBeTruthy();
  });

  it('should show status pill column', () => {
    const columns: Column[] = [
      {
        type: ColumnType.Status,
        field: 'status',
        title: 'Status',
        width: 100,
        sortable: false,
        filterable: true,
      },
    ];
    component.columns = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-status-pill'))).not.toBeTruthy();
    component.columns = columns.slice();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-status-pill'))).toBeTruthy();
  });

  it('should show icon column', () => {
    const columns: Column[] = [
      {
        type: ColumnType.Icon,
        field: 'edit',
        title: 'Edit',
        width: 20,
        sortable: false,
        filterable: false,
      },
    ];
    component.columns = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-field-icon'))).not.toBeTruthy();
    component.columns = columns.slice();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-field-icon'))).toBeTruthy();
  });

  it('should show checkbox column', () => {
    expect(fixture.debugElement.query(By.css('.k-checkbox'))).toBeNull();
    component.selectField = 'multi';
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.k-checkbox'))).toBeTruthy();
    component.selectField = 'single';
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.k-checkbox'))).toBeTruthy();
  });

  it('should show select all for multi select option', () => {
    component.selectField = 'multi';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.k-checkbox')).length).toBe(DATA.length + 1);
  });

  it('should not show select all for single select option', () => {
    component.selectField = 'single';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.k-checkbox')).length).toBe(DATA.length);
  });

  it('should select multiple checkboxes', () => {
    component.selectField = 'multi';
    fixture.detectChanges();
    const checkboxes = fixture.debugElement.queryAll(By.css('.k-checkbox'));
    checkboxes[0].nativeElement.click();

    expect(checkboxes.length).toBe(DATA.length + 1);
  });

  it('should select one checkbox', () => {
    component.selectField = 'single';
    fixture.detectChanges();
    const checkboxes = fixture.debugElement.queryAll(By.css('.k-checkbox'));
    checkboxes[0].nativeElement.click();
    checkboxes[1].nativeElement.click();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.k-checkbox:checked')).length).toBe(1);
    expect(checkboxes[1].nativeElement.checked).toBe(true);
  });

  it('should pre select multiple checkboxes', () => {
    component.selectField = 'multi';
    component.preSelectedRows = ['872bdb33-b240-11e9-8af1-1ed5bcbb47ce2', '872bdb33-b240-11e9-8af1-1ed5bcbb47ce3'];
    component.data.push({ id: 'test', name: 'testname' });
    component.ngDoCheck();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.k-checkbox:checked')).length).toBe(2);
  });

  it('should pre select single checkbox', () => {
    component.selectField = 'single';
    component.preSelectedRows = ['872bdb33-b240-11e9-8af1-1ed5bcbb47ce2', '872bdb33-b240-11e9-8af1-1ed5bcbb47ce3'];
    component.data.push({ id: 'test', name: 'testname' });
    component.ngDoCheck();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.k-checkbox:checked')).length).toBe(1);
    expect(fixture.debugElement.query(By.css('.k-checkbox:checked')).nativeElement.value).toBe(component.preSelectedRows[0]);
  });

  it('should show field tooltip column', () => {
    const columns: Column[] = [
      {
        type: ColumnType.String,
        field: 'groups',
        title: 'groups',
        width: 100,
        sortable: false,
        filterable: true,
      },
    ];

    expect(fixture.debugElement.query(By.css('app-field-tooltip'))).not.toBeTruthy();
    component.data = [
      {
        groups: [],
      },
    ];
    component.columns = columns.slice();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('app-field-tooltip'))).toBeTruthy();
  });

  it('should show action popover column', () => {
    const columns: Column[] = [
      {
        type: ColumnType.ActionPopover,
        field: 'options',
        title: '',
        width: 100,
        sortable: false,
        filterable: true,
        popover: { action: { items: [] } },
      },
    ];

    expect(fixture.debugElement.query(By.directive(FieldPopoverComponent))).not.toBeTruthy();
    component.data = [{ id: '1', active: true }];
    component.columns = columns.slice();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.directive(FieldPopoverComponent))).toBeTruthy();
  });

  it('should show pagination when rows is greater than default page size', () => {
    expect(fixture.debugElement.query(By.css('kmd-pagination'))).toBeFalsy();
    component.pagination = true;
    component.paginationTotal = component.data.length;
    component.paginationOptions = [15, 20, 25, 30, 35];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-pagination'))).toBeTruthy();
  });

  it('should show dataset based on page size', () => {
    expect(component.pageData.length).toBe(DATA.length);
    component.pagination = true;
    component.data.push({ id: 'test', name: 'testname' });
    component.ngDoCheck();

    expect(component.pageData.length).toBe(15);
  });

  it('should deselect the checkbox when grid inits', () => {
    spyOn(gridService, 'getClearCheckboxes').and.returnValue(of(true));

    expect(component.selectAllState).toEqual('unchecked');
    expect(fixture.debugElement.queryAll(By.css('.k-checkbox:checked')).length).toBe(0);
  });

  it('should show the checkbox selected when the modal action cancelled', () => {
    component.selectField = 'multi';
    spyOn(gridService, 'getClearCheckboxes').and.returnValue(of(false));

    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.k-checkbox')).length).toBe(DATA.length + 1);
  });
});
