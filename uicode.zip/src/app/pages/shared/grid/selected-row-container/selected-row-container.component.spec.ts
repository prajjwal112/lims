import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedRowContainerComponent } from './selected-row-container.component';

describe('SelectedRowContainerComponent', () => {
  let component: SelectedRowContainerComponent;
  let fixture: ComponentFixture<SelectedRowContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SelectedRowContainerComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedRowContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
