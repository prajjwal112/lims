import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SelectedRowContainerComponent } from './selected-row-container.component';

@NgModule({
  declarations: [SelectedRowContainerComponent],
  imports: [CommonModule],
  exports: [SelectedRowContainerComponent]
})
export class SelectedRowContainerModule {}
