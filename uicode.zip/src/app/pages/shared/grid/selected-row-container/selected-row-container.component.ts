import { Component, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-selected-row-container',
  templateUrl: './selected-row-container.component.html',
  styleUrls: ['./selected-row-container.component.scss'],
})
export class SelectedRowContainerComponent {
  @Output() actionOnSelectedRows = new EventEmitter<string>();
  @Input() selectedRows: any[];
  @Input() actions: Record<string, string>;

  openModal(id: string): void {
    this.actionOnSelectedRows.emit(id);
  }
  returnZero(): any {
    return 0;
  }
}
