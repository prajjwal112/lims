import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { GridModule as KendoGridModule } from '@progress/kendo-angular-grid';
import { FormsModule } from '@angular/forms';

import { PriorityPillModule } from './priority-pill/priority-pill.module';
import { StatusPillModule } from './status-pill/status-pill.module';
import { FieldTooltipModule } from './field-tooltip/field-tooltip.module';
import { FieldPopoverModule } from './popover/field-popover.module';
import { FieldIconModule } from './field-icon/field-icon.module';
import { CheckboxModule, PaginationModule } from 'gds-atom-components';

import { GridComponent } from './grid.component';
import { PillsModule } from '../pills/pills.module';
import { FilterModule } from './filter/filter.module';
import { SelectedRowContainerModule } from './selected-row-container/selected-row-container.module';
import { FieldGaugeModule } from '../field-gauge/field-gauge.module';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DueDateLabelModule } from '../due-date-label/due-date-label.module';
import { DateLabelModule } from '../date-label/date-label.module';
import { FieldActionComponent } from './action/field-action.component';

@NgModule({
  declarations: [GridComponent, FieldActionComponent],
  imports: [
    CommonModule,
    KendoGridModule,
    FilterModule,
    PriorityPillModule,
    StatusPillModule,
    PillsModule,
    RouterModule,
    FieldTooltipModule,
    FieldPopoverModule,
    FieldIconModule,
    CheckboxModule,
    FormsModule,
    SelectedRowContainerModule,
    FieldGaugeModule,
    WorkflowPipeModule,
    PaginationModule,
    DueDateLabelModule,
    DateLabelModule,
  ],
  exports: [GridComponent],
})
export class GridModule {}
