import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalsModule } from 'gds-atom-components';

import { FieldIconComponent } from './field-icon.component';

@NgModule({
  declarations: [FieldIconComponent],
  imports: [CommonModule, ModalsModule],
  exports: [FieldIconComponent],
})
export class FieldIconModule {}
