import { Component, Input, Output, EventEmitter } from '@angular/core';

enum Names {
  Edit = 'edit',
  Delete = 'delete',
}

@Component({
  selector: 'app-field-icon',
  templateUrl: './field-icon.component.html',
  styleUrls: ['./field-icon.component.scss'],
})
export class FieldIconComponent {
  @Input() modal: Names;
  @Output() iconClicked = new EventEmitter<Names>();
  public readonly modalNames = Names;

  openModal(modalName: Names): void {
    this.iconClicked.emit(modalName);
  }
}
