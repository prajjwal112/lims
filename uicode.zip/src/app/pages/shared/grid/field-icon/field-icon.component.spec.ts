import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { FieldIconComponent } from './field-icon.component';

describe('FieldIconComponent', () => {
  let component: FieldIconComponent;
  let fixture: ComponentFixture<FieldIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FieldIconComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain an edit icon', () => {
    component.modal = component.modalNames.Edit;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.gds-icon-edit-default-mono'))).toBeTruthy();
  });

  it('should contain a delete icon', () => {
    component.modal = component.modalNames.Delete;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.gds-icon-bin-mono'))).toBeTruthy();
  });
});
