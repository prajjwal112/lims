import { Component, EventEmitter, Input, Output } from '@angular/core';
import type { Column } from '../column';

export interface FieldActionItem {
  name: string;
  display: string;
}

@Component({
  selector: 'app-field-action',
  templateUrl: './field-action.component.html',
  styleUrls: ['./field-action.component.scss'],
})
export class FieldActionComponent {
  @Input() column: Column;
  @Output() readonly actionClick = new EventEmitter<string>();

  readonly defaultSeparator = ' | ';
}
