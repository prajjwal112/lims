import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldActionComponent } from './field-action.component';
import { ColumnType } from '../column-type';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import type { FieldActionItem } from './field-action.component';
import type { Column } from '../column';

describe('FieldActionComponent', () => {
  const FIELD_ACTION_ITEMS: ReadonlyArray<FieldActionItem> = [
    { name: 'a', display: 'A' },
    { name: 'b', display: 'B' },
    { name: 'c', display: 'C' },
  ] as const;
  const newColumn = (): Column => {
    return { type: ColumnType.Action, field: 'action', title: '', width: 0, action: { items: [] } };
  };
  const setUpActions = (...fieldActionItems: FieldActionItem[]): void => {
    component.column.action.items.push(...fieldActionItems);
    fixture.detectChanges();
  };
  let component: FieldActionComponent;
  let fixture: ComponentFixture<FieldActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FieldActionComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldActionComponent);
    component = fixture.componentInstance;
    component.column = newColumn();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('display', () => {
    it('should have no actions by default', () => {
      expect(fixture.debugElement.nativeElement.textContent.trim()).toBe('');
    });

    it('should have one action when given one action', () => {
      setUpActions(FIELD_ACTION_ITEMS[0]);

      expect(fixture.debugElement.nativeElement.textContent.trim()).toBe(FIELD_ACTION_ITEMS[0].display);
    });

    it('should have multiple actions when given multiple actions', () => {
      setUpActions(...FIELD_ACTION_ITEMS);

      expect(fixture.debugElement.nativeElement.textContent.trim()).toBe(
        `${FIELD_ACTION_ITEMS[0].display} | ${FIELD_ACTION_ITEMS[1].display} | ${FIELD_ACTION_ITEMS[2].display}`
      );
    });

    it('should not use the default separator when given a separator', () => {
      setUpActions(...FIELD_ACTION_ITEMS);
      component.column.action.separator = ', ';
      fixture.detectChanges();

      expect(fixture.debugElement.nativeElement.textContent.trim()).toBe(
        `${FIELD_ACTION_ITEMS[0].display}, ${FIELD_ACTION_ITEMS[1].display}, ${FIELD_ACTION_ITEMS[2].display}`
      );
    });
  });

  describe('action click', () => {
    const EVENT = new Event('click');
    let actionClickEmitSpy: jasmine.Spy<(name: string) => void>;

    beforeEach(() => {
      actionClickEmitSpy = spyOn(component.actionClick, 'emit');
    });

    it('should emit proper name when only one action', () => {
      setUpActions(FIELD_ACTION_ITEMS[0]);

      fixture.debugElement.query(By.css('span')).nativeElement.dispatchEvent(EVENT);

      expect(actionClickEmitSpy).toHaveBeenCalledWith(FIELD_ACTION_ITEMS[0].name);
    });

    it('should emit proper names when multiple actions', () => {
      setUpActions(...FIELD_ACTION_ITEMS);

      const spans: DebugElement[] = fixture.debugElement.queryAll(By.css('span'));

      spans[0].nativeElement.dispatchEvent(EVENT);
      spans[1].nativeElement.dispatchEvent(EVENT);
      spans[2].nativeElement.dispatchEvent(EVENT);

      expect(spans.length).toBe(3);
      expect(actionClickEmitSpy).toHaveBeenCalledWith(FIELD_ACTION_ITEMS[0].name);
      expect(actionClickEmitSpy).toHaveBeenCalledWith(FIELD_ACTION_ITEMS[1].name);
      expect(actionClickEmitSpy).toHaveBeenCalledWith(FIELD_ACTION_ITEMS[2].name);
    });
  });
});
