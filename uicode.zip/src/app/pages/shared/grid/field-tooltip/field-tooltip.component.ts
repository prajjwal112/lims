import { Component, Input, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { isEmpty, isEqual, xorWith } from 'lodash';

const DEFAULT_MAX_ITEMS = 10;

@Component({
  selector: 'app-field-tooltip',
  templateUrl: './field-tooltip.component.html',
  styleUrls: ['./field-tooltip.component.scss'],
})
export class FieldTooltipComponent implements OnChanges {
  @Input() displayText = '';
  @Input() tooltipItems: (Record<string, unknown> | string)[] = [];
  @Input() tooltipItemsKey: string;
  @Input() maxItems = DEFAULT_MAX_ITEMS;

  items: (Record<string, unknown> | string)[] = [];

  ngOnChanges(changes: SimpleChanges): void {
    const tooltipItemsChange: SimpleChange = changes.tooltipItems;
    if (tooltipItemsChange && !isEmpty(xorWith(tooltipItemsChange.previousValue, tooltipItemsChange.currentValue, isEqual))) {
      const items = tooltipItemsChange.currentValue.slice(0, this.maxItems);

      if (tooltipItemsChange.currentValue.length > this.maxItems) {
        items.push('&mldr;');
      }

      this.items = items;
    }
  }
}
