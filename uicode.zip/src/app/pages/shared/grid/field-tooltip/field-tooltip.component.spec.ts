import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldTooltipComponent } from './field-tooltip.component';
import { TooltipModule } from 'gds-atom-components';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { DebugElement, SimpleChange } from '@angular/core';

describe('FieldTooltipComponent', () => {
  let component: FieldTooltipComponent;
  let fixture: ComponentFixture<FieldTooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FieldTooltipComponent],
      imports: [TooltipModule, NoopAnimationsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show dash by default', () => {
    expect(fixture.debugElement.nativeElement.textContent.trim()).toBe('-');
  });

  it('should show display text when given', () => {
    const text = 'Display Text';
    component.displayText = text;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent.trim()).toBe(text);
  });

  it('should show tooltip items when given', () => {
    const tooltipItems = ['1', '2'];
    component.ngOnChanges({ tooltipItems: new SimpleChange([], tooltipItems, true) });
    fixture.detectChanges();

    expect(
      fixture.debugElement.queryAll(By.css('li')).map((debugElement: DebugElement) => debugElement.nativeElement.textContent.trim())
    ).toEqual(tooltipItems);
  });

  it('should show ellipsis at end when too many items given', () => {
    const baseItems = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
    component.ngOnChanges({ tooltipItems: new SimpleChange([], [...baseItems, '11', '12'], true) });
    fixture.detectChanges();

    expect(
      fixture.debugElement.queryAll(By.css('li')).map((debugElement: DebugElement) => debugElement.nativeElement.textContent.trim())
    ).toEqual([...baseItems, '&mldr;']);
  });
});
