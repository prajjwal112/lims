import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TooltipModule } from 'gds-atom-components';
import { FieldTooltipComponent } from './field-tooltip.component';

@NgModule({
  declarations: [FieldTooltipComponent],
  imports: [CommonModule, TooltipModule],
  exports: [FieldTooltipComponent],
})
export class FieldTooltipModule {}
