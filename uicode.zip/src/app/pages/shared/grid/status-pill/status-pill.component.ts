import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { Status } from '../../status';
import { PillType } from '../../pills/pill-type';

@Component({
  selector: 'app-status-pill',
  templateUrl: './status-pill.component.html',
  styleUrls: ['./status-pill.component.scss'],
})
export class StatusPillComponent implements OnInit, OnChanges {
  /**
   * Pill status value
   */
  @Input() status: Status;

  /**
   * The pill type enum made public to the component template so it can build the UI
   */
  pillType: PillType;

  ngOnInit(): void {
    this.setPillType();
  }

  ngOnChanges(): void {
    this.setPillType();
  }

  private setPillType(): void {
    switch (this.status) {
      case Status.Completed:
        this.pillType = PillType.Success;
        break;
      case Status.InProgress:
        this.pillType = PillType.InProgress;
        break;
      case Status.Pending:
      case Status.Todo:
        this.pillType = PillType.Secondary;
        break;
      case Status.Blocked:
        this.pillType = PillType.Blocked;
        break;
    }
  }
}
