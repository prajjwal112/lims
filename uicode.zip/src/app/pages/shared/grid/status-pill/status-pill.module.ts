import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PillsModule } from '../../pills/pills.module';
import { StatusPillComponent } from './status-pill.component';

@NgModule({
  declarations: [StatusPillComponent],
  imports: [CommonModule, PillsModule],
  exports: [StatusPillComponent]
})
export class StatusPillModule {}
