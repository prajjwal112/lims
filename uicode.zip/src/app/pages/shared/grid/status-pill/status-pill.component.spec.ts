import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { Status } from '../../status';
import { StatusPillComponent } from './status-pill.component';
import { PillsModule } from '../../pills/pills.module';

describe('StatusPillComponent', () => {
  let component: StatusPillComponent;
  let fixture: ComponentFixture<StatusPillComponent>;
  const initComponent = (): void => {
    component.ngOnInit();
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StatusPillComponent],
      imports: [PillsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatusPillComponent);
    component = fixture.componentInstance;
    initComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show N/A as default', () => {
    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent).toBe('N/A');
  });

  it(`should show ${Status.Completed}`, () => {
    component.status = Status.Completed;
    initComponent();

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent).toBe(Status.Completed);
  });

  it(`should show ${Status.InProgress}`, () => {
    component.status = Status.InProgress;
    initComponent();

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent).toBe(Status.InProgress);
  });

  it(`should show ${Status.Pending}`, () => {
    component.status = Status.Pending;
    initComponent();

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent).toBe(Status.Pending);
  });

  it(`should show ${Status.Blocked}`, () => {
    component.status = Status.Blocked;
    initComponent();

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent).toBe(Status.Blocked);
  });

  it(`should show ${Status.Todo}`, () => {
    component.status = Status.Todo;
    initComponent();

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent).toBe(Status.Todo);
  });
});
