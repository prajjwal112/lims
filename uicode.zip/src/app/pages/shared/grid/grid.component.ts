import { Component, Input, Output, EventEmitter, KeyValueDiffers, KeyValueDiffer, DoCheck, ElementRef, ViewChild } from '@angular/core';
import { SortDescriptor } from '@progress/kendo-data-query';
import { RowArgs, SelectAllCheckboxState } from '@progress/kendo-angular-grid';
import { KmdPaginationComponent } from 'gds-atom-components';

import { GridService } from './grid.service';
import { ColumnType } from './column-type';
import { DEFAULT_SKIP } from '../common-data-type';
import { ItemizedTooltipType } from '../../../core/pipe/itemized-tooltip/workflow-itemized-tooltip.pipe';
import { FilterComponent } from './filter/filter.component';

import type { Column } from './column';

export interface Pagination {
  first: number;
  resultsPerPage: number;
  currentPage?: number;
}

export interface OptionResponse {
  dataItem: any;
  name: string;
}

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss'],
})
export class GridComponent implements DoCheck {
  @Input() actions: Record<string, string>;
  @Input() data: any[] = [];
  @Input() sort: SortDescriptor[] = [];
  @Input() sortMode: 'single' | 'multiple' = 'multiple';
  @Input() columns: Column[];
  @Input() searchBoxData: any[];
  @Input() searchBoxPlaceHolder: string;
  @Input() searchBoxKey: string;
  @Input() pagination: boolean;
  @Input() paginationOptions: any[] = [15, 20, 25, 30, 35];
  @Input() paginationTotal = 0;
  @Input() recordIdKey = '';
  @Input() selectField: '' | 'multi' | 'single' = '';
  @Input() showFilter = true;
  @Input() showSelectWithField = '';
  @Input() preSelectedRows: any[] = [];
  @Input() serverPagination = false;
  @Output() filterEvent = new EventEmitter<any>();
  @Output() searchEvent = new EventEmitter<string>();
  @Output() actionClick = new EventEmitter<OptionResponse>();
  @Output() iconClicked = new EventEmitter<OptionResponse>();
  @Output() rowSelected = new EventEmitter<any[]>();
  @Output() sortChanged = new EventEmitter<SortDescriptor[]>();
  @Output() actionOnSelectedRows = new EventEmitter<string>();
  @Output() pageChanged = new EventEmitter<Pagination>();

  @ViewChild('filter', { read: ElementRef }) private filterComponentElementRef: ElementRef;
  @ViewChild('filter') private filterComponent: FilterComponent;
  @ViewChild('paginationComponent') private paginationComponent: KmdPaginationComponent;

  readonly columnType = ColumnType;
  readonly itemizedTooltipType = ItemizedTooltipType;

  allowUnsort = true;
  selectedRows: any[] = [];
  selectAllState: SelectAllCheckboxState = 'unchecked';
  pageData: any[] = [];

  private differ: KeyValueDiffer<string, any>;

  constructor(private gridService: GridService, private differs: KeyValueDiffers) {
    this.rowsSelectedKeys = this.rowsSelectedKeys.bind(this);
  }

  ngDoCheck(): void {
    this.initializeDiffer();

    const didChange = this.differ?.diff(this.data);
    if (didChange) {
      this.pageData = this.data.slice();
      if (this.pagination && !this.serverPagination) {
        this.pageData = this.data.slice(DEFAULT_SKIP, this.paginationOptions[0]);
      }

      this.selectedRows = this.selectField === 'multi' ? this.preSelectedRows.slice() : this.preSelectedRows.slice(0, 1);

      this.gridService.getClearCheckboxes().subscribe({
        next: (data) => {
          if (data) {
            this.selectAllState = 'unchecked';
            this.gridService.setClearCheckboxes(false);
          }
        },
      });
    }
  }

  sortChange(sort: SortDescriptor[]): void {
    // Clear list by removing sort descriptors without direction
    const currentSort = sort.filter((item) => item.dir);

    // Emit the event
    this.sortChanged.emit(currentSort);
  }

  onSubmitFilter(filter: any): void {
    this.selectedRows = [];
    this.selectAllState = 'unchecked';
    this.filterEvent.emit(filter);
    this.resetPagination();
  }

  onActionClick(event: string, rowData: any): void {
    const emitObj = {
      dataItem: rowData,
      name: event,
    };
    this.actionClick.emit(emitObj);
  }

  clickIcon($event, rowData): void {
    const emitObj = {
      dataItem: rowData,
      name: $event,
    };
    this.iconClicked.emit(emitObj);
  }

  onSelectRow(): void {
    this.selectAllState = this.selectedRows.length === this.data.length ? 'checked' : 'unchecked';
    this.rowSelected.emit(this.selectedRows);
  }

  /**
   * Gives access to parent component to reset pagination
   */
  resetPagination(): void {
    if (this.paginationComponent) {
      this.paginationComponent.resultsPerPage = this.paginationOptions[0];
      this.paginationComponent.changePage(0);
    }
  }

  resetFilters(): void {
    if (this.filterComponent) {
      this.filterComponent.resetFilters();
    }
  }

  onSelectedRows(event: string): void {
    this.actionOnSelectedRows.emit(event);
  }

  rowsSelectedKeys(context: RowArgs): any {
    return context.dataItem[this.recordIdKey];
  }

  onSelectAllChange(checkedState: SelectAllCheckboxState): void {
    const checkboxChecked = checkedState === 'checked';
    this.selectedRows = checkboxChecked
      ? this.data.filter((obj) => !this.showSelectWithField || obj[this.showSelectWithField]).map((data) => data[this.recordIdKey])
      : [];
    this.selectAllState = checkedState;
    this.rowSelected.emit(this.selectedRows);
  }

  onSearchEvent(value: string): void {
    this.searchEvent.emit(value);
  }

  onPageChange(event: Pagination): void {
    if (this.selectField === 'multi') {
      this.gridService.setClearCheckboxes(true);
    }

    const start = event.first;
    const end = event.currentPage * event.resultsPerPage;
    this.pageData = this.data.slice(start, end);
    this.filterComponentElementRef.nativeElement.scrollIntoView();

    this.pageChanged.emit(event);
  }

  onRemoteTooltipItemHover(dataItem: any, column: Column): void {
    if (column.tooltipItems.loadField) {
      dataItem[column.tooltipItems.loadField]();
    }
  }

  private initializeDiffer(): void {
    if (this.data && !this.differ) {
      this.differ = this.differs.find(this.data).create();
    }
  }
}
