import { ColumnType } from './column-type';
import { FilterType } from './filter/shared/filter-type';
import { FilterRangeField, FilterListField, FilterCategorizedListField } from './filter/shared/filter-field';
import type { FilterRange } from './filter/shared/filter-range';
import type { FieldActionItem } from './action/field-action.component';
import type { ActionClickEvent, FieldPopoverMenuAction } from './popover/action/action-popover';

export interface ColumnFilter {
  type?: FilterType;
  field?: FilterRangeField | FilterListField | FilterCategorizedListField;
  // RangeList or List
  values?: any[];
  // List
  multiselect?: boolean;
  keyField?: string;
  displayField?: string;
  groupField?: string;
  categoryField?: string;
  // RangeList
  getRange?(key: string): FilterRange;
}

export interface Column {
  /** The column type. **/
  type: ColumnType;

  /** A row's data item key. */
  field: string;

  /** The header to be displayed. */
  title: string;

  /** The width. */
  width: number;

  /** Whether or not the column should be sortable. */
  sortable?: boolean;

  /** Whether or not the column should be filterable. */
  filterable?: boolean;

  /** The path to route to for {@link ColumnType.Link}. */
  linkPath?: string;

  /** An alternate data item key to use for display purposes. Useful for post-formatted data. */
  displayWithField?: string;

  /** The filter to use when {@link filterable} is <code>true</code>. */
  filter?: ColumnFilter;

  /**
   * The value to default to for this column when the row's value is empty. This will override the default values set in the grid.
   * You may supply an empty string if you do not want anything to display for when the row's value is empty.
   */
  defaultValueOverride?: string;

  /** The settings for {@link ColumnType.RemoteItemizedTooltip}. */
  tooltipItems?: {
    /** The field to read the tooltip items from. */
    field: string;

    /**
     * The field for a function on the data item which should be responsible for loading that data item's tooltip items.
     * The function should be zero-arg and return nothing.
     */
    loadField?: string;
  };

  /** The settings to use if the column type is a popover. */
  popover?: {
    /** Specialized settings for {@link ColumnType.ActionPopover}. */
    action?: {
      /** The items. */
      items: FieldPopoverMenuAction[];

      /** The callback for when an item is clicked. */
      onClick?(event: ActionClickEvent): void;
    };

    /** A callback, useful for dynamically changing popover content based on the given data item. */
    callback?(dataItem?: Record<string, unknown>): void;
  };

  /** The settings to use if the column type is {@link ColumnType.Action}. */
  action?: {
    /** The items. */
    items: FieldActionItem[];

    /** A separator. */
    separator?: string;
  };
}
