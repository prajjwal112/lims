import { DatePipe } from '@angular/common';
import { Component, Input, SimpleChanges, EventEmitter, Output, OnChanges } from '@angular/core';
import differenceWith from 'lodash/differenceWith';
import isEqual from 'lodash/isEqual';

import { ColumnFilter, Column } from '../column';
import { FilterType } from './shared/filter-type';
import { FilterListField, FilterRangeField, FilterCategorizedListField } from './shared/filter-field';
import { DateRangeFilter } from './date-range-filter/date-range-filter';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss'],
})
export class FilterComponent implements OnChanges {
  @Input() columns: Column[];
  @Input() searchBoxData: any;
  @Input() searchBoxPlaceHolder: string;
  @Input() searchBoxKey: string;
  @Input() showFilter = true;
  @Output() filterEvent = new EventEmitter<any>();
  @Output() searchEvent = new EventEmitter<string>();

  filterType = FilterType;
  hasFilters = false;

  filterIsOpen = {};
  filterValue = {};
  displayValue = {};

  private datePipe = new DatePipe('en-US');
  private filter = {};

  /**
   * Detect changes in the Component and updates internal values
   * with them.
   * @param {SimpleChanges} changes
   */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.columns && differenceWith(changes.columns.currentValue, changes.columns.previousValue, isEqual).length > 0) {
      this.hasFilters = changes.columns.currentValue.some((col: Column) => col.filterable);
    }
  }

  /**
   * Opens the filter for an specific column
   * @param {Column} column The filter related column
   */
  openFilter(column: Column): void {
    // Open just one
    this.filterIsOpen = { [column.field]: true };
  }

  /**
   * Called when a filter value has changed for an specific column
   * @param {Column} column The filter related column
   * @param {*} [filter] Filter params with the new value
   */
  filterChange(column: Column, filter?: any): void {
    const columnFilter = column.filter;

    // Filter with a value => Updates the filtering
    if (filter) {
      switch (columnFilter?.type) {
        case FilterType.DateRangeFuture:
        case FilterType.DateRangePast:
          this.dateRangeFilterChange(column.field, column.filter, filter);
          break;

        case FilterType.List:
          this.listFilterChange(column.field, column.filter, filter);
          break;

        case FilterType.RangeList:
          this.rangeListFilterChange(column.field, column.filter, filter);
          break;

        case FilterType.CategorizedList:
          this.categorizedListFilterChange(column.field, column.filter, filter);
          break;

        default:
          this.defaultFilterChange(column.field, filter);
      }
    } else {
      // No filter value => Clear filtering
      this.clearColumnFilter(column);
    }

    // Apply the filter
    this.submitFilter();
  }

  /**
   * Reset all the filters
   */
  resetFilters(): void {
    // Resets current filter
    this.filter = {};
    this.filterValue = {};
    this.displayValue = {};

    // Apply the filter
    this.submitFilter();
  }

  onSelectEvent(value: string): void {
    this.searchEvent.emit(value);
  }

  /**
   * Applies the current filter by emiting the filterEvent event
   */
  private submitFilter(): void {
    this.filterEvent.emit(this.filter);
  }

  /**
   * Called when a DateRange filter value has changed. Updates the filter object and current and display
   * values of the column filter.
   * @param {string} columnField
   * @param {ColumnFilter} columnFilter
   * @param {DateRangeFilter} filter
   */
  private dateRangeFilterChange(columnField: string, columnFilter: ColumnFilter, filter: DateRangeFilter): void {
    const filterField = columnFilter.field as FilterRangeField;
    let displayValue: string;

    this.filter = Object.assign({}, this.filter, {
      [filterField.min]: filter.minDate,
      [filterField.max]: filter.maxDate,
    });

    if (filter.minDate) {
      displayValue = this.datePipe.transform(filter.minDate, 'mediumDate');
    } else if (filter.maxDate) {
      displayValue = '';
    }

    if (filter.minDate && filter.maxDate) {
      displayValue += '-';
    }
    if (filter.maxDate) {
      displayValue += this.datePipe.transform(filter.maxDate, 'mediumDate');
    }

    // Updates the filter current and display values
    this.filterValue[columnField] = filter;
    this.displayValue[columnField] = displayValue;
  }

  /**
   * Called when a List filter value has changed. Updates the filter object and current and display
   * values of the column filter.
   * @param {string} columnField
   * @param {ColumnFilter} columnFilter
   * @param {object} filter
   */
  private listFilterChange(columnField: string, columnFilter: ColumnFilter, filter: Record<string, unknown[]>): void {
    const filterField = (columnFilter.field as FilterListField) || { field: columnField };
    const filterValue = filter[columnField];
    let displayValue: string;

    if (columnFilter.multiselect) {
      const items = filter[columnField];
      const keys = items.map((itemTmp) => itemTmp[columnFilter.keyField]);
      this.filter = Object.assign({}, this.filter, { [filterField.field]: keys });
    } else {
      this.filter = Object.assign({}, this.filter, { [filterField.field]: filter[columnField][columnFilter.keyField] });
    }

    if (columnFilter.multiselect) {
      displayValue = filterValue[0][columnFilter.displayField];
      if (filterValue.length > 1) {
        displayValue += ' +' + (filterValue.length - 1);
      }
    } else {
      displayValue = filterValue[columnFilter.displayField];
    }

    // Updates the filter current and display values
    this.filterValue[columnField] = filterValue;
    this.displayValue[columnField] = displayValue;
  }

  /**
   * Called when a RangeList filter value has changed. Updates the filter object and current and display
   * values of the column filter.
   * @param {string} columnField
   * @param {ColumnFilter} columnFilter
   * @param {object} filter
   */
  private rangeListFilterChange(columnField: string, columnFilter: ColumnFilter, filter: Record<string, unknown>): void {
    const filterField = columnFilter.field as FilterRangeField;
    const listItem = filter[columnField];
    const listItemKey = columnFilter.keyField ? listItem[columnFilter.keyField] : listItem;
    const range = columnFilter.getRange ? columnFilter.getRange(listItemKey) : null;

    this.filter = Object.assign({}, this.filter, {
      [filterField.min]: range?.min,
      [filterField.max]: range?.max,
    });

    // Updates the filter current and display values
    this.filterValue[columnField] = listItem;
    this.displayValue[columnField] = listItemKey;
  }

  /**
   * Called when a CategorizedList filter value has changed. Updates the filter object and current and display
   * values of the column filter.
   * @param {string} columnField
   * @param {ColumnFilter} columnFilter
   * @param {object} filter
   */
  private categorizedListFilterChange(columnField: string, columnFilter: ColumnFilter, filter: Record<string, unknown>): void {
    const categorizedListFilterField = columnFilter.field as FilterCategorizedListField;
    const categorizedItem = filter[columnField];
    const categorizedItemKey: string = categorizedItem[columnFilter.keyField].split('|')[1];
    const categorizedItemCategory: string = categorizedItem[columnFilter.categoryField];

    // Clear first previous values in case a different category has been selected
    Object.values(categorizedListFilterField.categories).forEach((field) => this.clearFilter(field));

    this.filter = Object.assign({}, this.filter, {
      [categorizedListFilterField.categories[categorizedItemCategory]]: categorizedItemKey,
    });

    // Updates the filter current and display values
    this.filterValue[columnField] = categorizedItem;
    this.displayValue[columnField] = categorizedItem[columnFilter.displayField];
  }

  /**
   * Called when a Default filter value has changed. Updates the filter object and current and display
   * values of the column filter.
   * @param {string} columnField
   * @param {ColumnFilter} columnFilter
   * @param {object} filter
   */
  private defaultFilterChange(columnField: string, filter: Record<string, unknown>): void {
    this.filter = Object.assign({}, this.filter, { [columnField]: filter[columnField] });

    // Updates the filter current and display values
    this.filterValue[columnField] = filter[columnField];
    this.displayValue[columnField] = filter[columnField];
  }

  /**
   * Clears a column filter
   * @param {Column} column
   */
  private clearColumnFilter(column: Column): void {
    const columnFilter = column.filter;

    if (columnFilter.field) {
      switch (columnFilter.type) {
        case FilterType.DateRangeFuture:
        case FilterType.DateRangePast:
        case FilterType.RangeList:
          this.clearFilter((columnFilter.field as FilterRangeField).min);
          this.clearFilter((columnFilter.field as FilterRangeField).max);
          break;

        case FilterType.List:
          this.clearFilter((columnFilter.field as FilterListField).field);
          break;

        case FilterType.CategorizedList:
          Object.values((columnFilter.field as FilterCategorizedListField).categories).forEach((field) => this.clearFilter(field));
          break;

        case FilterType.Generic:
          this.clearFilter(column.field);
          break;
      }
    } else {
      this.clearFilter(column.field);
    }

    // Removes the filter current and display values
    delete this.filterValue[column.field];
    delete this.displayValue[column.field];
  }

  /**
   * Clears part of the current filter
   * @param {string} [key] Key within the filter
   */
  private clearFilter(key?: string): void {
    if (key) {
      delete this.filter[key];
    }
  }
}
