export interface FilterRange {
  min: number;
  max: number;
}
