export enum FilterType {
  DateRangeFuture,
  DateRangePast,
  List,
  RangeList,
  CategorizedList,
  Generic,
}
