export class FilterListField {
  constructor(public field: string) {}
}

export class FilterRangeField {
  constructor(public min: string, public max: string) {}
}

export class FilterCategorizedListField {
  constructor(public categories: Record<string, string>) {}
}
