import { FilterRange } from './filter-range';

/**
 * List of priority types of a task
 */
export enum PriorityType {
  Low = 'Low',
  Medium = 'Medium',
  High = 'High',
  Critical = 'Critical',
}

enum PriorityNumeric {
  LOW_MIN = 0,
  LOW_MAX = 25,
  MEDIUM_MIN = 26,
  MEDIUM_MAX = 50,
  HIGH_MIN = 51,
  HIGH_MAX = 75,
  CRITICAL_MIN = 76,
  CRITICAL_MAX = 100,
}

export class PriorityNumericRange implements FilterRange {
  static readonly LOW = new PriorityNumericRange('LOW', PriorityNumeric.LOW_MIN, PriorityNumeric.LOW_MAX);
  static readonly MEDIUM = new PriorityNumericRange('MEDIUM', PriorityNumeric.MEDIUM_MIN, PriorityNumeric.MEDIUM_MAX);
  static readonly HIGH = new PriorityNumericRange('HIGH', PriorityNumeric.HIGH_MIN, PriorityNumeric.HIGH_MAX);
  static readonly CRITICAL = new PriorityNumericRange('CRITICAL', PriorityNumeric.CRITICAL_MIN, PriorityNumeric.CRITICAL_MAX);

  private constructor(private readonly key: string, public readonly min: number, public readonly max: number) {}

  static getRange(key: string): PriorityNumericRange {
    return PriorityNumericRange[key.toUpperCase()];
  }

  toString(): string {
    return this.key;
  }
}
