import { Component, EventEmitter, Input, OnChanges, Output, SimpleChange, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { addDays } from '@progress/kendo-date-math';
import { DateRange, DateRangeFilter } from './date-range-filter';
import { FilterType } from '../shared/filter-type';
import { DATE_INPUT_FORMAT } from '../../../../../core/app-settings';

@Component({
  selector: 'app-date-range-filter',
  templateUrl: './date-range-filter.component.html',
  styleUrls: ['./date-range-filter.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DateRangeFilterComponent implements OnChanges {
  @Input() filterIsOpen: boolean;
  @Input() filteredValue: DateRangeFilter;
  @Input() filterType: FilterType.DateRangeFuture | FilterType.DateRangePast;
  @Input() title = '';
  @Output() filterIsOpenChange = new EventEmitter<boolean>();
  @Output() filterChange = new EventEmitter<DateRangeFilter>();

  readonly dateInputFormat = DATE_INPUT_FORMAT;

  filterValue: DateRange = { min: null, max: null };
  fieldsDisplay = true;
  titleDisplay = '';

  private static setToStartOfDay(date: Date): Date {
    const dateCopy = DateRangeFilterComponent.copyDate(date);
    dateCopy.setHours(0, 0, 0, 0);
    return dateCopy;
  }

  private static setToEndOfDay(date: Date): Date {
    const dateCopy = DateRangeFilterComponent.copyDate(date);
    dateCopy.setHours(23, 59, 59, 999);
    return dateCopy;
  }

  private static copyDate(date: Date): Date {
    return new Date(date.getTime());
  }

  /**
   * Detects changes in the Component and updates internal values with
   * them.
   * @param {SimpleChanges} changes
   */
  ngOnChanges(changes: SimpleChanges): void {
    const filteredValue = changes.filteredValue?.currentValue;
    if (filteredValue) {
      this.refreshFilterValue(filteredValue);
    }

    this.setTitleDisplay(changes.title);
    this.fieldsDisplay = !this.filterValue.min || !this.filterValue.max;
  }

  /**
   * Sets the date rage to the specified days in the future/past.
   * @param {number} days
   */
  onSetDateRange(days: number): void {
    if (this.filterType === FilterType.DateRangeFuture) {
      this.setDateRangeFuture(days);
    } else if (this.filterType === FilterType.DateRangePast) {
      this.setDateRangePast(days);
    }
  }

  /**
   * Shows the fields.
   */
  onShowFields(): void {
    this.fieldsDisplay = true;
  }

  /**
   * Clears the specified field value.
   * @param {('min' | 'max')} dateRange
   */
  onClearField(dateRange: 'min' | 'max'): void {
    // First show the date fields
    this.onShowFields();

    // Then clear the value using a setTimeout. This is done to avoid errors as there are another update
    // on initialization of the date field at display time. So we wait it is initialized and then we clear it.
    setTimeout(() => {
      this.filterValue[dateRange] = null;
    });
  }

  /**
   * Closes the filter.
   */
  onCloseFilter(): void {
    this.filterIsOpenChange.emit(false);

    // Reset back to the filtered value
    this.refreshFilterValue(this.filteredValue);
  }

  /**
   * Confirms the filter value and close it.
   */
  onConfirmFilter(): void {
    this.filterIsOpenChange.emit(false);

    if (this.filterValue.min || this.filterValue.max) {
      this.filterChange.emit({
        minDate: this.filterValue.min ? DateRangeFilterComponent.setToStartOfDay(this.filterValue.min).toISOString() : null,
        maxDate: this.filterValue.max ? DateRangeFilterComponent.setToEndOfDay(this.filterValue.max).toISOString() : null,
      });
    } else {
      this.filterChange.emit();
    }
  }

  private setTitleDisplay(titleChange?: SimpleChange): void {
    const previousTitleValue = titleChange?.previousValue?.trim().toLowerCase();
    const currentTitleValue = titleChange?.currentValue?.trim().toLowerCase();
    if (currentTitleValue && currentTitleValue !== previousTitleValue) {
      this.titleDisplay =
        currentTitleValue.charAt(0).toUpperCase() +
        currentTitleValue.slice(1) +
        (this.filterType === FilterType.DateRangeFuture ? ' in next: ' : ' in past: ');
    }
  }

  /**
   * Refreshes the internal filter value.
   * @param {*} newValue
   */
  private refreshFilterValue(newValue: DateRangeFilter): void {
    if (!newValue) {
      this.filterValue = { min: null, max: null };
    } else {
      this.filterValue = {
        min: newValue.minDate ? new Date(newValue.minDate) : null,
        max: newValue.maxDate ? new Date(newValue.maxDate) : null,
      };
    }
  }

  private setDateRangeFuture(days: number): void {
    const min = new Date();
    const max = addDays(min, days);

    this.resetFilterValues(max, min);
  }

  private setDateRangePast(days: number): void {
    const max = new Date();
    const min = addDays(max, -Math.abs(days));

    this.resetFilterValues(max, min);
  }

  private resetFilterValues(max: Date, min: Date): void {
    this.filterValue.min = min;
    this.filterValue.max = max;

    // Hide fields
    this.fieldsDisplay = false;
  }
}
