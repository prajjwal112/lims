import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { WindowModule } from '@progress/kendo-angular-dialog';
import { IntlModule } from '@progress/kendo-angular-intl';
import { DateInputModule, DateRangeModule } from '@progress/kendo-angular-dateinputs';
import { LabelModule } from '@progress/kendo-angular-label';

import { DateRangeFilterComponent } from './date-range-filter.component';
import { DateRangeFilter } from './date-range-filter';
import { FilterType } from '../shared/filter-type';
import { SimpleChange } from '@angular/core';

describe('DateRangeFilterComponent', () => {
  let component: DateRangeFilterComponent;
  let fixture: ComponentFixture<DateRangeFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DateRangeFilterComponent],
      imports: [WindowModule, IntlModule, LabelModule, DateRangeModule, DateInputModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateRangeFilterComponent);
    component = fixture.componentInstance;
    component.filterIsOpen = true;
    component.filterType = FilterType.DateRangeFuture;
    fixture.detectChanges();
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('title', () => {
    it('should not show by default', () => {
      expect(fixture.debugElement.query(By.css('p.mb-2.px-3')).nativeElement.textContent.trim()).toBe('');
    });

    it(`should show when given with ${FilterType[FilterType.DateRangeFuture]}`, () => {
      component.ngOnChanges({ title: new SimpleChange('', 'Due Date', true) });
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('p.mb-2.px-3')).nativeElement.textContent.trim()).toBe('Due date in next:');
    });

    it(`should show when given with ${FilterType[FilterType.DateRangePast]}`, () => {
      component.filterType = FilterType.DateRangePast;
      component.ngOnChanges({ title: new SimpleChange('', 'Estimated Completion Date', true) });
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('p.mb-2.px-3')).nativeElement.textContent.trim()).toBe('Estimated completion date in past:');
    });
  });

  it('should have day preset filters', () => {
    const links = fixture.debugElement.queryAll(By.css('div.row a'));

    expect(links.length).toEqual(3);
  });

  it('should select 15 days in the future', () => {
    const addFifteenDays = 1.296e9;
    jasmine.clock().install();

    expect(component.filterValue.min).toBeNull();
    const button = fixture.debugElement.queryAll(By.css('div.row a:nth-child(1)'))[0].nativeElement;
    button.click();
    fixture.detectChanges();

    const endTimeMock = component.filterValue.min;
    jasmine.clock().mockDate(endTimeMock);
    jasmine.clock().tick(addFifteenDays);

    expect(component.filterValue.min).not.toBeNull();
    expect(component.filterValue.max).toEqual(new Date());
    pending('Jasmine clock handles daylight savings time differently from the component date range');
  });

  it('should select 30 days in the future', () => {
    const addThirtyDays = 2.592e9;
    jasmine.clock().install();

    expect(component.filterValue.min).toBeNull();
    const button = fixture.debugElement.queryAll(By.css('div.row a:nth-child(1)'))[1].nativeElement;
    button.click();
    fixture.detectChanges();

    const endTimeMock = component.filterValue.min;
    jasmine.clock().mockDate(endTimeMock);
    jasmine.clock().tick(addThirtyDays);

    expect(component.filterValue.min).not.toBeNull();
    expect(component.filterValue.max).toEqual(new Date());
    pending('Jasmine clock handles daylight savings time differently from the component date range');
  });

  it('should select 90 days in the future', () => {
    const addNinetyDays = 7.7796e9;
    jasmine.clock().install();

    expect(component.filterValue.min).toBeNull();
    const button = fixture.debugElement.queryAll(By.css('div.row a:nth-child(1)'))[2].nativeElement;
    button.click();
    fixture.detectChanges();

    const endTimeMock = component.filterValue.min;
    jasmine.clock().mockDate(endTimeMock);
    jasmine.clock().tick(addNinetyDays);

    expect(component.filterValue.min).not.toBeNull();
    expect(component.filterValue.max).toEqual(new Date());
    pending('Jasmine clock handles daylight savings time differently from the component date range');
  });

  it('should show filter pills after selecting preset', () => {
    const button = fixture.debugElement.query(By.css('div.row a')).nativeElement;

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label')).length).toEqual(0);
    button.click();
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label')).length).toEqual(2);
  });

  it('should clear selected start date range', (done) => {
    component.fieldsDisplay = false;
    component.filterValue.min = new Date();
    fixture.detectChanges();

    expect(component.filterValue.min).not.toBeNull();
    const link = fixture.debugElement.queryAll(By.css('.gds-icon-close-bold'))[0].nativeElement;
    link.click();
    setTimeout(() => {
      expect(component.filterValue.min).toBeNull();
      done();
    });
  });

  it('should clear selected end date range', (done) => {
    component.fieldsDisplay = false;
    component.filterValue.max = new Date();
    fixture.detectChanges();

    expect(component.filterValue.max).not.toBeNull();
    const link = fixture.debugElement.queryAll(By.css('.gds-icon-close-bold'))[1].nativeElement;
    link.click();
    setTimeout(() => {
      expect(component.filterValue.max).toBeNull();
      done();
    });
  });

  it('should raise dateFilterChange event when submit is clicked', () => {
    const date = new Date();
    const expectedDateFilter: DateRangeFilter = {
      minDate: new Date(date.setHours(0, 0, 0, 0)).toISOString(),
      maxDate: null,
    };
    let dateFilter: DateRangeFilter;
    component.filterChange.subscribe((filter: DateRangeFilter) => (dateFilter = filter));

    component.filterValue.min = date;
    component.fieldsDisplay = false;
    fixture.detectChanges();

    const button = fixture.debugElement.query(By.css('button[kmdsecondarybutton]')).nativeElement;
    button.click();

    expect(dateFilter).toEqual(expectedDateFilter);
  });
});
