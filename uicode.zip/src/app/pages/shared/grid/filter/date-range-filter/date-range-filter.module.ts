import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { IntlModule } from '@progress/kendo-angular-intl';
import { DateRangeModule, DateInputModule } from '@progress/kendo-angular-dateinputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { ButtonModule } from 'gds-atom-components';

import { DateRangeFilterComponent } from './date-range-filter.component';

@NgModule({
  declarations: [DateRangeFilterComponent],
  imports: [CommonModule, WindowModule, IntlModule, LabelModule, DateRangeModule, DateInputModule, ButtonModule],
  exports: [DateRangeFilterComponent],
})
export class DateRangeFilterModule {}
