type iso = string;

export interface DateRange {
  min: Date;
  max: Date;
}

export interface DateRangeFilter {
  minDate?: iso;
  maxDate?: iso;
}
