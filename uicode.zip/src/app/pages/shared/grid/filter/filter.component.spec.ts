import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { FilterComponent } from './filter.component';
import { DateRangeFilterModule } from './date-range-filter/date-range-filter.module';
import { GenericFilterModule } from './generic-filter/generic-filter.module';
import { Column } from '../column';
import { ColumnType } from '../column-type';
import { SimpleChange } from '@angular/core';
import { DropDownAutoCompleteModule } from '../../dropdown-autocomplete/dropdown-autocomplete.module';
import { FilterType } from './shared/filter-type';

describe('FilterComponent', () => {
  let component: FilterComponent;
  let fixture: ComponentFixture<FilterComponent>;
  let allColumns: Map<string, Column>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FilterComponent],
      imports: [DateRangeFilterModule, GenericFilterModule, DropDownAutoCompleteModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    allColumns = new Map<string, Column>();
    allColumns.set('dueDate', {
      type: ColumnType.Date,
      field: 'dueDate',
      title: 'Due date',
      width: 100,
      sortable: true,
      filterable: false,
    });
    allColumns.set('taskName', {
      type: ColumnType.Link,
      field: 'name',
      title: 'Task name',
      width: 100,
      sortable: false,
      filterable: false,
    });
    allColumns.set('workflowName', {
      type: ColumnType.String,
      field: 'workflowName',
      title: 'Workflow',
      width: 100,
      sortable: false,
      filterable: false,
    });
    allColumns.set('status', {
      type: ColumnType.String,
      field: 'status',
      title: 'Status',
      width: 100,
      sortable: false,
      filterable: false,
    });
    allColumns.set('priority', {
      type: ColumnType.String,
      field: 'priority',
      title: 'Priority',
      width: 100,
      sortable: false,
      filterable: false,
    });
    allColumns.set('roles', {
      type: ColumnType.String,
      field: 'roles',
      title: 'Role',
      width: 100,
      sortable: false,
      filterable: false,
    });
    allColumns.set('groups', {
      type: ColumnType.String,
      field: 'groups',
      title: 'Group',
      width: 100,
      sortable: false,
      filterable: false,
    });
    allColumns.set('projects', {
      type: ColumnType.String,
      field: 'projects',
      title: 'Project',
      width: 100,
      sortable: false,
      filterable: false,
    });

    fixture = TestBed.createComponent(FilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not show filters', () => {
    component.columns = [...allColumns.values()];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('div'))).not.toBeTruthy();
  });

  it('should show date filter', () => {
    allColumns.get('dueDate').filterable = true;
    allColumns.get('dueDate').filter = { type: FilterType.DateRangeFuture };

    const columns = [...allColumns.values()];

    component.columns = columns;
    component.ngOnChanges({
      columns: new SimpleChange(null, columns, true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('app-date-range-filter')).length).toEqual(1);
  });

  it('should show generic filter', () => {
    allColumns.get('status').filterable = true;
    allColumns.get('priority').filterable = true;

    const columns = [...allColumns.values()];

    component.columns = columns;
    component.ngOnChanges({
      columns: new SimpleChange(null, columns, true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('app-generic-filter')).length).toEqual(2);
  });

  it('should show status filter label when value is populated', () => {
    allColumns.get('status').filterable = true;
    allColumns.get('priority').filterable = true;

    const columns = [...allColumns.values()];

    component.columns = columns;
    component.ngOnChanges({
      columns: new SimpleChange(null, columns, true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Status');
    component.filterChange(allColumns.get('status'), { status: 'Status value' });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Status value');
  });

  it('should show priority filter label when value is populated', () => {
    allColumns.get('status').filterable = true;
    allColumns.get('priority').filterable = true;

    const columns = [...allColumns.values()];

    component.columns = columns;
    component.ngOnChanges({
      columns: new SimpleChange(null, columns, true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[1].nativeElement.textContent.trim()).toBe('Priority');
    component.filterChange(allColumns.get('status'), { status: 'Priority value' });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Priority value');
  });

  it('should show role filter label when value is populated', () => {
    allColumns.get('roles').filterable = true;
    const columns = [...allColumns.values()];

    component.columns = columns.slice();
    component.ngOnChanges({
      columns: new SimpleChange(null, columns.slice(), true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Role');
    component.filterChange(allColumns.get('roles'), { roles: 'Role value' });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Role value');
  });

  it('should show project filter label when value is populated', () => {
    allColumns.get('projects').filterable = true;
    const columns = [...allColumns.values()];

    component.columns = columns.slice();
    component.ngOnChanges({
      columns: new SimpleChange(null, columns.slice(), true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Project');
    component.filterChange(allColumns.get('projects'), { projects: 'Project value' });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Project value');
  });

  it('should show group filter label when value is populated', () => {
    allColumns.get('groups').filterable = true;
    const columns = [...allColumns.values()];

    component.columns = columns.slice();
    component.ngOnChanges({
      columns: new SimpleChange(null, columns.slice(), true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Group');
    component.filterChange(allColumns.get('groups'), { groups: 'Group value' });
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.grid-filter-label'))[0].nativeElement.textContent.trim()).toBe('Group value');
  });
});
