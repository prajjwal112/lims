import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DateRangeFilterModule } from './date-range-filter/date-range-filter.module';
import { GenericFilterModule } from './generic-filter/generic-filter.module';
import { FilterComponent } from './filter.component';
import { DropDownAutoCompleteModule } from '../../dropdown-autocomplete/dropdown-autocomplete.module';
import { ListFilterModule } from './list-filter/list-filter.module';

@NgModule({
  declarations: [FilterComponent],
  imports: [CommonModule, DateRangeFilterModule, ListFilterModule, GenericFilterModule, DropDownAutoCompleteModule],
  exports: [FilterComponent],
})
export class FilterModule {}
