import { Component, Input, Output, EventEmitter, SimpleChanges, OnChanges, OnInit } from '@angular/core';
import { groupBy } from '@progress/kendo-data-query';

@Component({
  selector: 'app-list-filter',
  templateUrl: './list-filter.component.html',
  styleUrls: ['./list-filter.component.scss'],
})
export class ListFilterComponent implements OnInit, OnChanges {
  @Input() multiselect: boolean;
  @Input() filterIsOpen: boolean;
  @Input() key: string;
  @Input() title: string;
  @Input() keyField: string;
  @Input() displayField: string;
  @Input() groupField: string;
  @Input() data: any[];
  @Input() filteredValue: any;
  @Output() filterIsOpenChange = new EventEmitter<boolean>();
  @Output() filterChange = new EventEmitter<any>();

  defaultItem: any;
  filterValue: any;
  filteredData: any[];

  /**
   * Initializes the Component.
   */
  ngOnInit(): void {
    if (this.multiselect) {
      this.defaultItem = [];
    } else {
      this.defaultItem = this.displayField ? { [this.displayField]: '(None)' } : '(None)';
    }
  }

  /**
   * Detects changes in the Component and updates internal values with
   * them.
   * @param {SimpleChanges} changes
   */
  ngOnChanges(changes: SimpleChanges): void {
    if (!this.filteredValue) {
      this.filterValue = this.filteredValue;
    }

    if (changes.data) {
      this.filteredData = changes.data.currentValue;
      if (this.filteredData && this.groupField) {
        this.filteredData = groupBy(this.filteredData, [{ field: this.groupField }]);
      }
    }
  }

  /**
   * Checks whether an item is currently selected or not.
   * @param {*} item
   * @returns {boolean}
   */
  isItemSelected(item: any): boolean {
    return this.filterValue?.some((selectedItem) => selectedItem === item);
  }

  /**
   * Closes the filter
   */
  onCloseFilter(): void {
    this.filterIsOpenChange.emit(false);

    if (this.filteredValue) {
      this.filterValue = this.filteredValue;
    }
  }

  /**
   * Confirms the filter value and close it.
   */
  onConfirmFilter(): void {
    this.filterIsOpenChange.emit(false);

    if (this.filterValue && this.filterValue !== this.defaultItem && (!this.multiselect || this.filterValue.length > 0)) {
      this.filterChange.emit({
        [this.key]: this.filterValue,
      });
    } else {
      this.filterChange.emit();
    }
  }

  /**
   * Called when the value has changed to store it.
   * @param {*} event
   */
  onValueChange(event: any): void {
    this.filterValue = event;
  }

  /**
   * Called when the value of the searchbox changes to refilter listed
   * data.
   * @param {string} event The new value to filter values of the dropdown list
   */
  onFilterChange(event: string): void {
    const filterValue = event.toLowerCase();
    this.filteredData = this.data.filter((item) => item[this.displayField].toLowerCase().indexOf(filterValue) !== -1);

    if (this.filteredData && this.groupField) {
      this.filteredData = groupBy(this.filteredData, [{ field: this.groupField }]);
    }
  }
}
