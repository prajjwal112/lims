import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DropDownListModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { ButtonModule } from 'gds-atom-components';

import { ListFilterComponent } from './list-filter.component';

@NgModule({
  declarations: [ListFilterComponent],
  imports: [CommonModule, DropDownsModule, DropDownListModule, WindowModule, ButtonModule],
  exports: [ListFilterComponent],
})
export class ListFilterModule {}
