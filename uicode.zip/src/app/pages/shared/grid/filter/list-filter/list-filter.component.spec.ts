import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SimpleChange } from '@angular/core';
import { By } from '@angular/platform-browser';

import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { WindowModule } from '@progress/kendo-angular-dialog';

import { ListFilterComponent } from './list-filter.component';

describe('ListFilterComponent', () => {
  let component: ListFilterComponent;
  let fixture: ComponentFixture<ListFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ListFilterComponent],
      imports: [WindowModule, DropDownListModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListFilterComponent);
    component = fixture.componentInstance;

    component.filterIsOpen = true;
    component.data = ['', 'Pending', 'In Progress', 'Completed', 'To Do', 'Blocked'];
    component.key = 'status';
    component.ngOnChanges({
      filterIsOpen: new SimpleChange(null, true, true),
    });

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show filter control and confirm button', () => {
    expect(fixture.debugElement.queryAll(By.css('kendo-dropdownlist')).length).toEqual(1);
    expect(fixture.debugElement.queryAll(By.css('button[kmdSecondaryButton]')).length).toEqual(1);
  });

  it('should raise filterChange event when confirm is clicked', () => {
    const expectedFilter = {
      status: 'Pending',
    };
    let filterValue;
    component.filterChange.subscribe(filter => (filterValue = filter));

    component.filterValue = 'Pending';
    fixture.detectChanges();

    const button = fixture.debugElement.query(By.css('button[kmdSecondaryButton]')).nativeElement;
    button.click();

    expect(filterValue).toEqual(expectedFilter);
  });
});
