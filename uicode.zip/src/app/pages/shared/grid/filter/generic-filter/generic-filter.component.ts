import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';

@Component({
  selector: 'app-generic-filter',
  templateUrl: './generic-filter.component.html',
  styleUrls: ['./generic-filter.component.scss'],
})
export class GenericFilterComponent implements OnChanges {
  @Input() filterIsOpen: boolean;
  @Input() key: string;
  @Input() title: string;
  @Input() data: any;
  @Input() filteredValue: string;
  @Output() filterIsOpenChange = new EventEmitter<boolean>();
  @Output() filterChange = new EventEmitter<any>();

  filterValue: string;

  /**
   * Called when there are changes in the Component.
   */
  ngOnChanges(): void {
    if (!this.filteredValue) {
      this.filterValue = '';
    }
  }

  /**
   * Closes the filter.
   */
  onCloseFilter(): void {
    this.filterIsOpenChange.emit(false);

    if (this.filteredValue) {
      this.filterValue = this.filteredValue;
    }
  }

  /**
   * Confirms the filter value and close it.
   */
  onConfirmFilter(): void {
    this.filterIsOpenChange.emit(false);

    if (this.filterValue) {
      this.filterChange.emit({
        [this.key]: this.filterValue,
      });
    } else {
      this.filterChange.emit();
    }
  }
}
