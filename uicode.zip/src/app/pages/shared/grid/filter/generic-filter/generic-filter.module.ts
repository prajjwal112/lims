import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { WindowModule } from '@progress/kendo-angular-dialog';

import { GenericFilterComponent } from './generic-filter.component';
import { ButtonModule } from 'gds-atom-components';

@NgModule({
  declarations: [GenericFilterComponent],
  imports: [CommonModule, DropDownListModule, WindowModule, ButtonModule],
  exports: [GenericFilterComponent],
})
export class GenericFilterModule {}
