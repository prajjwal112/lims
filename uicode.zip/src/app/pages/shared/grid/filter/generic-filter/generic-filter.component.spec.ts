import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { WindowModule } from '@progress/kendo-angular-dialog';

import { GenericFilterComponent } from './generic-filter.component';

describe('GenericFilterComponent', () => {
  let component: GenericFilterComponent;
  let fixture: ComponentFixture<GenericFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GenericFilterComponent],
      imports: [WindowModule, DropDownListModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericFilterComponent);
    component = fixture.componentInstance;

    component.filterIsOpen = true;
    component.data = ['', 'Pending', 'In Progress', 'Completed', 'Todo', 'Blocked'];
    component.key = 'status';

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show filter control and confirm button', () => {
    expect(fixture.debugElement.queryAll(By.css('kendo-dropdownlist')).length).toEqual(1);
    expect(fixture.debugElement.queryAll(By.css('button[kmdSecondaryButton]')).length).toEqual(1);
  });

  it('should raise filterChange event when confirm is clicked', () => {
    const expectedFilter = {
      status: 'Pending',
    };
    let filterValue;
    component.filterChange.subscribe(filter => (filterValue = filter));

    component.filterValue = 'Pending';
    fixture.detectChanges();

    const button = fixture.debugElement.query(By.css('button[kmdSecondaryButton]')).nativeElement;
    button.click();

    expect(filterValue).toEqual(expectedFilter);
  });
});
