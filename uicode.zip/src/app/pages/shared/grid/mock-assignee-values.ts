import type { Assignee } from '../../../core/api/assignee/assignee.service';

export const mockAssigneeValues: Assignee[] = [
  {
    id: 'Group|672',
    name: 'Analytical',
    category: 'Group',
  },
  {
    id: 'Group|676',
    name: 'Davin Group A',
    category: 'Group',
  },
  {
    id: 'Group|677',
    name: 'Davin Group B',
    category: 'Group',
  },
  {
    id: 'Group|679',
    name: 'Davin Group C',
    category: 'Group',
  },
  {
    id: 'Group|680',
    name: 'Davin Group D',
    category: 'Group',
  },
  {
    id: 'Group|681',
    name: 'Davin Group E',
    category: 'Group',
  },
  {
    id: 'Group|694',
    name: 'Davin Group F',
    category: 'Group',
  },
  {
    id: 'Group|696',
    name: 'Documentation',
    category: 'Group',
  },
  {
    id: 'Group|695',
    name: 'Global Research and Development',
    category: 'Group',
  },
  {
    id: 'Group|673',
    name: 'Molecular Biology',
    category: 'Group',
  },
  {
    id: 'Group|674',
    name: 'Sample Accessioning',
    category: 'Group',
  },
  {
    id: 'Group|675',
    name: 'Sequencing',
    category: 'Group',
  },
  {
    id: 'Group|684',
    name: 'Test Group A',
    category: 'Group',
  },
  {
    id: 'Group|697',
    name: 'Testing new build',
    category: 'Group',
  },
  {
    id: 'User|25',
    name: 'Davin English',
    category: 'User',
  },
  {
    id: 'User|24',
    name: 'LIMS Account',
    category: 'User',
  },
  {
    id: 'User|17',
    name: 'Nicole Ware',
    category: 'User',
  },
  {
    id: 'User|10',
    name: 'Norah Do',
    category: 'User',
  },
  {
    id: 'User|11',
    name: 'Sharif Ahmed',
    category: 'User',
  },
  {
    id: 'User|12',
    name: 'Shen Liu',
    category: 'User',
  },
  {
    id: 'User|15',
    name: 'Swift Five',
    category: 'User',
  },
  {
    id: 'User|14',
    name: 'Swift Four',
    category: 'User',
  },
  {
    id: 'User|13',
    name: 'Swift Three',
    category: 'User',
  },
];
