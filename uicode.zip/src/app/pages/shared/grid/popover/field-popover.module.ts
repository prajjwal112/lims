import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopoverModule, ModalsModule } from 'gds-atom-components';

import { FieldPopoverComponent } from './field-popover.component';
import { FieldActionPopoverContentComponent } from './action/field-action-popover-content.component';

@NgModule({
  declarations: [FieldPopoverComponent, FieldActionPopoverContentComponent],
  imports: [CommonModule, PopoverModule, ModalsModule],
  exports: [FieldPopoverComponent, FieldActionPopoverContentComponent],
})
export class FieldPopoverModule {}
