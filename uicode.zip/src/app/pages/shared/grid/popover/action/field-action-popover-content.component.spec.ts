import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldActionPopoverContentComponent } from './field-action-popover-content.component';
import { ActionClickEvent, FieldPopoverMenuAction } from './action-popover';
import { Column } from '../../column';
import { ColumnType } from '../../column-type';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('FieldPopoverItemModalMenuComponent', () => {
  const FIELD_POPOVER_MENU_ACTIONS: ReadonlyArray<FieldPopoverMenuAction> = [
    { name: 'a', display: 'A' },
    { name: 'b', display: 'B' },
    { name: 'c', display: 'C' },
  ] as const;
  const newColumn = (): Column => {
    return {
      type: ColumnType.ActionPopover,
      field: 'action',
      title: '',
      width: 0,
      popover: { action: { items: [] } },
    };
  };
  const setUpActions = (...fieldPopoverMenuActions: FieldPopoverMenuAction[]): void => {
    component.column.popover.action.items.push(...fieldPopoverMenuActions);
    fixture.detectChanges();
  };
  const queryListItems = (): DebugElement[] => {
    return fixture.debugElement.queryAll(By.css('li'));
  };
  let component: FieldActionPopoverContentComponent;
  let fixture: ComponentFixture<FieldActionPopoverContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FieldActionPopoverContentComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldActionPopoverContentComponent);
    component = fixture.componentInstance;
    component.column = newColumn();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('display', () => {
    it('should have no actions by default', () => {
      expect(fixture.debugElement.query(By.css('li'))).toBeFalsy();
    });

    it('should have one action when given one action', () => {
      setUpActions(FIELD_POPOVER_MENU_ACTIONS[0]);

      expect(fixture.debugElement.query(By.css('li')).nativeElement.textContent.trim()).toBe(FIELD_POPOVER_MENU_ACTIONS[0].display);
    });

    it('should have multiple actions when given multiple actions', () => {
      setUpActions(...FIELD_POPOVER_MENU_ACTIONS);

      const listItems = queryListItems();

      expect(listItems.length).toBe(3);
      expect(listItems[0].nativeElement.textContent.trim()).toBe(FIELD_POPOVER_MENU_ACTIONS[0].display);
      expect(listItems[1].nativeElement.textContent.trim()).toBe(FIELD_POPOVER_MENU_ACTIONS[1].display);
      expect(listItems[2].nativeElement.textContent.trim()).toBe(FIELD_POPOVER_MENU_ACTIONS[2].display);
    });

    it('should have a disabled element when given a disabled element', () => {
      FIELD_POPOVER_MENU_ACTIONS[1].disabled = true;

      setUpActions(FIELD_POPOVER_MENU_ACTIONS[0], FIELD_POPOVER_MENU_ACTIONS[1]);

      const listItems = queryListItems();

      expect(listItems.length).toBe(2);
      expect(listItems[0].nativeElement.classList).not.toContain('disabled');
      expect(listItems[1].nativeElement.classList).toContain('disabled');
    });
  });

  describe('action click', () => {
    const EVENT = new Event('click');
    let actionClickEmitSpy: jasmine.Spy<(event: ActionClickEvent) => void>;

    beforeEach(() => {
      actionClickEmitSpy = spyOn(component.actionClick, 'emit');
    });

    it('should emit proper name when only one action', () => {
      setUpActions(FIELD_POPOVER_MENU_ACTIONS[0]);

      fixture.debugElement.query(By.css('li')).nativeElement.dispatchEvent(EVENT);

      expect(actionClickEmitSpy).toHaveBeenCalledWith({ name: FIELD_POPOVER_MENU_ACTIONS[0].name, dataItem: undefined });
    });

    it('should emit proper names when multiple actions', () => {
      setUpActions(...FIELD_POPOVER_MENU_ACTIONS);

      const listItems = queryListItems();

      listItems[0].nativeElement.dispatchEvent(EVENT);
      listItems[1].nativeElement.dispatchEvent(EVENT);
      listItems[2].nativeElement.dispatchEvent(EVENT);

      expect(listItems.length).toBe(3);
      expect(actionClickEmitSpy).toHaveBeenCalledWith({ name: FIELD_POPOVER_MENU_ACTIONS[0].name, dataItem: undefined });
      expect(actionClickEmitSpy).toHaveBeenCalledWith({ name: FIELD_POPOVER_MENU_ACTIONS[1].name, dataItem: undefined });
      expect(actionClickEmitSpy).toHaveBeenCalledWith({ name: FIELD_POPOVER_MENU_ACTIONS[2].name, dataItem: undefined });
    });
  });
});
