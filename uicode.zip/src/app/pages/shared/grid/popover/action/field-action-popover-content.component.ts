import { Component, EventEmitter, Output } from '@angular/core';
import { FieldPopoverContentDirective } from '../field-popover-content.directive';
import type { ActionClickEvent } from './action-popover';

@Component({
  selector: 'app-field-action-popover-content',
  templateUrl: './field-action-popover-content.component.html',
  styleUrls: ['./field-action-popover-content.component.scss'],
})
export class FieldActionPopoverContentComponent extends FieldPopoverContentDirective {
  @Output() readonly actionClick = new EventEmitter<ActionClickEvent>();

  onActionClick(name: string): void {
    this.actionClick.emit({ name, dataItem: this.dataItem });
  }
}
