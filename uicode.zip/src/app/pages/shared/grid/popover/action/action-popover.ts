import { ColumnType } from '../../column-type';
import type { Column } from '../../column';

type ActionClick = (event: ActionClickEvent) => void;

export type FieldPopoverMenuAction = { name: string; display: string; disabled?: boolean };
export type ActionClickEvent = { name: string; dataItem: Record<string, unknown> };
export interface OnActionClick {
  onActionClick: ActionClick;
}
export const defaultActionPopoverColumn = (items: FieldPopoverMenuAction[]): Column => {
  return {
    type: ColumnType.ActionPopover,
    field: 'options',
    title: '',
    width: 40,
    sortable: false,
    filterable: false,
    popover: { action: { items } },
  };
};

/**
 * Binds a the action click event of the column to the given element, only if there is not an existing action click
 * event on the column.
 *
 * Useful for repeatedly-called Angular lifecycle hooks when the click event shouldn't change between calls (like AfterViewChecked).
 */
export const bindActionClick = (column: Column, element?: OnActionClick): ActionClick => {
  const onClick = column.popover.action.onClick;
  return element && !onClick ? element.onActionClick.bind(element) : onClick;
};
