import { Component, ViewChild } from '@angular/core';
import { KmdPopoverComponent } from 'gds-atom-components';
import { FieldPopoverContentDirective } from './field-popover-content.directive';

@Component({
  selector: 'app-field-popover',
  templateUrl: './field-popover.component.html',
  styleUrls: ['./field-popover.component.scss'],
})
export class FieldPopoverComponent extends FieldPopoverContentDirective {
  @ViewChild(KmdPopoverComponent) private kmdPopover: KmdPopoverComponent;

  posX: number = null;
  posY: number = null;

  constructor() {
    super();
  }

  onIconClick(event: Event): void {
    event.preventDefault();

    const target = event.target as HTMLElement;
    const currentTarget = event.currentTarget as Element;
    const offsetParent = target.offsetParent as HTMLElement;
    const popoverIconPosition = target.getBoundingClientRect();
    this.posX = popoverIconPosition.left - currentTarget.clientWidth - 80;
    this.posY = offsetParent.offsetTop - window.scrollY + target.offsetTop + popoverIconPosition.height / 2;

    this.loadPopover();
    this.kmdPopover.toggle(event);
  }

  private loadPopover(): void {
    if (this.column?.popover?.callback) {
      this.column.popover.callback(this.dataItem);
    }
  }
}
