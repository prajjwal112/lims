import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldPopoverComponent } from './field-popover.component';
import { PopoverModule } from 'gds-atom-components';

describe('FieldPopoverComponent', () => {
  let component: FieldPopoverComponent;
  let fixture: ComponentFixture<FieldPopoverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FieldPopoverComponent],
      imports: [PopoverModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldPopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
