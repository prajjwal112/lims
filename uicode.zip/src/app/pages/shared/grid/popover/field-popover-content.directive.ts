import { Directive, Input } from '@angular/core';
import type { Column } from '../column';

@Directive()
export abstract class FieldPopoverContentDirective {
  @Input() column: Column;
  @Input() dataItem: Record<string, unknown>;
}
