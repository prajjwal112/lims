import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { PriorityPillComponent } from './priority-pill.component';
import { PillsModule } from '../../pills/pills.module';

enum PriorityValue {
  Low,
  Critical,
  High,
  Medium,
  Default,
}

describe('PriorityPillComponent', () => {
  let component: PriorityPillComponent;
  let fixture: ComponentFixture<PriorityPillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PriorityPillComponent],
      imports: [PillsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PriorityPillComponent);
    component = fixture.componentInstance;
    component.priority = null;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show Low as default label when `priority` input is not passed', () => {
    delete component.priority;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent.trim()).toBe('Low');
  });

  Object.entries({
    [PriorityValue[PriorityValue.Low]]: [1, 25],
    [PriorityValue[PriorityValue.Medium]]: [26, 50],
    [PriorityValue[PriorityValue.High]]: [51, 75],
    [PriorityValue[PriorityValue.Critical]]: [76, 100],
    [PriorityValue[PriorityValue.Default]]: [null, 0],
  }).forEach(([label, values]) => {
    describe(`for ${label} priority`, () => {
      values.forEach((value) => {
        it(`should show when ${value} is passed`, () => {
          component.priority = value;
          fixture.detectChanges();

          expect(fixture.debugElement.query(By.css('span')).nativeElement.textContent.trim()).toBe(label);
        });

        it(`should return ${values[values.length - 1]} when passing ${value}`, () => {
          expect(PriorityPillComponent.setPriorityRangeValue(value)).toBe(values[1]);
        });
      });
    });
  });
});
