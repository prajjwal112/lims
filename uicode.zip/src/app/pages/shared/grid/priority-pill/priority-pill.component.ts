import { Component, Input } from '@angular/core';
import { PillType } from '../../pills/pill-type';

@Component({
  selector: 'app-priority-pill',
  templateUrl: './priority-pill.component.html',
  styleUrls: ['./priority-pill.component.scss'],
})
export class PriorityPillComponent {
  @Input() priority: number;

  /**
   * The pill type enum made public to the component template so it can build the UI
   */
  pillType: typeof PillType = PillType;

  public static setPriorityRangeValue(priority: number): number {
    if (priority > 0 && priority <= 25) {
      return 25;
    } else if (priority > 25 && priority <= 50) {
      return 50;
    } else if (priority > 50 && priority <= 75) {
      return 75;
    } else if (priority > 75) {
      return 100;
    } else {
      return 0;
    }
  }
}
