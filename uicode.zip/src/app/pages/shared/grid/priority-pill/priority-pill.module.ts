import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PriorityPillComponent } from './priority-pill.component';
import { PillsModule } from '../../pills/pills.module';

@NgModule({
  declarations: [PriorityPillComponent],
  imports: [CommonModule, PillsModule],
  exports: [PriorityPillComponent]
})
export class PriorityPillModule {}
