export enum ColumnType {
  Date,
  String,
  /** Like {@link ColumnType.String} except nothing is displayed on empty values. */
  BlankString,
  RemoteItemizedTooltip,
  Link,
  Number,
  Gauge,
  Status,
  Priority,
  Icon,
  ActionPopover,
  Action,
}
