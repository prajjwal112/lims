/**
 * List of status of a workflow task
 */
export enum Status {
  Pending = 'Pending',
  InProgress = 'In Progress',
  Completed = 'Complete',
  Todo = 'To-do',
  Blocked = 'Blocked',
}
