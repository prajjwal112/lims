export enum CamundaServerVariable {
  Priority = 'tf_priority',
  EnforceDueDates = 'tf_enforceDueDates',
  QueueTimeHours = 'tf_queueTimeHours',
  ExecutionTimeHours = 'tf_executionTimeHours',
  OverrideBusinessHours = 'tf_overrideBusinessHours',

  Endpoint = 'tf_endpoint',
  EndpointDescription = 'tf_endpointDescription',
  EndpointLabel = 'tf_endpointLabel',

  TaskInputMapping = 'tf_inputVarMapping',
  BackingEntityLabel = 'tf_backingEntityLabel',
  BackingEntityType = 'tf_backingEntityType',
  BackingEntityEndpoint = 'tf_backingEntityEndpoint',

  TaskInput = 'tf_taskInput',
  TaskInstructions = 'tf_instructions',
  TaskAutoExecute = 'tf_autoExecute',

  OutputMappingPublic = 'tf_outputVariables',
  OutputMappingPrivate = 'tf_outputVarMapping',

  TaskInputVariable = 'tf_inputVariablesNames',
  TaskOutputVariable = 'tf_outputVariablesNames',
}

export enum CamundaCustomVariable {
  GatewayType = 'tf_gatewayType',
  TaskActionType = 'type',
  TaskActionName = 'name',
  TaskActionTemplateKey = 'templateKey',
  TaskActionVariables = 'variables',
  TaskActionKey = 'key',
  AllConditions = 'tf_allConditions',
}
