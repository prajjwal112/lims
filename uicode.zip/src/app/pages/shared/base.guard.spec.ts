import { TestBed, async } from '@angular/core/testing';

import { BaseGuard } from './base.guard';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';

describe('BaseGuard', () => {
  let guard: BaseGuard;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    guard = TestBed.inject(BaseGuard);
    router = TestBed.inject(Router);
    spyOn(router, 'getCurrentNavigation').and.returnValue({
      id: 0,
      initialUrl: null,
      extractedUrl: null,
      trigger: 'imperative',
      previousNavigation: null,
      extras: { state: {} },
    });
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
