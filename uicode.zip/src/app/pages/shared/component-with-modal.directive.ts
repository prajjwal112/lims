import { Directive } from '@angular/core';
import { KmdModalService } from 'gds-atom-components';
import { ModalId } from './modal-id';

@Directive()
export abstract class ComponentWithModalDirective {
  openModalId: ModalId = null;

  protected constructor(protected readonly kmdModalService: KmdModalService) {}

  openModal(id: ModalId): void {
    this.openModalId = id;

    setTimeout(() => {
      this.kmdModalService.open(id);
    }, 0);
  }

  closeModal(id?: ModalId): void {
    this.openModalId = null;

    if (id) {
      this.kmdModalService.close(id);
    }
  }
}
