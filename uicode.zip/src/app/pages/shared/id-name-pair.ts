export interface IdNamePair {
  id: string | number;
  name: string;
}

export interface WorkflowCamundaIdPair {
  workflowId: number;
  camundaId: string;
}
