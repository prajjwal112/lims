import { fakeAsync, TestBed } from '@angular/core/testing';

import { SearchTextService } from './search-text.service';

describe('SearchTextService', () => {
  let service: SearchTextService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchTextService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return Text before setting', fakeAsync(() => {
    service.getText().subscribe({
      next: (error) => {
        expect(error).toBe('');
      },
    });
  }));

  it('should set Text', fakeAsync(() => {
    service.setText('abc');
    service.getText().subscribe({
      next: (error) => {
        expect(error).toBe('abc');
      },
    });
  }));
});
