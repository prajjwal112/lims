import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertsModule, ButtonModule, InputFieldsModule, ModalsModule } from 'gds-atom-components';

import { ManageItemsComponent } from './manage-items.component';
import { DropDownAutoCompleteModule } from '../dropdown-autocomplete/dropdown-autocomplete.module';
import { ListItemsModule } from '../list-items/list-items.module';
import { SimpleChange } from '@angular/core';
import { ModalId } from '../modal-id';

describe('ManageItemsComponent', () => {
  let component: ManageItemsComponent;
  let fixture: ComponentFixture<ManageItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ManageItemsComponent],
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        ModalsModule,
        ButtonModule,
        InputFieldsModule,
        FormsModule,
        ReactiveFormsModule,
        DropDownAutoCompleteModule,
        AlertsModule,
        ListItemsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageItemsComponent);
    component = fixture.componentInstance;
    component.idName = ModalId.ManageRoles;
    component.listItems = [
      {
        id: 1,
        name: 'group1',
      },
    ];
    component.columns = [{ name: 'name', title: 'Name', sortable: false }];

    component.propertyToSelect = 'id';
    fixture.detectChanges();

    component['kmdModalService'].open(ModalId.ManageRoles);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show disabled button when no group name', () => {
    component.addItem = true;
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeTrue();
  });

  it('should enable button when no item is selected and group name is populated', () => {
    component.addItem = true;
    component.formItem.controls.newItem.setValue('new group');
    component.selectedItems = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeFalse();
  });

  it('should close modal after confirm', () => {
    component.confirmedStatus = { status: true, message: '' };

    component.ngOnChanges({
      confirmedStatus: new SimpleChange(null, component.confirmedStatus, true),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('.kmd-modal'))).toBeFalsy();
  });

  it('should enable confirm button when selection is not required and selection is made', () => {
    component.requireSelection = false;
    component.selectedItems = [123, 543];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeFalse();
  });

  it('should enable confirm button when selection is not required and no selection is made', () => {
    component.requireSelection = false;
    component.selectedItems = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeFalse();
  });

  it('should disable confirm button when selection is required and no selection is made', () => {
    component.requireSelection = true;
    component.selectedItems = [];
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeTrue();
  });

  describe('show error message', () => {
    beforeEach(() => {
      component.showErrorAlert = true;
      fixture.detectChanges();
    });

    it('should clear error message  on close', () => {
      component.onCloseModal();
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('kmd-alerts'))).toBeFalsy();
    });

    it('should clear error message on cancel', () => {
      component.onCancel();
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('kmd-alerts'))).toBeFalsy();
    });
  });
});
