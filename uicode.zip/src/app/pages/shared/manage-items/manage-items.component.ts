import { Component, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { isEqual, differenceWith } from 'lodash';
import { KmdModalService } from 'gds-atom-components';
import { ModalId } from '../modal-id';
import { ComponentWithModalDirective } from '../component-with-modal.directive';
import { CustomValidators } from '../custom-validators';
import type { OnInit, SimpleChanges, OnChanges } from '@angular/core';
import type { ConfirmedStatus, ListColumns, ManageItemsRequest } from '../common-data-type';

@Component({
  selector: 'app-manage-items',
  templateUrl: './manage-items.component.html',
  styleUrls: ['./manage-items.component.scss'],
})
export class ManageItemsComponent extends ComponentWithModalDirective implements OnInit, OnChanges {
  @Input() idName: ModalId;
  @Input() title: string;
  @Input() addItem = false;
  @Input() searchItem = false;
  @Input() name: string;
  @Input() propertyName: string;
  @Input() filterKey: string;
  @Input() selectedData: any[] = [];
  @Input() placeholder: string;
  @Input() listItems: any[] = [];
  @Input() isMultiSelect: boolean;
  @Input() columns: ListColumns[];
  @Input() propertyToSelect: string;
  @Input() noItemsMessage: string;
  @Input() displayRadioButton: boolean;
  @Input() requireSelection = true;
  @Input() confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };
  @Output() confirmedStatusChange = new EventEmitter<ConfirmedStatus>();
  @Output() confirmEvent = new EventEmitter<ManageItemsRequest>();
  @Output() searchText = new EventEmitter<string>();
  @Input() modalSize: string;
  @Output() selectedItemsChange = new EventEmitter<number[]>();

  selectedItems: number[] | string = [];
  searchData: any[] = [];
  formItem = new FormGroup({
    newItem: new FormControl('', [Validators.maxLength(100), CustomValidators.notBlank]),
  });
  errorMessage = '';
  searchValue: string;
  showErrorAlert = false;

  constructor(protected readonly kmdModalService: KmdModalService) {
    super(kmdModalService);
  }

  private static segregateIds(selectedList: any[], propertyToSelect: string): number[] {
    if (selectedList.length > 0) {
      return selectedList.map((obj) => ManageItemsComponent.getNumberValue(obj, propertyToSelect)).filter((obj) => obj);
    }
    return [];
  }

  private static getNumberValue(obj: any, property: string): number {
    return typeof obj[property] === 'number' ? obj[property] : obj.id;
  }

  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (!this.isMultiSelect && this.selectedData.length > 0) {
      let selectedData = this.selectedData.slice();
      if (this.propertyName) {
        selectedData = selectedData.reduce((group, item) => {
          if (Object.keys(item).includes(this.propertyName)) {
            group.push(...item[this.propertyName]);
          }
          return group;
        }, []);
      }
      this.selectedItems = ManageItemsComponent.segregateIds(selectedData, this.propertyToSelect);
    }
    if (this.isMultiSelect) {
      this.selectedItems = [];
    }

    const confirmedStatus: SimpleChange = simpleChanges.confirmedStatus;

    if (confirmedStatus?.currentValue?.status) {
      this.closeModal(this.idName);
    } else if (confirmedStatus?.currentValue?.status === false) {
      this.showErrorAlert = true;
    }

    if (
      simpleChanges.listItems &&
      simpleChanges.listItems.currentValue &&
      (differenceWith(simpleChanges.listItems.currentValue, simpleChanges.listItems.previousValue, isEqual).length > 0 ||
        simpleChanges.listItems.currentValue.length !==
          (simpleChanges.listItems.previousValue && simpleChanges.listItems.previousValue.length))
    ) {
      this.searchData = this.listItems.slice();
    }
  }

  ngOnInit(): void {
    this.searchData = this.listItems?.slice() ?? [];
  }

  onSelectedItemsChange(event: number[]): void {
    this.selectedItemsChange.emit(event);
  }

  onSelectChange(event: string): void {
    this.searchValue = event;
    this.searchText.emit(this.searchValue);
    this.searchData = this.listItems.filter(
      (obj) => obj[this.filterKey]?.toLowerCase().indexOf(this.searchValue.trim().toLowerCase()) !== -1
    );
  }

  onConfirm(): void {
    this.clearError();
    const itemValue = this.formItem.controls.newItem.value;
    if (itemValue) {
      if (this.isDuplicateItem(itemValue)) {
        this.errorMessage = `Already exists, Please provide another ${this.name} name.`;
      }
    }

    if (!this.formItem.controls.newItem.value || this.formItem.controls.newItem.valid) {
      this.confirmEvent.emit(this.getConfirmedData());
    } else {
      this.errorMessage = 'Please verify that the name is under 100 characters';
    }
  }

  onCancel(): void {
    this.onCloseModal();
    this.closeModal(this.idName);
  }

  onCloseButtonClick(): void {
    this.closeModal(this.idName);
    this.clearError();
  }

  onCloseModal(): void {
    this.clearError();
    this.resetSelection();
  }

  private resetSelection(): void {
    this.searchValue = '';
    this.formItem.controls.newItem.setValue('');

    this.selectedItems = [];
    this.onSelectChange('');
  }

  private isDuplicateItem(newItem: string): boolean {
    return this.listItems.some((obj) => obj[this.propertyName]?.toLowerCase() === newItem.toLowerCase());
  }

  private getConfirmedData(): ManageItemsRequest {
    const updateIds: ManageItemsRequest['updateIds'] = this.selectedItems.slice() as number[];

    return {
      userIds: this.selectedData.map((user) => ManageItemsComponent.getNumberValue(user, this.propertyToSelect)),
      newName: this.formItem.controls.newItem.value || null,
      updateIds,
    };
  }

  private clearError(): void {
    this.errorMessage = '';
    this.showErrorAlert = false;
  }
}
