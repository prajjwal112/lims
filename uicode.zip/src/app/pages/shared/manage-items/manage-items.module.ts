import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertsModule, InputFieldsModule, ModalsModule, ButtonModule } from 'gds-atom-components';

import { ManageItemsComponent } from './manage-items.component';
import { DropDownAutoCompleteModule } from '../dropdown-autocomplete/dropdown-autocomplete.module';
import { ListItemsModule } from '../list-items/list-items.module';

@NgModule({
  declarations: [ManageItemsComponent],
  imports: [
    CommonModule,
    DropDownAutoCompleteModule,
    FormsModule,
    ReactiveFormsModule,
    AlertsModule,
    ListItemsModule,
    ModalsModule,
    InputFieldsModule,
    ButtonModule,
  ],
  exports: [ManageItemsComponent],
})
export class ManageItemsModule {}
