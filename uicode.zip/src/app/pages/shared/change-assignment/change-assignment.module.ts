import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangeAssignmentComponent } from './change-assignment.component';
import { TabsModule } from 'gds-atom-components';
import { ManageItemsModule } from '../manage-items/manage-items.module';
@NgModule({
  declarations: [ChangeAssignmentComponent],
  imports: [CommonModule, TabsModule, ManageItemsModule],
  exports: [ChangeAssignmentComponent],
})
export class ChangeAssignmentModule {}
