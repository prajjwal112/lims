import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { TabsModule } from 'gds-atom-components';
import { DefaultAssignmentTab } from '../../workflow-definitions/default-assignment/default-assignment';
import { ManageItemsModule } from '../manage-items/manage-items.module';
import { TabConfig } from '../tabconfig';
import { ChangeAssignmentComponent } from './change-assignment.component';
import { ModalId } from '../modal-id';

describe('ChangeAssignmentComponent', () => {
  let component: ChangeAssignmentComponent;
  let fixture: ComponentFixture<ChangeAssignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ChangeAssignmentComponent],
      imports: [HttpClientTestingModule, ManageItemsModule, TabsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeAssignmentComponent);
    component = fixture.componentInstance;
    component.tabConfig = getTabConfig();
    component.title = 'ABC';
    component['kmdModalService'].open(ModalId.ChangeAssignment);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display Users tab bydefault as activeTab', () => {
    expect(component.activeTab).toEqual(DefaultAssignmentTab.User);
  });

  it('should have modal closed when modal was closed and remove the error alert message', fakeAsync(() => {
    spyOn(component['kmdModalService'], 'close');

    const event = { status: true, message: '' };
    component.onConfirmedStatusChange(event);

    expect(component['kmdModalService'].close).toHaveBeenCalledWith(ModalId.ChangeAssignment);
  }));
});
function getTabConfig(): TabConfig {
  return {
    users: {
      name: 'Users',
      id: DefaultAssignmentTab.User,
      propertyId: 'id',
      columns: [{ name: 'fullName', title: 'Name', sortable: true }],
      filterKey: 'fullName',
    },
    groups: {
      name: 'Groups',
      id: DefaultAssignmentTab.Group,
      propertyId: 'id',
      columns: [{ name: 'name', title: 'Name', sortable: true }],
      filterKey: 'name',
    },
  };
}
