import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { differenceWith, isEqual } from 'lodash';
import { KmdModalService, KmdTabsComponent } from 'gds-atom-components';
import { ComponentWithModalDirective } from '../component-with-modal.directive';
import { SearchTextService } from '../search-text.service';
import { DefaultAssignmentTab } from '../../workflow-definitions/default-assignment/default-assignment';
import { ModalId } from '../modal-id';
import type { OnChanges, SimpleChanges } from '@angular/core';
import type { Group } from '../../groups/shared/group';
import type { UserFilterItem } from '../../users/shared/user';
import type { AssigneeSelection, DefaultAssignmentItems } from '../../workflow-definitions/default-assignment/default-assignment';
import type { ConfirmedStatus, ManageItemsRequest } from '../common-data-type';
import type { TabConfig } from '../tabconfig';

@Component({
  selector: 'app-change-assignment',
  templateUrl: './change-assignment.component.html',
  styleUrls: ['./change-assignment.component.scss'],
})
export class ChangeAssignmentComponent extends ComponentWithModalDirective implements OnChanges {
  @Output() readonly selectedItemsChange = new EventEmitter<number[]>();
  @Output() readonly closeEvent = new EventEmitter<DefaultAssignmentItems>();
  readonly modalId = ModalId;

  @ViewChild('tabsComponent') private readonly tabsComponent: KmdTabsComponent;

  @Input() processTaskAssignments = false;
  @Input() title: string;
  @Input() tabConfig: TabConfig;
  @Input() show = false;
  @Input() modalSize: string;
  @Input() userList: UserFilterItem[] = [];
  @Input() groupList: Group[] = [];
  @Input() assigneeSelection: AssigneeSelection[] = [];
  @Input() confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };
  public activeTab: DefaultAssignmentTab = DefaultAssignmentTab.User;
  public listItems: UserFilterItem[] | Group[] = [];
  public selectedListItems: UserFilterItem[] | Group[] = [];

  #searchName = '';

  constructor(protected readonly kmdModalService: KmdModalService, private readonly searchTextService: SearchTextService) {
    super(kmdModalService);
  }

  public onSelectedItemsChange(event: number[]): void {
    this.selectedItemsChange.emit(event);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.show?.currentValue) {
      this.openModal(ModalId.ChangeAssignment);
    }

    if (this.processTaskAssignments) {
      this.processTaskAssignment(changes);
    } else {
      this.processChangeAssignment(changes);
    }
  }

  public onConfirm(event: ManageItemsRequest): void {
    this.closeEvent.emit({
      ...event,
      tab: this.activeTab,
    });
  }

  public onSearchText(event: string): void {
    this.#searchName = event;
  }

  public onConfirmedStatusChange(event: { status: boolean; message: string }): void {
    this.confirmedStatus = event;
    this.closeModal(ModalId.ChangeAssignment);
  }

  public onTabChange(event: { activeId: DefaultAssignmentTab; nextId: DefaultAssignmentTab }): void {
    this.searchTextService.setText(this.#searchName);
    this.activeTab = event.nextId;
    this.listItems = event.nextId === DefaultAssignmentTab.User ? this.userList.slice() : this.groupList.slice();
  }

  private processChangeAssignment(changes: SimpleChanges): void {
    if (
      changes.userList &&
      (differenceWith(changes.userList.currentValue, changes.userList.previousValue, isEqual).length > 0 ||
        changes.userList.currentValue?.length !== changes.userList.previousValue?.length)
    ) {
      this.listItems = changes.userList.currentValue ? changes.userList.currentValue.slice() : [];
    }
  }

  private processTaskAssignment(changes: SimpleChanges): void {
    if (changes.assigneeSelection?.currentValue?.length > 0) {
      const id = changes.assigneeSelection?.currentValue[0].assigneeId;
      let list = [];

      if (changes.assigneeSelection.currentValue[0].tab === DefaultAssignmentTab.User) {
        this.listItems = this.userList;
        list = this.userList.filter((user) => user[this.tabConfig.users.propertyId] === id);
      } else if (changes.assigneeSelection.currentValue[0].tab === DefaultAssignmentTab.Group) {
        this.activeTab = DefaultAssignmentTab.Group;
        list = this.groupList.filter((group) => group[this.tabConfig.groups.propertyId] === id);
        this.onTabChange({ activeId: DefaultAssignmentTab.User, nextId: DefaultAssignmentTab.Group });
        this.tabsComponent.select(DefaultAssignmentTab.Group);
      }
      this.selectedListItems = list.slice();
    }
  }
}
