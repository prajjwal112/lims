import { Observable } from 'rxjs';

export interface IdNameDescriptionRequest {
  id?: number;
  name?: string;
  description?: string;
}

export interface IdNameDescriptionResponse {
  id: number;
}

export interface IdNameDescriptionService {
  create: (request: IdNameDescriptionRequest) => Observable<IdNameDescriptionResponse>;
  update: (request: IdNameDescriptionRequest) => Observable<IdNameDescriptionResponse>;
}
