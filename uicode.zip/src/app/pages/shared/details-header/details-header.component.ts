import { Component } from '@angular/core';

@Component({
  selector: 'app-details-header',
  templateUrl: './details-header.component.html',
  styleUrls: ['./details-header.component.scss', '../../shared/page-header.scss'],
})
export class DetailsHeaderComponent {}
