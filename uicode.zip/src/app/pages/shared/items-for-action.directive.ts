import { Directive } from '@angular/core';
import { forkJoin } from 'rxjs';
import { take } from 'rxjs/operators';
import { KmdModalService } from 'gds-atom-components';

import { GroupService } from '../../core/api/group/group.service';
import { UserService } from '../../core/api/user/user.service';
import { TaskService } from '../../core/api/task/task.service';
import { SortDirection } from './sort-direction';
import type { TaskFilterItemResponse, ActionItemRequest } from '../task-list/shared/task-filter';
import type { UserFilter, UserFilterItem } from '../users/shared/user';
import type { Group, GroupResponse } from '../groups/shared/group';
import type { ActionClickEvent } from './grid/popover/action/action-popover';
import type { IdNamePair, WorkflowCamundaIdPair } from './id-name-pair';
import type { ConfirmedStatus } from './common-data-type';
import { ModalId } from './modal-id';

@Directive()
export abstract class ItemsForActionDirective {
  public tasks: TaskFilterItemResponse[] = [];
  public selectedTasks: TaskFilterItemResponse[] = [];
  public selectedTaskReferenceIds: WorkflowCamundaIdPair[] = [];
  public showAssign = false;
  public userList: UserFilterItem[] = [];
  public groupList: Group[] = [];
  public confirmedStatus: ConfirmedStatus = {
    status: true,
    message: '',
  };

  protected constructor(
    protected readonly kmdModalService: KmdModalService,
    protected readonly userService: UserService,
    protected readonly groupService: GroupService,
    protected readonly taskService: TaskService
  ) {}

  public onActionClick(event: ActionClickEvent): void {
    const filteredTask = this.tasks.find((task) => task.referenceId === event.dataItem.referenceId);
    this.selectedTaskReferenceIds = this.updateSelectedTasks(filteredTask);

    if (event.name === ModalId.ChangeAssignment) {
      this.openChangeAssignment(filteredTask?.projects);
    } else {
      this.kmdModalService.open(event.name);
    }
  }

  public openChangeAssignment(task: IdNamePair[]): void {
    const projectIds = task.map((project) => +project.id);
    forkJoin([
      this.userService.filter({
        projectIds: projectIds.slice(),
        sortColumn: 'name',
      }),
      this.groupService.filter({
        projectIds: projectIds.slice(),
        sort: SortDirection.Ascending,
      }),
    ])
      .pipe(take(1))
      .subscribe({
        next: ([userList, groupList]: [UserFilter, GroupResponse]) => {
          this.userList = userList.items.slice();
          this.groupList = groupList.items.slice();
          this.openAssignmentModal();
        },
      });
  }

  public openAssignmentModal(): void {
    this.showAssign = true;
    setTimeout(() => {
      this.showAssign = false;
    }, 500);
  }

  protected updateSelectedTasks(taskOrTasks: TaskFilterItemResponse | TaskFilterItemResponse[]): WorkflowCamundaIdPair[] {
    if (Array.isArray(taskOrTasks)) {
      this.selectedTasks = taskOrTasks;
    } else if (typeof taskOrTasks === 'object') {
      this.selectedTasks = [taskOrTasks];
    } else {
      this.selectedTasks = [];
    }

    return this.selectedTasks.map((task) => ({ workflowId: task.referenceId, camundaId: task.id }));
  }

  protected updateTaskActionItems(
    request: Omit<ActionItemRequest, 'taskInstanceIds'>,
    modalId: string,
    errorMessage: string,
    callback: () => void,
    taskInstanceIds?: WorkflowCamundaIdPair[]
  ): void {
    this.taskService
      .updateTaskActionItems({
        ...request,
        taskInstanceIds: taskInstanceIds ?? [{ workflowId: this.selectedTasks[0].referenceId, camundaId: this.selectedTasks[0].id }],
      })
      .pipe(take(1))
      .subscribe({
        next: () => {
          callback();
          this.kmdModalService.close(modalId);
        },
        error: () => {
          this.confirmedStatus = {
            status: false,
            message: errorMessage,
          };
        },
      });
  }
}
