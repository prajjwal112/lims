import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IframeComponent } from './iframe.component';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';

@NgModule({
  declarations: [IframeComponent],
  imports: [CommonModule, WorkflowPipeModule],
  exports: [IframeComponent],
})
export class IframeModule {}
