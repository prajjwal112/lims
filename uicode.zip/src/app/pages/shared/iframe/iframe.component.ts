import { Component, ElementRef, EventEmitter, Input, Output, ViewChild, HostListener, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-iframe',
  templateUrl: './iframe.component.html',
  styleUrls: ['./iframe.component.scss'],
})
export class IframeComponent implements AfterViewInit {
  @ViewChild('iframe') iframe: ElementRef;
  @Input() title = '';
  @Input() url: string;
  @Input() width: number | string;
  @Input() height: number | string;
  @Output() load = new EventEmitter<Event>();

  ngAfterViewInit(): void {
    this.iframe.nativeElement.addEventListener('load', (event: Event) => {
      this.load.emit(event);
    });
  }

  @HostListener('window:message', ['$event'])
  onMessage(event: MessageEvent): void {
    this.receiveMessage(event);
  }

  private receiveMessage(event): void {
    const data = event.data;
    if (data === 'application_ready') {
      this.iframe.nativeElement.contentWindow.postMessage('application_embedded', '*');
    }
  }
}
