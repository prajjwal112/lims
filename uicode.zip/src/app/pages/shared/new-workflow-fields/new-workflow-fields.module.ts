import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  AlertsModule,
  ButtonModule,
  DropdownsModule,
  CheckboxModule,
  InputFieldsModule,
  ModalsModule,
  RadioButtonModule,
} from 'gds-atom-components';

import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DueDateLabelModule } from '../../shared/due-date-label/due-date-label.module';
import { NewWorkflowFieldsComponent } from './new-workflow-fields.component';
import { ValidationErrorsModule } from '../../shared/validation-errors/validation-errors.module';

@NgModule({
  declarations: [NewWorkflowFieldsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ModalsModule,
    AlertsModule,
    ButtonModule,
    InputFieldsModule,
    RadioButtonModule,
    DueDateLabelModule,
    CheckboxModule,
    WorkflowPipeModule,
    DropdownsModule,
    ValidationErrorsModule,
  ],
  exports: [NewWorkflowFieldsComponent],
})
export class NewWorkflowFieldsModule {}
