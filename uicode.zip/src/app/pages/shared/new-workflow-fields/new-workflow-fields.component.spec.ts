import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import {
  AlertsModule,
  ButtonModule,
  DropdownsModule,
  CheckboxModule,
  InputFieldsModule,
  ModalsModule,
  RadioButtonModule,
} from 'gds-atom-components';

import { ProjectService } from '../../../core/api/project/project.service';
import { NewWorkflowFieldsComponent } from './new-workflow-fields.component';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DueDateLabelModule } from '../due-date-label/due-date-label.module';
import { ValidationErrorsModule } from '../validation-errors/validation-errors.module';

describe('NewWorkflowFieldsComponent', () => {
  let component: NewWorkflowFieldsComponent;
  let fixture: ComponentFixture<NewWorkflowFieldsComponent>;
  let projectService: ProjectService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NewWorkflowFieldsComponent],
      imports: [
        AlertsModule,
        ButtonModule,
        RadioButtonModule,
        DropdownsModule,
        CheckboxModule,
        InputFieldsModule,
        DueDateLabelModule,
        WorkflowPipeModule,
        ModalsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        CommonModule,
        ValidationErrorsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewWorkflowFieldsComponent);
    projectService = TestBed.inject(ProjectService);

    spyOn(projectService, 'filter').and.returnValue(
      of({
        count: 2,
        items: [
          {
            referenceId: 1,
            id: 1,
            name: 'test',
            description: 'test description',
            activeRun: '',
            tasks: '',
          },
          {
            referenceId: 2,
            id: 2,
            name: 'test2',
            description: 'test description 2',
            activeRun: '',
            tasks: '',
          },
        ],
      })
    );

    component = fixture.componentInstance;
    component.workflowDefinition = {
      trackDueDate: true,
      projects: [1, 2],
      id: '0',
      referenceId: 0,
      lastUpdate: '',
      active: true,
      name: 'mock-name',
      description: 'mock-description',
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not show error messages', () => {
    expect(fixture.debugElement.query(By.css('#workflowNameError p'))).toBeFalsy();
    expect(fixture.debugElement.query(By.css('#descriptionError p'))).toBeFalsy();
    expect(fixture.debugElement.query(By.css('#projectError p'))).toBeFalsy();
  });

  const invalidValues = [null, '', '    '];
  describe('workflow name error', () => {
    describe('workflow falsy value', () => {
      invalidValues.forEach((test) => {
        it(`should show error message when '${test}' value is entered`, () => {
          component.newWorkflowForm.get('workflowName').setValue(test);
          component.onSubmit();
          fixture.detectChanges();

          expect(fixture.debugElement.query(By.css('#workflowNameError')).nativeElement.textContent).toContain(
            NewWorkflowFieldsComponent['getMissingErrorMessage']('Workflow name')
          );
        });
      });

      it('should be invalid by server when missing', () => {
        component.formatErrorMessages(
          new HttpErrorResponse({
            error: [{ message: 'Workflow name error', details: ['Missing workflow name'] }],
          })
        );

        expect(component.newWorkflowForm.get('workflowName').errors).toEqual({ required: true });
      });
    });

    describe('workflow maximum characters', () => {
      it('should show error message', () => {
        component.newWorkflowForm.get('workflowName').setValue('a'.repeat(51));
        component.onSubmit();
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('#workflowNameError')).nativeElement.textContent).toContain(
          NewWorkflowFieldsComponent['getErrorMessageForExceedingCharactersLimit']('Workflow name', 50)
        );
      });

      it('should be invalid by server', () => {
        component.formatErrorMessages(
          new HttpErrorResponse({
            error: [{ message: 'Workflow name error', details: ['Workflow name cannot be longer than 50 characters'] }],
          })
        );

        expect(component.newWorkflowForm.get('workflowName').errors).toEqual({ maxlength: true });
      });
    });

    it('should show error message when workflow name has reserved keyword', () => {
      component.newWorkflowForm.get('workflowName').setValue('tf-tenant');
      component.onSubmit();
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('#workflowNameError')).nativeElement.textContent).toContain(
        component.reservedKeywordErrorMessage
      );
    });

    it('should show error message when workflow name has invalid character', () => {
      component.newWorkflowForm.get('workflowName').setValue('*invalid#character');
      component.onSubmit();
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('#workflowNameError')).nativeElement.textContent).toContain(
        component.reservedKeywordErrorMessage
      );
    });

    it('should show error message when name is duplicated', () => {
      component.formatErrorMessages(
        new HttpErrorResponse({
          error: [{ message: 'Workflow name error', details: ['Duplicate workflow name'] }],
        })
      );

      expect(component.newWorkflowForm.get('workflowName').errors).toEqual({ duplicateName: true });
    });
  });

  describe('description', () => {
    describe('description falsy value', () => {
      invalidValues.forEach((test) => {
        it(`should show error message when '${test}' value is entered`, () => {
          component.newWorkflowForm.get('description').setValue(test);
          component.onSubmit();
          fixture.detectChanges();

          expect(fixture.debugElement.query(By.css('#descriptionError')).nativeElement.textContent).toContain(
            NewWorkflowFieldsComponent['getMissingErrorMessage']('Description')
          );
        });

        it('should show error message when description is missing on server', () => {
          component.formatErrorMessages(
            new HttpErrorResponse({
              error: [{ message: 'Description error', details: ['Missing description'] }],
            })
          );

          expect(component.newWorkflowForm.get('description').errors).toEqual({ required: true });
        });
      });

      describe('description maximum characters', () => {
        it('should show error message when description exceeds maximum characters', () => {
          component.newWorkflowForm.get('description').setValue('a'.repeat(501));
          component.onSubmit();
          fixture.detectChanges();

          expect(fixture.debugElement.query(By.css('#descriptionError')).nativeElement.textContent).toContain(
            NewWorkflowFieldsComponent['getErrorMessageForExceedingCharactersLimit']('Description', 500)
          );
        });

        it('should show error message when description is longer than 500 characters', () => {
          component.formatErrorMessages(
            new HttpErrorResponse({
              error: [{ message: 'Description error', details: ['Description cannot be longer than 500 characters'] }],
            })
          );

          expect(component.newWorkflowForm.get('description').errors).toEqual({ maxlength: true });
        });
      });
    });
  });

  it('should show error message when project is missing', () => {
    component.newWorkflowForm.get('project').setValue(null);
    component.onSubmit();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('#projectError')).nativeElement.textContent).toContain(
      NewWorkflowFieldsComponent['getMissingErrorMessage']('Project')
    );
  });

  it('should set project field to invalid when missing from server', () => {
    component.formatErrorMessages(
      new HttpErrorResponse({
        error: [{ message: 'Project error', details: ['Missing project'] }],
      })
    );

    expect(component.newWorkflowForm.get('project').errors).toEqual({ required: true });
  });

  describe('preload data', () => {
    it('should preload name', () => {
      expect(fixture.debugElement.query(By.css('input#workflowName')).nativeElement.value).toBe('Copy of mock-name');
    });

    it('should preload description', () => {
      expect(fixture.debugElement.query(By.css('textarea#description')).nativeElement.value).toBe('mock-description');
    });

    it('should preload project', () => {
      expect(component.multiSelectedProjects).toEqual([
        {
          referenceId: 1,
          id: 1,
          name: 'test',
          description: 'test description',
          activeRun: '',
          tasks: '',
        },
        {
          referenceId: 2,
          id: 2,
          name: 'test2',
          description: 'test description 2',
          activeRun: '',
          tasks: '',
        },
      ]);
    });
  });
});
