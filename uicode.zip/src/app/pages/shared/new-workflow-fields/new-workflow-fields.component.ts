import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError, debounceTime, map, switchMap, take } from 'rxjs/operators';
import { Observable, of, throwError } from 'rxjs';
import { KmdModalService } from 'gds-atom-components';

import { ProjectService } from '../../../core/api/project/project.service';
import { WorkflowDefinitionService } from '../../../core/api/workflow-definition/workflow-definition.service';
import { CustomValidators } from '../custom-validators';
import { ModalId } from '../modal-id';
import type { Project, ProjectResponse } from '../../projects/shared/project';
import type { FilteredWorkflowDefinitionWithSimplifiedProjects } from '../../workflow-definitions/shared/workflow-definition';

const MAX_CHARACTERS_FOR_WORKFLOW_NAME = 50;
const MAX_CHARACTERS_FOR_DESCRIPTION = 500;

@Component({
  selector: 'app-new-workflow-fields',
  templateUrl: './new-workflow-fields.component.html',
  styleUrls: ['./new-workflow-fields.component.scss'],
})
export class NewWorkflowFieldsComponent implements OnInit {
  @Input() workflowDefinition: FilteredWorkflowDefinitionWithSimplifiedProjects;
  @Output() close = new EventEmitter<void>();
  @Output() submitForm = new EventEmitter<NewWorkflowFieldsComponent>();

  newWorkflowForm: FormGroup;
  projects: Project[];
  multiSelectedProjects: any[] = [];
  dueDateTracked: boolean;
  newWorkflowError = false;
  bpmnError: string;
  genericError: boolean;
  bpmnValidationErrors: string[];
  modelInvalid = true;
  projectIsEmpty = false;

  readonly modalId = ModalId;
  readonly asyncValidatorDebounceTime = 1000;
  readonly duplicateNameErrorMessage = 'A workflow definition with this name already exists. Please select a new name.';
  readonly reservedKeywordErrorMessage = 'Workflow name can contain alphanumerical characters, spaces, hyphens (-), and underscores (_).';
  readonly missingNameError = NewWorkflowFieldsComponent.getMissingErrorMessage('Workflow name');
  readonly missingDescriptionError = NewWorkflowFieldsComponent.getMissingErrorMessage('Description');
  readonly missingBpmnError = NewWorkflowFieldsComponent.getMissingErrorMessage('BPMN file');
  readonly missingProjectError = NewWorkflowFieldsComponent.getMissingErrorMessage('Project');
  readonly longNameError = NewWorkflowFieldsComponent.getErrorMessageForExceedingCharactersLimit(
    'Workflow name',
    MAX_CHARACTERS_FOR_WORKFLOW_NAME
  );
  readonly longDescriptionError = NewWorkflowFieldsComponent.getErrorMessageForExceedingCharactersLimit(
    'Description',
    MAX_CHARACTERS_FOR_DESCRIPTION
  );

  #definitionTemplateId: number | null;
  #currentWorkflowName: string;

  constructor(
    private readonly projectService: ProjectService,
    private readonly workflowDefinitionService: WorkflowDefinitionService,
    private readonly kmdModalService: KmdModalService
  ) {}

  private static getMissingErrorMessage(param: string): string {
    return `${param} is required.`;
  }

  private static getErrorMessageForExceedingCharactersLimit(param: string, max: number): string {
    return `${param} cannot exceed ${max} characters.`;
  }

  ngOnInit(): void {
    this.newWorkflowForm = new FormGroup({
      workflowName: new FormControl(
        '',
        [
          Validators.maxLength(MAX_CHARACTERS_FOR_WORKFLOW_NAME),
          Validators.required,
          CustomValidators.notBlank,
          Validators.pattern(CustomValidators.disallowWorkflowNameCharactersPattern),
          CustomValidators.notContainObjectStoreKeywords,
        ],
        [this.nameAsyncValidator.bind(this)]
      ),
      description: new FormControl('', [
        Validators.maxLength(MAX_CHARACTERS_FOR_DESCRIPTION),
        Validators.required,
        CustomValidators.notBlank,
      ]),
      project: new FormControl(null, [Validators.required]),
    });
    const { referenceId, name = '', description = '', projects = [], trackDueDate = false } = { ...this.workflowDefinition };
    this.projectService
      .filter({})
      .pipe(take(1))
      .subscribe({
        next: (data: ProjectResponse) => {
          this.projects = data.items;
          this.multiSelectedProjects = projects.map((project) => data.items.find((item) => item.id === project));
          this.newWorkflowForm.get('project').setValue(this.multiSelectedProjects);
        },
      });
    this.#currentWorkflowName = name ? `Copy of ${name}` : name;
    this.#definitionTemplateId = referenceId;
    this.dueDateTracked = trackDueDate;
    this.newWorkflowForm.get('workflowName').setValue(this.#currentWorkflowName);
    this.newWorkflowForm.get('description').setValue(description);

    this.newWorkflowForm.addControl('dueDateTracked', new FormControl(this.dueDateTracked));
    if (this.#currentWorkflowName) {
      this.newWorkflowForm.controls.workflowName.markAsTouched();
    }
  }

  nameAsyncValidator(control: AbstractControl): Observable<{ duplicatetName: true | null }> {
    if (this.#currentWorkflowName && control.value === this.#currentWorkflowName) {
      return of(null);
    }
    return of(control.value).pipe(
      debounceTime(this.asyncValidatorDebounceTime),
      switchMap(() =>
        this.workflowDefinitionService.definitionExists(control.value).pipe(
          map(() => ({ duplicateName: true })),
          catchError((e: HttpErrorResponse) => {
            if (e.status === 404) {
              return of(null);
            }
            throwError(e);
          })
        )
      )
    );
  }

  onModelChange(): void {
    const keys = Object.keys(this.newWorkflowForm.controls);

    for (const key of keys) {
      if (this.newWorkflowForm.controls[key].invalid === true) {
        this.modelInvalid = true;
        return;
      }
    }

    this.modelInvalid = false;
  }

  onProjectsChange(event: any): void {
    this.modelInvalid = false;

    // Check again the model invalid value after the projects dropdown value has changed
    const keys = Object.keys(this.newWorkflowForm.controls);

    for (const key of keys) {
      if (this.newWorkflowForm.controls[key].invalid && key !== 'project') {
        this.modelInvalid = true;
      } else if (key === 'project') {
        if (event.selectedOptions.length === 0) {
          this.modelInvalid = true;
        }
      }
    }

    this.newWorkflowForm.patchValue({ project: event.selectedOptions });
  }

  onProjectsClicked(): void {
    if (!this.newWorkflowForm.get('project')?.value || this.newWorkflowForm.get('project').value.length <= 0) {
      this.projectIsEmpty = true;
    }
  }

  onSubmit(): void {
    if (this.newWorkflowForm.invalid) {
      this.newWorkflowError = true;
      return;
    }

    // TODO: check if the emit is completed successfully
    this.submitForm.emit(this);

    this.newWorkflowError = true;
  }

  closeModal(id: string): void {
    this.kmdModalService.close(id);
    this.close.emit();
  }

  formatErrorMessages(e: HttpErrorResponse): void {
    if (e.error?.length > 0) {
      for (const workflowError of e.error) {
        if (workflowError.message === 'Workflow name error') {
          const field = this.newWorkflowForm.get('workflowName');
          for (const detail of workflowError.details) {
            if (detail === 'Missing workflow name') {
              field.setErrors({ required: true });
            } else if (detail === 'Workflow name cannot be longer than 50 characters') {
              field.setErrors({ maxlength: true });
            } else if (detail === 'Duplicate workflow name') {
              field.setErrors({ duplicateName: true });
            }
          }
        } else if (workflowError.message === 'Description error') {
          const field = this.newWorkflowForm.get('description');
          for (const detail of workflowError.details) {
            if (detail === 'Missing description') {
              field.setErrors({ required: true });
            } else if (detail === 'Description cannot be longer than 500 characters') {
              field.setErrors({ maxlength: true });
            }
          }
        } else if (workflowError.message === 'Project error') {
          for (const detail of workflowError.details) {
            if (detail === 'Missing project') {
              this.newWorkflowForm.get('project').setErrors({ required: true });
            }
          }
        } else if (workflowError.message === 'BPMN error') {
          for (const detail of workflowError.details) {
            if (detail === 'Missing BPMN') {
              this.bpmnError = this.missingBpmnError;
            }
          }
        }
      }
    } else {
      this.genericError = true;
      if (e.error.message === 'BPMN was not valid and will not be deployable' && e.error.details) {
        this.bpmnValidationErrors = e.error.details;
      }
    }
  }
}
