import { getDate } from '@progress/kendo-date-math';

export class DateUtility {
  /* eslint-disable-next-line @typescript-eslint/no-empty-function */
  private constructor() {}

  /**
   * Checks if a date has passed.
   * @param {Date} [date]
   * @returns {boolean}
   */
  static hasDatePassed(date?: Date): boolean {
    return date && getDate(date) < getDate(new Date());
  }
}
