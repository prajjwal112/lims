import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SortUtility {
  public sortItems(listItems: any[], property: string, sortDirection: string): any[] {
    return listItems.sort((item1, item2) => {
      if (item1[property] < item2[property]) {
        return sortDirection === 'desc' ? -1 : 1;
      }
      if (item1[property] > item2[property]) {
        return sortDirection === 'desc' ? 1 : -1;
      }
      return 0;
    });
  }
}
