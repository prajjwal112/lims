import { AssigneeUtility } from './assignee-utility';

describe('AssigneeUtility', () => {
  describe('buildAssigneeNames', () => {
    it('should return empty string when no object given', () => {
      expect(AssigneeUtility.buildAssigneeNames()).toBe('');
    });

    it('should return group assignee names when given group assignees', () => {
      expect(
        AssigneeUtility.buildAssigneeNames({
          groupAssignees: [
            { id: 1, name: 'Group A' },
            { id: 2, name: 'Group B' },
          ],
          assignees: [],
        })
      ).toBe('Group A, Group B');
    });

    it('should return assignee names when given assignees', () => {
      expect(
        AssigneeUtility.buildAssigneeNames({
          groupAssignees: [],
          assignees: [
            {
              id: 1,
              firstName: 'User',
              lastName: 'One',
              email: 'user.one@company.com',
              active: true,
              admin: false,
              roles: [],
              projects: [],
              groups: [],
            },
            {
              id: 2,
              firstName: 'User',
              lastName: 'Two',
              email: 'user.two@company.com',
              active: true,
              admin: false,
              roles: [],
              projects: [],
              groups: [],
            },
          ],
        })
      ).toBe('User One, User Two');
    });

    it('should return only assignee names when given group assignees and assignees', () => {
      expect(
        AssigneeUtility.buildAssigneeNames({
          groupAssignees: [
            { id: 1, name: 'Group A' },
            { id: 2, name: 'Group B' },
          ],
          assignees: [
            {
              id: 1,
              firstName: 'User',
              lastName: 'One',
              email: 'user.one@company.com',
              active: true,
              admin: false,
              roles: [],
              projects: [],
              groups: [],
            },
            {
              id: 2,
              firstName: 'User',
              lastName: 'Two',
              email: 'user.two@company.com',
              active: true,
              admin: false,
              roles: [],
              projects: [],
              groups: [],
            },
          ],
        })
      ).toBe('User One, User Two');
    });
  });
});
