import type { IdNamePair } from '../id-name-pair';
import type { UserFilterItemResponse } from '../../users/shared/user';

export class AssigneeUtility {
  /* eslint-disable-next-line @typescript-eslint/no-empty-function */
  private constructor() {}

  static buildAssigneeNames(obj?: { groupAssignees?: IdNamePair[]; assignees?: UserFilterItemResponse[] }): string {
    if (!obj) {
      return '';
    }

    const assigneeNames: string[] = [];

    if (obj.assignees.length > 0) {
      assigneeNames.push(...obj.assignees.map((assignee: UserFilterItemResponse) => `${assignee.firstName} ${assignee.lastName}`));
    } else if (obj.groupAssignees.length > 0) {
      assigneeNames.push(...obj.groupAssignees.map((groupAssignee: IdNamePair) => groupAssignee.name));
    }

    return assigneeNames.join(', ');
  }
}
