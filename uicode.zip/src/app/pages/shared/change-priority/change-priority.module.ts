import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangePriorityComponent } from './change-priority.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertsModule, ButtonModule, ModalsModule, RadioButtonModule } from 'gds-atom-components';

@NgModule({
  declarations: [ChangePriorityComponent],
  imports: [CommonModule, AlertsModule, ModalsModule, RadioButtonModule, ButtonModule, ReactiveFormsModule, FormsModule],
  exports: [ChangePriorityComponent],
})
export class ChangePriorityModule {}
