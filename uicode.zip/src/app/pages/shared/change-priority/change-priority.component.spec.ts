import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ButtonModule, ModalsModule, RadioButtonModule, AlertsModule } from 'gds-atom-components';

import { ChangePriorityComponent } from './change-priority.component';
import { ModalId } from '../modal-id';

describe('ChangePriorityComponent', () => {
  let component: ChangePriorityComponent;
  let fixture: ComponentFixture<ChangePriorityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ChangePriorityComponent],
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        ModalsModule,
        ButtonModule,
        RadioButtonModule,
        AlertsModule,
        ReactiveFormsModule,
        FormsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePriorityComponent);
    component = fixture.componentInstance;
    component.modalSize = 'medium';
    component.headLine = 'Change task priority';
    fixture.detectChanges();
    component['kmdModalService'].open(ModalId.ChangePriority);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show cancel button', () => {
    expect(fixture.debugElement.query(By.css('form button[kmdInfoButton]'))).toBeTruthy();
  });

  it('should show confirm button', () => {
    expect(fixture.debugElement.query(By.css('form button[kmdFeaturedButton]'))).toBeTruthy();
  });

  it('should show 5 radio buttons', () => {
    expect(fixture.debugElement.queryAll(By.css('form kmd-radio-button')).length).toBe(5);
  });

  it('should fire onCancel method called when cancel button is clicked on', () => {
    spyOn(component, 'onCancel');
    fixture.debugElement.query(By.css('form button[kmdInfoButton]')).nativeElement.click();
    fixture.detectChanges();

    expect(component.onCancel).toHaveBeenCalledWith();
  });

  it('should fire onConfirm method called when confirm button is clicked on', () => {
    spyOn(component, 'onConfirm');
    fixture.debugElement.query(By.css('form button[kmdFeaturedButton]')).nativeElement.click();
    fixture.detectChanges();

    expect(component.onConfirm).toHaveBeenCalledWith();
  });
});
