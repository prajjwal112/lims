import { Component, EventEmitter, Input, Output } from '@angular/core';
import type { OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { KmdModalService } from 'gds-atom-components';

import { ModalId } from '../modal-id';
import { PriorityPillComponent } from '../grid/priority-pill/priority-pill.component';

@Component({
  selector: 'app-change-priority',
  templateUrl: './change-priority.component.html',
  styleUrls: ['./change-priority.component.scss'],
})
export class ChangePriorityComponent implements OnChanges {
  @Input() priority = 0;
  @Input() modalSize: 'small' | 'medium' | 'large' = 'medium';
  @Input() headLine: string;
  @Input() errorMessage = '';
  @Output() errorMessageChange = new EventEmitter<string>();
  @Output() confirmChanged = new EventEmitter<number>();
  @Output() cancelChanged = new EventEmitter<void>();

  readonly modalId = ModalId;

  public priorityForm = new FormGroup({
    priority: new FormControl(PriorityPillComponent.setPriorityRangeValue(this.priority), [Validators.required]),
  });

  #priorityValue = 0;

  constructor(private readonly kmdModalService: KmdModalService) {}

  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (simpleChanges.priority && simpleChanges.priority.currentValue !== simpleChanges.priority.previousValue) {
      this.#priorityValue = PriorityPillComponent.setPriorityRangeValue(simpleChanges.priority.currentValue);
      this.priorityForm.controls.priority.setValue(this.#priorityValue);
    }
  }

  public onConfirm(): void {
    this.errorMessage = '';
    this.#priorityValue = PriorityPillComponent.setPriorityRangeValue(+this.priorityForm.get('priority').value);
    this.confirmChanged.emit(this.#priorityValue);
  }

  public modalClosed(): void {
    this.errorMessageChange.emit('');
    this.priorityForm.controls.priority.setValue(this.#priorityValue);
    this.onCancelChange();
  }

  public onCancel(): void {
    this.kmdModalService.close(ModalId.ChangePriority);
    this.onCancelChange();
  }

  private onCancelChange(): void {
    this.cancelChanged.emit();
  }
}
