import { Component, Input, SimpleChanges, OnChanges, Output, EventEmitter } from '@angular/core';

import { Card, CardDetail } from './cards';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.scss'],
})
export class CardsComponent implements OnChanges {
  @Input() cardsData: Card[];
  @Input() cardDetails: CardDetail[] = [];
  @Input() pathLink: string;
  @Input() collapsible: boolean;
  @Input() serverRendering: boolean;
  @Input() openCardIds: number[] = [];
  @Input() viewType: string;
  @Output() getCardDetails = new EventEmitter<number>();

  public readonly calculateWorkflowPercent = CardsComponent.calculateWorkflowPercent;
  public openedCards: number[] = [];

  private static calculateWorkflowPercent(card: Card | CardDetail): number {
    return Math.floor((card.completedTasksCount && card.totalTasksCount ? card.completedTasksCount / card.totalTasksCount : 0) * 100);
  }

  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (simpleChanges.openCardIds) {
      this.openedCards = simpleChanges.openCardIds.currentValue;
    }
  }

  openCloseProjectCard(id: number): void {
    const index = this.openedCards.indexOf(id);
    if (index === -1) {
      if (!this.cardDetails.some((card) => card.id === id)) {
        this.getCardDetails.emit(id);
      } else {
        this.openedCards.push(id);
      }
    } else {
      this.openedCards.splice(index, 1);
    }
  }

  getCardDetail(id: number): Card | CardDetail {
    return this.cardDetails.find((card) => card.id === id) || this.cardsData.find((card) => card.id === id);
  }
}
