export interface Card {
  id: number;
  name: string;
  failedTasksCount?: number;
  activeRunsCount?: number;
  tasksInProgressCount?: number;
  blockedTasksCount?: number;
  completedTasksCount?: number;
  totalTasksCount?: number;
}

export interface CardDetail {
  id: number;
  name: string;
  processDefinitionId: number;
  workflowCount: number;
  activeRuns: number;
  completedTasksCount?: number;
  totalTasksCount?: number;
}
