import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CardsComponent } from './cards.component';
import { FieldGaugeModule } from '../field-gauge/field-gauge.module';
import { WorkflowCoreApiModule } from '../../../core/api/workflow-core-api.module';

@NgModule({
  declarations: [CardsComponent],
  imports: [CommonModule, RouterModule, FieldGaugeModule, WorkflowCoreApiModule],
  exports: [CardsComponent],
})
export class CardsModule {}
