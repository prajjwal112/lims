import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';

import { CardsComponent } from './cards.component';
import { FieldGaugeModule } from '../field-gauge/field-gauge.module';
import { WorkflowCoreApiModule } from '../../../core/api/workflow-core-api.module';

describe('CardsComponent', () => {
  let component: CardsComponent;
  let fixture: ComponentFixture<CardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CardsComponent],
      imports: [BrowserAnimationsModule, RouterTestingModule, FieldGaugeModule, WorkflowCoreApiModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardsComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display cards', () => {
    component.cardsData = [
      {
        id: 0,
        name: 'test',
      },
    ];
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.card-head')).length).toBe(1);
  });

  it('should display one non collapsible card and viewType is taskView', () => {
    expect(component).toBeTruthy();
    component.cardsData = [
      {
        id: 1,
        name: 'test card',
        failedTasksCount: 0,
        activeRunsCount: 3,
        tasksInProgressCount: 5,
        blockedTasksCount: 1,
        completedTasksCount: 0,
        totalTasksCount: 0,
      },
    ];
    component.pathLink = '';
    component.collapsible = false;
    component.openedCards = [];
    component.viewType = 'taskView';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.card-head')).length).toBe(1);
    expect(fixture.debugElement.queryAll(By.css('.card-head'))[0].nativeElement.textContent.trim()).toBe('test card');
    expect(fixture.debugElement.queryAll(By.css('.card-count')).length).toBe(3);
    expect(fixture.debugElement.queryAll(By.css('.card-count'))[0].nativeElement.textContent.trim()).toBe('3');
    expect(fixture.debugElement.queryAll(By.css('.card-count'))[1].nativeElement.textContent.trim()).toBe('5');
    expect(fixture.debugElement.queryAll(By.css('.card-count'))[2].nativeElement.textContent.trim()).toBe('1');
  });

  it('should display one collapsible card and viewType is groups', () => {
    expect(component).toBeTruthy();
    component.cardsData = [
      {
        id: 1,
        name: 'group test card',
      },
    ];
    component.openedCards = [1];
    component.pathLink = '';
    component.collapsible = true;
    component.cardDetails = [
      {
        id: 1,
        name: 'group test card',
        processDefinitionId: 1,
        workflowCount: 2,
        activeRuns: 3,
        completedTasksCount: 4,
        totalTasksCount: 5,
      },
    ];
    component.viewType = 'groups';
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.card-head')).length).toBe(1);
    expect(fixture.debugElement.queryAll(By.css('.card-head'))[0].nativeElement.textContent.trim()).toBe('group test card');
    expect(fixture.debugElement.queryAll(By.css('.card-count')).length).toBe(2);
    expect(fixture.debugElement.queryAll(By.css('.card-count'))[0].nativeElement.textContent.trim()).toBe('3');
    expect(fixture.debugElement.queryAll(By.css('.card-count'))[1].nativeElement.textContent.trim()).toBe('2');
  });
});
