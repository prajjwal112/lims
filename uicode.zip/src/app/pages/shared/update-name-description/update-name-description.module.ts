import { NgModule } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';

import { UpdateNameDescriptionComponent } from './update-name-description.component';
import { ModalsModule, AlertsModule, ButtonModule, InputFieldsModule } from 'gds-atom-components';
import { ReactiveFormsModule } from '@angular/forms';
import { ValidationErrorsModule } from '../validation-errors/validation-errors.module';

@NgModule({
  declarations: [UpdateNameDescriptionComponent],
  imports: [CommonModule, ModalsModule, ReactiveFormsModule, AlertsModule, ButtonModule, ValidationErrorsModule, InputFieldsModule],
  providers: [TitleCasePipe],
  exports: [UpdateNameDescriptionComponent],
})
export class UpdateNameDescriptionModule {}
