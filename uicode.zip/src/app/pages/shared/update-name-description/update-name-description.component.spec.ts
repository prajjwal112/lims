import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ModalsModule, AlertsModule, ButtonModule, InputFieldsModule } from 'gds-atom-components';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ValidationErrorsModule } from '../validation-errors/validation-errors.module';
import { UpdateNameDescriptionComponent } from './update-name-description.component';
import { TitleCasePipe } from '@angular/common';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ModalId } from '../modal-id';

describe('UpdateNameDescriptionComponent', () => {
  let component: UpdateNameDescriptionComponent;
  let fixture: ComponentFixture<UpdateNameDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateNameDescriptionComponent],
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        ModalsModule,
        AlertsModule,
        ButtonModule,
        ReactiveFormsModule,
        ValidationErrorsModule,
        InputFieldsModule,
      ],
      providers: [TitleCasePipe],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateNameDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component['kmdModalService'].open(ModalId.UpdateNameDescription);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the closeModal method called when cancel button is clicked on', () => {
    spyOn(component, 'closeModal');
    fixture.debugElement.query(By.css('button[kmdInfoButton]')).nativeElement.dispatchEvent(new Event('click'));

    expect(component.closeModal).toHaveBeenCalledWith();
  });

  it('should disable confirm button when form is invalid', () => {
    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeTrue();
  });

  it('form should not be valid if name field does not contain any values', () => {
    const name = component.updateForm.controls['name'];

    expect(name.valid).toBeFalsy();

    name.setValue('');

    expect(name.hasError('required')).toBeTruthy();
    expect(component.updateForm.valid).toBeFalsy();
  });

  it('form should not be valid if description field does not contain any values', () => {
    const description = component.updateForm.controls['description'];

    expect(description.valid).toBeFalsy();

    description.setValue('');

    expect(component.updateForm.valid).toBeFalsy();
  });

  it('should enable confirm button when form is valid', () => {
    component.updateForm = new FormGroup({
      name: new FormControl('name1'),
      description: new FormControl('value'),
    });
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.disabled).toBeFalse();
  });

  it('should show alert if error code is 500', () => {
    expect(fixture.debugElement.query(By.css('kmd-alerts'))).toBeFalsy();
    component.confirmedStatus = {
      status: false,
      errorCode: 500,
      message: '',
    };
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('kmd-alerts'))).toBeTruthy();
  });
});
