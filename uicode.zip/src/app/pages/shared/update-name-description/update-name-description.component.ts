import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { PartialObserver, Subject } from 'rxjs';
import { KmdModalService } from 'gds-atom-components';
import { ModalId } from '../modal-id';
import { CustomValidators } from '../custom-validators';
import { ConfirmedStatus } from '../common-data-type';
import { WorkflowHttpErrorResponse } from '../../../core/api/workflow-error';
import { IdNameDescriptionService } from '../id-name-description-service';
import { TitleCasePipe } from '@angular/common';
import { takeUntil } from 'rxjs/operators';
import type { OnChanges, SimpleChanges, OnInit, OnDestroy } from '@angular/core';
import type { IdNameDescriptionRequest, IdNameDescriptionResponse } from '../id-name-description-service';

@Component({
  selector: 'app-update-name-description',
  templateUrl: './update-name-description.component.html',
  styleUrls: ['./update-name-description.component.scss'],
})
export class UpdateNameDescriptionComponent implements OnChanges, OnInit, OnDestroy {
  @Input() itemName = '';
  @Input() id: string | number;
  @Input() name = '';
  @Input() description = '';
  @Input() linkPath = '';
  @Input() service: IdNameDescriptionService;
  @Input() modelName: string;
  @Output() confirmedAction = new EventEmitter<void>();
  public updateForm = new FormGroup({
    name: new FormControl('', [Validators.required, CustomValidators.notBlank]),
    description: new FormControl('', [CustomValidators.notBlank]),
  });
  public didSubmit = false;
  public nameValue = '';
  public descriptionValue = '';
  public titleCasedItemName = '';

  readonly modalId = ModalId;

  readonly #unsubscribe: Readonly<Subject<void>> = new Subject<void>();
  confirmedStatus = UpdateNameDescriptionComponent.resetConfirmStatus();

  constructor(
    private readonly kmdModalService: KmdModalService,
    private readonly router: Router,
    private readonly titleCasePipe: TitleCasePipe
  ) {}

  private static resetConfirmStatus(): ConfirmedStatus {
    return {
      status: true,
      errorCode: 0,
      message: '',
    };
  }
  ngOnInit(): void {
    this.updateForm
      .get('name')
      .valueChanges.pipe(takeUntil(this.#unsubscribe))
      .subscribe({
        next: () => {
          if (this.confirmedStatus && !this.confirmedStatus.status) {
            this.confirmedStatus = UpdateNameDescriptionComponent.resetConfirmStatus();
          }
        },
      });
  }

  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (simpleChanges.itemName) {
      this.titleCasedItemName = this.titleCasePipe.transform(simpleChanges.itemName.currentValue);
    }
    if (simpleChanges.name) {
      this.nameValue = simpleChanges.name.currentValue;
      this.updateForm.controls.name.setValue(simpleChanges.name.currentValue);
    }
    if (simpleChanges.description) {
      this.descriptionValue = simpleChanges.description.currentValue;
      this.updateForm.controls.description.setValue(simpleChanges.description.currentValue);
    }
  }

  ngOnDestroy(): void {
    this.#unsubscribe.next();
    this.#unsubscribe.complete();
  }

  public onSubmit(): void {
    this.confirmedStatus = UpdateNameDescriptionComponent.resetConfirmStatus();
    this.didSubmit = true;
    if (this.updateForm.invalid) {
      return;
    }

    const request: IdNameDescriptionRequest = {
      name: this.updateForm.get('name').value.trim(),
      description: this.updateForm.get('description').value?.trim(),
    };
    const requestData: IdNameDescriptionRequest = this.id ? Object.assign({ id: this.id }, request) : request;
    if (this.id) {
      this.service.update(requestData).subscribe(this.processResponse());
    } else {
      this.service.create(requestData).subscribe(this.processResponse());
    }
  }

  public modalClosed(): void {
    this.confirmedStatus = UpdateNameDescriptionComponent.resetConfirmStatus();
    this.didSubmit = false;
    this.updateForm.controls.name.setValue(this.id ? this.nameValue : '');
    this.updateForm.controls.description.setValue(this.id ? this.descriptionValue : '');
  }

  public closeModal(): void {
    this.kmdModalService.close(this.modelName || ModalId.UpdateNameDescription);
  }

  private processResponse(): PartialObserver<IdNameDescriptionResponse> {
    return {
      next: (data): void => {
        if (!this.id) {
          if (data.id) {
            this.router.navigate([this.linkPath, data.id], { queryParams: { success: true } });
          } else {
            this.confirmedStatus = {
              status: false,
              errorCode: 500,
              message: `Unable to navigate to newly created ${this.itemName} page.`,
            };
          }
        } else {
          this.nameValue = this.updateForm.get('name').value.trim();
          this.descriptionValue = (this.updateForm.get('description').value || '').trim();
          this.confirmedAction.emit();
          this.kmdModalService.close(ModalId.UpdateNameDescription);
        }
      },
      error: (error: WorkflowHttpErrorResponse): void => {
        const errorCode = error.status === 400 ? 400 : 500;
        const errorMessage =
          error.status === 400
            ? (error.error && error.error.message) || `Duplicate ${this.itemName} name`
            : `Unable to ${this.id ? 'update' : 'create'} ${this.itemName}. Please try again later.`;
        this.confirmedStatus = {
          status: false,
          errorCode,
          message: errorMessage,
        };
      },
    };
  }
}
