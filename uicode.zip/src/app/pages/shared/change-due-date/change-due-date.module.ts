import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangeDueDateComponent } from './change-due-date.component';
import { ButtonModule, InputFieldsModule, ModalsModule, TooltipModule } from 'gds-atom-components';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidationErrorsModule } from '../validation-errors/validation-errors.module';
import { DatePickerModule, TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { DateLabelModule } from '../date-label/date-label.module';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';

@NgModule({
  declarations: [ChangeDueDateComponent],
  imports: [
    CommonModule,
    ModalsModule,
    ButtonModule,
    ReactiveFormsModule,
    FormsModule,
    InputFieldsModule,
    ValidationErrorsModule,
    DatePickerModule,
    TimePickerModule,
    TooltipModule,
    DateLabelModule,
    WorkflowPipeModule,
  ],
  exports: [ChangeDueDateComponent],
})
export class ChangeDueDateModule {}
