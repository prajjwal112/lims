import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule, KmdModalComponent, ModalsModule, TooltipModule } from 'gds-atom-components';
import { ChangeDueDateComponent } from './change-due-date.component';
import { WorkflowPipeModule } from '../../../core/pipe/workflow-pipe.module';
import { DateLabelModule } from '../date-label/date-label.module';
import { ModalId } from '../modal-id';
import { DatePickerModule, TimePickerModule } from '@progress/kendo-angular-dateinputs';
import { ReactiveFormsModule } from '@angular/forms';
import type { IsoDate } from '../../../core/app-settings';

describe('ChangeDueDateComponent', () => {
  let component: ChangeDueDateComponent;
  let fixture: ComponentFixture<ChangeDueDateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ChangeDueDateComponent],
      imports: [
        ModalsModule,
        ButtonModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        WorkflowPipeModule,
        DateLabelModule,
        TooltipModule,
        DatePickerModule,
        TimePickerModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeDueDateComponent);
    component = fixture.componentInstance;
    component.modalSize = 'medium';
    fixture.detectChanges();
    component['kmdModalService'].open(ModalId.ChangeDueDate);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show cancel button', () => {
    expect(fixture.debugElement.query(By.css('button[kmdInfoButton]')).nativeElement.textContent).toBe('Cancel');
  });

  it('should show confirm button', () => {
    expect(fixture.debugElement.query(By.css('button[kmdFeaturedButton]')).nativeElement.textContent).toBe('Confirm');
  });

  it('should show "current due date" label', () => {
    expect(fixture.debugElement.query(By.css('p')).nativeElement.textContent.trim()).toBe('Current due date:');
  });

  it('should show "current due date" label with date when given a date', () => {
    component.currentDueDate = new Date(2021, 1, 18, 13).toISOString();
    fixture.detectChanges();

    expect(fixture.debugElement.query(By.css('p')).nativeElement.textContent.trim()).toBe(
      'Current due date:\u00A0\u00A0 Feb 18, 2021 1:00 PM'
    );
  });

  it('should emit a date-time on confirm', () => {
    const spy: jasmine.Spy<(event: IsoDate) => void> = spyOn(component.confirmed, 'emit');
    component.changeDueDateForm.setValue({ newDate: new Date(2021, 1, 18), newTime: new Date(0, 0, 0, 13) });
    fixture.detectChanges();

    component.onConfirm();

    expect(spy).toHaveBeenCalledWith('2021-02-18T13:00');
  });

  it('should reset form when modal is closed', () => {
    const spy: jasmine.Spy<() => void> = spyOn(component.changeDueDateForm, 'reset');

    fixture.debugElement.query(By.directive(KmdModalComponent)).triggerEventHandler('modalClosed', null);

    expect(spy).toHaveBeenCalledWith();
  });
});
