import { Component, EventEmitter, Input, Output } from '@angular/core';
import { KmdModalService } from 'gds-atom-components';
import { ComponentWithModalDirective } from '../component-with-modal.directive';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DATE_API_FORMAT, DATE_INPUT_FORMAT, TIME_API_FORMAT, TIME_INPUT_FORMAT } from '../../../core/app-settings';
import moment from 'moment-timezone';
import { ModalId } from '../modal-id';
import type { IsoDate } from '../../../core/app-settings';
import type { WorkflowCamundaIdPair } from '../id-name-pair';

@Component({
  selector: 'app-change-due-date',
  templateUrl: './change-due-date.component.html',
  styleUrls: ['./change-due-date.component.scss'],
})
export class ChangeDueDateComponent extends ComponentWithModalDirective {
  static readonly errorMessage = 'Unable to change due date.';

  @Input() modalSize: 'small' | 'medium' | 'large' = 'medium';
  @Input() currentDueDate: string;
  @Input() taskIds: WorkflowCamundaIdPair[] = [];
  @Output() readonly confirmed = new EventEmitter<IsoDate>();

  readonly newDateMinimum = new Date();
  readonly dateInputFormat = DATE_INPUT_FORMAT;
  readonly timeInputFormat = TIME_INPUT_FORMAT;
  readonly modalId = ModalId;
  readonly changeDueDateForm = new FormGroup({
    newDate: new FormControl('', [Validators.required]),
    newTime: new FormControl('', [Validators.required]),
  });

  constructor(protected readonly kmdModalService: KmdModalService) {
    super(kmdModalService);
  }

  onConfirm(): void {
    const date = moment(this.changeDueDateForm.controls.newDate.value).format(DATE_API_FORMAT);
    const time = moment(this.changeDueDateForm.controls.newTime.value).format(TIME_API_FORMAT);

    this.confirmed.emit(`${date}T${time}`);
  }

  onModalClosed(): void {
    this.changeDueDateForm.reset();
  }
}
