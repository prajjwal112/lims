import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BaseGuard } from './base.guard';

@Injectable({
  providedIn: 'root',
})
export class PublishAccessGuard extends BaseGuard {
  constructor(protected readonly router: Router) {
    super(router, ['verifiedTaskTemplate', 'workflowName'], '/workflow-definitions');
  }
}
