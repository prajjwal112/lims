import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { environment } from '../../../../environments/environment';
import { WorkflowHttpParams } from '../../../core/api/workflow-http-params';
import type { ManageItemsRequest } from '../common-data-type';

const URL = `${environment.endpoint}/user-management`;
const ROLE_TYPE_PARAM = new WorkflowHttpParams().append('type', 'role');
const PROJECT_TYPE_PARAM = new WorkflowHttpParams().append('type', 'project');
const GROUP_TYPE_PARAM = new WorkflowHttpParams().append('type', 'group');

@Injectable({
  providedIn: 'root',
})
export class UserManagementService {
  constructor(private http: HttpClient) {}

  addRoles(requestData: ManageItemsRequest): Observable<void> {
    return this.http
      .post<void>(URL, requestData, { params: ROLE_TYPE_PARAM })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  updateRoles(requestData: ManageItemsRequest): Observable<void> {
    return this.http
      .put<void>(URL, requestData, { params: ROLE_TYPE_PARAM })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  addProjects(requestData: ManageItemsRequest): Observable<void> {
    return this.http
      .post<void>(URL, requestData, { params: PROJECT_TYPE_PARAM })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  updateProjects(requestData: ManageItemsRequest): Observable<void> {
    return this.http
      .put<void>(URL, requestData, { params: PROJECT_TYPE_PARAM })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  addGroups(requestData: ManageItemsRequest): Observable<void> {
    return this.http
      .post<void>(URL, requestData, { params: GROUP_TYPE_PARAM })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  updateGroups(requestData: ManageItemsRequest): Observable<void> {
    return this.http
      .put<void>(URL, requestData, { params: GROUP_TYPE_PARAM })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  removeGroups(requestData: ManageItemsRequest): Observable<void> {
    return this.http
      .request<void>('DELETE', URL, { body: requestData, params: GROUP_TYPE_PARAM })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }
}
