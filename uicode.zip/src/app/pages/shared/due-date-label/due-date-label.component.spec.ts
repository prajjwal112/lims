import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { By } from '@angular/platform-browser';
import { DueDateLabelComponent } from './due-date-label.component';
import { DateLabelModule } from '../date-label/date-label.module';

describe('DueDateLabelComponent', () => {
  const EXPECTED_DATE = 'Sep 24, 2019';
  const EXPECTED_DATE_TIME = `${EXPECTED_DATE} 12:00 AM`;

  let component: DueDateLabelComponent;
  let fixture: ComponentFixture<DueDateLabelComponent>;
  let date: Date;
  const updateComponent = (config: object) => {
    Object.keys(config).forEach(key => (component[key] = config[key]));
    fixture.detectChanges();
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DueDateLabelComponent],
      imports: [DateLabelModule],
    })
      .compileComponents()
      .then(() => {
        fixture = TestBed.createComponent(DueDateLabelComponent);
        component = fixture.componentInstance;
      });
  }));

  beforeEach(() => {
    date = new Date(2019, 8, 24);
  });

  it('should add danger class if date is past due', () => {
    expect(fixture.debugElement.query(By.css('app-date-label')).nativeElement.classList).not.toContain('text-danger');
    updateComponent({ date: new Date(Date.now() - 100000000) });

    expect(fixture.debugElement.query(By.css('app-date-label')).nativeElement.classList).toContain('text-danger');
  });

  it('should show warning icon if date is past due', () => {
    expect(fixture.debugElement.query(By.css('.gds-icon-alert-bold'))).toBeFalsy();
    updateComponent({ date: new Date(Date.now() - 100000000) });

    expect(fixture.debugElement.query(By.css('.gds-icon-alert-bold'))).toBeTruthy();
  });
});
