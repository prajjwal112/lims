import { Component, Input } from '@angular/core';
import { DateUtility } from '../utility/date-utility';

@Component({
  selector: 'app-due-date-label',
  templateUrl: './due-date-label.component.html',
  styleUrls: ['./due-date-label.component.scss'],
})
export class DueDateLabelComponent {
  /** The date to display. */
  @Input() date: Date;

  /** Whether or not to display the time on the element. */
  @Input() displayTimeOnElement: boolean;

  /** Whether or not to display the time on the title of the element. */
  @Input() displayTimeOnTitle: boolean;

  hasDatePassed(date?: Date): boolean {
    return DateUtility.hasDatePassed(date);
  }
}
