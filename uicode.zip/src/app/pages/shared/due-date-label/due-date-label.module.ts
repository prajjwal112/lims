import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DueDateLabelComponent } from './due-date-label.component';
import { DateLabelModule } from '../date-label/date-label.module';

@NgModule({
  declarations: [DueDateLabelComponent],
  imports: [CommonModule, DateLabelModule],
  exports: [DueDateLabelComponent],
})
export class DueDateLabelModule {}
