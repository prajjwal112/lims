import { TestBed } from '@angular/core/testing';

import { UnassociatedService } from './unassociated.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('UnassociatedService', () => {
  let service: UnassociatedService;

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule] });
    service = TestBed.inject(UnassociatedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
