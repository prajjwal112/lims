import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IdNamePair } from '../id-name-pair';
import { environment } from '../../../../environments/environment';
import { WorkflowHttpParams } from '../../../core/api/workflow-http-params';
import { UserFilterItem, UserFilterItemResponse } from '../../users/shared/user';

const UNASSOCIATED_USERS_URL = `${environment.endpoint}/unassociated-users`;
const UNASSOCIATED_GROUPS_URL = `${environment.endpoint}/unassociated-groups`;
const UNASSOCIATED_PROJECTS_URL = `${environment.endpoint}/unassociated-projects`;

@Injectable({
  providedIn: 'root',
})
export class UnassociatedService {
  constructor(private http: HttpClient) {}

  private static buildParams(roleReferenceId?: number, projectReferenceId?: number, groupReferenceId?: number): WorkflowHttpParams {
    let params = new WorkflowHttpParams();

    if (UnassociatedService.isNotNullOrUndefined(roleReferenceId)) {
      params = params.append('roleId', roleReferenceId.toString());
    }

    if (UnassociatedService.isNotNullOrUndefined(projectReferenceId)) {
      params = params.append('projectId', projectReferenceId.toString());
    }

    if (UnassociatedService.isNotNullOrUndefined(groupReferenceId)) {
      params = params.append('groupId', groupReferenceId.toString());
    }

    return params;
  }

  private static isNotNullOrUndefined(referenceId?: number): boolean {
    return referenceId !== null && referenceId !== undefined;
  }

  getUnassociatedUsers(roleReferenceId?: number, projectReferenceId?: number, groupReferenceId?: number): Observable<UserFilterItem[]> {
    return this.http
      .get<UserFilterItemResponse[]>(UNASSOCIATED_USERS_URL, {
        params: UnassociatedService.buildParams(roleReferenceId, projectReferenceId, groupReferenceId),
      })
      .pipe(
        catchError((error: HttpErrorResponse) => throwError(error)),
        map((responses: UserFilterItemResponse[]) =>
          responses.map((response: UserFilterItemResponse) => ({ ...response, fullName: `${response.firstName} ${response.lastName}` }))
        )
      );
  }

  getUnassociatedGroups(projectReferenceId?: number): Observable<IdNamePair[]> {
    return this.http
      .get<IdNamePair[]>(UNASSOCIATED_GROUPS_URL, { params: UnassociatedService.buildParams(undefined, projectReferenceId) })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }

  getUnassociatedProjects(groupReferenceId?: number): Observable<IdNamePair[]> {
    return this.http
      .get<IdNamePair[]>(UNASSOCIATED_PROJECTS_URL, { params: UnassociatedService.buildParams(undefined, undefined, groupReferenceId) })
      .pipe(catchError((error: HttpErrorResponse) => throwError(error)));
  }
}
