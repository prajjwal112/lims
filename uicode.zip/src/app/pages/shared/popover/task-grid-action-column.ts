import { isStatusActive } from '../task-detail';
import { ModalId } from '../modal-id';
import type { FieldPopoverMenuAction } from '../grid/popover/action/action-popover';
import type { Column } from '../grid/column';
import type { Status } from '../status';

const CHANGE_DUE_DATE_ACTION: FieldPopoverMenuAction = { name: ModalId.ChangeDueDate, display: 'Change Due Date' };

export const BASE_OPTIONS: ReadonlyArray<FieldPopoverMenuAction> = [
  { name: ModalId.ChangeAssignment, display: 'Change Assignment' },
  { name: ModalId.ChangePriority, display: 'Change Priority' },
] as const;

/** Adds change due date as an option and disables it if data is not applicable */
export const popoverCallback = (column: Column) => (dataItem: Record<string, unknown>): void => {
  column.popover.action.items =
    dataItem.dueDate && isStatusActive({ id: dataItem.id as string, status: dataItem.status as Status })
      ? [...BASE_OPTIONS, CHANGE_DUE_DATE_ACTION]
      : [...BASE_OPTIONS, { ...CHANGE_DUE_DATE_ACTION, disabled: true }];
};
