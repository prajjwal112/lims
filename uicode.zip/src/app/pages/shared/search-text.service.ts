import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SearchTextService {
  readonly #searchedText = new BehaviorSubject<string>('');

  setText(text: string): void {
    this.#searchedText.next(text);
  }

  getText(): Observable<string> {
    return this.#searchedText.asObservable();
  }
}
