import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class CustomValidators {
  public static readonly disallowSpecialCharactersPattern = /^[ \t]*[^\d\W]+([\w ]+[\w ])*\t*$/;
  public static readonly disallowWorkflowNameCharactersPattern = /^[\w\s-]+$/;

  /* eslint-disable-next-line @typescript-eslint/no-empty-function */
  private constructor() {}

  /**
   * Checks if control value is only white spaces or not.
   * @returns {{ whitespace: boolean }} { whitespace: true } | null
   */
  static notBlank(control: AbstractControl): ValidationErrors | null {
    const value = Array.isArray(control.value) ? control.value.join('') : control.value;
    return value?.trim() ? null : { whitespace: true };
  }

  /**
   * Checks if control value starts with `tf_`.
   * @returns {{ prefix: boolean }} { prefix: true } | null
   */
  static noTFPrefix(control: AbstractControl): ValidationErrors | null {
    const isValid = control.value.slice(0, 3).toLowerCase() !== 'tf_';
    return isValid ? null : { prefix: true };
  }

  /**
   * Parses a control value to ensure all sub-strings delimited by the new line character, or all items if the value is an array, are numeric.
   * @returns {{ nonnumericLine: boolean }} { nonnumericLine: true } | null
   */
  static numericLinesOnly(control: AbstractControl): ValidationErrors | null {
    const lines: string[] = Array.isArray(control.value) ? control.value : control.value?.split('\n');
    return !lines.some((line: string) => isNaN(+line)) ? null : { nonnumericLine: true };
  }

  /**
   * Parses a control value to validate each line has &lt;= `limit`.
   * @param limit
   * @returns {{ maxChracters: boolean }} { maxCharacters: true } | null
   */
  static maxCharactersPerLine(limit: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const lines: string[] = Array.isArray(control.value) ? control.value : control.value?.split('\n');
      return lines.every((line: string) => line.length <= limit) ? null : { maxCharacters: true };
    };
  }

  /**
   * Parses a control value to validate that input does not contain any of the reserved keyword.
   * @param control
   * @returns {{ hasObjectStoreKeyword: boolean }} { hasObjectStoreKeyword: true } | null
   */
  static notContainObjectStoreKeywords(control: AbstractControl): ValidationErrors | null {
    const objectStoreKeywords: string[] = ['tf-tenant', 'tf-global-tenant', 'tf-workflow-definition-template', 'tf-task-template'];
    return control.value && objectStoreKeywords.some((keyword: string) => control.value.includes(keyword))
      ? { hasObjectStoreKeyword: true }
      : null;
  }
}
