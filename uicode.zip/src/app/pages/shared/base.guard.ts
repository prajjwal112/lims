import { Injectable, Optional } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export abstract class BaseGuard implements CanActivate {
  constructor(
    protected readonly router: Router,
    @Optional() private readonly navigationStateKeys: string[],
    @Optional() private readonly path: string
  ) {}
  canActivate(): boolean {
    const navigationState = this.router.getCurrentNavigation().extras.state;

    if (this.navigationStateKeys.every((key) => navigationState?.[key])) {
      return true;
    }

    this.router.navigate([this.path]);
    return false;
  }
}
