/**
 * Types of pill
 */
export enum PillType {
  Success = 'success',
  Danger = 'danger',
  Warning = 'warning',
  Secondary = 'secondary',
  Info = 'info',
  InProgress = 'inprogress',
  Blocked = 'blocked',
}
