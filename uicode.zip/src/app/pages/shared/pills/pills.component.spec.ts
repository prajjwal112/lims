import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PillsComponent } from './pills.component';
import { By } from '@angular/platform-browser';
import { PillType } from './pill-type';

describe('PillsComponent', () => {
  let component: PillsComponent;
  let fixture: ComponentFixture<PillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PillsComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  function testBadgeWithDifferentLabels(input) {
    it(`should show badge with ${input} class`, () => {
      component.type = input;
      fixture.detectChanges();

      expect(fixture.debugElement.query(By.css('span')).nativeElement.className).toContain(input);
    });
  }

  for (const badgeType in PillType) {
    if (Object.prototype.hasOwnProperty.call(badgeType, PillType)) {
      testBadgeWithDifferentLabels(badgeType);
    }
  }
});
