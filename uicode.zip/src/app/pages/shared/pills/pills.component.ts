import { Component, OnInit, Input } from '@angular/core';
import { PillType } from './pill-type';

@Component({
  selector: 'app-pills',
  templateUrl: './pills.component.html',
  styleUrls: ['./pills.component.scss'],
})
export class PillsComponent implements OnInit {
  /**
   * The pill type
   */
  @Input() type: PillType;

  /**
   * The pill type enum made public to the component template so it can build the UI
   */
  pillType: typeof PillType = PillType;

  constructor() {}

  ngOnInit(): void {}
}
