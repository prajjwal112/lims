import { Component, Input } from '@angular/core';

import { PROGRESSCOLOR } from '../common-data-type';

@Component({
  selector: 'app-field-gauge',
  templateUrl: './field-gauge.component.html',
  styleUrls: ['./field-gauge.component.scss'],
})
export class FieldGaugeComponent {
  @Input() value = 0;
  @Input() width = 54;
  @Input() height = 54;

  public readonly progressColor = PROGRESSCOLOR;
}
