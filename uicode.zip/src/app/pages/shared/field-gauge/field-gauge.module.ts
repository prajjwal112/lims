import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GaugesModule } from '@progress/kendo-angular-gauges';

import { FieldGaugeComponent } from './field-gauge.component';

@NgModule({
  declarations: [FieldGaugeComponent],
  imports: [CommonModule, GaugesModule],
  exports: [FieldGaugeComponent],
})
export class FieldGaugeModule {}
