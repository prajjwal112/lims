import { Status } from './status';
import { CamundaServerVariable } from './camunda-variable';

import type { IdNamePair } from './id-name-pair';
import type { UserFilterItemResponse } from '../users/shared/user';
import type { IsoDate, Integer } from '../../core/app-settings';

export enum TaskInputType {
  Basic,
  Date,
  Select,
}

export enum TaskFormInputType {
  // eslint-disable-next-line id-blacklist
  Boolean = 'boolean',
  Date = 'date',
  Numeric = 'numeric',
  Textarea = 'textarea',
  Text = 'text',
}

export const DISPLAY_TYPE_TO_LOGIC_TYPE = {
  [TaskFormInputType.Boolean]: 'BOOLEAN',
  [TaskFormInputType.Date]: 'DATE',
  [TaskFormInputType.Numeric]: 'INTEGER',
  [TaskFormInputType.Textarea]: 'STRING',
  [TaskFormInputType.Text]: 'STRING',
} as const;

export interface BasicTaskFormInput {
  type: TaskFormInputType;
  name: string;
  displayName: string;
  sequence: Integer;
  mandatory: boolean;
  defaultValue?: string;
}

export interface DateTaskFormInput extends BasicTaskFormInput {
  type: TaskFormInputType.Date;
  defaultToCurrentDate: boolean;
}

export interface SelectTaskFormInput extends BasicTaskFormInput {
  type: TaskFormInputType.Text | TaskFormInputType.Numeric;
  multiple: boolean;
  items: string[];
}

export interface TaskFormInput {
  basics?: BasicTaskFormInput[];
  dates?: DateTaskFormInput[];
  selects?: SelectTaskFormInput[];
}

export type WorkflowTaskInput = (BasicTaskFormInput | SelectTaskFormInput | DateTaskFormInput) & { taskInputType: TaskInputType };

export interface TaskDetail {
  taskInstanceReferenceId: Integer;
  id: string;
  name: string;
  priority: Integer;
  status: Status;
  dueDate?: IsoDate;
  completeDate?: IsoDate;
  processDefinitionName: string;
  assignees: UserFilterItemResponse[];
  groupAssignees: IdNamePair[];
  projects: IdNamePair[];
  taskVariables?: {
    [CamundaServerVariable.QueueTimeHours]?: Integer;
    [CamundaServerVariable.ExecutionTimeHours]?: Integer;
    [CamundaServerVariable.OverrideBusinessHours]?: boolean;
    [CamundaServerVariable.Endpoint]?: string;
    [CamundaServerVariable.EndpointDescription]?: string;
    [CamundaServerVariable.EndpointLabel]?: string;
    [CamundaServerVariable.TaskInput]?: string;
  };
  processInstanceVariables?: Record<string, unknown>;
  backingEntity?: {
    type: string;
    identifiers: string[];
    label?: string;
    connectionInformation: {
      endpoint?: string;
    };
  };
}

export interface FormattedBackingEntity {
  identifier: string;
  endpoint?: string;
}

type TaskDetailForStatus = { id: string; status: Status };

export const isStatusInactive = (taskDetail?: TaskDetailForStatus): boolean => {
  return !isStatusActive(taskDetail);
};

export const isStatusActive = (taskDetail?: TaskDetailForStatus): boolean => {
  if (!taskDetail) {
    return false;
  }

  const status = taskDetail.status;
  return status === Status.Todo || status === Status.InProgress || (taskDetail.id && status === Status.Blocked);
};
