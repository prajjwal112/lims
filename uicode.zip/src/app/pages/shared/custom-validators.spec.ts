import { FormControl, ValidationErrors } from '@angular/forms';

import { CustomValidators } from './custom-validators';

describe('CustomValidators', () => {
  describe('not blank validator', () => {
    const ERROR: Readonly<ValidationErrors> = Object.freeze({ whitespace: true });

    it('should be valid when string value is not blank', () => {
      expect(CustomValidators.notBlank(new FormControl('ABCD'))).toBeNull();
    });

    it('should be valid when array value is not blank', () => {
      expect(CustomValidators.notBlank(new FormControl(['A', 'B', 'C', 'D']))).toBeNull();
    });

    it('should be invalid when control value is falsy', () => {
      expect(CustomValidators.notBlank(new FormControl(''))).toEqual(ERROR);
    });

    it('should be invalid when array value is empty array', () => {
      expect(CustomValidators.notBlank(new FormControl([]))).toEqual(ERROR);
    });

    it('should be invalid when array value only contains blank/falsy values', () => {
      expect(CustomValidators.notBlank(new FormControl([null, undefined, '      ', '', '\t']))).toEqual(ERROR);
    });
  });

  describe('no `tf_` prefix', () => {
    const ERROR: Readonly<ValidationErrors> = Object.freeze({ prefix: true });

    it('should not allow tf_ prefix', () => {
      expect(CustomValidators.noTFPrefix(new FormControl('tf_name'))).toEqual(ERROR);
    });

    it('should allow tf_ within the string', () => {
      expect(CustomValidators.noTFPrefix(new FormControl('name_tf_value'))).toEqual(null);
    });
  });

  describe('numeric lines only validator', () => {
    const ERROR: Readonly<ValidationErrors> = Object.freeze({ nonnumericLine: true });

    it('should be valid when control value is falsy', () => {
      expect(CustomValidators.numericLinesOnly(new FormControl(''))).toBeNull();
    });

    it('should be valid when string value contains all numeric values', () => {
      expect(CustomValidators.numericLinesOnly(new FormControl('1\n2\n3'))).toBeNull();
    });

    it('should be valid when array value contains all numeric values', () => {
      expect(CustomValidators.numericLinesOnly(new FormControl(['1', '2', '3', '444']))).toBeNull();
    });

    it('should be invalid when string value contains nonnumeric value', () => {
      expect(CustomValidators.numericLinesOnly(new FormControl('1\n2\nabc\n3'))).toEqual(ERROR);
    });

    it('should be invalid when array value contains nonnumeric value', () => {
      expect(CustomValidators.numericLinesOnly(new FormControl(['1', '2', '3', 'abcd']))).toEqual(ERROR);
    });
  });

  describe('max characters per line validator', () => {
    const ERROR: Readonly<ValidationErrors> = Object.freeze({ maxCharacters: true });
    const limit = 4;
    it('should be invalid when 5 characters entered on single line', () => {
      expect(CustomValidators.maxCharactersPerLine(limit)(new FormControl('a long value'))).toEqual(ERROR);
    });

    it('should be invalid when 5 characters entered on second line', () => {
      expect(CustomValidators.maxCharactersPerLine(limit)(new FormControl('test\ntesting\ntest'))).toEqual(ERROR);
    });

    it('should be invalid when 5 characters entered on multiple lines', () => {
      expect(CustomValidators.maxCharactersPerLine(limit)(new FormControl('testing\ntesting\ntesting'))).toEqual(ERROR);
    });

    it('should be valid when up to 4 characters are entered on any line', () => {
      expect(CustomValidators.maxCharactersPerLine(limit)(new FormControl('test\ntest\ntest'))).toEqual(null);
    });
  });

  describe('not contain object store keywords', () => {
    it('should be invalid when containing a keyword reserved for tenant', () => {
      const ERROR: Readonly<ValidationErrors> = Object.freeze({ hasObjectStoreKeyword: true });

      expect(CustomValidators.notContainObjectStoreKeywords(new FormControl('tf-tenant'))).toEqual(ERROR);
    });

    it('should be invalid when containing a keyword reserved for global', () => {
      const ERROR: Readonly<ValidationErrors> = Object.freeze({ hasObjectStoreKeyword: true });

      expect(CustomValidators.notContainObjectStoreKeywords(new FormControl('tf-global-tenant'))).toEqual(ERROR);
    });

    it('should be invalid when containing a keyword reserved for task template', () => {
      const ERROR: Readonly<ValidationErrors> = Object.freeze({ hasObjectStoreKeyword: true });

      expect(CustomValidators.notContainObjectStoreKeywords(new FormControl('tf-task-template'))).toEqual(ERROR);
    });

    it('should be invalid when containing a keyword reserved for workflow template', () => {
      const ERROR: Readonly<ValidationErrors> = Object.freeze({ hasObjectStoreKeyword: true });

      expect(CustomValidators.notContainObjectStoreKeywords(new FormControl('tf-workflow-definition-template'))).toEqual(ERROR);
    });

    it('should be valid when not containing any reserved keyword', () => {
      expect(CustomValidators.notContainObjectStoreKeywords(new FormControl('valid-keyword'))).toEqual(null);
    });
  });

  describe('not contain special characters', () => {
    it('should be invalid when string value contain special characters', () => {
      expect(CustomValidators.disallowSpecialCharactersPattern.test('@ABC')).toBeFalsy();
    });

    it('should be invalid when string starts with numbers', () => {
      expect(CustomValidators.disallowSpecialCharactersPattern.test('123ABC')).toBeFalsy();
    });

    it('should be valid when string ends with whitespaces', () => {
      expect(CustomValidators.disallowSpecialCharactersPattern.test('ABC  ')).toBeTruthy();
    });

    it('should be valid when string contains whitespaces in between', () => {
      expect(CustomValidators.disallowSpecialCharactersPattern.test('ABC DEF')).toBeTruthy();
    });

    it('should be invalid when string contains a tabspace between words', () => {
      expect(CustomValidators.disallowSpecialCharactersPattern.test('AB\tC')).toBeFalsy();
    });

    it('should be valid when string contains a tabspace at the beginning', () => {
      expect(CustomValidators.disallowSpecialCharactersPattern.test('\tABC')).toBeTruthy();
    });

    it('should be valid when string contains a tabspace at the end', () => {
      expect(CustomValidators.disallowSpecialCharactersPattern.test('ABC\t')).toBeTruthy();
    });
  });
});
