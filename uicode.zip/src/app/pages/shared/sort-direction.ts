import { SortDescriptor } from '@progress/kendo-data-query';

/**
 * Sort directions
 */
export enum SortDirection {
  Ascending = 'asc',
  Descending = 'desc',
}

export type CapitalizedSortDirection = 'ASC' | 'DESC';

declare global {
  // eslint-disable-next-line id-blacklist
  export interface String {
    toUpperCase(this: SortDescriptor['dir']): CapitalizedSortDirection;
  }
}
