import { TestBed } from '@angular/core/testing';

import { PublishAccessGuard } from './publish-access.guard';
import { RouterTestingModule } from '@angular/router/testing';

describe('PublishAccessGuard', () => {
  let guard: PublishAccessGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
    });
    guard = TestBed.inject(PublishAccessGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
