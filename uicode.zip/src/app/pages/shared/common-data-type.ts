export const PROGRESSCOLOR = '#1e8ae7';
export const DEFAULT_SKIP = 0;
export const DEFAULT_TOP = 15;

export interface ListColumns {
  name: string;
  title: string;
  sortable: boolean;
}

export interface ConfirmedStatus {
  status: boolean;
  message: string;
  errorCode?: number;
}

export interface ManageItemsRequest {
  userIds: number[];
  updateIds: number[];
  newName?: string;
}
