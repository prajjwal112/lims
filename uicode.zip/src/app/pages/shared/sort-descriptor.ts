import { CapitalizedSortDirection } from './sort-direction';
import { SortDescriptor as KendoSortDescriptor } from '@progress/kendo-data-query';

export type SortDescriptor = { sort: string; order: CapitalizedSortDirection };

export const mapKendoToWorkflow = (kendoSortDescriptors: KendoSortDescriptor[]): SortDescriptor[] => {
  return kendoSortDescriptors.map((kendoSortDescriptor: KendoSortDescriptor) => ({
    sort: kendoSortDescriptor.field,
    order: kendoSortDescriptor.dir.toUpperCase(),
  }));
};
