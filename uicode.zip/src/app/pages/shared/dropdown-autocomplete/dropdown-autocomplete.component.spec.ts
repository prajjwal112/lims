import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { DropDownAutoCompleteComponent } from './dropdown-autocomplete.component';

describe('DropDownAutoCompleteComponent', () => {
  let component: DropDownAutoCompleteComponent;
  let fixture: ComponentFixture<DropDownAutoCompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DropDownAutoCompleteComponent],
      imports: [DropDownsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropDownAutoCompleteComponent);
    component = fixture.componentInstance;
    component.placeholder = 'Test';
    component.arrayKey = 'name';
    component.data = [
      {
        processDefinitionId: 'Process_1:33:ff404aff-7652-11e9-8c25-8ed52e04f07e',
        processInstanceId: '046e9640-7653-11e9-8c25-8ed52e04f07e',
        projects: null,
        parentTaskId: null,
        description: null,
        workflowName: null,
        priority: 50,
        duration: '219506',
        taskDefinitionKey: 'Task_0orrebb',
        dueDate: '2019-07-20T16:12:15.259+0000',
        callStatus: null,
        name: 'make experiment',
        tenantId: 'WORKFLOWD',
        startTime: '2019-05-14T16:08:35.753+0000',
        id: '8721e9ed-7662-11e9-8c25-8ed52e04f07e',
        assignee: 'EM16',
        endTime: null,
        status: 'Blocked',
      },
      {
        processDefinitionId: 'Process_1:33:ff404aff-7652-11e9-8c25-8ed52e04f07e',
        processInstanceId: '046e9640-7653-11e9-8c25-8ed52e04f07e',
        projects: null,
        parentTaskId: null,
        description: null,
        workflowName: null,
        priority: 50,
        duration: '219506',
        taskDefinitionKey: 'Task_0orrebb',
        dueDate: '2019-07-20T16:12:15.259+0000',
        callStatus: null,
        name: 'make experiment',
        tenantId: 'WORKFLOWD',
        startTime: '2019-05-14T16:08:35.753+0000',
        id: '8721e9ed-7662-11e9-8c25-8ed52e04f07e',
        assignee: 'EM16',
        endTime: null,
        status: 'Blocked',
      },
    ];
    spyOn(component.selectEvent, 'emit');

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should dedupe results', () => {
    component.onHandleFilter('make');

    expect(component.dataClone.length).toBe(1);
  });
});
