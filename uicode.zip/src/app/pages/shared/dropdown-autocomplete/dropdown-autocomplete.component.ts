import { Component, Input, Output, EventEmitter, ViewChild, AfterViewInit } from '@angular/core';
import { AutoCompleteComponent } from '@progress/kendo-angular-dropdowns';
import { SearchTextService } from '../search-text.service';

const FILTER_MINIMUM_LENGTH = 1;

@Component({
  selector: 'app-dropdown-autocomplete',
  templateUrl: './dropdown-autocomplete.component.html',
  styleUrls: ['./dropdown-autocomplete.component.scss'],
})
export class DropDownAutoCompleteComponent implements AfterViewInit {
  @Input() placeholder: string;
  @Input() arrayKey: string;
  @Input() data: any[] = [];
  @Input() value: string;
  @Input() suggest = true;
  @Output() selectEvent = new EventEmitter<string>();

  public dataClone: any[] = [];
  @ViewChild('autocomplete') private autocomplete: AutoCompleteComponent;

  constructor(private readonly searchTextService: SearchTextService) {}
  ngAfterViewInit(): void {
    this.searchTextService.getText().subscribe({
      next: (text: string) => {
        if (text) {
          this.autocomplete.reset();
        }
      },
    });
  }

  onHandleFilter(value: string): void {
    if (value.trim().length > FILTER_MINIMUM_LENGTH && this.suggest) {
      this.dataClone = this.data.reduce((items: any[], item) => {
        const found = item[this.arrayKey]?.toLowerCase()?.indexOf(value.trim().toLowerCase()) !== -1;
        if (!found || items.some((x) => x[this.arrayKey] === item[this.arrayKey])) {
          return [...items];
        }
        return [...items, item];
      }, []);
    } else {
      this.autocomplete.toggle(false);
    }
  }

  onValueChange(event: string): void {
    this.selectEvent.emit(event);
  }
}
