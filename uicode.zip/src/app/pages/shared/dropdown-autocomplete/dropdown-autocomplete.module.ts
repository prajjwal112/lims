import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';

import { DropDownAutoCompleteComponent } from './dropdown-autocomplete.component';

@NgModule({
  declarations: [DropDownAutoCompleteComponent],
  imports: [CommonModule, DropDownsModule],
  exports: [DropDownAutoCompleteComponent]
})
export class DropDownAutoCompleteModule {}
