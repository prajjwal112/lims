import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { KmdModalService } from 'gds-atom-components';
import { distinctUntilChanged, delay } from 'rxjs/operators';
import { PlatformHeaderData, LibPlatformHeaderDataService } from '@dsp/lib-platform-header-data';
import { environment } from '../environments/environment';
import { AuthService } from './auth.service';
import { ErrorService } from './error.service';
import { ModalId } from './pages/shared/modal-id';
import type { OnInit } from '@angular/core';
import type { PfsRoute } from '@dsp/platform-components';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  public readonly routes: Readonly<PfsRoute[]> = [
    { name: 'Home', path: '/my-tasks', icon: 'gds-icon-home-mono', default: true },
    { name: 'Workflow Mgmt.', path: '/workflow-definitions', icon: 'workflow-icon-workflow-mono' },
    { name: 'Tasks', path: '/tasks', icon: 'gds-icon-clipboard-mono' },
    { name: 'Projects', path: '/projects', icon: 'gds-icon-techdocumentation-mono' },
    {
      name: 'User Mgmt.',
      path: '',
      default: false,
      icon: 'workflow-icon-users-mono',
      links: [
        {
          path: '/users',
          name: 'Users',
          default: false,
          external: false,
        },
        {
          path: '/groups',
          name: 'Groups',
          default: false,
          external: false,
        },
        {
          path: '/roles',
          name: 'Roles',
          default: false,
          external: false,
        },
      ],
    },
    {
      name: 'Organization Settings',
      path: '/organization-settings',
      icon: 'gds-icon-settings-mono',
      settings: true,
    },
  ];
  public readonly modalId = ModalId;
  public readonly redirectToLogin = AppComponent.redirectToLogin.bind(this);
  public adminUser = false;

  constructor(
    private readonly headerDataService: LibPlatformHeaderDataService,
    private readonly kmdModalService: KmdModalService,
    private readonly authService: AuthService,
    private readonly errorService: ErrorService,
    private readonly router: Router
  ) {
    this.headerDataService.headerServiceURL = environment.loginService;
  }

  private static redirectToLogin(): void {
    location.href = environment.loginHome;
  }

  ngOnInit(): void {
    this.headerDataService.headerDataObservable.subscribe({
      next: (headerData: PlatformHeaderData) => {
        if (!headerData?.sessionData) {
          this.displayTimeoutError();
        } else {
          this.hideTimeoutError();
          this.errorService.addError(false);
          this.authService.sessionData = headerData.sessionData;
          this.authService.adminUser = headerData.sessionData.tfsPlatformIsTenantAdministrator;
        }
      },
      error: () => {
        this.displayTimeoutError();
      },
    });

    this.authService.subscribeToAdminUser().subscribe({
      next: (admin: boolean) => {
        this.adminUser = admin;
      },
    });

    this.authService
      .subscribeToRedirectUrl()
      .pipe(
        distinctUntilChanged((first, second) => first === second),
        delay(500) // Without this, navigation fails on app first load
      )
      .subscribe({
        next: (url: string) => {
          this.router.navigate([url]);
        },
      });

    this.errorService.getError().subscribe({
      next: (hasError: boolean) => {
        if (hasError) {
          this.displayTimeoutError();
        }
      },
    });
  }

  private displayTimeoutError(): void {
    this.kmdModalService.open(ModalId.SessionTimeout);
  }

  private hideTimeoutError(): void {
    this.kmdModalService.close(ModalId.SessionTimeout);
  }
}
