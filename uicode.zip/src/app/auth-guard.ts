import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthService } from './auth.service';
import { ErrorService } from './error.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly authService: AuthService, private readonly errorService: ErrorService) {}
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const url: string = state.url;

    return this.checkLogin(url);
  }

  private checkLogin(url: string): boolean {
    if (this.authService.loggedIn) {
      return true;
    }
    this.errorService.addError(true);
    this.authService.redirectUrl = url;

    return false;
  }
}
