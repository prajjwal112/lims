module.exports = {
    "env": {
        "browser": true,
        "es6": true,
        "node": true,
        "jasmine": true
    },
    "parser": "@typescript-eslint/parser",
    "parserOptions": {
      "project": "tsconfig.json",
      "sourceType": "module",
    },
    "extends": [
        "eslint:recommended",
        "plugin:@typescript-eslint/recommended",
        "plugin:@angular-eslint/recommended",
        "plugin:jasmine/recommended",
        "plugin:import/warnings",
        "plugin:import/typescript",
        "prettier/@typescript-eslint",
    ],
    "plugins": [
        "@typescript-eslint",
        "import",
        "jasmine",
        "sort-class-members"
    ],
    "rules": {
        "@angular-eslint/no-output-native": "off",
        "@typescript-eslint/explicit-function-return-type": "error",
        "@typescript-eslint/naming-convention": [
          "error",
          {
            "selector": "default",
            "format": ["camelCase"],
            "filter": {
              "regex": "[- ]",
              "match": false
            }
          },
          {
            "selector": "enumMember",
            "format": ["PascalCase"]
          },
          {
            "selector": "parameter",
            "format": ["camelCase"],
            "leadingUnderscore": "allow"
          },
          {
            "selector": "typeLike",
            "format": ["PascalCase"]
          },
          {
            "selector": "variable",
            "format": ["camelCase", "UPPER_CASE"]
          },
        ],
        "@typescript-eslint/no-floating-promises": "off",
        "@typescript-eslint/no-unused-vars": ["error", { "ignoreRestSiblings": true }],
        "@typescript-eslint/unbound-method": "warn",
        "sort-class-members/sort-class-members": [2, {
          "order": [
            "[static-properties]",
            "[properties]",
            "[conventional-private-properties]",
            "constructor",
            "[static-methods]",
            "[methods]",
            "[conventional-private-methods]"
          ],
          "accessorPairPositioning": "getThenSet",
        }],
        "camelcase": "off",
        "class-methods-use-this": ["warn"],
        "max-len": [
          "error",
          {
            "ignorePattern": "^import [^,]+ from |^export | implements",
            "code": 160
          }
        ],
        "no-console": ["error", { allow: ["warn", "error"] }],
    },
    "settings": {}
};
